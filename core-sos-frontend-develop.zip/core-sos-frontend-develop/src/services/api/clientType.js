import Axios from "axios";
import endpoints from "./index";

const getAllClientTypes = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.clientTypes.getAllClientTypes,
    config
  );
  return response.data;
};

const addClientType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.clientTypes.addClientType,
    body,
    config
  );
  return response.data;
};

const updateClientType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.clientTypes.updateClientType,
    body,
    config
  );
  return response.data;
};

const deleteClientType = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.clientTypes.deleteClientType(id),
    config
  );
  return response.data;
};

export { addClientType, deleteClientType, getAllClientTypes, updateClientType };

