import Axios from "axios";
import endpoints from "./index";

const getAllProviders = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.providers.getAllProviders, config);
  return response.data;
};

const updateProvider = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.providers.updateProvider,
    body,
    config
  );
  return response.data;
};

const deleteProvider = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.providers.deleteProvider(id),
    config
  );
  return response.data;
};

const addProvider = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.providers.addProvider,
    body,
    config
  );
  return response.data;
};

export { addProvider, deleteProvider, getAllProviders, updateProvider };

