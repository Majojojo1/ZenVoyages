import Axios from "axios";
import endpoints from "./index";

const getAllThirdParties = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(
    endpoints.thirdParties.getAllThirdParties,
    config
  );
  return response.data;
};

const addThirdParty = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.thirdParties.addThirdParty,
    body,
    config
  );
  return response.data;
};

const updateThirdParty = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.thirdParties.updateThirdParty,
    body,
    config
  );
  return response.data;
};

const deleteThirdParty = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.thirdParties.deleteThirdParty(id),
    config
  );
  return response.data;
};

export {
    addThirdParty, deleteThirdParty, getAllThirdParties, updateThirdParty
};

