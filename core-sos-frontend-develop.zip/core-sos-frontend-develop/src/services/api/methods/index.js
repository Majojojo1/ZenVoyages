import Axios from "axios";
import Cookie from "js-cookie";

const COOKIE_USER = parseInt(Cookie.get("idUsuario"));

const DATE_CREATED_AT = "2022-12-11T05:00:00.000+00:00";

const SOURCE = Axios.CancelToken.source();

const config = {
  headers: {
    accept: "*/*",
    "Content-Type": "application/json",
    Authorization: sessionStorage.getItem("token"),
  },
  cancelToken: SOURCE.token,
};

const configFile = {
  headers: {
    accept: "*/*",
    "Content-Type": "multipart/form-data",
    Authorization: sessionStorage.getItem("token"),
  },
};

const getWithParameters = async (endpoint, params) => {
  const configWparams = {
    headers: {
      ...params,
    },
    data: params,
  };

  const response = await Axios.get(endpoint, { configWparams });

  return response.data;
};

const getAll = async (endpoint) => {
  const response = await Axios.get(endpoint, config);
  return response.data;
};

const getItemById = async (endpoint, id) => {
  const response = await Axios.get(endpoint(id), config);
  return response.data;
};

const getItemWithBody = async (endpoint, body) => {
  const response = await Axios.get(endpoint, body, config);
  return response.data;
};

// Now only works in ListSchedule.jsx
const getItemBetweenDates = async (endpoint, start, end) => {
  const response = await Axios.get(endpoint(start, end), config);
  return response.data;
};

const addItem = async (endpoint, body) => {
  const response = await Axios.post(endpoint, body, config);
  return response.data;
};

const updateItem = async (endpoint, body) => {
  const response = await Axios.put(endpoint, body, config);
  return response.data;
};

const updateItemById = async (endpoint, id, body) => {
  const response = await Axios.put(endpoint(id), body, config);
  return response.data;
};

const deleteItem = async (endpoint, id) => {
  const response = await Axios.delete(endpoint(id), config);
  return response.data;
};

const uploadFile = async (endpoint, body) => {
  const response = await Axios.post(endpoint, body, configFile);
  return response.data;
};

export {
  COOKIE_USER,
  DATE_CREATED_AT, addItem, deleteItem, getAll, getItemBetweenDates, getItemById,
  getItemWithBody, getWithParameters, updateItem,
  updateItemById, uploadFile
};

