import Axios from "axios";
import endpoints from "./index";

const getAllBillingTypes = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.billingTypes.getAllBillingTypes,
    config
  );
  return response.data;
};

const addBillingType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.billingTypes.addBillingType,
    body,
    config
  );
  return response.data;
};

const updateBillingType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.billingTypes.updateBillingType,
    body,
    config
  );
  return response.data;
};

const deleteBillingType = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.billingTypes.deleteBillingType(id),
    config
  );
  return response.data;
};

const getBillingById = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.billingTypes.getBillingTypeById(id),
    config
  );
  return response.data;
};

export {
  addBillingType, deleteBillingType, getAllBillingTypes, getBillingById, updateBillingType
};

