import Axios from "axios";
import endpoints from "./index";

const CONFIG = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

const excelListPrices = async ()=>{
    const response = await Axios.get(endpoints.listPriceClient.downloadExcelListPriceClient, CONFIG);
    return response.data;
}

export {
    excelListPrices
};
