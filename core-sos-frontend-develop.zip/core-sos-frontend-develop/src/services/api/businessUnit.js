import Axios from "axios";
import endpoints from "./index";

const getAllBusinessUnits = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.businessUnit.getAllBusinessUnits,
    config
  );
  return response.data;
};

const getAllMarketCountry = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.businessUnit.getAllMarketCountry,
    config
  );
  return response.data;
};

const getMarketCountryByUnit = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.businessUnit.getMarketCountryByUnit(id),
    config
  );
  return response.data;
};

const getUnitByMarket = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.businessUnit.getBusinessUnitByMarket(id),
    config
  );
  return response.data;
};

const getUnitsByClient = async (clientId) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.businessUnit.getUnitBusinessByClient(clientId),
    config
  );
  return response.data;
};

const addBusinessUnit = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.businessUnit.addBusinessUnit,
    body,
    config
  );
  return response.data;
};

const addMarketCountryToUnit = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.businessUnit.addMarketCountryToUnit,
    body,
    config
  );
  return response.data;
};

const updateBusinessUnit = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.businessUnit.updateBusinessUnit,
    body,
    config
  );
  return response.data;
};

const updateMarketCountryToUnit = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.businessUnit.updateMarketCountryToUnit,
    body,
    config
  );
  return response.data;
};

const deleteBusinessUnit = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.businessUnit.deleteBusinessUnit(id),
    config
  );
  return response.data;
};

const deleteMarketCountryFromUnit = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.businessUnit.deleteMarketCountryFromUnit(id),
    config
  );
  return response.data;
};

export {
    addBusinessUnit,
    addMarketCountryToUnit, deleteBusinessUnit,
    deleteMarketCountryFromUnit, getAllBusinessUnits, getAllMarketCountry,
    getMarketCountryByUnit, getUnitByMarket, getUnitsByClient, updateBusinessUnit,
    updateMarketCountryToUnit
};

