import Axios from "axios";
import endpoints from "./index";

const getAllBranchOffices = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.branchOffices.getAllBranchOffices,
    config
  );
  return response.data;
};

const addBranchOffice = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.branchOffices.addBranchOffice,
    body,
    config
  );
  return response.data;
};

export { addBranchOffice, getAllBranchOffices };

