import Axios from "axios";
import endpoints from "./index";

const getMailById = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.mail.getMailById(id), config);
  return response.data;
};

const getsMails = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.mail.getAllMails, config);
  return response.data;
};

const addMail = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.mail.addMail, body, config);
  return response.data;
};

const updateMail = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.mail.updateMail, body, config);
  return response.data;
};

const sendMail = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  // TODO: Cambiar a mail normal
  const response = await Axios.post(endpoints.mail.sendMailTest, body, config);
  return response.data;
};

export { addMail, getMailById, getsMails, sendMail, updateMail };

