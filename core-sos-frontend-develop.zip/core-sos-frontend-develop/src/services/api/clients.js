import Axios from "axios";
import endpoints from "./index";

const getAllClients = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.clients.getAllClients, config);
  return response.data;
};

const addClient = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.clients.addClient, body, config);
  return response.data;
};

const deleteClient = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.clients.deleteClient(id),
    config
  );
  return response.data;
};

const updateClient = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.clients.updateClient,
    body,
    config
  );
  return response.data;
};

const getClienteUnidadNegocioByCliente = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.clients.getClienteUnidadNegocioByIdCliente(id),
    config
  );
  return response.data;
};



export { addClient, deleteClient, getAllClients, getClienteUnidadNegocioByCliente, updateClient };

