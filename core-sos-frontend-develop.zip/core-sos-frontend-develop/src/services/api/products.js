import Axios from "axios";
import endpoints from "./index";

const CONFIG = {
  headers: {
    accept: "*/*",
    "Content-Type": "application/json",
    Authorization: sessionStorage.getItem("token"),
  },
};
const addProduct = async (body) => {
  const response = await Axios.post(
    endpoints.products.addProduct,
    body,
    CONFIG,
  );
  return response.data;
};

const excelProducts = async () => {
  const response = await Axios.get(endpoints.products.exportJson, CONFIG);
  return response.data;
};

const getAllProducts = async () => {
  
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.products.getAllProduct, config);
  return response.data;
};





export { addProduct, excelProducts, getAllProducts };
