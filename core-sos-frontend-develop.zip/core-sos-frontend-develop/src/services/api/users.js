import Axios from "axios";
import Cookie from "js-cookie";
import endpoints from "./index";

const addUser = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.users.addUser, body, config);
  return response.data;
};

const getAllUsers = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.users.getAllUsers, config);
  return response.data;
};
const tercerosGetByUserAsing = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.users.tercerosGetByUserAsing,
    config,
  );
  return response.data;
};
const empleadoGetByUserAsing = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.users.empleadoGetByUserAsing,
    config,
  );
  return response.data;
};

const getUserInfo = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.users.getUserById(id), config);
  return response.data;
};

const getUserNoti = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.users.notifyGetAll,
    config,
  );
  return response.data;
};

const getNotifiByUser = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.users.notifiGetUser(id),
    config,
  );
  return response.data;
};

const updateUser = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.users.updateUser, body, config);
  return response.data;
};

const updateAndCreateNotify = async (body) => {
  console.log("data users", body);
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.users.addNotify, body, config);
  return response.data;
};

const getProfileImage = async () => {
  const bodyFind = {
    idOrigen: Cookie.get("idUsuario"),
    idTipoOrigenArchivo: 4,
  };
  let files = [];
  let bodyDownload = {};
  let extensionArchivo = "";
  let data = {};
  try{
    const response = await Axios.postForm(
      endpoints.UploadFiles.findArchivosById,
      bodyFind,
    );
    files = response.data.map((file) => {
      return {
        name: file,
        url: file,
      };
    });
    bodyDownload = { file: files[files.length - 1]?.name || "file" };
    extensionArchivo = (files[files.length - 1]?.name || "file").substring(
      (files[files.length - 1]?.name || "file").lastIndexOf("."),
    );
    const responseImageDownload = await Axios.postForm(
      endpoints.UploadFiles.download,
      bodyDownload,
    );
    data = {
      name: files[files.length - 1].name,
      ext: extensionArchivo.replace(".", ""),
      image: responseImageDownload.data,
    };
  }catch(error){
    console.log('error', error);
  }
  return data;
};

export {
    addUser, empleadoGetByUserAsing, getUserNoti, getNotifiByUser, getAllUsers, getProfileImage, getUserInfo, updateAndCreateNotify, tercerosGetByUserAsing, updateUser
};

