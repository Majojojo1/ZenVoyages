import Axios from 'axios';
import { addPermisoModulo, addRole,
    deleteRole, getPerssimionModuleByUser, updateRole } from '../roles'; 
import endpoints from '../index';
import 'jest-localstorage-mock';

jest.mock('axios');

describe('getPerssimionModuleByUser', () => {
  it('should return a list of permissions and modules for a given user ID', async () => {
   
    const userId = 225;
    const expectedData = [
      { permission: 'Administrador', module: 'modulo 1' },
      { permission: 'Tecnico', module: 'modulo 2' },
    ];
    const expectedResponse = { data: expectedData };
    const expectedConfig = {
      headers: {
        accept: '*/*',
        'Content-Type': 'application/json',
        Authorization: 'mockToken', 
      },
    };

    Axios.get.mockResolvedValueOnce(expectedResponse);
    jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce('mockToken');

    const result = await getPerssimionModuleByUser(userId);

    expect(result).toEqual(expectedData);
    expect(Axios.get).toHaveBeenCalledWith(
      endpoints.roles.getAllRolPermisosModulosByUser(userId),
      expectedConfig
    );
    expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
  });

  it('should handle errors when fetching permissions and modules', async () => {
    
    const userId = 225;
    const errorMessage = 'Failed to fetch permissions and modules';
    const expectedConfig = {
      headers: {
        accept: '*/*',
        'Content-Type': 'application/json',
        Authorization: 'mockToken', 
      },
    };

    Axios.get.mockRejectedValueOnce(new Error(errorMessage));
    jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce('mockToken');

    try {
      await getPerssimionModuleByUser(userId);
      
      expect(true).toBe(false);
    } catch (error) {
      
      expect(error.message).toEqual(errorMessage);
      expect(Axios.get).toHaveBeenCalledWith(
        endpoints.roles.getAllRolPermisosModulosByUser(userId),
        expectedConfig
      );
      expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
    }
  });
});



describe('addRole', () => {
    it('should add a role successfully', async () => {
   
      const mockToken = 'mockToken';
      const requestBody = { roleName: 'Admin' };
      const expectedResponse = { data: 'Role added successfully' };
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.post.mockResolvedValueOnce(expectedResponse);
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      const result = await addRole(requestBody);
  
      expect(result).toEqual(expectedResponse.data);
      expect(Axios.post).toHaveBeenCalledWith(endpoints.roles.addRole, requestBody, expectedConfig);
      expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
    });
  
    it('should handle errors when adding a role', async () => {

      const mockToken = 'mockToken';
      const requestBody = { roleName: 'Admin' };
      const errorMessage = 'Failed to add role';
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.post.mockRejectedValueOnce(new Error(errorMessage));
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      try {
        await addRole(requestBody);
        
        expect(true).toBe(false);
      } catch (error) {
  
        expect(error.message).toEqual(errorMessage);
        expect(Axios.post).toHaveBeenCalledWith(endpoints.roles.addRole, requestBody, expectedConfig);
        expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
      }
    });
});



describe('deleteRole', () => {
    it('should delete a role successfully', async () => {
      
      const mockToken = 'mockToken';
      const roleId = 123;
      const expectedResponse = { data: 'Role deleted successfully' };
      const expectedConfig = {
        headers: {
          Authorization: mockToken,
        },
      };
  
      Axios.delete.mockResolvedValueOnce(expectedResponse);
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      const result = await deleteRole(roleId);
  
      expect(result).toEqual(expectedResponse.data);
      expect(Axios.delete).toHaveBeenCalledWith(endpoints.roles.deleteRole(roleId), expectedConfig);
      expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
    });
  
    it('should handle errors when deleting a role', async () => {
     
      const mockToken = 'mockToken';
      const roleId = 123;
      const errorMessage = 'Failed to delete role';
      const expectedConfig = {
        headers: {
          Authorization: mockToken,
        },
      };
  
      Axios.delete.mockRejectedValueOnce(new Error(errorMessage));
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      try {
        await deleteRole(roleId);
        
        expect(true).toBe(false);
      } catch (error) {
        // Assert
        expect(error.message).toEqual(errorMessage);
        expect(Axios.delete).toHaveBeenCalledWith(endpoints.roles.deleteRole(roleId), expectedConfig);
        expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
      }
    });
  });
  
  describe('updateRole', () => {
    it('should update a role successfully', async () => {
      
      const mockToken = 'mockToken';
      const requestBody = { roleId: 123, roleName: 'Admin' };
      const expectedResponse = { data: 'Role updated successfully' };
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.put.mockResolvedValueOnce(expectedResponse);
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      
      const result = await updateRole(requestBody);
  
      expect(result).toEqual(expectedResponse.data);
      expect(Axios.put).toHaveBeenCalledWith(endpoints.roles.updateRole, requestBody, expectedConfig);
      expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
    });
  
    it('should handle errors when updating a role', async () => {
    
      const mockToken = 'mockToken';
      const requestBody = { roleId: 123, roleName: 'Admin' };
      const errorMessage = 'Failed to update role';
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.put.mockRejectedValueOnce(new Error(errorMessage));
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      try {
        await updateRole(requestBody);
        
        expect(true).toBe(false);
      } catch (error) {

        expect(error.message).toEqual(errorMessage);
        expect(Axios.put).toHaveBeenCalledWith(endpoints.roles.updateRole, requestBody, expectedConfig);
        expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
      }
    });
});



describe('addPermisoModulo', () => {
    it('should add permission module successfully', async () => {
    
      const mockToken = 'mockToken';
      const requestBody = { permission: 'permission1', module: 'module1' };
      const expectedResponse = { data: 'Permission module added successfully' };
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.post.mockResolvedValueOnce(expectedResponse);
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      const result = await addPermisoModulo(requestBody);
  
      expect(result).toEqual(expectedResponse.data);
      expect(Axios.post).toHaveBeenCalledWith(endpoints.roles.addRolePermisoModulo, requestBody, expectedConfig);
      expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
    });
  
    it('should handle errors when adding permission module', async () => {
      
      const mockToken = 'mockToken';
      const requestBody = { permission: 'permission1', module: 'module1' };
      const errorMessage = 'Failed to add permission module';
      const expectedConfig = {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: mockToken,
        },
      };
  
      Axios.post.mockRejectedValueOnce(new Error(errorMessage));
      jest.spyOn(sessionStorage, 'getItem').mockReturnValueOnce(mockToken);
  
      try {
        await addPermisoModulo(requestBody);
        
        expect(true).toBe(false);
      } catch (error) {
        
        expect(error.message).toEqual(errorMessage);
        expect(Axios.post).toHaveBeenCalledWith(endpoints.roles.addRolePermisoModulo, requestBody, expectedConfig);
        expect(sessionStorage.getItem).toHaveBeenCalledWith('token');
      }
    });
});