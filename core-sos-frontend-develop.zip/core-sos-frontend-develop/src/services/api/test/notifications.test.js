import Axios from 'axios';
import Cookie from 'js-cookie';
import {  markAllAsRead,
          getAllNotifications,
          notificationsByUser,
          countNotificationsByUser,
          getCountNotificationsIcon, } 
    from '../notifications'; 
import endpoints from '../index';

jest.mock('axios');
jest.mock('js-cookie');

describe('markAllAsRead', () => {
  it('should mark all notifications as read for the user', async () => {
    
    Cookie.get.mockReturnValueOnce('mockUserID');

    const mockResponse = { data: 'mocked data' };
    Axios.get.mockResolvedValueOnce(mockResponse);

    const result = await markAllAsRead();

    expect(Cookie.get).toHaveBeenCalledWith('idUsuario');

    const expectedUrl = endpoints.notificationsTable.markAllAsRead('mockUserID');
    expect(Axios.get).toHaveBeenCalledWith(expectedUrl);

    expect(result).toEqual('mocked data');
  });

  it('should handle errors when marking all notifications as read', async () => {
   
    Cookie.get.mockReturnValueOnce('mockUserID');
  
    const errorMessage = 'Failed to mark notifications as read';
    Axios.get.mockRejectedValueOnce(new Error(errorMessage));
  
    try {
      const result = await markAllAsRead();
  
      expect(result).toBeUndefined();
    } catch (error) {
      
      expect(Cookie.get).toHaveBeenCalledWith('idUsuario');
  
      const expectedUrl = endpoints.notificationsTable.markAllAsRead('mockUserID');
      expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
  
      expect(error.message).toEqual(errorMessage);
    }
  });
});


describe('getAllNotifications', () => {
    it('should successfully retrieve all notifications', async () => {
    
      Cookie.get.mockReturnValueOnce('mockUserID');
  
      const expectedUrl = endpoints.notificationsTable.getAllNotificationsUserIcon({
        idUser: 'mockUserID',
        currentPage: 0,
        registersPerPage: 25,
      });
      const mockResponse = { data: 'mock notifications data' };
      Axios.get.mockResolvedValueOnce(mockResponse);
  
      const result = await getAllNotifications();
  
      expect(Cookie.get).toHaveBeenCalledWith('idUsuario');
  
      expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
  
      expect(result).toEqual(mockResponse.data);
    });
  
    it('should handle errors when retrieving notifications', async () => {

      Cookie.get.mockReturnValueOnce('mockUserID');
  
      const errorMessage = 'Failed to retrieve notifications';
      Axios.get.mockRejectedValueOnce(new Error(errorMessage));
  
      try {
        await getAllNotifications();
      
        expect(true).toBe(false);
      } catch (error) {
        
        expect(Cookie.get).toHaveBeenCalledWith('idUsuario');
  
        const expectedUrl = endpoints.notificationsTable.getAllNotificationsUserIcon({
          idUser: 'mockUserID',
          currentPage: 0,
          registersPerPage: 25,
        });
        expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
  
        expect(error.message).toEqual(errorMessage);
      }
    });
});


  describe('getCountNotificationsIcon', () => {
  it('should successfully retrieve the count of notifications', async () => {
    
    Cookie.get.mockReturnValueOnce('mockUserID');

    const expectedUrl = endpoints.notificationsTable.getCountNotificationsIcon({
      idUser: 'mockUserID',
    });
    const mockResponse = { data: 5 }; 
    Axios.get.mockResolvedValueOnce(mockResponse);

    const result = await getCountNotificationsIcon();

    expect(Cookie.get).toHaveBeenCalledWith('idUsuario');

    expect(Axios.get).toHaveBeenCalledWith(expectedUrl);

    expect(result).toEqual(mockResponse.data);
  });

  it('should handle errors when retrieving the count of notifications', async () => {
    
    Cookie.get.mockReturnValueOnce('mockUserID');

    const errorMessage = 'Failed to retrieve notification count';
    Axios.get.mockRejectedValueOnce(new Error(errorMessage));

    try {
      await getCountNotificationsIcon();
      
      expect(true).toBe(false);
    } catch (error) {
     
      expect(Cookie.get).toHaveBeenCalledWith('idUsuario');

      const expectedUrl = endpoints.notificationsTable.getCountNotificationsIcon({
        idUser: 'mockUserID',
      });
      expect(Axios.get).toHaveBeenCalledWith(expectedUrl);

      expect(error.message).toEqual(errorMessage);
    }
  });
});



describe('notificationsByUser', () => {
  it('should return a list of notifications when valid parameters are provided', async () => {
  
    const params = {
      dUser: 225,
      currentPage: 18,
      registersPerPage: 22,
    };
    const expectedData = [{ id: 1, message: 'Creación' }, { id: 2, message: 'Actualización' }];
    const expectedUrl = endpoints.notificationsTable.getAllNotificationsUser(params);
    Axios.get.mockResolvedValueOnce({ data: expectedData });

    const result = await notificationsByUser(params);

    expect(result).toEqual(expectedData);
    expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
  });

  it('should handle errors when retrieving notifications', async () => {
   
    const params = {
      idUser: 225,
      currentPage: 18,
      registersPerPage: 22,
    };
    const errorMessage = 'Failed to retrieve notifications';
    const expectedUrl = endpoints.notificationsTable.getAllNotificationsUser(params);
    Axios.get.mockRejectedValueOnce(new Error(errorMessage));

    try {
      await notificationsByUser(params);
   
      expect(true).toBe(false);
    } catch (error) {
     
      expect(error.message).toEqual(errorMessage);
      expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
    }
  });
});



describe('countNotificationsByUser', () => {
    it('should return a number when there are notifications', async () => {
   
      const expectedData = 5;
      const expectedUrl = endpoints.notificationsTable.getCountNotificationsPanel({
        idUser: '145', 
      });
  
      Axios.get.mockResolvedValueOnce({ data: expectedData });
      jest.spyOn(Cookie, 'get').mockReturnValueOnce('145');
  
      // Act
      const result = await countNotificationsByUser();
  
      
      expect(result).toBe(expectedData);
      expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
      expect(Cookie.get).toHaveBeenCalledWith('idUsuario');
    });
  
    it('should handle errors when retrieving notification count', async () => {
     
      const errorMessage = 'Failed to retrieve notification count';
      const expectedUrl = endpoints.notificationsTable.getCountNotificationsPanel({
        idUser: '145', 
      });
  
      Axios.get.mockRejectedValueOnce(new Error(errorMessage));
      jest.spyOn(Cookie, 'get').mockReturnValueOnce('145');
  
      try {
        await countNotificationsByUser();
       
        expect(true).toBe(false);
      } catch (error) {
        
        expect(error.message).toEqual(errorMessage);
        expect(Axios.get).toHaveBeenCalledWith(expectedUrl);
        expect(Cookie.get).toHaveBeenCalledWith('idUsuario');
      }
    });
  });