import Axios from 'axios';
import { addClient, deleteClient, getAllClients, getClienteUnidadNegocioByCliente, updateClient } from '../clients';
import endpoints from '../index';
import 'jest-localstorage-mock'; 

describe('getAllClients', () => {
  it('should handle empty client list and return an empty array', async () => {
 
    const mockResponse = { data: [] };
    jest.spyOn(Axios, 'get').mockResolvedValue(mockResponse);

    jest.spyOn(sessionStorage, 'getItem').mockReturnValue('valid_token');

    const clients = await getAllClients();

    expect(Array.isArray(clients)).toBe(true);
    expect(clients.length).toBe(0);

    expect(Axios.get).toHaveBeenCalledWith(endpoints.clients.getAllClients, {
      headers: {
        accept: '*/*',
        'Content-Type': 'application/json',
        Authorization: 'valid_token',
      },
    });
  });
});


describe('addClient', () => {
    it('should successfully add a client', async () => {
      const mockResponse = { data: { id: 52, name: 'Karen Perez' } };
      jest.spyOn(Axios, 'post').mockResolvedValue(mockResponse);
  
      jest.spyOn(sessionStorage, 'getItem').mockReturnValue('valid_token');
  
      const clientBody = {
        name: 'Karen Perez',
      };
  
      const addedClient = await addClient(clientBody);
  
      expect(addedClient).toEqual({ id: 52, name: 'Karen Perez' });
  
      expect(Axios.post).toHaveBeenCalledWith(endpoints.clients.addClient, clientBody, {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: 'valid_token',
        },
      });
    });
});



describe('deleteClient', () => {
  it('should successfully delete a client', async () => {

    const mockResponse = { data: { message: 'Client deleted successfully' } };
    jest.spyOn(Axios, 'delete').mockResolvedValue(mockResponse);
  
    jest.spyOn(sessionStorage, 'getItem').mockReturnValue('valid_token');
  
    const clientId = 52;
  
    const deletedClient = await deleteClient(clientId);
  
    expect(deletedClient).toEqual({ message: 'Client deleted successfully' });
  
    expect(Axios.delete).toHaveBeenCalledWith(endpoints.clients.deleteClient(clientId), {
      headers: {
        Authorization: 'valid_token',
      },
    });
  });

});



describe('updateClient', () => {
  it('should successfully update a client', async () => {
    
    const mockResponse = { data: { id: 52, name: 'Rosario' } };
    jest.spyOn(Axios, 'put').mockResolvedValue(mockResponse);

    jest.spyOn(sessionStorage, 'getItem').mockReturnValue('valid_token');

    const updatedClientBody = {
      id: 52,
      name: 'Rosario',
      
    };

    const updatedClient = await updateClient(updatedClientBody);

    expect(updatedClient).toEqual({ id: 52, name: 'Rosario' });

    expect(Axios.put).toHaveBeenCalledWith(endpoints.clients.updateClient, updatedClientBody, {
      headers: {
        accept: '*/*',
        'Content-Type': 'application/json',
        Authorization: 'valid_token',
      },
    });
  });
});


describe('getClienteUnidadNegocioByCliente', () => {
  it('should successfully get cliente unidad negocio by cliente ID', async () => {
    const mockResponse = { data: { unidadNegocio: 'Sample Unidad de Negocio' } };
    jest.spyOn(Axios, 'get').mockResolvedValue(mockResponse);

    jest.spyOn(sessionStorage, 'getItem').mockReturnValue('valid_token');

    const clientId = 52;

    const clienteUnidadNegocio = await getClienteUnidadNegocioByCliente(clientId);

    expect(clienteUnidadNegocio).toEqual({ unidadNegocio: 'Sample Unidad de Negocio' });

    expect(Axios.get).toHaveBeenCalledWith(
      endpoints.clients.getClienteUnidadNegocioByIdCliente(clientId),
      {
        headers: {
          accept: '*/*',
          'Content-Type': 'application/json',
          Authorization: 'valid_token',
        },
      }
    );
  });

});