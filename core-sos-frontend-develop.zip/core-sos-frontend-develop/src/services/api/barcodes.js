import Axios from "axios";
import endpoints from "./index";

const getAllBarcodes = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.barcodes.getAllBarcodes, config);
  return response.data;
};

const addBarcode = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.barcodes.addBarcode,
    body,
    config
  );
  return response.data;
};

const deleteBarcode = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.barcodes.deleteBarcode(id),
    config
  );
  return response.data;
};

const updateBarcode = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.barcodes.updateBarcode,
    body,
    config
  );
  return response.data;
};

export { addBarcode, deleteBarcode, getAllBarcodes, updateBarcode };

