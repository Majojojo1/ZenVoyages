import Axios from "axios";
import endpoints from "./index";

const getAllCargos = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(endpoints.cargos.getAllCargos, config);
  return response.data;
};

const addCargo = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.cargos.addCargo, body, config);
  return response.data;
};

const updateCargo = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.cargos.updateCargo, body, config);
  return response.data;
};

const getCargoById = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.cargos.getCargoById(id), config);
  return response.data;
};

const deleteCargo = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(endpoints.cargos.deleteCargo(id), config);
  return response.data;
};

const updateStateCargo = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.cargos.updateState, body, config);
  return response.data;
};

export {
    addCargo, deleteCargo, getAllCargos, getCargoById, updateCargo, updateStateCargo
};

