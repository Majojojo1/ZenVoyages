import Axios from "axios";
import endpoints from "./index";

const getAllEmployees = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(endpoints.employees.getAllEmployees, config);
  return response.data;
};

const getAllSelectEmployees = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(
    endpoints.employees.getAllSelectEmployees,
    config
  );
  return response.data;
};

const getFamiltybyEmployee = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(
    endpoints.employees.getFamiltybyEmployee(id),
    config
  );
  return response.data;
};

const addEmployee = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.employees.addEmployee,
    body,
    config
  );
  return response.data;
};

const updateEmployee = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.employees.updateEmployee,
    body,
    config
  );
  return response.data;
};

const deleteEmployee = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.employees.deleteEmployee(id),
    config
  );
  return response.data;
};

const addFamily = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.employees.addFamily,
    body,
    config
  );
  return response.data;
};

const updateFamily = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.employees.updateFamily,
    body,
    config
  );
  return response.data;
};

const deleteFamilyByEmployee = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.employees.deleteFamilyByEmployee(id),
    config
  );
  return response.data;
};

export {
    addEmployee, addFamily, deleteEmployee, deleteFamilyByEmployee, getAllEmployees,
    getAllSelectEmployees,
    getFamiltybyEmployee, updateEmployee, updateFamily
};

