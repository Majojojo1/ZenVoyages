import Axios from "axios";
import endpoints from "./index";

const uploadExcelCountriesFile = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "multipart/form-data",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.zones.uploadPaises, body, config);

  return response.data;
};

const uploadExcelDepartamentsFile = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "multipart/form-data",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.zones.uploadDepartments,
    body,
    config
  );

  return response.data;
};

const uploadExcelMunicipalitiesFile = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "multipart/form-data",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.zones.uploadMunicipalities,
    body,
    config
  );

  return response.data;
};

const uploadExcelSectorsFile = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "multipart/form-data",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.zones.uploadSectors,
    body,
    config
  );

  return response.data;
};

const getAllCountries = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.zones.getAllCountries, config);
  return response.data;
};

const getAllDepartments = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.zones.getAllDepartments, config);
  return response.data;
};

const getAllMunicipalities = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.zones.getAllMunicipalities,
    config
  );
  return response.data;
};

const updateMunicipality = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.zones.updateMunicipality,
    body,
    config
  );
  return response.data;
};

const updateDepartment = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.zones.updateDepartment,
    body,
    config
  );
  return response.data;
};

const updateCountry = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.zones.updateCountry, body, config);
  return response.data;
};

const getAllSectors = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.zones.getAllSectors, config);
  return response.data;
};

const deleteSector = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(endpoints.zones.deleteSector(id), config);
  return response.data;
};

const addSector = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.zones.addSector, body, config);
  return response.data;
};

const getSectorById = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.zones.getSectorById(id), config);
  return response.data;
};

const updateSector = async(body)=> {

  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.zones.updateSectors, body, config);
  return response.data;

}

export {
    addSector, deleteSector, getAllCountries,
    getAllDepartments,
    getAllMunicipalities,
    getAllSectors,
    getSectorById, updateCountry, updateDepartment, updateMunicipality, updateSector, uploadExcelCountriesFile,
    uploadExcelDepartamentsFile,
    uploadExcelMunicipalitiesFile,
    uploadExcelSectorsFile
};

