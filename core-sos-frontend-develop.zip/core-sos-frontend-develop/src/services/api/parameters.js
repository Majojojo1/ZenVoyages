import Axios from "axios";
import endpoints from "./index";

const getAllThirdTypes = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.parameters.getAllThirdTypes,
    config
  );
  return response.data;
};

const addThirdType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.parameters.addThirdType,
    body,
    config
  );
  return response.data;
};

const deleteThirdType = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.parameters.deleteThirdType(id),
    config
  );
  return response.data;
};

const updateThirdType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.parameters.updateThirdType,
    body,
    config
  );
  return response.data;
};

export { addThirdType, deleteThirdType, getAllThirdTypes, updateThirdType };

