import Axios from "axios";
import endpoints from "./index";

const getAllProviderTypes = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.providerType.getAllProviderTypes,
    config
  );
  return response.data;
};

const addProviderType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.providerType.addProviderType,
    body,
    config
  );
  return response.data;
};

const deleteProviderType = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.providerType.deleteProviderType(id),
    config
  );
  return response.data;
};

const updateProviderType = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.providerType.updateProviderType,
    body,
    config
  );
  return response.data;
};

const getProviderById = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.providerType.getProviderTypeById(id),
    config
  );
  return response.data;
};

export {
  addProviderType,
  deleteProviderType, getAllProviderTypes, getProviderById, updateProviderType
};

