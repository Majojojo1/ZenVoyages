import Axios from "axios";
import endpoints from "./index";

const getAllTechnical = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.technical.getAllTechnical, config);
  return response.data;
};

const getVehiclesByTechnical = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.technical.getVehiclesByTechnical,
    config
  );
  return response.data;
};

const addTechnical = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.technical.addTechnical,
    body,
    config
  );
  return response.data;
};

const updateTechnical = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.technical.updateTechnical,
    body,
    config
  );
  return response.data;
};

const deleteTechnical = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.technical.deleteTechnical(id),
    config
  );
  return response.data;
};

const deleteVehicleFromTechnical = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.technical.deleteVehicleFromTechnical(id),
    config
  );
  return response.data;
};

export {
    addTechnical, deleteTechnical, deleteVehicleFromTechnical, getAllTechnical,
    getVehiclesByTechnical, updateTechnical
};

