import Axios from "axios";
import endpoints from "./index";

const getAllMarkets = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.markets.getAllMarkets, config);
  return response.data;
};

const getMarketByCountry = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.markets.getMarketByCountry(id),
    config
  );
  return response.data;
};
const getMarketAssociateByCountry = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.markets.getMarketAssociateByCountry(id),
    config
  );
  return response.data;
};

const getMercadoByIdMercado = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.markets.findMercadoByIdMercado(id),
    config
  );
  return response.data;
};

const addMarket = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.markets.addMarket, body, config);
  return response.data;
};

const addMarketCountry = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.markets.addMarketCountry,
    body,
    config
  );
  return response.data;
};

const deleteMarket = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.markets.deleteMarket(id),
    config
  );
  return response.data;
};

const deleteMarketFromCountry = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.markets.deleteMarketFromCountry(id),
    config
  );
  return response.data;
};

const updateMarket = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.markets.updateMarket(body?.idMercado),
    body,
    config
  );
  return response.data;
};

export {
  addMarket,
  addMarketCountry,
  deleteMarket, deleteMarketFromCountry, getAllMarkets,
  getMarketAssociateByCountry,
  getMarketByCountry, getMercadoByIdMercado, updateMarket
};

