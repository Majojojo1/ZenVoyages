import Axios from "axios";
import endpoints from "./index";

const getAllContracts = async () => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };
  const response = await Axios.get(endpoints.contracts.getAllContracts, config);
  return response.data;
};

const addContract = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.contracts.addContract,
    body,
    config
  );
  return response.data;
};

const updateContract = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(
    endpoints.contracts.updateContract,
    body,
    config
  );
  return response.data;
};

const getContractById = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.contracts.getContractById(id),
    config
  );
  return response.data;
};

const deleteContract = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.contracts.deleteContract(id),
    config
  );
  return response.data;
};

const updateStateContract = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.contracts.updateState,
    body,
    config
  );
  return response.data;
};

export {
    addContract, deleteContract, getAllContracts, getContractById, updateContract, updateStateContract
};

