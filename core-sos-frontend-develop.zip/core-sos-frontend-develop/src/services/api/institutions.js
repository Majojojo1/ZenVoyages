import Axios from "axios";
import endpoints from "./index";

const getAllTechnicalOperators = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getAllTechnical,
    config
  );
  return response.data;
};

const getVehicles = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.institutions.getVehicles, config);
  return response.data;
};

const technicalVehicles = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.technicalVehicles,
    config
  );
  return response.data;
};

const brandVehicles = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.brandVehicles,
    config
  );
  return response.data;
};

const categoryLicenses = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.categoryLicenses,
    config
  );
  return response.data;
};

const getAllbanks = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.institutions.getAllbanks, config);
  return response.data;
};

const getAllHalthEntities = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getAllHalthEntities,
    config
  );
  return response.data;
};

const getAllGenres = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.institutions.getAllGenres, config);
  return response.data;
};

const getAllTypeAccounts = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getAllTypeAccounts,
    config
  );
  return response.data;
};

const getAllTypeDocument = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getAllTypeDocument,
    config
  );
  return response.data;
};

const getAllKin = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(endpoints.institutions.getAllKin, config);
  return response.data;
};

const getAllFamilies = async () => {
  const config = {
    headers: {
      accept: "*/*",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getAllFamilies,
    config
  );
  return response.data;
};

const saveVehicle = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.institutions.saveVehicle,
    body,
    config
  );
  return response.data;
};

const getTechnicalVehiclesById = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getTechnicalVehiclesById(id),
    config
  );
  return response.data;
};

const deleteVehicle = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(
    endpoints.institutions.deleteVehicle(id),
    config
  );
  return response.data;
};

const getUnidadMedida = async () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.institutions.getUnidadMedida,
    config
  );
  return response.data;
};

export {
    brandVehicles, categoryLicenses, deleteVehicle, getAllFamilies, getAllGenres, getAllHalthEntities, getAllKin, getAllTechnicalOperators, getAllTypeAccounts,
    getAllTypeDocument, getAllbanks, getTechnicalVehiclesById, getUnidadMedida, getVehicles, saveVehicle, technicalVehicles
};

