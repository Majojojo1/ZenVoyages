import Axios from "axios";
import endpoints from "./index";

const getPerssimionModuleByUser = async (id) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.get(
    endpoints.roles.getAllRolPermisosModulosByUser(id),
    config
  );
  return response.data;
};

const addRole = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(endpoints.roles.addRole, body, config);
  return response.data;
};

const deleteRole = async (id) => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.delete(endpoints.roles.deleteRole(id), config);
  return response.data;
};

const updateRole = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.put(endpoints.roles.updateRole, body, config);

  return response.data;
};

const addPermisoModulo = async (body) => {
  const config = {
    headers: {
      accept: "*/*",
      "Content-Type": "application/json",
      Authorization: sessionStorage.getItem("token"),
    },
  };

  const response = await Axios.post(
    endpoints.roles.addRolePermisoModulo,
    body,
    config
  );
  return response.data;
};

export {
    addPermisoModulo, addRole,
    deleteRole, getPerssimionModuleByUser, updateRole
};

