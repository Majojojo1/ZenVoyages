import React, { useState } from "react";
// Mui table styles
import MuiAlert from "@mui/material/Alert";
import Paper from "@mui/material/Paper";
import Snackbar from "@mui/material/Snackbar";
import Stack from "@mui/material/Stack";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableFooter from "@mui/material/TableFooter";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
// Pagination actions
import TablePagination from "@mui/material/TablePagination";
import UserPaginateActions from "components/tableOptions/UserPaginateActions";
// Dynamic cell
import { useSeachContext } from "context/SearchContext";
import NewDynamicCell from "./NewDynamicCell";
// Search context

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const NewDynamicTable = ({ titles, pageName, getData }) => {
  // context de búsqueda
  const { searchResults = [] } = useSeachContext();
  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  // Alerts
  const [open, setOpen] = useState(false);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 250 }} aria-label="Tabla de informacion">
          <TableHead>
            <TableRow>
              {titles.map((title, index) => (
                <TableCell key={index} align="left">
                  {title}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowsPerPage > 0
              ? searchResults.slice(
                  page * rowsPerPage,
                  page * rowsPerPage + rowsPerPage
                )
              : searchResults
            ).map((item, index) => (
              <NewDynamicCell
                titles={titles}
                key={index}
                columns={item}
                pageName={pageName}
                getData={getData}
              />
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TableFooter
        sx={{
          display: "flex",
          justifyItems: "center",
          justifyContent: "right",
          mt: 2,
          mb: 2,
        }}
      >
        <TablePagination
          sx={{
            boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px",
            marginTop: "25px",
            borderRadius: "10px",
          }}
          rowsPerPageOptions={[
            25,
            50,
            100,
            200,
            { label: "Todos", value: searchResults.length },
          ]}
          colSpan={3}
          count={searchResults.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          ActionsComponent={UserPaginateActions}
          labelRowsPerPage={pageName + " por página"}
          align="center"
        />
      </TableFooter>
      <Stack spacing={2} sx={{ width: "100%" }}>
        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
          <Alert
            onClose={handleClose}
            severity="warning"
            sx={{ width: "100%" }}
          >
            Se esta actualizando el registro
          </Alert>
        </Snackbar>
      </Stack>
    </>
  );
};

export default NewDynamicTable;
