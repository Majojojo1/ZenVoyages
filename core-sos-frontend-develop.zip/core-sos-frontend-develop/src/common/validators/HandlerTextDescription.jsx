import React from 'react';
import { TEXTREGEX } from './Regex';

const HandlerTextDescription = (e, currentValue, setCurrentValue) => {

  setCurrentValue((prevValue) => ({
    ...prevValue,
    [e.target.name]: e.target.value,
  }));

};

export default HandlerTextDescription;
