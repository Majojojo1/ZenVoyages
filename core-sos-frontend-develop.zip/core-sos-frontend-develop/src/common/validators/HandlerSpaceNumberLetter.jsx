
/***
 * Validate space, number and letter
 */
const HandlerSpaceNumberLetter = (e, setCurrentValue) => {
    if(/^[a-zA-Z0-9\s]+$/.test(e.target.value))
      setCurrentValue((prevValue) => ({
        ...prevValue,
        [e.target.name]: e.target.value,
      }));
};

export default HandlerSpaceNumberLetter;