// eslint-disable-next-line no-unused-vars
import React from "react";

/**
 * Validator to avoid double spaces in numbers,
 * but in the POST need to do a trim()
 */
const HandlerNumbers = (e, currentValue, setCurrentValue) => {
  if (e.target.value.match(/^[0-9]*$/)) {
    let result = /\s{2}/.test(e.target.value);
    if (result) {
      console.log("No se permiten espacios en blanco");
    } else {
      setCurrentValue({
        ...currentValue,
        [e.target.name]: e.target.value,
      });
    }
  }
};

export default HandlerNumbers;
