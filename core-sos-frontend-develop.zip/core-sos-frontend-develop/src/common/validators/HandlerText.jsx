// eslint-disable-next-line no-unused-vars

/**
 * Validator to avoid double spaces in text,
 * but in the POST need to do a trim()
 */
const HandlerText = (e, currentValue, setCurrentValue) => {
  if (e.target.value.match("^[a-zA-Z0-9]*$") !== null) {
    let result = /\s{2}/.test(e.target.value);
    if (result) {
      console.log("No se permiten espacios en blanco");
    } else {
      setCurrentValue((prevValue) => ({
        ...prevValue,
        [e.target.name]: e.target.value,
      }));
    }
  }
};


// const HandlerText = (e, currentValue, setCurrentValue) => {
//   const regex = /^[a-zA-Z0-9 ]*$/;
//   const inputValue = e.target.value;

//   if (inputValue.match(regex) && !/\s{2}/.test(inputValue)) {
//     const sanitizedValue = removeAccents(inputValue);
//     setCurrentValue((prevValue) => ({
//       ...prevValue,
//       [e.target.name]: sanitizedValue,
//     }));
//   } else {
//     console.log("No se permiten espacios en blanco o acentos");
//   }
// };


// const removeAccents = (text) => {
//   return text
//     .normalize("NFD")
//     .replace(/[\u0300-\u036f]/g, "")
//     .replace(/\s{2,}/g, " ");
// };


export default HandlerText;

