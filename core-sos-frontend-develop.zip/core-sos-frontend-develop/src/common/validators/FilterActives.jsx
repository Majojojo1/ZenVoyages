/**
 * Utilidad para filtrar elemntos activos
 *
 * @param {Array} array -- Elementos que contengan clave estado
 * @returns arrayFilter
 *
 * @author Luis Fernandez -- QVision
 */
export const FilterActive = (array) => array.filter((item) => item.estado === 1);
