import React from "react";
// Import Hooks
import { useField } from "@formiz/core";
// Import Components
import currencyFormat from "common/utils/currencyFormat";
import rawCurrency from "common/utils/rawCurrency";
import {
  ADDRESSREGEX,
  ALPHANUMERICREGEX,
  IDREGEX,
  NUMBERREGEX,
  PRICEREGEX,
  SKUREGEX,
  TEXTREGEX,
  URLREGEX
} from "common/validators/Regex";

export const InputFieldResponsive = (props) => {
  const { errorMessage, id, isValid, isSubmitted, setValue, value } =
    useField(props);
  const {
    type,
    name,
    labelText,
    placeholder,
    validateInput,
    disabled,
    required,
    styleName,
  } = props;
  const [isTouched, setIsTouched] = React.useState(false);
  const showError = !isValid && (isTouched || isSubmitted);

  const validateRegex = (value, regex) => {
    const isMatch = value.match(regex);
    if (isMatch) setValue(value);
  };

  const handleChange = (e) => {
    const { name = "", value = "" } = e.target;

    const valueWithoutSpaces = (value || "").replaceAll(
      /\s{2,}/gi,
      " ",
    );

    switch (validateInput) {
      case "number":
        validateRegex(valueWithoutSpaces, PRICEREGEX);
        break;
      case "identificacion":
        validateRegex(valueWithoutSpaces, IDREGEX);
        break;
      case "text":
        if (/sku/gi.test(name)) validateRegex(valueWithoutSpaces, SKUREGEX);
        else if (/descripcion/gi.test(name)) setValue(e.target.value);
        else validateRegex(valueWithoutSpaces, TEXTREGEX);
        break;
      case "web":
        validateRegex(valueWithoutSpaces, URLREGEX);
        break;
      case "integer":
        validateRegex(valueWithoutSpaces, NUMBERREGEX);
        break;
      case "address":
        validateRegex(valueWithoutSpaces, ADDRESSREGEX);
        break;
      case "alphanumber":
        validateRegex(valueWithoutSpaces, ALPHANUMERICREGEX);
        break;
      default:
        setValue(e.target.value);
        break;
    }
  };

  return (
    <label className="d-flex">
      <span className="text-inline">{labelText}</span>
      <section className="w100-container">
        {props.area === undefined ? (
          <input
            id={id}
            type={type || "text"}
            value={value || ""}
            name={name}
            onChange={handleChange}
            onBlur={() => {
              setIsTouched(true);
              if (validateInput === "number") {
                setValue(currencyFormat(value));
              }
            }}
            onFocus={() => {
              if (validateInput === "number") {
                if (value) {
                  setValue(rawCurrency(value));
                }
              }
            }}
            placeholder={placeholder}
            className={styleName || "input-default-3c"}
            aria-invalid={showError}
            aria-required={!!required}
            aria-describedby={showError ? `${id}-error` : null}
            disabled={disabled}
            min={props.min}
          />
        ) : (
          <textarea
            id={id}
            //type={type || "text"}
            value={value || ""}
            name={name}
            onChange={handleChange}
            onBlur={() => setIsTouched(true)}
            placeholder={placeholder}
            className={styleName || "input-default-3c"}
            aria-invalid={showError}
            aria-required={!!required}
            aria-describedby={showError ? `${id}-error` : null}
            disabled={disabled}
            rows={props.row} cols={props.cols}
            style={{
              resize: 'none',
              borderRadius: '5px',
              boxShadow: '0px 4px 8px rgba(0, 174, 142, 0.2)',
              padding: '1rem',
              outline: 'none',
              display: 'block'
            }}
          />
        )}
        {showError && (
          <span id={`${id}-error`} className="error-msg">
            {errorMessage}
          </span>
        )}
      </section>
    </label>
  );
};
