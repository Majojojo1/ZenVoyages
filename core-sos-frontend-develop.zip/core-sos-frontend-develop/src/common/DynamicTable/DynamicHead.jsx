import React, { memo, useState } from 'react';
// Mui table styles
import MuiAlert from '@mui/material/Alert';
import Paper from '@mui/material/Paper';
import Snackbar from '@mui/material/Snackbar';
import Stack from '@mui/material/Stack';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
// Pagination actions
import TablePagination from '@mui/material/TablePagination';
import UserPaginateActions from 'components/tableOptions/UserPaginateActions';
// Dynamic cell
import { TableFooter } from '@mui/material';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import DynamicRow from './DynamicRow';
// Search context

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const DynamicHead = ({
  titles,
  pageName,
  getData,
  data,
  handleDownloadItem,
  handleDeleteItem,
  handleEditStateItem,
  noHandleEditStateItem,
  routeToEdit,
  canDeleted,
  canDeletedInvoice,
  canModify,
  canDownload,
  canSelectEU,
  canSelectSC,
  canSelectSSU,
  canSelectSBU,
  canEditPrecaution,
  onClose,
  functions,
  minRows = 25,
}) => {
  // context de búsqueda
  const {
    rowsPerPage,
    setRowsPerPage,
    rowMarket,
    setRowMarket,
    rowParams,
    setRowParams,
    rowBilling,
    setRowBilling,
    rowClient,
    setRowClient,
    rowProvider,
    setRowProvider,
    rowBussinesUnit,
    setRowBussinesUnit,
    rowCategories,
    setRowCategories,
    rowStages,
    setRowStages,
    rowActivities,
    setRowActivities,
    rowPrices,
    setRowPrices,
    rowForms,
    setRowForms,
    rowtechs,
    setRowTechs,
    rowVehicles,
    setRowVehicles,
    RowcategoriesProduct,
    setRowscategoriesProduct,
    RowproductsPage,
    setRowproductsPage,

    searchResults,

    page,
    setPage,
    thirdPage,
    setThirdPage,
    billingPage,
    setBillingPage,
    clientPage,
    setClientPage,
    providerPage,
    setProviderPage,
    unitBussinesPage,
    setUnitBussinesPage,
    marketPage,
    setMarketPage,
    serviceCatPage,
    setServiceCatPage,
    serviceStagetPage,
    setServiceStagetPage,
    activitiesPage,
    setActivitiesPage,
    priceListPage,
    setPriceListPage,
    formPage,
    setFormPage,
    techsPage,
    setTechsPage,
    vehiclesPage,
    setVehiclesPage,
    categoriesProductPage,
    setcategoriesProductPage,
    productsPage,
    setProductsPage,
  } = useSeachContext();

  const { formatterText } = useLangv2();

  const [open, setOpen] = useState(false);

  const handleChangePage = (event, newPage) => {
    switch (pageName) {
      case PAGE_NAMES.Mercados:
        setMarketPage(newPage);
        break;
      case PAGE_NAMES.UnidadNegocio:
        setUnitBussinesPage(newPage);
        break;
      case PAGE_NAMES.ProveedorTipo:
        setProviderPage(newPage);
        break;
      case PAGE_NAMES.ClienteTipo:
        setClientPage(newPage);
        break;
      case PAGE_NAMES.Facturacion:
        setBillingPage(newPage);
        break;
      case PAGE_NAMES.Terceros:
        setThirdPage(newPage);
        break;
      case PAGE_NAMES.Categorías:
        setServiceCatPage(newPage);
        break;
      case PAGE_NAMES.Etapas:
        setServiceStagetPage(newPage);
        break;
      case PAGE_NAMES.Actividades:
        setActivitiesPage(newPage);
        break;
      case PAGE_NAMES.Precios:
        setPriceListPage(newPage);
        break;
      case PAGE_NAMES.Formularios:
        setFormPage(newPage);
        break;
      case PAGE_NAMES.Técnicos:
        setTechsPage(newPage);
        break;
      case PAGE_NAMES.Vehículos:
        setVehiclesPage(newPage);
        break;
      case PAGE_NAMES.CategoríasProductos:
        setcategoriesProductPage(newPage);
        break;
      case PAGE_NAMES.Productos:
        setProductsPage(newPage);
        break;
      case PAGE_NAMES.Agendas:
        setPage(newPage);
        break;
      case PAGE_NAMES.Servicios:
        setPage(newPage);
        break;
      case PAGE_NAMES.Usuarios:
        setPage(newPage);
        break;
      case PAGE_NAMES.Roles:
        setPage(newPage);
        break;
      case PAGE_NAMES.Archivos:
        setPage(newPage);
        break;
      case PAGE_NAMES.Cargos:
        setPage(newPage);
        break;
      case PAGE_NAMES.Contratos:
        setPage(newPage);
        break;
      case PAGE_NAMES.Empleados:
        setPage(newPage);
        break;
      case PAGE_NAMES.Terceras:
        setPage(newPage);
        break;
      case PAGE_NAMES.Clientes:
        setPage(newPage);
        break;
      case PAGE_NAMES.Proveedores:
        setPage(newPage);
        break;
      case PAGE_NAMES.Actividad:
        setPage(newPage);
        break;
      case PAGE_NAMES.Recaudos:
        setPage(newPage);
        break;

      default:
        setPage(newPage);
        break;
    }
  };

  const pages = (type) => {
    const typeToDataMap = {
      [PAGE_NAMES.Mercados]: marketPage,
      [PAGE_NAMES.UnidadNegocio]: unitBussinesPage,
      [PAGE_NAMES.ProveedorTipo]: providerPage,
      [PAGE_NAMES.ClienteTipo]: clientPage,
      [PAGE_NAMES.Facturacion]: billingPage,
      [PAGE_NAMES.Terceros]: thirdPage,
      [PAGE_NAMES.Categorías]: serviceCatPage,
      [PAGE_NAMES.Etapas]: serviceStagetPage,
      [PAGE_NAMES.Actividades]: activitiesPage,
      [PAGE_NAMES.Precios]: priceListPage,
      [PAGE_NAMES.Formularios]: formPage,
      [PAGE_NAMES.Técnicos]: techsPage,
      [PAGE_NAMES.Vehículos]: vehiclesPage,
      [PAGE_NAMES.CategoríasProductos]: categoriesProductPage,
      [PAGE_NAMES.Productos]: productsPage,
      [PAGE_NAMES.Agendas]: page,
      [PAGE_NAMES.Servicios]: page,
      [PAGE_NAMES.Usuarios]: page,
      [PAGE_NAMES.Roles]: page,
      [PAGE_NAMES.Archivos]: page,
      [PAGE_NAMES.Cargos]: page,
      [PAGE_NAMES.Contratos]: page,
      [PAGE_NAMES.Empleados]: page,
      [PAGE_NAMES.Terceras]: page,
      [PAGE_NAMES.Clientes]: page,
      [PAGE_NAMES.Proveedores]: page,
      [PAGE_NAMES.Actividad]: page,
      [PAGE_NAMES.Recaudos]: page,
    };

    const dataToRender = typeToDataMap[type];
    return dataToRender;
  };


  const handleChangeRowsPerPage = (event) => {
    switch (pageName) {
      case PAGE_NAMES.Mercados:
        setRowMarket(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.UnidadNegocio:
        setRowBussinesUnit(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.ProveedorTipo:
        setRowProvider(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.ClienteTipo:
        setRowClient(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Facturacion:
        setRowBilling(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Terceros:
        setRowParams(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Categorías:
        setRowCategories(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Etapas:
        setRowStages(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Actividades:
        setRowActivities(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Precios:
        setRowPrices(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Formularios:
        setRowForms(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Técnicos:
        setRowTechs(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Vehículos:
        setRowVehicles(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.CategoríasProductos:
        setRowscategoriesProduct(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Productos:
        setRowproductsPage(event.target.value, 10);
        setPage(0);
        break;
      case PAGE_NAMES.Servicios:
      case PAGE_NAMES.Agendas:
      case PAGE_NAMES.Usuarios:
      case PAGE_NAMES.Roles:
      case PAGE_NAMES.Archivos:
      case PAGE_NAMES.Cargos:
      case PAGE_NAMES.Contratos:
      case PAGE_NAMES.Empleados:
      case PAGE_NAMES.Terceras:
      case PAGE_NAMES.Clientes:
      case PAGE_NAMES.Proveedores:
      case PAGE_NAMES.Actividad:
      case PAGE_NAMES.Recaudos:
        setRowsPerPage(event.target.value, 10);
        setPage(0);
        break;

    }
  };

  const rowPages = (type) => {
    const typeToDataMap = {
      [PAGE_NAMES.Mercados]: rowMarket,
      [PAGE_NAMES.UnidadNegocio]: rowBussinesUnit,
      [PAGE_NAMES.ProveedorTipo]: rowProvider,
      [PAGE_NAMES.ClienteTipo]: rowClient,
      [PAGE_NAMES.Facturacion]: rowBilling,
      [PAGE_NAMES.Terceros]: rowParams,
      [PAGE_NAMES.Categorías]: rowCategories,
      [PAGE_NAMES.Etapas]: rowStages,
      [PAGE_NAMES.Actividades]: rowActivities,
      [PAGE_NAMES.Precios]: rowPrices,
      [PAGE_NAMES.Formularios]: rowForms,
      [PAGE_NAMES.Técnicos]: rowtechs,
      [PAGE_NAMES.Vehículos]: rowVehicles,
      [PAGE_NAMES.CategoríasProductos]: RowcategoriesProduct,
      [PAGE_NAMES.Productos]: RowproductsPage,
      [PAGE_NAMES.Agendas]: rowsPerPage,
      [PAGE_NAMES.Servicios]: rowsPerPage,
      [PAGE_NAMES.Usuarios]: rowsPerPage,
      [PAGE_NAMES.Roles]: rowsPerPage,
      [PAGE_NAMES.Archivos]: rowsPerPage,
      [PAGE_NAMES.Cargos]: rowsPerPage,
      [PAGE_NAMES.Contratos]: rowsPerPage,
      [PAGE_NAMES.Empleados]: rowsPerPage,
      [PAGE_NAMES.Terceras]: rowsPerPage,
      [PAGE_NAMES.Clientes]: rowsPerPage,
      [PAGE_NAMES.Proveedores]: rowsPerPage,
      [PAGE_NAMES.Actividad]: rowsPerPage,
      [PAGE_NAMES.Recaudos]: rowsPerPage,
    };

    const dataToRender = typeToDataMap[type];
    return dataToRender;
  };


  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  }; 

  return (
    <>
      <TableContainer component={Paper}>
        <Table
          sx={{ minWidth: 250, }}
          aria-label="Tabla de informacion">
          <TableHead>
            <TableRow>
              {titles.map((title, index) => (
                <TableCell
                  key={`title_${index + 1}`}
                  sx={{
                    fontWeight: 'bold',
                  }}
                  align="left"
                >
                  {title}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowPages(pageName) > 0
              ? searchResults.slice(pages(pageName) * rowPages(pageName), pages(pageName) * rowPages(pageName) + rowPages(pageName))
              : searchResults
            ).map((item, index) => (
              <DynamicRow
                key={`row_${index + 1}`}
                titles={titles}
                columns={item}
                getData={getData}
                handleDownloadItem={handleDownloadItem}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                noHandleEditStateItem={noHandleEditStateItem}
                routeToEdit={routeToEdit}
                canDeleted={canDeleted}
                canDeletedInvoice={canDeletedInvoice}
                canModify={canModify}
                canDownload={canDownload}
                canSelectEU={canSelectEU}
                canSelectSBU={canSelectSBU}
                canSelectSC={canSelectSC}
                canSelectSSU={canSelectSSU}
                canEditPrecaution={canEditPrecaution}
                onClose={onClose}
                functions={functions}
                data={data}
              />
            ))}
          </TableBody>
          <TableFooter
            sx={{
              display: 'inherit',
              justifyItems: 'center',
              justifyContent: 'right',
              mt: 2,
              mb: 2,
              minWidth: 250,
              borderRadius: '10px'
            }}
          >
            <TablePagination
              sx={{
                boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
                marginTop: '25px',
                borderRadius: '10px',
              }}
              rowsPerPageOptions={[
                25,
                50,
                100,
                200,
                { label: 'Todos', value: searchResults.length },
              ]}
              colSpan={3}
              count={searchResults.length}
              rowsPerPage={rowPages(pageName) || rowsPerPage}
              page={pages(pageName) || page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              ActionsComponent={UserPaginateActions}
              labelRowsPerPage={formatterText(pageName) + formatterText('title.per.page')}
              align="center"
            />
          </TableFooter>

        </Table>

      </TableContainer>
      <Stack spacing={2} sx={{ width: '100%' }}>
        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
          <Alert onClose={handleClose} severity="warning" sx={{ width: '100%' }}>
            {formatterText('alert.update')}
          </Alert>
        </Snackbar>
      </Stack>
    </>
  );
};

export default memo(DynamicHead);
