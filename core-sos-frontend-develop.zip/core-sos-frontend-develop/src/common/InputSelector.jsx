import React, { useState } from "react";
import Select from "react-select";
import { useField } from "@formiz/core";
import { FormattedMessage } from "react-intl";

const InputSelector = (props) => {
  const { errorMessage, id, isValid, isSubmitted, setValue, value } = useField(
    props
  );
  const {
    type,
    name,
    labelText,
    required,
    placeholder,
    valueInput,
    defaultValue,
    isLoading,
    data,
  } = props;
  const [isTouched, setIsTouched] = useState(false);
  const showError = !isValid && (isTouched || isSubmitted);

  const [selectedOption, setSelectedOption] = useState(null);

  return (
    <label className="wrapForm__label">
      <span className="warpForm-text">{labelText}</span>
      <section className="container-wrapForm__label">
        <Select
          defaultValue={defaultValue}
          onChange={(selectedOption) => {
            setSelectedOption(selectedOption.label);
            setValue(selectedOption.value);
          }}
          options={data}
          placeholder={
            isLoading ? (
              <FormattedMessage
                id="input.loading"
                defaultMessage="Cargando..."
              />
            ) : (
              placeholder
            )
          }
        />

        <input
          className="input-required"
          id={id}
          type={type || "text"}
          value={selectedOption || ""}
          name={name}
          onBlur={() => setIsTouched(true)}
          placeholder={placeholder}
          //   className="input-primary-wrap"
          aria-invalid={showError}
          autoComplete="off"
          aria-required={!!required}
          aria-describedby={showError ? `${id}-error` : null}
        />
        {showError && (
          <span id={`${id}-error`} className="error-msg">
            {errorMessage}
          </span>
        )}
      </section>
    </label>
  );
};

export default InputSelector;
