import dateFormat from "dateformat";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
// Mui Cell row style
import TableCell from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
// Icons for cell
import { MdDelete, MdEdit } from "react-icons/md";
// Alert to show when delete is clicked
import WarningDialog from "components/tableOptions/WarningDialog";
// Service to delete data
import { deleteCargo, updateStateCargo } from "services/api/cargos";
// Custom alerts
import CustomAlert from "components/CustomAlert";
import CustomToast from "components/CustomToast";
import { useSeachContext } from "context/SearchContext";
import Cookie from "js-cookie";
import { useIntl } from "react-intl";
import { deleteBillingType, updateBillingType } from "services/api/billingType";
import {
  deleteBusinessUnit,
  updateBusinessUnit,
} from "services/api/businessUnit";
import { deleteClientType, updateClientType } from "services/api/clientType";
import { deleteContract, updateStateContract } from "services/api/contracts";
import { deleteEmployee, updateEmployee } from "services/api/employees";
import { deleteMarket, updateMarket } from "services/api/markets";
import { deleteThirdType, updateThirdType } from "services/api/parameters";
import {
  deleteProviderType,
  updateProviderType,
} from "services/api/providerType";
import {
  deleteTechnical,
  deleteVehicleFromTechnical,
} from "services/api/technicals";
import { deleteThirdParty, updateThirdParty } from "services/api/thirdParties";
import { deleteClient, updateClient } from "../services/api/clients";

// AHORA solo agrega abajo NO arriba
const idLang = [
  "table.name.search.positions",
  "table.name.search.contracts",
  "table.name.search.employee",
  "table.name.search.parameter",
  "table.name.search.thirdParties",
  "table.name.search.technicalOperators",
  "table.name.search.vehicleTechnicalOperators",
  "table.name.search.market",
  "table.name.search.businessUnits",
  "table.name.search.providerType",
  "table.name.search.clientType",
  "table.name.search.billingType",
  "table.name.search.client",
];

const NewDynamicCell = ({ titles, columns, pageName, getData }) => {
  const intl = useIntl();
  const { dataTable, setDataTable, setSearchResults } =
    useSeachContext();
  const navigate = useNavigate();

  const [stateAux, setStateAux] = useState(columns.estado);
  const [dateAux, setDateAux] = useState(columns.fechaModificacion);
  const [loading, setLoading] = useState(false);

  // Dialog edit
  const [dialog, setDialog] = useState({
    text: "",
    active: false,
    function: null,
  });

  // State when edit the state
  const { OnMessage, CustomComponentToast } = CustomToast();

  // This helps to update a single row in the state and date of modification
  useEffect(() => {
    // setStateAux(columns.estado);
    // setDateAux(columns.fechaModificacion);
  }, [dataTable]);

  // DANNY hay que refractorizar todo esto para que no se repita
  // y acepte en varios idiomas, en este momento el texto puede cambiar
  // Navigate to edit pageName when edit button is clicked
  const handleEdit = (id) => {
    // Se hace esta validacion ya que pageName con la traducción no es un string
    if (typeof pageName === "string") {
      if (pageName === "Empleado") {
        localStorage.setItem("currentEmployee", JSON.stringify(columns.objeto));
      } else if (pageName === "Tercero") {
        localStorage.setItem("currentThird", JSON.stringify(columns.objeto));
      } else if (pageName === "Operador-tecnico") {
        localStorage.setItem(
          "currentTechnical",
          JSON.stringify(columns.objeto),
        );
      }
      localStorage.setItem("dataUpdate", JSON.stringify(columns.objeto));

      navigate(`/editar/${pageName.toLocaleLowerCase()}/${id}`);
    } else {
      newHandleEdit(id);
    }
  };

  const newHandleEdit = (id) => {
    // FIXME: hay que refactorizar esto, ya que no esta para varios idiomas
    console.log(pageName[0]);
    if (pageName[0] === "Tipos de proveedor") {
      // TODO: Mejorar la logica de esto
      localStorage.setItem("dataUpdate", JSON.stringify(columns.objeto));
      navigate(`/editar/tipo-proveedor/${id}`);
    } else if (pageName[0] === "Unidades de negocio") {
      localStorage.setItem("dataUpdate", JSON.stringify(columns.objeto));
      navigate(`/editar/unidad-negocio/${id}`);
    } else if (pageName[0] === "Tipos de facturación") {
      localStorage.setItem("dataUpdate", JSON.stringify(columns.objeto));
      navigate(`/editar/tipo-facturacion/${id}`);
    } else if (pageName[0] === "Tipos de clientes") {
      localStorage.setItem("dataUpdate", JSON.stringify(columns.objeto));
      navigate(`/editar/tipo-cliente/${id}`);
    } else {
      console.log("No entro en ningun lugar");
    }
  };

  const handleDelete = (columns) => {
    switch (pageName) {
      case "Cargos":
        handleDeleteCargo(columns);
        break;
      case "Contratos":
        handleDeleteContract(columns);
        break;
      case "Empleado":
        handleDeleteEmployee(columns);
        break;
      case "Parametros":
        handleDeleteTipoTercero(columns);
        break;
      case "Tercero":
        handleDeleteTercero(columns);
        break;
      case "Operador-tecnico":
        handleDeleteTechnicalOperators(columns);
      case "Vehiculo-tecnico":
        handleDeleteVehicleTechnicalOperators(columns);
        break;
      case "Mercados":
        handleDeleteMercado(columns);
        break;
      default:
        // console.log("No se pudo eliminar");
        newhandleDelete(pageName[0]);
        break;
    }
  };

  const newhandleDelete = (pageName) => {
    console.log("nombre de la pagina", pageName);

    const index = idLang.findIndex((id) => {
      const textCurrentLang = formatterText(id);
      return textCurrentLang === pageName;
    });

    console.log("index", index);

    const DELETE_ITEM_FUNCTION = {
      0: handleDeleteCargo,
      1: handleDeleteContract,
      2: handleDeleteEmployee,
      3: handleDeleteTipoTercero,
      4: handleDeleteTercero,
      5: handleDeleteTechnicalOperators,
      6: handleDeleteVehicleTechnicalOperators,
      7: handleDeleteMercado,
      8: handleDeleteBusinessUnit,
      9: handleDeleteProviderType,
      10: handleDeleteClientType,
      11: handleDeleteBillingType,
      12: handleDeleteClient,
    };

    if (index !== -1) {
      DELETE_ITEM_FUNCTION[index](columns, formatterText(idLang[index]));
    } else {
      console.log("No se pudo eliminar");
    }
  };

  const formatterText = (textId) => {
    const plainText = intl.formatMessage({ id: textId });
    return plainText;
  };

  // Delete cargos
  const handleDeleteCargo = (columns) => {
    deleteCargo(columns.id)
      .then((res) => {
        displaySucess("cargo", res);
      })
      .catch((err) => {
        displayError("cargo", err);
      });
  };

  //Delete tipo de contrato
  const handleDeleteContract = () => {
    deleteContract(columns.id)
      .then((res) => {
        displaySucess("contrato", res);
      })
      .catch((err) => {
        displayError("contrato", err);
      });
  };

  //Delete employee
  const handleDeleteEmployee = () => {
    deleteEmployee(columns.id)
      .then((res) => {
        displaySucess("empleado", res);
      })
      .catch((err) => {
        displayError("empleado", err);
      });
  };

  // Delete tipo tercero
  const handleDeleteTipoTercero = (columns) => {
    deleteThirdType(columns.id)
      .then((res) => {
        displaySucess("tipo de tercero", res);
      })
      .catch((err) => {
        displayError("tipo de tercero", err);
      });
  };

  // Delete tercero
  const handleDeleteTercero = (columns) => {
    deleteThirdParty(columns.id)
      .then((res) => {
        displaySucess("tercero", res);
      })
      .catch((err) => {
        displayError("tercero", err);
      });
  };
  // Delete Market
  const handleDeleteMercado = (columns) => {
    deleteMarket(columns.id)
      .then((res) => {
        displaySucess("mercado", res);
      })
      .catch((err) => {
        displayError("mercado", err);
      });
  };
  // Delete BusinessUnit
  const handleDeleteBusinessUnit = (columns, module) => {
    deleteBusinessUnit(columns.id)
      .then((res) => {
        newdisplaySucess(module, res);
      })
      .catch((err) => {
        newdisplayError(module, err);
      });
  };
  // Delete Operators
  const handleDeleteTechnicalOperators = (columns) => {
    deleteTechnical(columns.id)
      .then((res) => {
        displaySucess("operador-tecnico", res);
      })
      .catch((err) => {
        displayError("operador-tecnico", err);
      });
  };
  // Delete vechnicalOperators
  const handleDeleteVehicleTechnicalOperators = (columns) => {
    deleteVehicleFromTechnical(columns.id)
      .then((res) => {
        displaySucess("vehiculo-tecnico", res);
      })
      .catch((err) => {
        displayError("vehiculo-tecnico", err);
      });
  };
  // Delete ProviderType
  const handleDeleteProviderType = (columns, module) => {
    deleteProviderType(columns.id)
      .then((res) => {
        newdisplaySucess(module, res);
      })
      .catch((err) => {
        newdisplayError(module, err);
      });
  };

  // Delete BillingType
  const handleDeleteBillingType = (columns, module) => {
    deleteBillingType(columns.id)
      .then((res) => {
        newdisplaySucess(module, res);
      })
      .catch((err) => {
        newdisplayError(module, err);
      });
  };

  // Delete ClientType
  const handleDeleteClientType = (columns, module) => {
    deleteClientType(columns.id)
      .then((res) => {
        newdisplaySucess(module, res);
      })
      .catch((err) => {
        newdisplayError(module, err);
      });
  };

  // handleDeleteClient
  const handleDeleteClient = (columns, module) => {
    deleteClient(columns.id)
      .then((res) => {
        newdisplaySucess(module, res);
      })
      .catch((err) => {
        newdisplayError(module, err);
      });
  };

  // Permite el cambio de estado de un registro
  const handleToggle = () => {
    switch (pageName) {
      case "Cargos":
        toggleCargos();
        break;

      case "Contratos":
        toggleTipoContrato();
        break;

      case "Parametros":
        toggleParametros();
        break;

      case "Tercero":
        toggleTerceros();
        break;

      case "Empleado":
        toggleEmpleado();
        break;

      default:
        newhandleToggle();
        break;
    }
  };

  const newhandleToggle = () => {
    // FIXME: hay que refactorizar esto, ya que no esta para varios idiomas
    if (pageName[0] === "Unidades de negocio") {
      // TODO: Mejorar la logica de esto
      toggleBusinessUnit();
    } else if (pageName === "Mercados") {
      toggleMarkets();
    } else if (pageName[0] === "Tipos de proveedor") {
      toggleProviderType();
    } else if (pageName[0] === "Tipos de clientes") {
      toggleClientType();
    } else if (pageName[0] === "Tipos de facturación") {
      toggleBillingType();
    } else if (pageName[0] === "Cliente") {
      toggleClient();
    } else {
      console.log("No tiene funcionalidad");
    }
  };

  const toggleCargos = () => {
    const estado = stateAux === 1 ? 0 : 1;
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();
    const newData = {
      estado: [
        {
          id_cargo: columns.id,
          estado: estado,
        },
      ],
    };

    updateStateCargo(newData)
      .then(() => {
        displayToast("success", "Se actualizó el cargo correctamente.");
        setStateAux(estado);
        setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleTipoContrato = () => {
    const estado = stateAux === 1 ? 0 : 1;
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();
    const newData = {
      estado: [
        {
          id_tipoContrato: columns.id,
          estado: estado,
        },
      ],
    };

    updateStateContract(newData)
      .then(() => {
        displayToast(
          "success",
          "Se actualizó el tipo de contrato correctamente.",
        );
        setStateAux(estado);
        setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleParametros = () => {
    const estado = stateAux === 1 ? 0 : 1;
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      idTipoTercero: columns.id,
      nombre: columns.objeto.nombre,
      descripcion: columns.objeto.descripcion,
      codigo: columns.objeto.codigo,
      estado: estado,
      fechaRegistro: columns.objeto.fechaRegistro,
      fechaModificacion: null,
      usuarioCreacion: columns.objeto.usuarioCreacion,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateThirdType(newData)
      .then(() => {
        displayToast(
          "success",
          "Se actualizó el tipo de tercero correctamente.",
        );
        setStateAux(estado);
        setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleEmpleado = () => {
    const estado = stateAux === 1 ? 0 : 1;
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateEmployee(newData)
      .then(() => {
        displayToast("success", "Se actualizó el empleado correctamente.");
        setStateAux(estado);
        setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleTerceros = () => {
    const estado = stateAux === 1 ? 0 : 1;
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateThirdParty(newData)
      .then(() => {
        displayToast("success", "Se actualizó el tercero correctamente.");
        setStateAux(estado);
        setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleBusinessUnit = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateBusinessUnit(newData)
      .then(() => {
        getData();
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleMarkets = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateMarket(newData)
      .then(() => {
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
        getData();
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleProviderType = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateProviderType(newData)
      .then(() => {
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
        getData();
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };
  const toggleClientType = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateClientType(newData)
      .then(() => {
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
        getData();
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleBillingType = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateBillingType(newData)
      .then(() => {
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
        getData();
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const toggleClient = () => {
    const estado = stateAux === 1 ? 0 : 1;
    // const currentDate = new Date();
    // const formatDate = d}ateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");

    closeDialog();

    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    updateClient(newData)
      .then(() => {
        displayToast("success", "Se actualizó el registro correctamente.");
        // setStateAux(estado);
        // setDateAux(formatDate);
        getData();
      })
      .catch((err) => {
        displayToast(
          "error",
          "No se pudo actualizar, intentalo ahora más tarde.",
        );
        console.log(err);
      });
  };

  const closeDialog = () => {
    setLoading(false);
    setDialog({ ...dialog, active: false });
  };

  const displayToast = (type, msg) => {
    OnMessage(type, msg);
  };

  const displaySucess = (module, response) => {
    closeDialog();
    let newArray = [];
    CreateNewDataTable(module, response, newArray);
    // Set data new table
    setDataTable(newArray);
    setSearchResults(newArray);
    CustomAlert("short_msg", {
      icon: "success",
      title: `Se eliminó el ${module} ${columns.nombre}`,
      text: formatterText("alert.action.confirm.general"),
    });
  };

  const newdisplaySucess = (moduleText, response) => {
    closeDialog();
    let newArray = [];
    newCreateNewDataTable(moduleText, response, newArray);
    // Set data new table
    setDataTable(newArray);
    setSearchResults(newArray);
    CustomAlert("short_msg", {
      icon: "success",
      title: `Se eliminó el ${moduleText.toLowerCase()} ${columns.nombre}`,
      text: formatterText("alert.action.confirm.general"),
    });
  };

  function newCreateNewDataTable(moduleText, response, newArray) {
    const index = idLang.findIndex((id) => {
      const textCurrentLang = formatterText(id);
      return textCurrentLang === moduleText;
    });

    const CHOOSE_TABLE_STRUCTURE = {
      0: DataTableCargo,
      1: DataTableContract,
      2: DataTableEmployee,
      3: DataTableTypeTercero,
      4: DataTableTercero,
      5: DataTableTechnicalOperators,
      6: DataTableVehicleTechnicalOperators,
      7: DataTableMarket,
      8: DataTableBusinessUnit,
      9: DataTableProviderType,
      10: DataTableClientType,
      11: DataTableBillingType,
      12: DataTableClient,
    };

    if (index !== -1) {
      CHOOSE_TABLE_STRUCTURE[index](response, newArray);
    } else {
      console.log("No se creo un nuevo array para el módulo");
    }
  }

  const displayError = (module, err) => {
    console.log(err);
    closeDialog();

    let textMsg = "";
    if (module === "cargo" || module === "contrato") {
      textMsg = `Este ${module} está relacionado a un empleado `;
    } else {
      textMsg = `El ${module} tiene relación con otras tablas`;
    }

    CustomAlert("short_msg", {
      icon: "error",
      title: `No se pudo eliminar el ${module} ${columns.nombre}`,
      text: textMsg,
    });
  };

  const newdisplayError = (module, err) => {
    console.log(err);
    closeDialog();

    let textMsg = "";
    if (module === "cargo" || module === "contrato") {
      textMsg = `Este ${module} está relacionado a un empleado `;
    } else {
      textMsg = `El ${module.toLowerCase()} tiene relación con otras tablas`;
    }

    CustomAlert("short_msg", {
      icon: "error",
      title: `No se pudo eliminar el ${module.toLowerCase()} ${columns.nombre}`,
      text: textMsg,
    });
  };

  const displayColor = (date) => {
    // Realizar un calculo de la fecha de vencimiento del soat para determinar si esta vencido o no, siendo 90 días a partir de la fecha de registro con color amarillo, 30 dias color naranja y color rojo si esta vencido
    const currentDate = new Date();
    const formatDate = dateFormat(currentDate, "yyyy/mm/dd - h:MM:ss TT");
    const date1 = new Date(date);
    const date2 = new Date(formatDate);
    const timeDiff = date1.getTime() - date2.getTime();
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    console.log(diffDays);
    if (diffDays >= 90 && diffDays > 30) {
      return "#FFC954";
      // return "yellow";
    } else if (diffDays <= 30 && diffDays > 0) {
      console.log("color naranja");
      return "#F4A64A";
      // return "orange";
    } else if (diffDays <= 0) {
      console.log("color rojo");
      return "#DD3333";
      // return "red";
    } else {
      console.log("no entro a ninguna, color de respaldo");
      return "gray";
    }
  };

  return (
    <>
      <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
        {Object.keys(columns).map((column, index) => {
          if (
            column === "id" ||
            column === "objeto" ||
            column === "usuarioCreacion" ||
            column === "fc" ||
            column === "uc"
          ) {
            return null;
          }
          if (column === "estado") {
            return (
              <TableCell
                className={loading ? "disabled" : "enabled"}
                align="center"
                key={index}
              >
                {stateAux === 1 ? (
                  <button
                    className="btn-state"
                    disabled={loading}
                    onClick={() =>
                      setDialog({
                        text: `Vas a cambiar el estado de ${columns.nombre} por Inactivo`,
                        active: true,
                        funcion: () => handleToggle(),
                      })
                    }
                  >
                    Activo
                  </button>
                ) : (
                  <button
                    className="btn-inactive_state"
                    disabled={loading}
                    onClick={() => {
                      setDialog({
                        text: `Vas a cambiar el estado de ${columns.nombre}`,
                        active: true,
                        action: "active",
                        funcion: () => handleToggle(),
                      });
                    }}
                  >
                    Inactivo
                  </button>
                )}
              </TableCell>
            );
          }
          if (column === "fechaModificacion") {
            return (
              <TableCell align="left" key={index}>
                {dateAux}
              </TableCell>
            );
          }
          if (column === "vencimientoSoat") {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: "none",
                    color: "white",
                    borderRadius: "15px",
                    fontWeight: "700",
                    padding: "0.7rem",
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          if (column === "vencimientoTecnicoMecanico") {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: "none",
                    color: "white",
                    borderRadius: "15px",
                    fontWeight: "700",
                    padding: "0.7rem",
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          if (column === "vencimientoRunt") {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: "none",
                    color: "white",
                    borderRadius: "15px",
                    fontWeight: "700",
                    padding: "0.7rem",
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          return (
            <TableCell
              key={index}
              component="th"
              scope="row"
              className="enabled"
            >
              {columns[column]}
            </TableCell>
          );
        })}

        {titles.includes("Acciones") && (
          <TableCell
            className={loading ? "disabled" : "enabled"}
            align="center"
          >
            <MdEdit
              size={25}
              color="gray"
              cursor="pointer"
              disabled={loading}
              onClick={() => handleEdit(columns.id)}
            />
            <MdDelete
              size={25}
              color="gray"
              cursor="pointer"
              onClick={() =>
                setDialog({
                  text: `Vas a eliminar ${columns.nombre}`,
                  active: true,
                  action: "delete",
                  funcion: () => handleDelete(columns),
                })
              }
              disabled={loading}
            />
          </TableCell>
        )}
        {titles.includes("Eliminar") && (
          <TableCell
            className={loading ? "disabled" : "enabled"}
            align="center"
          >
            <MdDelete
              size={25}
              color="gray"
              cursor="pointer"
              onClick={() =>
                setDialog({
                  text: `Vas a eliminar ${columns.nombre}`,
                  active: true,
                  action: "delete",
                  funcion: () => handleDelete(columns),
                })
              }
              disabled={loading}
            />
          </TableCell>
        )}
        <WarningDialog dialog={dialog} setDialog={setDialog} />
      </TableRow>
      <CustomComponentToast />
    </>
  );
};

export default NewDynamicCell;

function CreateNewDataTable(module, response, newArray) {
  switch (module) {
    case "cargo":
      DataTableCargo(response, newArray);
      break;
    case "contrato":
      DataTableContract(response, newArray);
      break;
    case "empleado":
      DataTableEmployee(response, newArray);
      break;
    case "tipo de tercero":
      DataTableTypeTercero(response, newArray);
      break;
    case "tercero":
      DataTableTercero(response, newArray);
      break;
    case "operador-tecnico":
      DataTableTechnicalOperators(response, newArray);
      break;
    case "vehiculo-tecnico":
      DataTableVehicleTechnicalOperators(response, newArray);
      break;
    case "mercado":
      DataTableMarket(response, newArray);
      break;
    default:
      console.log("No se creo un nuevo array para el módulo");
      break;
  }
}

function DataTableCargo(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idCargo,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
    });
  });
}

function DataTableTypeTercero(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idTipoTercero,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
    });
  });
}

function DataTableTercero(response, newArray) {
  response.forEach((data) => {
    let docType = `${data.idTipoDocumento.nombre} - ${data.idTipoDocumento.abreviatura}`;
    newArray.push({
      id: data.idTercero,
      nombre: data.nombre,
      tipo_documento: docType,
      documento: data.identificacion,
      municipio: data.idMunicipio.nombre,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}

function DataTableContract(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idTipoContrato,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
    });
  });
}

function DataTableEmployee(response, newArray) {
  response.forEach((data) => {
    let completeName = `${data.primerNombre} ${data.segundoNombre} ${data.primerApellido} ${data.segundoApellido}`;
    let formatedDate = data.fechaRegistro
      ? dateFormat(data.fechaRegistro, "yyyy/mm/dd - h:MM:ss TT")
      : "No tiene un valor";
    let typeDocument = `${data.idTipoDocumento.nombre} - ${data.idTipoDocumento.abreviatura}`;

    newArray.push({
      id: data.idEmpleado || "No tiene un valor",
      nombre: completeName,
      tipoDocumento: typeDocument,
      documento: data.identificacion || "No tiene un valor",
      municipio: data.idMunicipio.nombre || "No tiene un valor",
      estado: data.estado || "No tiene un valor",
      cargo: data.cargo.nombre || "No tiene un valor",
      tipoContrato: data.tipoContrato.nombre || "No tiene un valor",
      fechaRegistro: formatedDate,
      objeto: { ...data },
    });
  });
}

function DataTableTechnicalOperators(response, newArray) {
  response.forEach((data) => {
    let completeName = `${data.idEmpleado.primerNombre} ${data.idEmpleado.segundoNombre} ${data.idEmpleado.primerApellido} ${data.idEmpleado.segundoApellido}`;

    newArray.push({
      id: data.idTecnico,
      documento: data.idEmpleado.identificacion || "No tiene un valor",
      nombre: completeName,
      cargo: data.idEmpleado.cargo.nombre || "No tiene un valor",
      tipoContrato: data.idEmpleado.tipoContrato.nombre || "No tiene un valor",
      fechaCreacion:
        dateFormat(data.fechaCreacion, "yyyy/mm/dd - h:MM:ss TT") ||
        "No tiene un valor",
      objeto: { ...data },
    });
  });
}

function DataTableVehicleTechnicalOperators(response, newArray) {
  response.forEach((data) => {
    let completeName = `${data.idTecnico.idEmpleado.primerNombre} ${data.idTecnico.idEmpleado.segundoNombre} ${data.idTecnico.idEmpleado.primerApellido} ${data.idTecnico.idEmpleado.segundoApellido}`;
    newArray.push({
      id: data.idVehiculo,
      documento:
        data.idTecnico.idEmpleado.identificacion || "No tiene un valor",
      nombre: completeName,
      cargo: data.idTecnico.idEmpleado.cargo.nombre || "No tiene un valor",
      tipoContrato:
        data.idTecnico.idEmpleado.tipoContrato.nombre || "No tiene un valor",
      runt: data.runt || "No tiene un valor",
      vencimientoSoat:
        dateFormat(data.fechaSoap, "yyyy/mm/dd") || "No tiene un valor",
      vencimientoRunt:
        dateFormat(data.fechaRunt, "yyyy/mm/dd") || "No tiene un valor",
      vencimientoTecnicoMecanico:
        dateFormat(data.fechaTecnicoMecanica, "yyyy/mm/dd") ||
        "No tiene un valor",
      objeto: { ...data },
    });
  });
}

function DataTableMarket(response, newArray) {
  response.forEach((data) => {
    const paises =
      data.paises === null
        ? "No hay paises"
        : data.paises.map((pais, index) =>
            index === data.paises.length - 1
              ? pais.nombrePais + " "
              : pais.nombrePais + ", ",
          );

    newArray.push({
      id: data.idMercado,
      nombre: data.nombre,
      descripcion: data.descripcion,
      paises: paises,
      codigo: data.codigo,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}

function DataTableBusinessUnit(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idUnidadNegocio || "" || "",
      nombre: data.nombre || "",
      descripcion: data.descripcion || "",
      codigo: data.codigo || "",
      // mercados: data.idMercado.nombre || "",
      estado: data.estado || "",
      objeto: { ...data },
    });
  });
}

function DataTableProviderType(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idTipoProveedor,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}

function DataTableClientType(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idTipoCliente,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}

function DataTableBillingType(response, newArray) {
  response.forEach((data) => {
    newArray.push({
      id: data.idTipoFacturacion,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}

function DataTableClient(response, newArray) {
  response.forEach((data) => {
    let docType = `${data.idTipoDocumento.nombre} - ${data.idTipoDocumento.abreviatura}`;
    newArray.push({
      id: data.idCliente,
      nombre: data.nombreRazonSocial,
      tipo_documento: docType,
      documento: data.identificacion,
      estado: data.estado,
      objeto: { ...data },
    });
  });
}
