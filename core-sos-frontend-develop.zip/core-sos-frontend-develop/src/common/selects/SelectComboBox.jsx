import { useState } from "react";
// Import Material UI Components
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
// Import Libs
// Import Styles
import { isEmpty } from "lodash";
import styles from "./SelectComboBox.module.css";

export default function SelectComboBox({
  name,
  selectValue,
  setterFunction,
  data,
  placeholder,
}) {
  const [inputValue, setInputValue] = useState("");

  return (
    <Autocomplete
      disablePortal
      id={name}
      options={data}
      className={styles.container}
      sx={{ padding: 0, margin: 0 }}
      value={selectValue}
      onChange={(event, newValue) => {
        if (!isEmpty(newValue)) setterFunction(newValue);
        else setterFunction({ id: 0, label: "" });
      }}
      classes={{
        option: styles.menuItem,
        listbox: styles.menuList,
        noOptions: styles.noOptions,
        groupLabel: styles.headerItem,
        notchedOutline: styles.notchedOutline,
        input: styles.inputData,
      }}
      inputValue={inputValue}
      onInputChange={(event, newInputValue) => {
        setInputValue(newInputValue);
      }}
      renderInput={(params) => <TextField {...params} label={placeholder} />}
    />
  );
}

