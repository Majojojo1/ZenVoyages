import React, { useEffect, useState } from 'react';
import Select from "react-select";
import { useField } from '@formiz/core';
import customStyles2 from 'common/selects/generic.style.select';

export const FieldSelect = (props) => {
    const {
        errorMessage,
        id,
        isValid,
        isSubmitted,
        resetKey,
        setValue,
        value,
        otherProps
    } = useField(props);
    const { required, name } = props;
    const {
        setterFunction, data, noOptionsMessage, label, options = [], placeholder, helper, ...rest
    } = otherProps;
    const [isTouched, setIsTouched] = useState(false);
    const showError = !isValid && (isTouched || isSubmitted);

    useEffect(() => {
        setIsTouched(false);
    }, [resetKey]);

    useEffect(() => {
        if (data) {
            setValue(data)
        }
    }, [data]);

    const handleData = (e) => {
        console.log(e)
        setterFunction(e)
        setValue(e)
    };

    return (
        <Select
            id={id}
            value={value}
            onBlur={() => setIsTouched(true)}
            aria-invalid={showError}
            aria-describedby={!isValid ? `${id}-error` : undefined}
            placeholder={placeholder}
            onChange={handleData}
            styles={customStyles2}
            noOptionsMessage={noOptionsMessage}
            // isDisabled={!!disabled}
            options={options}
        />
    );
};

{/* <FieldSelect
    // eslint-disable-next-line react/no-array-index-key
    name={'idListaPrecios'}
    label={'idListaPrecios'}
    required="Required"
    options={listPrices}
    data={auxData.idListaPrecios}
    setterFunction={setAuxData}
/> */}