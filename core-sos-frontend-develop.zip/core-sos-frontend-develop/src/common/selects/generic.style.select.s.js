const customStyles2 = {
  control: (base, state) => ({
    ...base,
    width: "250px",
    margin: "15px 0 0 0",
    borderRadius: "70px",
    boxShadow: "0px 4px 8px rgba(0, 174, 142, 0.2)",
    border: "0px !important",
    padding: "0 6px",
    // "max-width": "20rem",
    minWidth: "250px",
  }),
  menu: (styles) => ({
    ...styles,
    width: "250px",
    zIndex: "2",
  }),
};

export default customStyles2;
