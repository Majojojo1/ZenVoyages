import React, { useState, useEffect } from "react";
import Select from "react-select";
import { FormattedMessage } from "react-intl";
import useLang from "hooks/useLang";
import customStyles from "./selects/default.select.style";

export default function SelectorMulti({
  data,
  isLoading,
  dataValue,
  setterFunction,
  isRequired,
}) {
  const [selectedOption, setSelectedOption] = useState(null);
  const { formatterText } = useLang();

  useEffect(() => {
    setSelectedOption(dataValue);
  }, [dataValue]);

  return (
    <>
      <Select
        styles={customStyles}
        value={dataValue}
        onChange={(selectedOption) => {
          setterFunction(selectedOption);
        }}
        isMulti
        noOptionsMessage={() => formatterText("select.placeholder.no.options")}
        name="multiple-select"
        options={data}
        className="basic-multi-select"
        classNamePrefix="select"
        placeholder={
          isLoading ? (
            <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
          ) : (
            <FormattedMessage
              id="input.placeholder.select"
              defaultMessage="Selecciona una opción"
            />
          )
        }
      />
      <input
        className="input-required"
        type="text"
        defaultValue={selectedOption || ""}
        value={selectedOption || ""}
        autoComplete="off"
        required={isRequired}
      />
    </>
  );
}
