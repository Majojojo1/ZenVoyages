import { useField } from "@formiz/core";
import React, { useEffect } from "react";

export const InputFieldDV = (props) => {
  const { errorMessage, id, isValid, isSubmitted, setValue } =
    useField(props);
  const {
    type,
    name,
    required,
    placeholder,
    disabled,
    values,
    labelText,
  } = props;
  const [isTouched, setIsTouched] = React.useState(false);
  const showError = !isValid && (isTouched || isSubmitted);


  useEffect(() => {
    setValue(values);
  }, [values, setValue]);

  return (
    <label className="d-flex">
      <span className="text-inline">{labelText}</span>
      <section className="w100-container">
        <input
          id={id}
          type={type || "text"}
          value={values || ""}
          name={name}
          onChange={(e) => {
            setValue(e.target.value);
          }}
          onBlur={() => setIsTouched(true)}
          placeholder={placeholder}
          className={
            disabled ? "input-default-3c disable-input" : "input-default-3c"
          }
          aria-invalid={showError}
          aria-required={!!required}
          aria-describedby={showError ? `${id}-error` : null}
          disabled={disabled}
        />
        {showError && (
          <span id={`${id}-error`} className="error-msg">
            {errorMessage}
          </span>
        )}
      </section>
    </label>
  );
};
