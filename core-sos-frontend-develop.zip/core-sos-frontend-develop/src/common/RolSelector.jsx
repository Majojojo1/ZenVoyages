import React from 'react';
import Search from './Search';

import { useSeachContext } from 'context/SearchContext';
import '../styles/rolSelector.css';

const RolSelector = ({ handleAdd }) => {
  const { searchResults = [] } = useSeachContext();
  return (
    <div className="searchRol">
      <Search width={'100%'} />
      <table className="scroll">
        <tbody>
          {searchResults.map((rol, index) => (
            <tr key={index}>
              <td>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    handleAdd(rol);
                  }}
                >
                  {rol.nombre}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RolSelector;
