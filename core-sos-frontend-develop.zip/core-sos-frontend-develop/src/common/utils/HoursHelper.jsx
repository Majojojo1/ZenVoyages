const HOURS = JSON.parse(localStorage.getItem('hours'));
const getValueHour = (idHora) => {
    const res = HOURS.find(elem=>elem.idHora === idHora);
    return res.valor;
};

export { getValueHour };

