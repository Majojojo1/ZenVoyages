import React, { useState } from 'react';
// Mui Cell row style
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import BtnAssignAgenda from 'common/minimalTables/actions/BtnAssignAgenda';
// Import Libs
import PropTypes from 'prop-types';

const RowTechnicalNoAssign = ({ item, i, type }) => {
  return item.tech ? (
    <TableRow key={i}>
      <TableCell>{item.tech}</TableCell>
      <TableCell>
        <BtnAssignAgenda item={item} type={type} />
      </TableCell>
    </TableRow>
  ) : (
    ''
  );
};

RowTechnicalNoAssign.propTypes = {
  item: PropTypes.object,
  i: PropTypes.number,
  type: PropTypes.string,
};

export default RowTechnicalNoAssign;
