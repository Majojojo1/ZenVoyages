import React, { useEffect, useRef, useState } from 'react';
// Import context
import WarningDialog from 'components/tableOptions/WarningDialog';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
// Import Libs
// Import Styles
import 'styles/minimalTable.css';
// Services module
import RowTypeServiceActivity from './serviceModule/RowTypeServiceActivity';
// Technical module
import RowAssociateCoverage from './technicalModule/RowAssociateCoverage';
import RowClienteSucursal from './technicalModule/RowClientSucursal';
import RowUnityBusiness from './technicalModule/RowUnityBusiness';
// Agenda module
import { useSeachContext } from 'context/SearchContext';
import RowTechnicalAssigned from './agenda/RowTechnicalAssigned';
import RowTechnicalNoAssign from './agenda/RowTechnicalNoAssign';
import RowTimeZoneSchedule from './agenda/RowTimeZoneSchedule';

export default function MultiTableMinimal({
  titles,
  data,
  type,
  max,
  canSearch,
  handleDelete,
  dialog,
  setDialog,
  closeDialog,
  auxFunction,
}) {
  const {
    searchUnitBussines = [],
    searchCoverage = [],
    searchResults = [],
    searchSucursal = [],
    activitiesResults,
    handleSearch,
    handleSearchUnityBussines,
    handleSearchClientSucursal,
    handleSearchModalFranjas,
    handleSearchCoverage,
    dataTableTechnical,
    dataTableTechToAssign,
    timeZoneSelected,
  } = useSeachContext();
  // use Hook of language v2
  const { formatterText } = useLangv2();
  // Choose a row
  const ChooseRow = (item, i) => {
    switch (type) {
      case 'associateBussinesTech':
        return (
          <RowUnityBusiness
            item={item}
            key={i}
            setDialog={setDialog}
            handleDelete={handleDelete}
            closeDialog={closeDialog}
            type={type}
          />
        );
      case 'clientSucursal':
        return (
          <RowClienteSucursal
            item={item}
            key={i}
            handleDelete={handleDelete}
            setDialog={setDialog}
            closeDialog={closeDialog}
          />
        );
      case 'associateCoverage':
        return (
          <RowAssociateCoverage
            item={item}
            key={i}
            handleDelete={handleDelete}
            setDialog={setDialog}
            closeDialog={closeDialog}
          />
        );

      case 'technicalNoAssign':
        const active = item.obj?.estado === 1 ? item : {};
        return <RowTechnicalNoAssign item={active} key={i} type={type} />;

      case 'technicalAssign':
        return <RowTechnicalAssigned item={item} key={i} type={type} handleDelete={handleDelete} />;
      case 'typeServiceActivities':
        return (
          <RowActivities
            item={item}
            key={i}
            handleDelete={handleDelete}
            setDialog={setDialog}
            closeDialog={closeDialog}
          />
        );
      case 'typeServiceActivity':
        return (
          <RowTypeServiceActivity
            item={item}
            key={i}
            handleDelete={handleDelete}
            setDialog={setDialog}
            closeDialog={closeDialog}
          />
        );
      case 'franjasHorariaSchedule':
        return <RowTimeZoneSchedule item={item} key={i} />;

      default:
        console.log('No se encontro el tipo de tabla');
        break;
    }
  };
  const searchRef = useRef(null);
  const [resultSearch, setResultSearch] = useState(data);

  useEffect(() => {
    setResultSearch(data);
  }, [data]);

  const renderBody = (type) => {
    const typeToDataMap = {
      typeServiceActivity: activitiesResults,
      associateBussinesTech: searchUnitBussines,
      clientSucursal: searchSucursal,
      associateCoverage: searchCoverage,
      technicalAssign: dataTableTechnical,
      technicalNoAssign: dataTableTechToAssign,
      franjasHorariaSchedule: timeZoneSelected,
    };

    const dataToRender = typeToDataMap[type] || searchResults;

    return dataToRender.map((item, i) => ChooseRow(item, i));
  };

  return (
    <>
      <div className={max ? 'table-minimal-container width-100' : 'table-minimal-container'}>
        {canSearch && (
          <div style={{ width: '50%' }} className="wrap">
            <div className="search">
              <input
                type="text"
                className="searchTerm spacing-b1"
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                ref={searchRef}
                onChange={
                  type === 'associateBussinesTech'
                    ? handleSearchUnityBussines
                    : type === 'clientSucursal'
                    ? handleSearchClientSucursal
                    : type === 'associateCoverage'
                    ? handleSearchCoverage
                    : type == 'technicalNoAssign'
                    ? handleSearchModalFranjas
                    : handleSearch
                }
              />
              <button
                type="button"
                onClick={(e) =>
                  type === 'associateBussinesTech'
                    ? handleSearchUnityBussines(e)
                    : type === 'clientSucursal'
                    ? handleSearchClientSucursal(e)
                    : type === 'associateCoverage'
                    ? handleSearchCoverage
                    : handleSearch(e)
                }
                className="searchButton"
              >
                <img
                  src={require('assets/search.png')}
                  style={{ height: '20px' }}
                  alt="search logo"
                />
              </button>
            </div>
          </div>
        )}
        <TableContainer component={Paper}>
          <Table className="table-minimal">
            <TableHead>
              <TableRow className="infoo">
                {titles.map((title, index) => (
                  <th scope="col" key={index}>
                    {title}
                  </th>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {renderBody(type)}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      <WarningDialog dialog={dialog} setDialog={setDialog} />
    </>
  );
}
