import React, { useState, useEffect } from "react";
// Mui Cell row style
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import BtnActions from "common/minimalTables/BtnActions";
const RowClienteSucursal = ({
  item,
  i, // index
  setDialog,
  closeDialog,
  handleDelete,
}) => {
  const [rowState, setRowState] = useState(item.estado);

  return (
    <TableRow key={i}>
      <TableCell>{item?.nombreCliente}</TableCell>
      <TableCell>{item?.tipoId?.label}</TableCell>
      <TableCell>{item?.numberId}</TableCell>
      <TableCell>{item?.citySucursal?.label}</TableCell>
      <TableCell>{item?.departamento?.label}</TableCell>
      <TableCell>{item?.pais?.label}</TableCell>

      <BtnActions
        item={item}
        rowState={rowState}
        setDialog={setDialog}
        handleDelete={handleDelete}
      />
    </TableRow>
  );
};

export default RowClienteSucursal;
