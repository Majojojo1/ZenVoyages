import React from "react";
// Mui Cell row style
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import BtnAssignSearch from "common/minimalTables/BtnAssignSearch";
import BtnSeeDetails from "common/minimalTables/BtnSeeDetails";
// Import services

const RowAssignTech = ({
  item,
  i, // index
  setDialog,
  handleDetails,
  handleSelect,
}) => {
  const handleDelete = (row) => {
    console.log("b");
  };

  const handleEdit = (row) => {
    console.log("a");
  };

  const handleColor = (item) => {
    let number = item;

    // si el numero es menor a 20.0 minutos devuelve uin texto rojo
    if (number < 20.0 && number >= 0.0) {
      return (
        <div
          style={{
            backgroundColor: "red",
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          Alta
        </div>
      );
    } else if (number > 20.0 && number < 40.0) {
      return (
        <div
          style={{
            backgroundColor: "orange",
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          Media
        </div>
      );
    } else {
      return (
        <div
          style={{
            backgroundColor: "yellow",
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          Baja
        </div>
      );
    }
  };

  return (
    <TableRow key={i}>
      <TableCell>{item.label}</TableCell>
      <TableCell>{item.docId}</TableCell>
      <TableCell>{item.isPrincipal ? "Principal" : "Auxiliar"}</TableCell>
      <TableCell>
        {new Date(item.dateAndTime?.d).toISOString().split("T")[0]}
      </TableCell>
      <TableCell>{item.dateAndTime?.h}</TableCell>
      {/* <TableCell>{handleColor(item.tiempoDisponibilidadInicio)}</TableCell> */}
      {/* <TableCell>{handleColor(item.tiempoDisponibilidadFin)}</TableCell> */}
      {/* <BtnSeeDetails item={item} handleDetails={handleDetails} /> */}
      {/* <BtnAssignSearch item={item} handleSelect={() => handleSelect(item)} /> */}
    </TableRow>
  );
};

export default RowAssignTech;
