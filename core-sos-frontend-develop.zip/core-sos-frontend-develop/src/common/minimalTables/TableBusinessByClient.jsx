import { useSeachContext } from 'context/SearchContext';
import { TableMinimalContext } from 'context/TableMinimalContext';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import React, { useContext } from 'react';
import { MdDelete } from 'react-icons/md';
import endpoints from 'services/api';
import { updateItem } from 'services/api/methods';

const TableBusinessByClient = ({ data, setDialog, closeDialog, handleOpen }) => {
  const {  setDataTable } = useSeachContext();
  const { setDataTableUnits, dataTableUnits} = useContext(TableMinimalContext);
  const { formatterText } = useLangv2();

  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();

  const displayError = () => {
    if (error) {
      return displayMessage(
        'error',
        'Ha ocurrido un error, intentalo más tarde.',
        'toast.error.general',
      );
    } else {
      return displayLoading();
    }
  };

  const handleDelete = (column, index) => {
    toggleLoading(true);
    console.log('3ntre en el delete');

    if (typeof column.idUnidadNegocio !== 'number') {
      updateItem(endpoints.businessUnit.updateBusinessUnitByClient, column.idUnidadNegocio)
        .then((res) => {
          setDataTable(
            data.filter((_, i) => {
              return i !== index;
            }),
          );
          toggleLoading(false);
        })
        .catch((err) => {
          console.log(err);
          toggleLoading(false);
        });
    } else {
      // filter in the array data the index selected and slice it
      const t = data.filter((_, i) => {      
        return i !== index;
      });
      setDataTableUnits(t);
      toggleLoading(false);
    }
    closeDialog();
  };

  return data.map((item, index) => (
    <>
      {!loading ? (
        <>
          <tr key={`${item?.idUnidadNegocio || index}`}>
            {/* <td>{item.codigo}</td> */}
            <td>{item?.nombre || ''}</td>
            <td>
              <MdDelete
                size={25}
                color="gray"
                cursor="pointer"
                onClick={() =>
                  setDialog({
                    text: `${formatterText('title.service.confirm.delete.row.category')}`,
                    active: true,
                    action: 'delete',
                    funcion: () => handleDelete(item, index),
                  })
                }
              />
            </td>
          </tr>
        </>
      ) : (
        displayError()
      )}
    </>
  ));
};

export default TableBusinessByClient;
