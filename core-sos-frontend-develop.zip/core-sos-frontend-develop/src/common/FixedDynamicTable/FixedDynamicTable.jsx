import React, { useContext, useRef, useState } from 'react';
// Import context
import WarningDialog from 'components/tableOptions/WarningDialog';
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableFooter from '@mui/material/TableFooter';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import UserPaginateActions from 'components/tableOptions/UserPaginateActions';
import { useSeachContext } from 'context/SearchContext';
import { Link } from 'react-router-dom';
import 'styles/minimalTable.css';

export default function FixedDynamicTable({
  titles,
  labelTable,
  canSearch,
  DisplayRow,
  dialog,
  setDialog,
  closeDialog,
  canCreate,
  pathCreate,
  textCreate,
}) {
  // useEffect(() => {
  //   if (data) {
  //     setRows(data);
  //   }
  // }, [data]);
  // Call context TableMinimalContext
  const {} = useContext(TableMinimalContext);

  const { handleSearch, searchResults = [] } = useSeachContext();

  // use Hook of language v2
  const { formatterText } = useLangv2();

  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // UseRef
  const searchRef = useRef(null);

  return (
    <>
      <div>
        <section className="userOptions">
          {canSearch && (
            <div style={{ width: '50%' }} className="wrap">
              <div className="search">
                <input
                  type="text"
                  className="searchTerm"
                  placeholder={formatterText(
                    'placeholder.search.multi.items',
                    'Buscar por palabra',
                  )}
                  ref={searchRef}
                  onChange={handleSearch}
                />
                <button
                  type="button"
                  onClick={() => handleSearch({ target: searchRef.current })}
                  className="searchButton"
                >
                  <img src={require('assets/search.png')} style={{ height: '20px' }} alt="search" />
                </button>
              </div>
            </div>
          )}
          {canCreate && (
            <Link to={pathCreate}>
              <button className="btn-add">{textCreate}</button>
            </Link>
          )}
        </section>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 250 }} className="table-minimal">
            <TableHead>
              <TableRow>
                {titles.map((title, index) => (
                  <TableCell
                    key={`${index + 1}`}
                    sx={{
                      fontWeight: 'bold',
                    }}
                    align="left"
                  >
                    {title}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {(rowsPerPage > 0
                ? searchResults.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                : searchResults
              ).map((item, i) => (
                <DisplayRow
                  item={item}
                  key={`${i + 1}`}
                  setDialog={setDialog}
                  closeDialog={closeDialog}
                />
              ))}
            </TableBody>

            {canSearch && (
              <TableFooter
                sx={{
                  display: 'flex',
                  justifyItems: 'center',
                  justifyContent: 'right',
                  mt: 2,
                  mb: 2,
                }}
              >
                <TablePagination
                  sx={{
                    boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
                    marginTop: '25px',
                    borderRadius: '10px',
                  }}
                  rowsPerPageOptions={[
                    25,
                    50,
                    100,
                    200,
                    { label: 'Todos', value: searchResults.length },
                  ]}
                  colSpan={3}
                  count={searchResults.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                  ActionsComponent={UserPaginateActions}
                  labelRowsPerPage={labelTable}
                  align="center"
                />
              </TableFooter>
            )}
          </Table>
        </TableContainer>
      </div>
      <WarningDialog dialog={dialog} setDialog={setDialog} />
    </>
  );
}
