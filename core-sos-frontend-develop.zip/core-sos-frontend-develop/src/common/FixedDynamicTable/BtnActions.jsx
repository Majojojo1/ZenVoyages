import React from "react";
// Import Components
import { MdDelete, MdEdit } from "react-icons/md";
import useLangv2 from 'hooks/useLangv2';

import PropTypes from "prop-types";
const BtnActions = ({
  row,
  canModify,
  canDeleted,
  handleEdit,
  handleDelete,
  setDialog,
}) => {
  const { formatterText } = useLangv2();
  return (
    <section
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-evenly",
      }}
    >
      {canModify && (
        <MdEdit
          size={25}
          color="gray"
          cursor="pointer"
          onClick={() => handleEdit(row.id)}
        />
      )}

      {canDeleted && (
        <MdDelete
          size={25}
          color="gray"
          cursor="pointer"
          onClick={() =>
            setDialog({
              text: `${formatterText('title.service.confirm.delete')} ${row.nombre}`,
              active: true,
              action: "delete",
              funcion: () => handleDelete(row.id),
            })
          }
        />
      )}
    </section>
  );
};

BtnActions.propTypes = {
  row: PropTypes.object,
  canModify: PropTypes.bool,
  canDeleted: PropTypes.bool,
  handleEdit: PropTypes.func,
  handleDelete: PropTypes.func,
  setDialog: PropTypes.func,
};

export default BtnActions;
