import React, { useEffect } from "react";
// Import Styles
import "styles/App.css";

function Home() {
  useEffect(() => {
    //navigate to /#/panel-notificaciones
    window.location.href = "/#/panel-notificaciones";
  }, []);
  return (
    <>
      {/* <div>
        <h3 className="text-center">Test de sonidos</h3>
        <button className="btn-primary" onClick={handleSound1}>
          Option 1
        </button>
        <button className="btn-primary" onClick={handleSound2}>
          Option 2
        </button>
        <button className="btn-primary" onClick={handleSound3}>
          Option 3
        </button>
        <button className="btn-primary" onClick={handleSound4}>
          Option 4
        </button>
      </div> */}
      <div
        style={{
          padding: "1rem",
        }}
      >
        <section style={{ width: "100%", height: "25vw" }}>
          <section
            className="mx-5"
            style={{
              border: "1px solid var(--color-primary)",
              borderRadius: "1rem",
              padding: "1rem",
            }}
          >
            <h3 className="text-center">
              Bienvenid@ a los servicios de gestión de SOS asistencia
            </h3>
            <p className="mt-4 pt-4">Hola, bienvenido</p>
            {/* <button className="btn-primary" onClick={() => navigate(paths.users)}>
            Usuarios
          </button> */}
          </section>
        </section>
      </div>
    </>
  );
}

export default Home;
