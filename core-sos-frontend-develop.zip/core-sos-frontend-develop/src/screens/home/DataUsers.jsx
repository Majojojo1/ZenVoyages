import React, { useEffect, useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import DataElement from './DataElement';
import endpoints from 'services/api/index';
import TableFooter from '@mui/material/TableFooter';
import TablePagination from '@mui/material/TablePagination';
import UserPaginateActions from 'components/tableOptions/UserPaginateActions';
import dateFormat from 'dateformat';
import { Link } from 'react-router-dom';
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import Cookie from 'js-cookie';
import paths from 'services/paths';
import { useLocation } from 'react-router';
import { getPerssimionModuleByUser } from 'services/api/roles';
import 'styles/userTable.css';
import { getAll } from 'services/api/methods';

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function createData(
  name,
  username,
  role,
  email,
  type_document,
  document,
  created_at,
  state,
  idUsuario,
) {
  return {
    name,
    username,
    role,
    email,
    type_document,
    document,
    created_at,
    state,
    idUsuario,
  };
}

const rows = [
  createData('User', 'Info', 'ADD', 'S@gmail.com', 'C.C', '10101010', '2020-01-01', 1, 1),
];

export default function BasicTable() {
  const [dataTable, setDataTable] = useState(rows);
  const [open, setOpen] = useState(false);
  const [userData, setUserData] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  const [data, setData] = useState([]);
  const location = useLocation();

  //Pagination
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(50);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // nuevo contexto
  const { permissionsAccess, crear, editar, eliminar, consultar, exportar, permissions } =
    usePermissionContext();

  const permissionsAccessDataUsers = () => {
    permissionsAccess(1);
  };

  useEffect(() => {
    permissionsAccessDataUsers();
  }, [permissions]);


  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  useEffect(() => {
    getData();
  }, []);

  const getData = (callback = null) => {
    // do a fecth to get the data
    getAll(endpoints.users.getAllUsers)
      .then((data) => {
        // create a new array with the data
        let newData = [];
        let newTableDownload = [];
        let stringAux = '';
        let definiteString = '';
        data.forEach((element, index) => {
          // create a string with the roles of the user
          let roles = '';
          let permission = '';
          if (element.roles.length > 0) {
            element.roles.forEach((role) => {
              permission += '(';
              roles += role.nombre + ', ';

              role.permisos.forEach((permiso) => {
                // console.log(permiso.nombre);
                permission += permiso.nombre + ', ';
              });
              permission += ')';
            });
            definiteString += `${roles} ${permission}`;
            // console.log(definiteString);
          } else {
            roles = 'Sin rol(es)';
          }

          newData.push(
            createData(
              'N/A',
              element.usuario,
              roles,
              element.correo,
              'N/A',
              'N/A',
              dateFormat(element.fechaRegistro, 'yyyy/mm/dd - h:MM:ss TT'),
              element.estado,
              element.idUsuario,
            ),
          );

          userData.push(element);
          newTableDownload.push({
            username: element.usuario,
            role: roles,
            email: element.correo,
            created_at: new Date(element.fechaRegistro).toLocaleString(),
            state: element.estado,
          });
        });

        setDataTable(newData);
        setUserData(data);
        setSearchResults(newData);
        if (callback) {
          callback();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <section className="userOptions">
        <Search placeholder="Buscar..." width="50%" />
        <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={paths.createUser}>
          {crear && <button className="btn-add">Crear Usuario</button>}
        </Link>
        {exportar && (
          <ExportJsonFile
            moduleName="Usuarios"
            userName={
              JSON.parse(localStorage.getItem('userData')).usuario
                ? JSON.parse(localStorage.getItem('userData')).usuario
                : 'ADMIN'
            }
            dataTable={dataTable}
          />
        )}
      </section>
      {consultar && (
        <>
          <TableContainer>
            <Table
              sx={{
                minWidth: 250,
                border: '1px solid rgba(0, 0, 0, 0.87)',
                width: '100%',
                justifyContent: 'center',
              }}
              aria-label="simple table"
            >
              <TableHead>
                <TableRow>
                  {/* <TableCell>Nombre (s)</TableCell> */}
                  <TableCell align="left">Usuario</TableCell>
                  <TableCell align="left">Rol (es)</TableCell>
                  <TableCell align="left">Correo electrónico</TableCell>
                  {/* <TableCell align="left">Tipo de documento</TableCell>
              <TableCell align="left">Documento</TableCell> */}
                  <TableCell align="left">Fecha de creación</TableCell>
                  <TableCell align="center">Estado</TableCell>
                  <TableCell align="center">Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(rowsPerPage > 0
                  ? searchResults.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  : searchResults
                ).map((item, index) => (
                  <DataElement
                    item={item}
                    key={index}
                    setOpen={setOpen}
                    getData={getData}
                    userData={userData[index]}
                    deletes={eliminar}
                    modify={editar}
                  />
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TableFooter
            sx={{
              display: 'flex',
              justifyItems: 'center',
              justifyContent: 'right',
              mt: 2,
              mb: 2,
            }}
          >
            <TablePagination
              sx={{
                boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
                borderRadius: '10px',
              }}
              rowsPerPageOptions={[
                25,
                50,
                100,
                200,
                { label: 'Todos', value: searchResults.length },
              ]}
              colSpan={3}
              count={searchResults.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              ActionsComponent={UserPaginateActions}
              labelRowsPerPage="Usuarios por página"
            />
          </TableFooter>
        </>
      )}
      <Stack spacing={2} sx={{ width: '100%' }}>
        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
          <Alert onClose={handleClose} severity="warning" sx={{ width: '100%' }}>
            Se esta actualizando el registro
          </Alert>
        </Snackbar>
      </Stack>
    </>
  );
}
