import TableCell from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import WarningDialog from "components/tableOptions/WarningDialog";
import React, { useState } from "react";
import { MdDelete, MdEdit } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import endpoints from "services/api";
import { deleteItem, updateItem } from "services/api/methods";
import "styles/userTable.css";

const DataElement = ({ item, setOpen, getData, userData, modify, deletes }) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [stateAux, setStateAux] = useState(item.state);
  const [dialog, setDialog] = useState({
    text: "",
    active: false,
    function: null,
  });

  const handleDelete = (id) => {
    setOpen(true);
    setLoading(true);
    deleteItem(endpoints.users.deleteUser,id)
      .then((data) => {
        getData(() => closeDialog());
      })
      .catch((error) => {
        closeDialog();
      });
  };

  const handleEdit = (id) => {
    navigate(`/editar/usuario/${id}`);
  };

  const handleToggle = (state) => {
    setOpen(true);
    setLoading(true);

    /* separar a un modelo de los datos de los db */
    const data = {
      idUsuario: userData.idUsuario,
      usuario: userData.usuario,
      correo: userData.correo,
      clave: userData.clave,
      estado: state,
      dobleAutenticacion: userData.dobleAutenticacion,
      fechaRegistro: userData.fechaRegistro,
      fechaModificacion: userData.fechaModificacion,
      tipoAcceso: userData.tipoAcceso,
      avatarUrl: userData.avatarUrl,
      idIdioma: userData.idIdioma,
      usuarioCreacion: userData.usuarioCreacion,
      usuarioModificacion: userData.usuarioModificacion,
      roles: userData.roles,
    };

    updateItem(endpoints.users.updateUser, JSON.stringify(data))
      .then(() => {
        // getData(() => closeDialog());
        setStateAux(state);
        closeDialog();
      })
      .catch(() => {
        closeDialog();
      });
  };

  const closeDialog = () => {
    setLoading(false);
    setOpen(false);
    setDialog({ ...dialog, active: false });
  };

  return (
    <TableRow>
      {/* <TableCell
        className={loading ? "disabled" : "enabled"}
        component="th"
        scope="row"
      >
        {item.name}
      </TableCell> */}
      <TableCell className={loading ? "disabled" : "enabled"} align="left">
        {item.username}
      </TableCell>
      <TableCell className={loading ? "disabled" : "enabled"} align="left">
        {item.role === "Sin rol(es)" ? "Sin rol(es)" : item.role.slice(0, -2)}
      </TableCell>
      <TableCell className={loading ? "disabled" : "enabled"} align="left">
        {item.email}
      </TableCell>
      {/* <TableCell className={loading ? "disabled" : "enabled"} align="left">
        {item.type_document}
      </TableCell>
      <TableCell className={loading ? "disabled" : "enabled"} align="left">
        {item.document}
      </TableCell> */}
      <TableCell
        sx={{ overflow: "clip" }}
        className={loading ? "disabled" : "enabled"}
        align="left"
      >
        {item.created_at}
      </TableCell>
      <TableCell className={loading ? "disabled" : "enabled"} align="center">
        {stateAux === 1 ? (
          <button
            className="btn-state"
            disabled={loading}
            onClick={() =>
              setDialog({
                text: `Vas a cambiar el estado del usuario ${item.username} por Inactivo`,
                active: true,
                funcion: () => handleToggle(0),
              })
            }
          >
            Activo
          </button>
        ) : (
          <button
            className="btn-inactive_state"
            disabled={loading}
            onClick={() =>
              setDialog({
                text: `Vas a cambiar el estado del usuario ${item.username} por Activo`,
                active: true,
                action: "active",
                funcion: () => handleToggle(1),
              })
            }
          >
            Inactivo
          </button>
        )}
      </TableCell>
      <TableCell className={loading ? "disabled" : "enabled"} align="center">
        {modify && (
          <MdEdit
            size={25}
            color="gray"
            cursor="pointer"
            disabled={loading}
            onClick={() => handleEdit(item.idUsuario)}
          />
        )}

        {deletes && (
          <MdDelete
            size={25}
            color="gray"
            cursor="pointer"
            onClick={() =>
              setDialog({
                text: `Vas a eliminar el usuario ${item.username}`,
                active: true,
                action: "delete",
                funcion: () => handleDelete(item.idUsuario),
              })
            }
            disabled={loading}
          />
        )}
      </TableCell>
      <WarningDialog dialog={dialog} setDialog={setDialog} />
    </TableRow>
  );
};

export default DataElement;
