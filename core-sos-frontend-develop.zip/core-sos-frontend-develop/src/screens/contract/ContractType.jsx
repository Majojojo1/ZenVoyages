import React, { useEffect, useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
// Import Libs
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import Services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteContract, updateContract } from 'services/api/contracts';
import { getAll } from 'services/api/methods';
import paths from 'services/paths';

const ContractType = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ContractComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function ContractComponent() {
  // hook to loading data
  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const [cargos, setCargos] = useState(null);

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.typeContract);
  };

  useEffect(() => {
    getDataTable();
  }, []);

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAll(endpoints.contracts.getAllContracts).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item));
      setDataTable(newArray);
      // show loading
      setCargos(newArray);
      toggleLoading(false);
    });
  };

  const handleDeleteItem = (id) => {
    return new Promise((resolve, reject) => {
      deleteContract(id)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });

          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateContract(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idTipoContrato,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      estado: item.estado,
      objeto: item,
    });
  };

  // titulos de la tabla
  const titles = [
    formatterText('table.title.contract.type.name', 'Nombre del tipo de contrato'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && cargos !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createContract}>
                <button className="btn-add">
                  <FormattedMessage
                    id="header.title.contract.type.create"
                    defaultMessage="Crear tipo de contrato"
                  />
                </button>
              </Link>
            )}
          </section>
          <FormattedMessage id="table.name.search.positions" defaultMessage="Cargos">
            {permittedActions.consultar &&
              ((placeholder) => (
                <DynamicTable
                  titles={titles}
                  pageName={PAGE_NAMES.Contratos}
                  getData={getDataTable}
                  handleDeleteItem={handleDeleteItem}
                  handleEditStateItem={handleEditStateItem}
                  routeToEdit={paths.updateContract}
                  canDeleted={permittedActions.eliminar}
                  canModify={permittedActions.editar}
                />
              ))}
          </FormattedMessage>
        </section>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
}

export default ContractType;
