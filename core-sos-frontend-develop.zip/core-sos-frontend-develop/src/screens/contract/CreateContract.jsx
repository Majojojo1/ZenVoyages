import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX } from "common/validators/Regex";
import { validateDuplicateName } from "common/validators/ValidateDuplicates";
import CustomAlert from "components/CustomAlert";
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import ContractType from "models/Contracts/ContractType";
import React, { useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate } from "react-router-dom";
import { addContract, getAllContracts } from "services/api/contracts";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function CreatePosition() {
  const navigate = useNavigate();
  // Datos de un formulario

  const { toggleLoading } = useGetData();
  const [formData, setFormData] = useState(new ContractType());

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      validateDuplicateName(
        formData.nombre,
        "El nombre del contrato no es válido o ya existe",
        () => getAllContracts(),
      )
    ) {
      Swal.fire({
        title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
        text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        showLoaderOnConfirm: true,
        cancelButtonColor: "#d33",
        confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
        allowOutsideClick: false,
        cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
        preConfirm: () => {
          return new Promise((resolve, reject) => {
            addContract(formData)
              .then((response) => {
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.contracts),
                });
              })
              .catch((err) => {
                if (err.response.status === 412) {                 
                  HandleOnError(formatterText('alert.message.code.error.general'));                 
                } else {
                  console.log("error");
                  HandleOnError(
                    formatterText('alert.title.contract.type.creation.error'),
                  );
                }

                console.log(err);
              });
          });
        },
      });
    }
  };

  const onError = (error) => {
    // verificar si este mensaje lo arroja el back
    CustomAlert("short_msg", {
      icon: "error",
      title: "Oops...",
      text: error,
    });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
      // instance.setPosition(e.target.name, e.target.value);
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.contract.type.name"
              defaultMessage="Nombre del tipo de contrato"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.contract.type.name",
              "Nombre del tipo de contrato",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder={formatterText(
              "input.placeholder.contract.type.code",
              "Código del tipo de contrato",
            )}
            maxLength="45"
            required
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.contracts)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
