import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
import useLangv2 from "hooks/useLangv2";
import Cookie from "js-cookie";
import ContractType from "models/Contracts/ContractType";
import React, { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import { getContractById, updateContract } from "services/api/contracts";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function UpdatePosition() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new ContractType());
  // toggle state
  const [active, setActive] = useState(false);

  useEffect(() => {
    getDataContractById();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getDataContractById = () => {
    getContractById(id)
      .then((res) => {
        setFormData(res);
        setActive(res.estado === 1);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match(TEXTREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  
  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();

    // Primera opción para crear
    const data = {
      ...formData,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
   
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText:  formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateContract(data)
            .then((response) => {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.contracts),
              });
            })
            .catch((err) => {
              if (err.response.status === 412) {
                HandleOnError(formatterText('alert.message.code.error.general'));
              } else {
                HandleOnError(
                  formatterText('alert.title.contract.type.creation.error'),
                );
              }
            });
        });
      },
    });
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.contract.type.name"
              defaultMessage="Nombre del tipo de contrato"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.contract.type.name",
              "Nombre del tipo de contrato",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder={formatterText(
              "input.placeholder.contract.type.code",
              "Código del tipo de contrato",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.contracts)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
