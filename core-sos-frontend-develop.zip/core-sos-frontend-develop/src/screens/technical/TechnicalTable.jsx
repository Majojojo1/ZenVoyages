import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import React, { useEffect, useState } from 'react';
// Import Hooks
import Search from 'common/Search';
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
import paths from 'services/paths';
import TechnicalsTable from './technicals/TechnicalsTable';
import VehiclesTable from './vehicles/VehiclesTable';

const ProductsTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ProductsTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const ProductsTableComponent = () => {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.technicians.principal);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    setSelectedTab(tabs[parseInt(localStorage.getItem('indexTab')) || 0]);
  }, [permittedActions]);

  const tabs = [
    {
      id: paths.technical,
      nombre: formatterText('header.title.technical.principal', 'Técnicos'),
      route: paths.createTechnical,
      nombreLink: (
        <FormattedMessage id="header.title.technical.create" defaultMessage="Crear Técnico" />
      ),
      componente: <TechnicalsTable />,
      exportExcel: permittedActions.exportar,
      idPermiso: MODULES_NAME.technicians.principal,
    },
    {
      id: paths.vehicleTechnical,
      nombre: formatterText('table.name.search.vehicles', 'Vehículos'),
      route: paths.vehicleTechnical,
      componente: <VehiclesTable props={permittedActions} />,
      exportExcel: permittedActions.exportar,
      idPermiso: MODULES_NAME.technicians.vehicules,
    },
  ];

  const { setSearch, searchResults = [] } = useSeachContext();

  // no pasa nada diferente cuando cambio el 0 a 1
  const [selectedTab, setSelectedTab] = useState(tabs[0]);
  return (
    <section className="table-container">
      <section className="userOptions">
        {permittedActions.consultar && (
          <Search
            placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
            width="50%"
          />
        )}
        {permittedActions.crear && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.route}>
            <button className="btn-add">{selectedTab.nombreLink}</button>
          </Link>
        )}
        {selectedTab.exportExcel && (
          <>
            {selectedTab.id === paths.vehicleTechnical ? (
              <ExportJsonFile
                moduleName={'TECNICOS'}
                userName={localStorage.getItem('userData').usuario || 'ADMIN'}
                dataTable={searchResults}
              />
            ) : (
              <ExportJsonFile
                moduleName={selectedTab.id.replace('/', '')}
                userName={JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN'}
                dataTable={searchResults}
              />
            )}
          </>
        )}
      </section>
      <Tabs selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                setSearch('');
                localStorage.setItem('indexTab', index.toString());
                permissionsAccess(tab.idPermiso);
              }}
              key={index}
              className="new-tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {permittedActions.consultar &&
          tabs.map((tab, index) => <TabPanel key={index}>{tab.componente}</TabPanel>)}
      </Tabs>
    </section>
  );
};

export default ProductsTable;
