import endpoints from "services/api";
import { getAll, getItemById } from "services/api/methods";

export const GetUnitBussines = async () => {

    getAll(endpoints.businessUnit.getAllBusinessUnits)
        .then((res) => {
            console.log("res", res);
            let newArray = [];
            res.forEach(async (item) => {
                if (item.estado === 1) {
                    await getItemById(endpoints.businessUnit.getMarketCountryByUnit, item.idUnidadNegocio).then(
                        (ans) => {
                            let country = ans[0];
                            let data = {
                                ...country,
                                value: item.idUnidadNegocio,
                                label: `${item.nombre} ${country !== undefined ? '- ' + country.idMercadoPais.mercado.nombre : ''
                                    } `,
                                code: item.codigo,
                                name: item.nombre,
                                isFixed: true,
                            };
                            newArray.push(data);
                        },
                    );
                }                
            });

            return newArray;
            
        }).catch((err) => {
            console.error(err);
        });
}