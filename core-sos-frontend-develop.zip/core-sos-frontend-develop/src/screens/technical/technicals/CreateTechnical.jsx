import React, { useEffect, useState } from 'react';
// Import Contexts
import TableMinimalNoContext from 'common/minimalTables/TableMinimalNoContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate } from 'react-router-dom';
// Import Components
import { InputFieldDV } from 'common/InputFieldDV';
import SelectorMulti from 'common/SelectorMulti';
import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import AssociateCoverage from 'common/multiTableType/AssociateCoverage';
import ClienteSucursal from 'common/multiTableType/ClienteSucursal';
import UnityBusiness from 'common/multiTableType/UnityBusiness';
import CustomAlert from 'components/CustomAlert';
// Import Libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import dateFormat from 'dateformat';
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Select from 'react-select';
import Swal from 'sweetalert2';
// Import Services
import customStyles from 'common/selects/generic.style.select';
import HandleOnError from 'common/validators/HandleOnError';
import HandleShortDate from 'common/validators/HandleShortDate';
import { CARREGEX, MODELCARREGEX } from 'common/validators/Regex';
import Attachments from 'components/AttachedFiles/Attachments';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { brandVehicles, categoryLicenses, saveVehicle } from 'services/api/institutions';
import { addItem, getAll } from 'services/api/methods';
import { addTechnical } from 'services/api/technicals';
import paths from 'services/paths';
const MODEL = {
  placa: '',
  idMarcaVehiculo: '',
  modelo: '',
  fechaTecnicoMecanica: '',
  fechaSoap: '',
  fechaRunt: '',
  runt: '',
};

export default function CreateTechnical() {
  return (
    <SearchWrapper>
      <CreateTechnicalCompnent />
    </SearchWrapper>
  );
}

function CreateTechnicalCompnent() {
  // use Hook of language v2
  const { formatterText, noFilledContent, customSB } = useLangv2();
  // title table
  const TITLE_TABLE = [
    formatterText('technicians.table.title.license.vehicle'),
    formatterText('p.vehicle.model'),
    formatterText('p.date.soat'),
    formatterText('p.date.runt'),
    formatterText('p.date.technicians.revision'),
    formatterText('table.title.runt.date'),
    formatterText('table.actions')

  ];

  // show or hide the section
  const [show, setShow] = useState(true);
  const { loading, toggleLoading } = useGetData();
  const { fetchData } = useAxios();
  const navigate = useNavigate();
  const [archivos, setCurrentFiles] = useState([]);
  const [formData, setFormData] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [thirdParties, setThirdParties] = useState([]);
  const [categoryLicense, setCategoryLicense] = useState([]);
  const [idEmployeeAux, setIdEmployeeAux] = useState(0);
  const [idThirdPartyAux, setIdThirdPartyAux] = useState(0);
  const [idUser, setIdUser] = useState(0);

  const [vehicles, setVehicles] = useState([]);
  const [currentVehicle, setCurrentVehicle] = useState(MODEL);
  const [vehiclesBrand, setVehiclesBrand] = useState([]);
  const [messageError, setMessageError] = useState('');
  const [messageErrorPlaca, setMessageErrorPlaca] = useState('');
  const now = new Date();

  const {
    secondMinimalTable,
    setSecondMinimalTable,
    thirdMinimalTable,
    setThirdMinimalTable,
    primaryMinimalTable,
    setPrimaryMinimalTable,
  } = useSeachContext();

  const handleAddFamily = () => {
    if (
      currentVehicle.placa !== '' &&
      currentVehicle.idMarcaVehiculo !== '' &&
      currentVehicle.modelo !== '' &&
      currentVehicle.fechaTecnicoMecanica !== '' &&
      currentVehicle.fechaSoap !== '' &&
      currentVehicle.fechaRunt !== '' &&
      currentVehicle.runt !== ''
    ) {
      // find in vehicles arr if the placa is already saved
      const findPlaca = vehicles.find((item) => item.placa === currentVehicle.placa);
      if (findPlaca) {
        customSB(
          'warning',
          'snackbar.warning.repeated.vehicle',
          'La placa ya existe, por favor ingrese una diferente.',
        );
      } else {
        setVehicles([...vehicles, currentVehicle]);
        setCurrentVehicle(MODEL);
        setShow(false);
        setTimeout(() => {
          setShow(true);
        }, 100);
      }
    } else {
      noFilledContent();
    }
  };

  const handleChangeRelative = (e) => {
    if (e.target.name !== 'placa') {
      setCurrentVehicle({ ...currentVehicle, [e.target.name]: e.target.value });
    } else {
      console.log(e.target.value.match(CARREGEX));
      if (e.target.value.match(CARREGEX)) {
        setMessageErrorPlaca('');
        setCurrentVehicle({
          ...currentVehicle,
          [e.target.name]: e.target.value,
        });
      } else if (e.target.value === null || e.target.value === '') {
        setMessageErrorPlaca('');
      } else {
        setMessageErrorPlaca(formatterText('p.label.title.placaFormatoIncorrecto'));
      }
    }
  };

  const handleChangeModel = (e) => {
    console.log(e.target.value.match(MODELCARREGEX));

    if (e.target.value.match(MODELCARREGEX)) {
      setMessageError('');

      setCurrentVehicle({ ...currentVehicle, [e.target.name]: e.target.value });
    } else if (e.target.value === null || e.target.value === '') {
      setMessageError('');
    } else {
      setMessageError(formatterText('p.label.title.modeloFormatoIncorrecto'));
    }
  };

  const handleChangeSelect = (selectedOption) => {
    setCurrentVehicle({
      ...currentVehicle,
      [selectedOption.target.name]:
        selectedOption.target.value === ''
          ? selectedOption.target.value
          : JSON.parse(selectedOption.target.value),
    });
  };

  const getMarcasVehiculos = () => {
    brandVehicles()
      .then((res) => {
        setVehiclesBrand(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const saveVehicles = (tecnicoInfo, resolve, reject) => {
    if (vehicles.length > 0) {
      const vehiclesPromises = vehicles.map(
        (vehicle) =>
          new Promise((resolve, reject) => {
            const data = {
              idVehiculo: null,
              placa: vehicle.placa,
              idMarcaVehiculo: {
                ...vehicle.idMarcaVehiculo,
              },
              idTecnico: {
                ...tecnicoInfo,
              },
              modelo: vehicle.modelo,
              fechaTecnicoMecanica: dateFormat(vehicle.fechaTecnicoMecanica, 'isoDateTime'),
              fechaSoap: dateFormat(vehicle.fechaSoap, 'isoDateTime'),
              fechaRunt: dateFormat(vehicle.fechaRunt, 'isoDateTime'),
              runt: vehicle.runt,
              estado: 1,
              fechaCreacion: null,
              fechaModificacion: null,
              usuarioCreacion: Cookie.get('userId'),
              usuarioModificacion: null,
            };
            saveVehicle(data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(vehiclesPromises)
        .then((res) => {
          postCategoryService(tecnicoInfo.idTecnico, resolve, reject);
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
              console.log(err.response.data);
            } else {
              console.log('error');
              HandleOnError(
                formatterText('p.label.title.tecnicoCreadoSinVehiculosAsociados'),
              );
            }
            console.log(err);
          });
        });
    } else {
      console.log('No hay vehiculos');
      postCategoryService(tecnicoInfo.idTecnico, resolve, reject);
    }
  };

  const postCategoryService = (id, resolve, reject) => {
    const promises = selectValues.map(
      (item) =>
        new Promise((resolve, reject) => {
          fetchData({
            url: endpoints.associateDataTechnical.addCategoryService,
            method: 'post',
            body: {
              idTecnico: id,
              idCategoriaServicio: item.value,
              fechaRegistro: new Date(),
              usuarioCreacion: Cookie.get('idUsuario'),
            },
          })
            .then((res) => {
              resolve(res);
            })
            .catch((err) => {
              reject(err);
            });
        }),
    );

    Promise.all(promises)
      .then((res) => {
        associateUnityBusiness(id, resolve, reject);
      })
      .catch((err) => {
        reject((err) => {
          if (err.response.status === 412) {
            HandleOnError(err.response.data);
            console.log(err.response.data);
          } else {
            console.log('error');
            HandleOnError(
              formatterText('p.label.title.tecnicoCreadoSinAsociaciones'),
            );
          }
          console.log(err);
        });
      });
  };

  //SPRINT 8 -- TODAS LAS ASOCIACIONES POST ASOCIACIONES PREVIAS
  const associateUnityBusiness = (id, resolve, reject) => {
    if (primaryMinimalTable.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = primaryMinimalTable.map((item) => {
        const data = {
          idUsuario: idUser,
          idUnidadNegocio: item.id,
        };
        addItem(endpoints.associateDataTechnical.addUnityBusiness, data)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      Promise.all(promises)
        .then((_) => {
          associateSucursal(id, resolve, reject);
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
              console.log(err.response.data);
            } else {
              console.log('error');
              HandleOnError(
                formatterText('p.label.title.tecnicoCreadoSinAsociaciones')
              );
            }
            console.log(err);
          });
        });
    } else {
      associateSucursal(id, resolve, reject);
    }
  };

  const associateSucursal = (id, resolve, reject) => {
    if (secondMinimalTable.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = secondMinimalTable.map((item) => {
        const data = {
          idUsuario: idUser,
          idSucursal: item.id,
        };
        addItem(endpoints.associateDataTechnical.addSucursal, data)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      Promise.all(promises)
        .then((_) => {
          postCoverage(id, resolve, reject);
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
              console.log(err.response.data);
            } else {
              console.log('error');
              HandleOnError(
               formatterText('p.label.title.tecnicoCreadoSinAsociaciones')
              );
            }
            console.log(err);
          });
        });
    } else {
      postCoverage(id, resolve, reject);
    }
  };

  const postCoverage = (id, resolve, reject) => {
    const data = thirdMinimalTable;
    if (data.length > 0) {
      const promises = data.map(
        (item) =>
          new Promise((resolve, reject) => {
            const data = {
              idMunicipio: item.citySucursal.value,
              idTecnico: id,
            };
            addItem(endpoints.associateDataTechnical.addCoverage, data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(promises)
        .then((res) => {
          resolve(uploadFiles(id));
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
              console.log(err.response.data);
            } else {
              console.log('error');
              HandleOnError(
                formatterText('p.label.title.tecnicoCreadoConVehiculosSinCategorias')
              );
            }
            console.log(err);
          });
        });
    } else {
      resolve(uploadFiles(id));
    }
  };

  useEffect(() => {
    getEmployeesThirdParties();
    getAllcategoryLicenses();
    getMarcasVehiculos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getEmployeesThirdParties = () => {
    toggleLoading(true);
    getAll(endpoints.technical.getEmployeesThirdPartiesNA).then((data) => {
      let arrayEmployee = [];
      let arrayThirdParties = [];

      data.forEach((item) => {
        let valueText = '';
        if (item.tipoEntidad === 1) {
          valueText = `${item.primerNombre} ${item.primerApellido} - ${item.identificacion}`;
          arrayEmployee.push({
            label: valueText,
            value: parseInt(item.id),
            idUser: parseInt(item.idUsuario),
            objeto: { ...item },
          });
        } else {
          valueText = `${item.primerNombre} - ${item.identificacion}`;
          arrayThirdParties.push({
            label: valueText,
            value: parseInt(item.id),
            idUser: parseInt(item.idUsuario),
            objeto: { ...item },
          });
        }
      });

      setThirdParties(arrayThirdParties);
      setEmployees(arrayEmployee);
      toggleLoading(false);
    });
  };

  const getAllcategoryLicenses = () => {
    toggleLoading(true);
    categoryLicenses()
      .then((response) => {
        let ArrayMunicipios = [];
        response.forEach((item) => {
          ArrayMunicipios.push({
            label: item.nombre,
            value: item.idCategoriaLicenciaConduccion,
          });
        });
        setCategoryLicense(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const myForm = useForm();

  const handleSubmit = (values) => {
    console.log(values);
    let data = {
      idVehiculo: null,
      restriccionLicencia: values.restriccionLicencia,
      licenciaFechaExpiracion: dateFormat(values.licenciaFechaExpiracion, 'isoDateTime'),
      idCategoriaLicenciaConduccion: {
        idCategoriaLicenciaConduccion: values.idCategoriaLicenciaConduccion,
      },
      idTercero: null,
      idEmpleado: null,
      estado: 1,
      fechaCreacion: null,
      fechaModificacion: null,
      usuarioCreacion: Cookie.get('userId'),
      usuarioModificacion: null,
    };

    if (idThirdPartyAux !== 0) {
      data = {
        ...data,
        idTercero: {
          idTercero: idThirdPartyAux,
        },
      };
    } else {
      data = {
        ...data,
        idEmpleado: {
          idEmpleado: idEmployeeAux,
        },
      };
    }

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addTechnical(data)
            .then((res) => {
              saveVehicles(res, resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 412) {
                HandleOnError(err.response.data);
                console.log(err.response.data);
              } else {
                console.log('error');
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              
              }
              console.log(err);
            });
        });
      },
    });
  };

  const [selectedOption, setSelectedOption] = useState(null);

  const setTechnicalInfo = (selectedOption) => {
    console.log(selectedOption);
    if (selectedOption.objeto.tipoEntidad === 1) {
      setFormData({
        idEmpleado: parseInt(selectedOption.objeto.id),
        primerNombre: selectedOption.objeto.primerNombre,
        segundoNombre: selectedOption.objeto.segundoNombre,
        primerApellido: selectedOption.objeto.primerApellido,
        segundoApellido: selectedOption.objeto.segundoApellido,
        // tipoDocumento: `${selectedOption.objeto.idTipoDocumento.abreviatura} - ${selectedOption.objeto.idTipoDocumento.nombre}`,
        tipoDocumento: selectedOption.objeto.tipoDocumento,
        identificacionEmpleado: selectedOption.objeto.identificacion,
        genero: selectedOption.objeto.genero,
      });
      // save the id of the employee
      setIdEmployeeAux(selectedOption.value);
      setIdUser(selectedOption.idUser);
      setIdThirdPartyAux(0);
    } else {
      setFormData({
        idEmpleado: parseInt(selectedOption.objeto.id),
        primerNombre: selectedOption.objeto.primerNombre,
        segundoNombre: '',
        primerApellido: '',
        segundoApellido: '',
        identificacionEmpleado: selectedOption.objeto.identificacion,
        // tipoDocumento: `${selectedOption.objeto.idTipoDocumento.abreviatura} - ${selectedOption.objeto.idTipoDocumento.nombre}`,
        tipoDocumento: selectedOption.objeto.tipoDocumento,
        genero: '',
      });
      // save the id of the third party
      setIdThirdPartyAux(selectedOption.value);
      setIdUser(selectedOption.idUser);
      setIdEmployeeAux(0);
    }
  };

  /* Group select */
  const groupedOptions = [
    {
      label: 'Empleados',
      options: employees,
    },
    {
      label: 'Terceros',
      options: thirdParties,
    },
  ];

  const [selectValues, setSelectValues] = useState([]);
  const [categoryService, setCategoryService] = useState({});
  useEffect(() => {
    getCategoryService();
    setPrimaryMinimalTable([]);
    setSecondMinimalTable([]);
    setThirdMinimalTable([]);
  }, []);

  //Obtener los datos de internet 1 vez
  const getCategoryService = () => {
    getAll(endpoints.serviceCategory.getAllServiceCategory)
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCategoriaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        setCategoryService(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };
  const uploadFiles = (id) => {
    return new Promise((resolve, reject) => {
      if (archivos.length > 0) {
        fetchData({
          url: endpoints.UploadFiles.save,
          method: 'post',
          body: {
            idOrigen: id,
            idTipoOrigenArchivo: 6, // 6 = Tecnico
            archivos,
          },
        })
          .then((response) => {
            resolve(
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.created.general',
                  'El registro se ha creado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.technical),
              }),
            );
          })
          .catch((err) => {
            reject(err);
          });
      } else {
        resolve(
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.confirm.created.general',
              'El registro se ha creado correctamente',
            ),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.technical),
          }),
        );
      }
    });
  };

  const deleteVehicule = (vehicle) => {
    const index = vehicles.indexOf(vehicle);
    const array = [...vehicles];
    if (index > -1) {
      // only splice array when item is found
      array.splice(index, 1);
      setVehicles(array); // 2nd parameter means remove one item only
    }
  };

  return (
    <div className="centered-form">
      {/* Quitar la S para conectar el formulario, al formulario de pruebas */}
      <Formiz onValidSubmit={handleSubmit} connect={myForm}>
        <form
          noValidate
          onSubmit={myForm.submit}
          className="container-wrapForm"
          style={{ minHeight: '16rem' }}
        >
          <div className="new-container-wrapForm__tabs">
            {myForm.steps.map((step) => (
              <button
                key={step.name}
                className={`new-tab-option ${step.name === myForm.currentStep.name ? 'is-active' : ''
                  }`}
                type="button"
                onClick={() => myForm.goToStep(step.name)}
              >
                {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                {formatterText(step.label)}
              </button>
            ))}
          </div>
          <div className="container-wrapForm-content">
            <section>
              {/*info technical */}
              <FormizStep
                name="step1"
                label='p.general.information'
              >
                <div className="title-section">
                  <span className="circle-form">
                    <span>1</span>
                  </span>
                  <h2>
                    <FormattedMessage
                      id="p.search.employes.third"
                      defaultMessage="Buscar empleado o tercero"
                    />
                  </h2>
                </div>
                <section className="grid-container-3c">
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="p.employed.third" defaultMessage="Empleado o tercero" />
                    </span>
                    <section className="w100-container">
                      <Select
                        styles={customStyles}
                        onChange={(selectedOption) => {
                          // helps to set the value of the input below
                          setSelectedOption(selectedOption.label);
                          // set the information in the front
                          setTechnicalInfo(selectedOption);
                        }}
                        options={groupedOptions}
                        placeholder={
                          loading ? (
                            <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                          ) : (
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecione una opción"
                            />
                          )
                        }
                      />
                      <input
                        className="input-required"
                        type="text"
                        value={selectedOption || ''}
                        name="idEmpleado"
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="p.service.category.per"
                        defaultMessage="Categoría de servicio a la que pertenece"
                      />
                    </span>
                    <section className="w100-container">
                      <SelectorMulti
                        data={categoryService}
                        dataValue={selectValues}
                        setterFunction={handleChangeMulti}
                      />
                    </section>
                  </label>
                  <InputFieldDV
                    type="text"
                    name="tipoDocumento"
                    labelText={formatterText('p.document.type', 'Tipo de documento')}
                    placeholder={formatterText('p.document.type', 'Tipo de documento')}
                    validateInput="text"
                    values={formData.tipoDocumento}
                    disabled={true}
                    required={formatterText('p.label.title.tipoDocumentoRequerido')}
                  />
                  <InputFieldDV
                    type="text"
                    name="genero"
                    labelText={formatterText('p.genero', 'Género')}
                    placeholder={formatterText('p.genero', 'Género')}
                    validateInput="text"
                    values={formData.genero || ''}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="identificacion"
                    labelText={formatterText('text.ID', 'Identificación')}
                    placeholder={formatterText('text.ID', 'Identificación')}
                    validateInput="number"
                    values={formData.identificacionEmpleado || ''}
                    disabled={true}
                    required={formatterText('p.label.title.identificacionRequerida')}
                  />
                  <InputFieldDV
                    type="text"
                    name="primerNombre"
                    labelText={formatterText('p.first.name', 'Primer nombre')}
                    placeholder={formatterText('p.first.name', 'Primer nombre')}
                    validateInput="text"
                    values={formData.primerNombre || ''}
                    disabled={true}
                    required={formatterText('p.label.title.primerNombreRequerido')}
                  />
                  <InputFieldDV
                    type="text"
                    name="segundoNombre"
                    labelText={formatterText('p.second.name', 'Segundo nombre')}
                    placeholder={formatterText('p.second.name', 'Segundo nombre')}
                    validateInput="text"
                    values={formData.segundoNombre || ''}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="primerApellido"
                    labelText={formatterText('p.first.lastname', 'Primer Apellido')}
                    placeholder={formatterText('p.first.lastname', 'Primer Apellido')}
                    validateInput="text"
                    values={formData.primerApellido || ''}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="segundoApellido"
                    labelText={formatterText('p.second.lastname', 'Segundo Apellido')}
                    placeholder={formatterText('p.second.lastname', 'Segundo Apellido')}
                    validateInput="text"
                    values={formData.segundoApellido || ''}
                    disabled={true}
                  />
                </section>
              </FormizStep>
              {/* info tech continue */}
              <FormizStep
                name="step2"
                label='p.operators.technicians'
              >
                <div className="title-section">
                  <span className="circle-form">
                    <span>2</span>
                  </span>
                  <h2>
                    <FormattedMessage
                      id="p.operators.technicians"
                      defaultMessage="Información Operarios/Técnicos"
                    />
                  </h2>
                </div>
                <section className="grid-container-2c" style={{ marginLeft: '10px' }}>
                  <InputFieldResponsive
                    type="date"
                    name="licenciaFechaExpiracion"
                    labelText={formatterText(
                      'p.date.expire.license',
                      'Fecha de expiración de la licencia de conducción',
                    )}
                    placeholder={formatterText(
                      'p.date.expire.license',
                      'Fecha de expiración de la licencia de conducción',
                    )}
                    required={formatterText('p.label.title.fechaExpiracionRequerida')}
                    min={dateFormat(
                      new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1),
                      'yyyy-mm-dd',
                    )}
                  />
                  <InputSelectorResponsive
                    type="text"
                    name="idCategoriaLicenciaConduccion"
                    labelText={formatterText(
                      'p.category.license',
                      'Categoría de licencia de conducción',
                    )}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    required={formatterText('p.label.title.categoriaLicenciaRequerida')}
                    data={categoryLicense}
                    isLoading={loading}
                  />
                </section>
                <label className="d-flex" 
                style={{ 
                  marginTop: '40px',
                  marginLeft: '10px' }}>
                  

                    <InputFieldResponsive
                      type="text"
                      name="restriccionLicencia"
                      labelText={formatterText(
                        'p.restricted.license',
                        'Restricciones de licencia de conducción',
                      )}
                      placeholder={formatterText(
                        'p.restricted.license',
                        'Restricciones de licencia de conducción',
                      )}
                      validateInput="text"
                      required={formatterText('alert.textarea.show.error.required')}
                      area={true}
                      styleName={"input-default-1c"}
                      rows="5"
                      cols="100"
                    />                 
                </label>


                {vehiclesBrand && (
                  <div>
                    <div className="title-section">
                      <span className="circle-form">
                        <span>2.1</span>
                      </span>
                      <h2>
                        <FormattedMessage id="p.add.vehicle" defaultMessage="Agregar vehículo" />
                      </h2>
                    </div>
                    {vehicles.length > 0 && (
                      <>
                        <section className="form-responsive-container-information">
                          <TableMinimalNoContext
                            titles={TITLE_TABLE}
                            type="vehiclesAssign"
                            data={vehicles}
                            labelTable="Vehículos por página"
                            handleDelete={(x) => deleteVehicule(x)}
                          />
                        </section>
                      </>
                    )}
                    {show && (
                      <>
                        <section className="grid-container-3c">
                          <label className="d-flex">
                            <span className="text-inline">
                              {
                                <FormattedMessage
                                  id="technicians.label.text.vehicle.license"

                                />
                              }
                            </span>
                            <section className="w100-container">
                              <input
                                name="placa"
                                labelText={formatterText(
                                  'p.enter.license.vehicle',
                                  'Ingrese la placa del vehiculo',
                                )}
                                placeholder={formatterText(
                                  'p.enter.license.vehicle',
                                  'Ingrese la placa del vehiculo',
                                )}
                                type="text"
                                required={formatterText('p.label.title.placaVehiculoRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                              />
                              <span className="error-msg">{messageErrorPlaca}</span>
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.vehicle.model" defaultMessage="Modelo" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="modelo"
                                placeholder={formatterText(
                                  'p.add.vehicle.model',
                                  'Ingrese el modelo del vehiculo',
                                )}
                                type="text"
                                required={formatterText('p.label.title.modeloVehiculoRequerido')}
                                className="input-default-3c"
                                onChange={handleChangeModel}
                                maxLength="4"
                              />
                              <span className="error-msg">{messageError}</span>
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.vehicle.brand" defaultMessage="Marca" />
                            </span>
                            <select
                              name="idMarcaVehiculo"
                              id="idMarcaVehiculo"
                              className="input-label-style"
                              onChange={handleChangeSelect}
                            >
                              <option value="">
                                <FormattedMessage
                                  id="p.selection.brand"
                                  defaultMessage="Seleccione una marca"
                                />
                              </option>
                              {vehiclesBrand.map((item) => (
                                <option
                                  key={item.idMarcaVehiculo}
                                  value={JSON.stringify({ ...item })}
                                >
                                  {item.nombre} - {item.codigo}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage
                                id="p.date.technicians.revision"
                                defaultMessage="Fecha revisión técnico mecánica"
                              />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaTecnicoMecanica"
                                placeholder="Ingrese la revisión técnico mecánica"
                                type="date"
                                required={formatterText('p.label.title.fechaRevisionTecnicoMecanicaRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                min={HandleShortDate()}
                                max={HandleShortDate(50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.date.soat" defaultMessage="Fecha Soat" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaSoap"
                                placeholder={formatterText(
                                  'p.add.date.soat',
                                  'Ingrese la fecha del soat',
                                )}
                                type="date"
                                required={formatterText('p.label.title.fechaSoatRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                min={HandleShortDate()}
                                max={HandleShortDate(50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.date.runt" defaultMessage="Fecha RUNT" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaRunt"
                                placeholder={formatterText(
                                  'p.add.date.runt',
                                  'Ingrese la fecha runt',
                                )}
                                type="date"
                                required={formatterText('p.label.title.fechaRuntRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                max={HandleShortDate()}
                                min={HandleShortDate(-50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.code.runt" defaultMessage="Código RUNT" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="runt"
                                placeholder={formatterText(
                                  'p.add.code.runt',
                                  'Ingrese el codigo runt',
                                )}
                                type="text"
                                required={formatterText('p.label.title.codigoRuntRequerido')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                maxLength="100"
                              />
                            </section>
                          </label>
                        </section>
                        <section className="form-responsive-container-buttons">
                          <input
                            onClick={handleAddFamily}
                            type="button"
                            className="btn-primary"
                            value={formatterText(
                              'p.add.vehicle'
                            )}
                          />
                        </section>
                      </>
                    )}
                  </div>
                )}
              </FormizStep>
              <FormizStep name="step3" label='p.associations'>
                <UnityBusiness
                  data={primaryMinimalTable}
                  setterFunction={setPrimaryMinimalTable}
                // type="create"
                />
                <ClienteSucursal data={secondMinimalTable} setterFunction={setSecondMinimalTable} />
                <AssociateCoverage data={thirdMinimalTable} setterFunction={setThirdMinimalTable} />
              </FormizStep>
              <FormizStep
                name="step4"
                label='p.charge.archvie'
              >
                <Attachments
                  currentFiles={archivos}
                  setCurrentFiles={setCurrentFiles}
                  isEdited={false}
                  showParameters={true}
                />
              </FormizStep>
            </section>
            <section className="form-responsive-container-buttons">
              <button type="submit" className="btn-primary">
                <FormattedMessage
                  id="alert.button.confirm.general"
                  defaultMessage="Guardar cambios"
                />
              </button>
              <button className="input-cancel" onClick={() => navigate(paths.technical)}>
                <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
              </button>
            </section>
          </div>
        </form>
      </Formiz>
    </div>
  );
}
