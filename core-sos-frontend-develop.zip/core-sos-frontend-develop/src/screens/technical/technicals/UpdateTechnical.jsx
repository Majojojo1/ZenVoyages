import React, { useEffect, useState } from 'react';
// Import Contexts
import TableMinimalNoContext from 'common/minimalTables/TableMinimalNoContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import { InputFieldDV } from 'common/InputFieldDV';
import SelectorMulti from 'common/SelectorMulti';
import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import AssociateCoverage from 'common/multiTableType/AssociateCoverage';
import ClienteSucursal from 'common/multiTableType/ClienteSucursal';
import UnityBusiness from 'common/multiTableType/UnityBusiness';
import HandleOnError from 'common/validators/HandleOnError';
import HandleShortDate from 'common/validators/HandleShortDate';
import { CARREGEX, MODELCARREGEX } from 'common/validators/Regex';
import CustomAlert from 'components/CustomAlert';
import { getAllThirdParties } from 'services/api/thirdParties';
// Import Libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import dateFormat from 'dateformat';
import Cookie from 'js-cookie';
import moment from 'moment';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
// Import Services
import Attachments from 'components/AttachedFiles/Attachments';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { getAllSelectEmployees } from 'services/api/employees';
import {
  brandVehicles,
  categoryLicenses,
  getTechnicalVehiclesById,
} from 'services/api/institutions';
import { addItem, deleteItem, getAll, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const MODEL = {
  placa: '',
  idMarcaVehiculo: '',
  modelo: '',
  fechaTecnicoMecanica: '',
  fechaSoap: '',
  fechaRunt: '',
  runt: '',
  idVehiculo: '',
};
export default function UpdateTechnical() {
  return (
    <SearchWrapper>
      <UpdateTechnicalComponent />
    </SearchWrapper>
  );
}
function UpdateTechnicalComponent() {
  // show or hide the section
  const [show, setShow] = useState(true);
  // title table

  const { loading, toggleLoading } = useGetData();
  const navigate = useNavigate();
  const myForm = useForm();
  const { fetchData, COOKIE_USER } = useAxios();

  // use Hook of language v2
  const { formatterText, noFilledContent, newItemCreated, successRemoveItem, customSB, resourceNotFound } =
    useLangv2();

  const TITLE_TABLE = [
    formatterText('technicians.table.title.license.vehicle'),
    formatterText('p.vehicle.model'),
    formatterText('p.date.soat'),
    formatterText('p.date.runt'),
    formatterText('p.date.technicians.revision'),
    formatterText('table.title.runt.date'),
    formatterText('table.actions')

  ];

  const {
    primaryMinimalTable,
    setPrimaryMinimalTable,
    prevPrimaryMinimalTable,
    setPrevPrimaryMinimalTable,
    secondMinimalTable,
    setSecondMinimalTable,
    prevSecondMinimalTable,
    setPrevSecondMinimalTable,
    thirdMinimalTable,
    setThirdMinimalTable,
    prevThirdMinimalTable,
    setPrevThirdMinimalTable,
    setSearchUnitBussines,
    setSearchSucursal,
    setSearchCoverage,
  } = useSeachContext();

  const [archivos, setCurrentFiles] = useState([]);
  const [formData, setFormData] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [categoryLicense, setCategoryLicense] = useState([]);
  const [thirdParties, setThirdParties] = useState([]);
  const [messageError, setMessageError] = useState('');
  const [messageErrorPlaca, setMessageErrorPlaca] = useState('');

  // get url id
  const { id } = useParams();

  const [vehicles, setVehicles] = useState([]);

  const [currentVehicle, setCurrentVehicle] = useState(MODEL);

  const [vehiclesBrand, setVehiclesBrand] = useState([]);
  const [savedVehicles, setSavedVehicles] = useState([]);

  const getCategoryService = () => {
    getAll(endpoints.serviceCategory.getAllServiceCategory)
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCategoriaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        setCategoryService(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleAddFamily = () => {
    if (
      currentVehicle.placa !== '' &&
      currentVehicle.idMarcaVehiculo !== '' &&
      currentVehicle.modelo !== '' &&
      currentVehicle.fechaTecnicoMecanica !== '' &&
      currentVehicle.fechaSoap !== '' &&
      currentVehicle.fechaRunt !== '' &&
      currentVehicle.runt !== ''
    ) {
      // find in vehicles arr if the placa is already saved
      const findPlaca = vehicles.find((item) => item.placa === currentVehicle.placa);
      if (findPlaca) {
        customSB(
          'warning',
          'snackbar.warning.repeated.vehicle',
          'La placa ya existe, por favor ingrese una diferente.',
        );
      } else {
        saveNewVehicles(currentVehicle);
      }
    } else {
      noFilledContent();
    }
  };

  // save new vehicles
  const saveNewVehicles = (vehicle) => {
    const DATA = {
      idVehiculo: null,
      placa: vehicle.placa,
      idMarcaVehiculo: {
        idMarcaVehiculo: vehicle.idMarcaVehiculo.idMarcaVehiculo,
      },
      idTecnico: {
        idTecnico: parseInt(id),
      },
      modelo: vehicle.modelo,
      fechaTecnicoMecanica: dateFormat(vehicle.fechaTecnicoMecanica, 'isoDateTime'),
      fechaSoap: dateFormat(vehicle.fechaSoap, 'isoDateTime'),
      fechaRunt: dateFormat(vehicle.fechaRunt, 'isoDateTime'),
      runt: vehicle.runt,
      estado: 1,
      fechaCreacion: null,
      fechaModificacion: null,
      usuarioCreacion: COOKIE_USER,
      usuarioModificacion: null,
    };
    fetchData({ url: endpoints.institutions.saveVehicle, method: 'post', body: DATA }).then(
      (data) => {
        const { error } = data;
        if (error === '200') {
          newItemCreated();
          setCurrentVehicle(MODEL);
          setShow(false);
          setTimeout(() => {
            setShow(true);
          }, 100);
          getDataVehicles(id);
        }
      },
    );
  };

  const handleChangeRelative = (e) => {
    if (e.target.name !== 'placa') {
      setCurrentVehicle({ ...currentVehicle, [e.target.name]: e.target.value });
    } else {
      if (e.target.value.match(CARREGEX)) {
        setMessageErrorPlaca('');
        setCurrentVehicle({
          ...currentVehicle,
          [e.target.name]: e.target.value,
        });
      } else {
        if (e.target.value === null || e.target.value === '') {
          setMessageErrorPlaca('');
        } else {
          setMessageErrorPlaca(formatterText('p.label.title.placaFormatoIncorrecto'));
        }
      }
    }
  };

  const handleChangeModel = (e) => {
    if (e.target.value.match(MODELCARREGEX)) {
      setMessageError('');

      setCurrentVehicle({ ...currentVehicle, [e.target.name]: e.target.value });
    } else {
      if (e.target.value === null || e.target.value === '') {
        setMessageError('');
      } else {
        setMessageError(formatterText('p.label.title.modeloFormatoIncorrecto'));
      }
    }
  };

  const handleChangeSelect = (selectedOption) => {
    setCurrentVehicle({
      ...currentVehicle,
      [selectedOption.target.name]:
        selectedOption.target.value === ''
          ? selectedOption.target.value
          : JSON.parse(selectedOption.target.value),
    });
  };

  const getMarcasVehiculos = () => {
    brandVehicles()
      .then((res) => {
        setVehiclesBrand(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const deleteCategoryAssociated = (resolve, reject) => {
    const deletedCategories = prevSelectValues.filter((item) => {
      return !selectValues.includes(item);
    });
    if (deletedCategories.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = deletedCategories.map((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteCategoryByid, item.idAssociate)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });

      Promise.all(promises)
        .then((res) => {
          postCategoryService(resolve, reject);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      postCategoryService(resolve, reject);
    }
  };

  const postCategoryService = (resolve, reject) => {
    const newCategories = selectValues.filter((item) => {
      return !prevSelectValues.includes(item);
    });
    const promises = newCategories.map(
      (item) =>
        new Promise((resolve, reject) => {
          const data = {
            idTecnico: formData.idTecnico,
            idCategoriaServicio: item.value,
          };
          addItem(endpoints.associateDataTechnical.addCategoryService, data)
            .then((res) => {
              resolve(res);
            })
            .catch((err) => {
              reject(err);
            });
        }),
    );
    Promise.all(promises)
      .then((res) => {
        deleteAssociateUnityBussiness(resolve, reject);
      })
      .catch((err) => {
        reject((err) => {
          if (err.response.status === 412) {
            HandleOnError(err.response.data);
          } else {
            HandleOnError(
              formatterText('p.label.title.tecnicoVehiculosAsociadosSinCategorias'),
            );
          }
        });
      });
  };

  // Sprint 8 , crear associaciones
  const deleteAssociateUnityBussiness = (resolve, reject) => {
    const data = getDiference(primaryMinimalTable, prevPrimaryMinimalTable);
    if (data.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = data.map((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteUnityBusiness, item.idAssociate)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });

      Promise.all(promises)
        .then((res) => {
          deleteAssociateSucursal(resolve, reject);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      deleteAssociateSucursal(resolve, reject);
    }
  };

  const deleteAssociateSucursal = (resolve, reject) => {
    const data = getDiference(secondMinimalTable, prevSecondMinimalTable);
    if (data.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = data.map((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteSucursal, item.idAssociate)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });

      Promise.all(promises)
        .then((res) => {
          deleteCoverage(resolve, reject);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      deleteCoverage(resolve, reject);
    }
  };

  const deleteCoverage = (resolve, reject) => {
    const data = getDiference(thirdMinimalTable, prevThirdMinimalTable);
    if (data.length > 0) {
      // eslint-disable-next-line array-callback-return
      const promises = data.map((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteCoverage, item.id)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });

      Promise.all(promises)
        .then((res) => {
          postAssociateUnityBussiness(resolve, reject);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      postAssociateUnityBussiness(resolve, reject);
    }
  };

  const postAssociateUnityBussiness = (resolve, reject) => {
    const data = getNewData(primaryMinimalTable, prevPrimaryMinimalTable);
    if (data.length > 0) {
      const promises = data.map(
        (item) =>
          new Promise((resolve, reject) => {
            const data = {
              idUsuario: formData.idUsuario,
              idUnidadNegocio: item.id,
            };
            addItem(endpoints.associateDataTechnical.addUnityBusiness, data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(promises)
        .then((res) => {
          postAssociateSucursal(resolve, reject);
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
            } else {
              HandleOnError(
                formatterText('p.label.title.tecnicoVehiculosAsociadosSinCategorias'),
              );
            }
            console.log(err);
          });
        });
    } else {
      postAssociateSucursal(resolve, reject);
    }
  };

  const postAssociateSucursal = (resolve, reject) => {
    const data = getNewData(secondMinimalTable, prevSecondMinimalTable);
    if (data.length > 0) {
      const promises = data.map(
        (item) =>
          new Promise((resolve, reject) => {
            const data = {
              idUsuario: formData.idUsuario,
              idSucursal: item.id,
            };
            addItem(endpoints.associateDataTechnical.addSucursal, data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(promises)
        .then((res) => {
          postCoverage(resolve, reject);
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
            } else {
              HandleOnError(
               formatterText('p.label.title.tecnicoVehiculosAsociadosSinCategorias'),
              );
            }
            console.log(err);
          });
        });
    } else {
      postCoverage(resolve, reject);
    }
  };

  const postCoverage = (resolve, reject) => {
    const data = getNewData(thirdMinimalTable, prevThirdMinimalTable);
    if (data.length > 0) {
      const promises = data.map(
        (item) =>
          new Promise((resolve, reject) => {
            const data = {
              idMunicipio: item.citySucursal.value,
              idTecnico: formData.idTecnico,
            };
            addItem(endpoints.associateDataTechnical.addCoverage, data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(promises)
        .then((res) => {
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText('p.label.title.tecnicoVehiculosCategoriasAsociadasCorrectamente2'),
              confirmButtonText: 'Continuar',
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.technical),
            }),
          );
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);
            } else {
              HandleOnError(
               formatterText('p.label.title.tecnicoVehiculosAsociadosSinCategorias'),
              );
            }
            console.log(err);
          });
        });
    } else {
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText('p.label.title.tecnicoVehiculosCategoriasAsociadasCorrectamente'),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.technical),
        }),
      );
    }
  };

  const getDataVehicles = (id) => {
    getTechnicalVehiclesById(id)
      .then((res) => {
        const allvehicles = res.map((vehicle) => ({
          placa: vehicle.placa,
          idMarcaVehiculo: { ...vehicle.idMarcaVehiculo },
          modelo: vehicle.modelo,
          fechaTecnicoMecanica: moment(vehicle.fechaTecnicoMecanica.split('T')[0]),
          fechaSoap: moment(vehicle.fechaSoap.split('T')[0]),
          fechaRunt: moment(vehicle.fechaRunt.split('T')[0]),
          runt: vehicle.runt,
          idVehiculo: vehicle.idVehiculo,
        }));
        setSavedVehicles(allvehicles);
        setVehicles(allvehicles);
      })
      .catch((err) => {
        console.log(err, 'no se logro obtener los vehiculos del tecnico');
      });
  };

  useEffect(() => {
    getDataTechnicalOperator();
    getCategoryService();
    getEmployees();
    getThirdParties();
    getAllcategoryLicenses();
    getMarcasVehiculos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getDataToUpdate(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const getEmployees = () => {
    toggleLoading(true);
    // getAllEmployees() switch
    getAllSelectEmployees()
      .then((response) => {
        let ArrayMunicipios = [];
        response.forEach((item) => {
          let valueText = `${item.primerNombre} ${item.primerApellido} - ${item.identificacion}`;
          ArrayMunicipios.push({
            label: valueText,
            value: item.idEmpleado,
            objeto: { ...item },
          });
        });
        setEmployees(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const getThirdParties = () => {
    toggleLoading(true);
    getAllThirdParties()
      .then((response) => {
        let newArray = [];
        response.forEach((item) => {
          let valueText = `${item.nombre} - ${item.identificacion}`;
          newArray.push({
            label: valueText,
            value: item.idTercero,
            objeto: { ...item },
          });
        });
        setThirdParties(newArray);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const getAllcategoryLicenses = () => {
    toggleLoading(true);
    categoryLicenses()
      .then((response) => {
        let ArrayMunicipios = [];
        response.forEach((item) => {
          ArrayMunicipios.push({
            label: item.nombre,
            value: item.idCategoriaLicenciaConduccion,
          });
        });
        setCategoryLicense(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const getData = (obj, url) => {
    getDataAttachedFiles(obj.idTecnico);
    if (obj?.idEmpleado !== null) {
      getItemById(url, obj?.idEmpleado?.idEmpleado)
        .then((res) => {
          getAllAssociated(res.idUsuario);
          setFormData({
            idTecnico: obj.idTecnico,
            idEmpleado: obj.idEmpleado,
            idUsuario: res.idUsuario,
            idTercero: null,
            primerNombre: obj.idEmpleado.primerNombre,
            segundoNombre: obj.idEmpleado.segundoNombre,
            primerApellido: obj.idEmpleado.primerApellido,
            segundoApellido: obj.idEmpleado.segundoApellido,
            identificacion: obj.idEmpleado.identificacion,
            genero: obj.idEmpleado.genero.abreviatura,
            idTipoDocumento: obj.idEmpleado.idTipoDocumento.nombre,
            idAbreviaturaDocumento: obj.idEmpleado.idTipoDocumento.abreviatura,
            idCategoriaLicenciaConduccion: obj.idCategoriaLicenciaConduccion,
            restriccionLicencia: obj.restriccionLicencia,
            empleado: obj.idEmpleado,
            fechaCreacion: obj.fechaCreacion,
            licenciaFechaExpiracion: obj.licenciaFechaExpiracion,
          });
        })
        .catch((err) => {
          setFormData({
            idTecnico: obj.idTecnico,
            idEmpleado: obj.idEmpleado,
            idUsuario: null,
            idTercero: null,
            primerNombre: obj.idEmpleado.primerNombre,
            segundoNombre: obj.idEmpleado.segundoNombre,
            primerApellido: obj.idEmpleado.primerApellido,
            segundoApellido: obj.idEmpleado.segundoApellido,
            identificacion: obj.idEmpleado.identificacion,
            genero: obj.idEmpleado.genero.abreviatura,
            idTipoDocumento: obj.idEmpleado.idTipoDocumento.nombre,
            idAbreviaturaDocumento: obj.idEmpleado.idTipoDocumento.abreviatura,
            idCategoriaLicenciaConduccion: obj.idCategoriaLicenciaConduccion,
            restriccionLicencia: obj.restriccionLicencia,
            empleado: obj.idEmpleado,
            fechaCreacion: obj.fechaCreacion,
            licenciaFechaExpiracion: obj.licenciaFechaExpiracion,
          });
        });
    } else {
      getItemById(endpoints.associateDataTechnical.getUserIdbyThird, obj.idTercero.idTercero)
        .then((res) => {
          getAllAssociated(res.idUsuario, obj.idTecnico);
          setFormData({
            idTecnico: obj.idTecnico,
            idEmpleado: null,
            idTercero: obj.idTercero,
            idUsuario: res.idUsuario,
            primerNombre: obj.idTercero.nombre,
            segundoNombre: obj.idTercero.segundoNombre || '',
            primerApellido: obj.idTercero.primerApellido || '',
            segundoApellido: obj.idTercero.segundoApellido || '',
            identificacion: obj.idTercero.identificacion,
            idTipoDocumento: obj.idTercero.idTipoDocumento.nombre,
            idAbreviaturaDocumento: obj.idTercero.idTipoDocumento.abreviatura,
            idCategoriaLicenciaConduccion: obj.idCategoriaLicenciaConduccion,
            restriccionLicencia: obj.restriccionLicencia,
            empleado: obj.idTercero,
            fechaCreacion: obj.fechaCreacion,
            licenciaFechaExpiracion: obj.licenciaFechaExpiracion,
          });
        })
        .catch(() => {
          setFormData({
            idTecnico: obj.idTecnico,
            idEmpleado: null,
            idTercero: obj.idTercero,
            idUsuario: null,
            primerNombre: obj.idTercero.nombre,
            segundoNombre: obj.idTercero.segundoNombre || '',
            primerApellido: obj.idTercero.primerApellido || '',
            segundoApellido: obj.idTercero.segundoApellido || '',
            identificacion: obj.idTercero.identificacion,
            idTipoDocumento: obj.idTercero.idTipoDocumento.nombre,
            idAbreviaturaDocumento: obj.idTercero.idTipoDocumento.abreviatura,
            idCategoriaLicenciaConduccion: obj.idCategoriaLicenciaConduccion,
            restriccionLicencia: obj.restriccionLicencia,
            empleado: obj.idTercero,
            fechaCreacion: obj.fechaCreacion,
            licenciaFechaExpiracion: obj.licenciaFechaExpiracion,
          });
        });
    }
    getCategoriasAsociadas(obj.idTecnico);
    getDataVehicles(obj.idTecnico);

  }

  //get data from localStorage
  const getDataTechnicalOperator = () => {
    const item = JSON.parse(localStorage.getItem('dataUpdate'));
    const url = endpoints.associateDataTechnical.getUserIdbyEmployee;
    getData(item, url);
  };

  //get data from api
  const getDataToUpdate = (id) => {
    getItemById(endpoints.technical.getTechicalById, id)
      .then((res) => {
        if (res !== null) {
          const item = res;
          const url = endpoints.associateDataTechnical.getUserIdbyEmployee;
          getData(item, url);
        } else {
          resourceNotFound();
        }
      }).catch((err) => {
        console.error(err)
      });
  };

  const getCategoriasAsociadas = (id) => {
    getItemById(endpoints.associateDataTechnical.getCategoryById, id)
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          newArray.push({
            value: item.idCategoriaServicio,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
            idAssociate: item.idTecnicoCategoriaServicio,
          });
        });
        setSelectValues(newArray);
        setPrevSelectValues(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // update Technical data
  const handleSubmit = (values) => {
    console.log(values.idCategoriaLicenciaConduccion);
    let data = {};
    // determinate if the technical is employee
    if (formData.idEmpleado !== null) {
      data = {
        idTecnico: formData.idTecnico,
        idVehiculo: null,
        idTercero: null,
        restriccionLicencia: values.restriccionLicencia,
        licenciaFechaExpiracion: dateFormat(values.licenciaFechaExpiracion, 'isoDateTime'),
        idCategoriaLicenciaConduccion: values.idCategoriaLicenciaConduccion.value,
        idEmpleado: { ...formData.empleado },
        estado: 1,
        fechaCreacion: formData.fechaCreacion,
        fechaModificacion: null,
        usuarioCreacion: Cookie.get('idUsuario'),
        usuarioModificacion: Cookie.get('idUsuario'),
      };
    } else {
      data = {
        idTecnico: formData.idTecnico,
        idVehiculo: null,
        idTercero: { ...formData.empleado },
        restriccionLicencia: values.restriccionLicencia,
        licenciaFechaExpiracion: dateFormat(values.licenciaFechaExpiracion, 'isoDateTime'),
        idCategoriaLicenciaConduccion: values.idCategoriaLicenciaConduccion.value,

        idEmpleado: null,
        estado: 1,
        fechaCreacion: formData.fechaCreacion,
        fechaModificacion: null,
        usuarioCreacion: Cookie.get('idUsuario'),
        usuarioModificacion: Cookie.get('idUsuario'),
      };
    }

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateItem(endpoints.technical.updateTechnical, data)
            .then((res) => {
              deleteCategoryAssociated(resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 412) {
                reject(HandleOnError(err.response.data));
                console.log(err.response.data);
              } else {
                console.log('error');
                reject(
                  HandleOnError(
                    formatterText(
                      'alert.message.failed.general',
                      'Error al crear el registro, por favor intente nuevamente.',
                    ),
                  ),
                );
              }
              reject(console.log(err));
            });
        });
      },
    });
  };

  const [selectValues, setSelectValues] = useState([]);
  const [prevSelectValues, setPrevSelectValues] = useState([]);
  const [categoryService, setCategoryService] = useState({});

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  const structurePrimaryMinimalTable = (data, array) => {
    data.forEach((item) => {
      array.push({
        idAssociate: item.idUsuarioUnidadNegocio,
        id: item.idUnidadNegocio,
        unityName: item.nombreUnidadNegocio,
        code: item.codigoUnidadNegocio,
        market: item.nombreMercado !== null ? item.nombreMercado : 'Sin mercado asociado',
        country: item.nombrePais !== null ? item.nombrePais : 'Sin país asociado',
      });
    });
    return array;
  };

  const structureSecondaryMinimalTable = (data, array) => {
    data.forEach((item) => {
      array.push({
        idAssociate: item.idUsuarioSucursal,
        id: item.idSucursal,
        nombreCliente: item.nombreRazonSocial,
        tipoId: {
          value: '',
          label: item.abreviaturaTipoDocumento,
        },
        numberId: item.identificacionCliente,
        citySucursal: {
          value: '',
          label: item.nombreMunicipio,
        },
        departamento: {
          value: '',
          label: item.nombreDepartamento,
        },
        pais: {
          value: '',
          label: item.nombrePais,
        },
      });
    });
    return array;
  };

  const structureThirdMinimalTable = (data, array) => {
    data.forEach((item) => {
      array.push({
        id: item.idCoberturaTecnico,
        citySucursal: {
          value: item.idMunicipio,
          label: item.nombreMunicipio,
        },
        departamento: {
          value: item.idDepartamento,
          label: item.nombreDepartamento,
        },
        pais: {
          value: item.idPais,
          label: item.nombrePais,
        },
        fecha: dateFormat(item.fechaRegistro, 'yyyy/mm/dd - h:MM:ss TT'),
      });
    });
    return array;
  };

  const getAllAssociated = (idUser, idTecnico) => {
    if (idUser !== null) {
      getItemById(endpoints.associateDataTechnical.getUnityBusinessById, idUser).then((res) => {
        let newArray = [];
        if (res.length > 0) {
          const dataPrimary = structurePrimaryMinimalTable(res, newArray);
          setPrimaryMinimalTable(dataPrimary);
          setPrevPrimaryMinimalTable(dataPrimary);
          setSearchUnitBussines(dataPrimary);
        }
      });
      getItemById(endpoints.associateDataTechnical.getSucursalById, idUser).then((res) => {
        let newArray = [];
        if (res.length > 0) {
          const dataPrimary = structureSecondaryMinimalTable(res, newArray);
          setSecondMinimalTable(dataPrimary);
          setPrevSecondMinimalTable(dataPrimary);
          setSearchSucursal(dataPrimary);
        }
      });
      getItemById(endpoints.associateDataTechnical.getCoverageById, id).then((res) => {
        let newArray = [];
        if (res.length > 0) {
          const dataPrimary = structureThirdMinimalTable(res, newArray);
          setThirdMinimalTable(dataPrimary);
          setPrevThirdMinimalTable(dataPrimary);
          setSearchCoverage(dataPrimary);
        }
      });
    }
  };

  // funcion que devuelva los datos que no se encuentran en un array buscando por un id
  const getDiference = (array2, array) => {
    let newArray = [];
    array.forEach((item) => {
      let found = array2.find((element) => element.id === item.id);
      if (found === undefined) {
        newArray.push(item);
      }
    });
    return newArray;
  };

  // funcion que devuelva los datos nuevos que se encuentran en un array buscando por un id y que no se encuentran en el otro array
  const getNewData = (array2, array) => {
    let newArray = [];
    array2.forEach((item) => {
      let found = array.find((element) => element.id === item.id);
      if (found === undefined) {
        newArray.push(item);
      }
    });
    return newArray;
  };

  const uploadNewFile = async (file) => {
    fetchData({
      url: endpoints.UploadFiles.save,
      method: 'post',
      body: {
        idOrigen: formData.idTecnico,
        idTipoOrigenArchivo: 6, // 6 = Tecnico
        archivos: [file],
      },
    }).then((response) => {
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
        text:  formatterText('alert.title.confirm.add.files'),
        confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
        allowOutsideClick: false,
        executeFunction: () => console.log(),
      });
    });
  };

  const getDataAttachedFiles = async (id) => {
    fetchData({
      url: endpoints.UploadFiles.findArchivosById,
      method: 'post',
      body: {
        idOrigen: id,
        idTipoOrigenArchivo: 6,
      },
      typeConfig: 'form',
    }).then((response) => {
      let files = response.response.map((file) => {
        return {
          name: file,
          url: file,
        };
      });
      setCurrentFiles(files);
    });
  };

  // delete vehicule asociated
  const deleteVehicule = (val) => {
    fetchData({ url: endpoints.institutions.deleteVehicle(val.idVehiculo), method: 'delete' }).then(
      (data) => {
        const { error } = data;
        if (error === '200') {
          successRemoveItem();
          getDataVehicles(id);
        }
      },
    );
  };

  return (
    <div className="centered-form">
      {formData && (
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form
            noValidate
            onSubmit={myForm.submit}
            className="container-wrapForm"
            style={{ minHeight: '16rem' }}
          >
            <div className="new-container-wrapForm__tabs">
              {myForm?.steps.map((step) => (
                <button
                  key={step.name}
                  className={`new-tab-option ${step.name === myForm?.currentStep.name ? 'is-active' : ''
                    }`}
                  type="button"
                  onClick={() => myForm.goToStep(step.name)}
                >
                  {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                  {formatterText(step.label)}
                </button>
              ))}
            </div>
            <div className="container-wrapForm-content">
              {/*info technical */}
              <FormizStep name="step1" label='p.general.information'>
                <div className="title-section">
                  <span className="circle-form">
                    <span>1</span>
                  </span>
                  <h2>
                    <FormattedMessage
                      id="technicians.title.general.information"
                    />{' '}
                    {` ${formData.primerNombre} ${formData.identificacion}`}
                  </h2>
                </div>
                <section className="grid-container-3c">
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="p.service.category.per"
                        defaultMessage="Categoría de servicio a la que pertenece"
                      />
                    </span>
                    <section className="w100-container">
                      <SelectorMulti
                        data={categoryService}
                        dataValue={selectValues}
                        setterFunction={handleChangeMulti}
                      />
                    </section>
                  </label>
                  <InputFieldDV
                    type="text"
                    name="tipoDocumento"
                    labelText={formatterText('p.document.type', 'Tipo de documento')}
                    placeholder={formData.idAbreviaturaDocumento + '-' + formData.idTipoDocumento}
                    validateInput="text"
                    defaultValue={formData.idAbreviaturaDocumento + '-' + formData.idTipoDocumento}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="genero"
                    labelText={formatterText('p.genero', 'Género')}
                    placeholder="Género"
                    validateInput="text"
                    values={formData.genero}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="identificacion"
                    labelText={formatterText('text.ID', 'Identificación')}
                    placeholder="Identificación"
                    validateInput="number"
                    values={formData.identificacion}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="primerNombre"
                    labelText={formatterText('p.first.name', 'Primer nombre')}
                    placeholder="Primer nombre"
                    validateInput="text"
                    values={formData.primerNombre}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="segundoNombre"
                    labelText={formatterText('p.second.name', 'Segundo nombre')}
                    placeholder="Segundo nombre"
                    validateInput="text"
                    values={formData.segundoNombre}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="primerApellido"
                    labelText={formatterText('p.first.lastname', 'Primer Apellido')}
                    placeholder="Primer Apellido"
                    validateInput="text"
                    values={formData.primerApellido}
                    disabled={true}
                  />
                  <InputFieldDV
                    type="text"
                    name="segundoApellido"
                    labelText={formatterText('p.second.lastname', 'Segundo Apellido')}
                    placeholder="Segundo Apellido"
                    validateInput="text"
                    values={formData.segundoApellido}
                    disabled={true}
                  />
                </section>
              </FormizStep>
              {/* info tech continue */}
              <FormizStep name="step2" label='p.operators.technicians'>
                <div className="title-section">
                  <span className="circle-form">
                    <span>2</span>
                  </span>
                  <h2>
                    <FormattedMessage
                      id="p.operators.technicians"
                      defaultMessage="Información Operarios/Técnicos"
                    />
                  </h2>
                </div>
                <section className="grid-container-2c"
                  style={{
                    marginLeft: '10px'
                  }}>
                  <InputFieldResponsive
                    type="date"
                    name="licenciaFechaExpiracion"
                    labelText={formatterText(
                      'p.date.expire.license',
                      'Fecha de expiración de la licencia de conducción',
                    )}
                    placeholder="Fecha de expiración de la licencia de conducción"
                    required="La fecha de expiración es requerida"
                    defaultValue={dateFormat(
                      moment(formData.licenciaFechaExpiracion.split('T')[0]),
                      'yyyy-mm-dd',
                    )}
                  />
                  <InputSelectorResponsive
                    type="text"
                    name="idCategoriaLicenciaConduccion"
                    labelText={formatterText(
                      'p.category.license',
                      'Categoría de licencia de conducción',
                    )}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    defaultValue={{
                      label: formData?.idCategoriaLicenciaConduccion.nombre || ' ',
                      value: formData?.idCategoriaLicenciaConduccion || '',
                    }}
                    required="La categoría de licencia es requerida"
                    data={categoryLicense}
                    isLoading={loading}
                  />
                </section>
                <label className="d-flex" style={{
                  marginTop: '40px',
                  marginLeft: '10px'
                }}>
                  <section className="grid-container-1c">
                    <InputFieldResponsive
                      type="text"
                      name="restriccionLicencia"
                      placeholder="Restricciones de licencia de conducción"
                      labelText={formatterText(
                        'p.restricted.license',
                        'Restricciones de licencia de conducción'
                      )}
                      validateInput="text"
                      defaultValue={formData.restriccionLicencia}
                      required={formatterText('alert.textarea.show.error.required')}
                      area={true}
                      styleName={"input-default-1c"}
                      rows="5"
                      cols="100"

                    />
                  </section>
                </label>

                {vehiclesBrand && (
                  <div>
                    <div className="title-section">
                      <span className="circle-form">
                        <span>2.1</span>
                      </span>
                      <h2>
                        <FormattedMessage id="p.add.vehicle" defaultMessage="Agregar vehículo" />
                      </h2>
                    </div>
                    {vehicles.length > 0 && (
                      <>
                        <section className="form-responsive-container-information">
                          <TableMinimalNoContext
                            titles={TITLE_TABLE}
                            type="vehiclesAssign"
                            data={vehicles}
                            labelTable="Vehículos por página"
                            handleDelete={(x) => deleteVehicule(x)}
                          />
                        </section>
                      </>
                    )}
                    {show && (
                      <>
                        <section className="grid-container-3c">
                          <label className="d-flex">
                            <span className="text-inline">
                              {
                                <FormattedMessage
                                  id="technicians.label.text.vehicle.license"

                                />
                              }
                            </span>
                            <section className="w100-container">
                              <input
                                name="placa"
                                placeholder={formatterText(
                                  'p.enter.license.vehicle',
                                  'Ingrese la placa del vehiculo',
                                )}
                                type="text"
                                required={formatterText('p.label.title.placaVehiculoRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                              />
                              <span className="error-msg">{messageErrorPlaca}</span>
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.vehicle.model" defaultMessage="Modelo" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="modelo"
                                placeholder={formatterText(
                                  'p.add.vehicle.model',
                                  'Ingrese el modelo del vehiculo',
                                )}
                                type="text"
                                required={formatterText('p.label.title.modeloVehiculoRequerido')}
                                className="input-default-3c"
                                onChange={handleChangeModel}
                                maxLength="4"
                              />
                              <span className="error-msg">{messageError}</span>
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.vehicle.brand" defaultMessage="Marca" />
                            </span>
                            <select
                              name="idMarcaVehiculo"
                              id="idMarcaVehiculo"
                              className="input-label-style"
                              onChange={handleChangeSelect}
                            >
                              <option value="">
                                <FormattedMessage
                                  id="p.selection.brand"
                                  defaultMessage="Seleccione una marca"
                                />
                              </option>
                              {vehiclesBrand.map((item) => (
                                <option
                                  key={item.idMarcaVehiculo}
                                  value={JSON.stringify({ ...item })}
                                >
                                  {item.nombre} - {item.codigo}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage
                                id="p.date.technicians.revision"
                                defaultMessage="Fecha revisión técnico mecánica"
                              />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaTecnicoMecanica"
                                placeholder="Ingrese la revisión técnico mecánica"
                                type="date"
                                required={formatterText('p.label.title.fechaRevisionTecnicoMecanicaRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                min={HandleShortDate()}
                                max={HandleShortDate(50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.date.soat" defaultMessage="Fecha Soat" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaSoap"
                                placeholder="Ingrese la fecha del soat"
                                type="date"
                                required={formatterText('p.label.title.fechaSoatRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                min={HandleShortDate()}
                                max={HandleShortDate(50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.date.runt" defaultMessage="Fecha RUNT" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="fechaRunt"
                                placeholder="Ingrese la fecha runt"
                                type="date"
                                required={formatterText('p.label.title.fechaRuntRequerida')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                max={HandleShortDate()}
                                min={HandleShortDate(-50)}
                              />
                            </section>
                          </label>
                          <label className="d-flex">
                            <span className="text-inline">
                              <FormattedMessage id="p.code.runt" defaultMessage="Código RUNT" />
                            </span>
                            <section className="w100-container">
                              <input
                                name="runt"
                                placeholder={formatterText(
                                  'p.add.code.runt',
                                  'Ingrese el codigo runt',
                                )}
                                type="text"
                                required={formatterText('p.label.title.codigoRuntRequerido')}
                                className="input-default-3c"
                                onChange={handleChangeRelative}
                                maxLength="100"
                              />
                            </section>
                          </label>
                        </section>
                        <section className="form-responsive-container-buttons">
                          <input
                            onClick={handleAddFamily}
                            type="button"
                            className="btn-primary"
                            value={formatterText(
                              'p.add.vehicle'
                            )}
                          />
                        </section>
                      </>
                    )}
                  </div>
                )}
              </FormizStep>
              {formData.idUsuario !== null && (
                <FormizStep name="step3" label="p.associations">
                  <form>
                    <UnityBusiness
                      data={primaryMinimalTable}
                      setterFunction={setPrimaryMinimalTable}
                    />
                    <ClienteSucursal
                      data={secondMinimalTable}
                      setterFunction={setSecondMinimalTable}
                    />
                    <AssociateCoverage
                      data={thirdMinimalTable}
                      setterFunction={setThirdMinimalTable}
                    />
                  </form>
                </FormizStep>
              )}
              <FormizStep name="step4" label="p.charge.archvie">
                <Attachments
                  currentFiles={archivos}
                  setCurrentFiles={setCurrentFiles}
                  isEdited={true}
                  uploadNewFile={uploadNewFile}
                  showParameters={true}
                />
              </FormizStep>
              <section className="form-responsive-container-buttons">
                <button type="submit" className="btn-primary">
                  <FormattedMessage
                    id="alert.button.confirm.general"
                    defaultMessage="Guardar cambios"
                  />
                </button>
                <button className="input-cancel" onClick={() => navigate(paths.technical)}>
                  <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
                </button>
              </section>
            </div>
          </form>
        </Formiz>
      )}
    </div>
  );
}
