import Search from 'common/Search';
import React, { useEffect, useState } from 'react';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import { Link } from 'react-router-dom';
import paths from 'services/paths';
// paths to routes
// hook para cargar los datos
import useGetData from 'hooks/useGetData';
// Context de búsqueda
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Llamar a la API
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';

const File = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <FileComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function FileComponent() {
  // use Hook of language v2
  const { formatterText, successRemoveItem } = useLangv2();
  // hook to loading data
  const { error, toggleLoading, displayMessage, displayLoading } = useGetData();

  // useContext de búsqueda
  const { setDataTable, dataTable, setSearchResults } = useSeachContext();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.attachmentType);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    getAll(endpoints.attachedFiles.getAllAttachedFiles).then((data) => {
      let newArray = [];
      data.forEach((item) =>
        newArray.push({
          id: item.idTipoArchivoAdjunto,
          nombre: item.nombre,
          extencionArchivo: item.extension,
          pesoMaximoArchivo: `${item.pesoMaximoArchivo} MB`,
          cantidad: item.cantidadMaxima,
          estado: item.estado,
          objeto: item,
        }),
      );
      setDataTable(newArray);
      setSearchResults(newArray);
      // show loading
      toggleLoading(false);
      setFile(newArray);
      setLoading(false);
    });
  };

  const handleDeleteItem = (id) => {
    deleteItem(endpoints.attachedFiles.deleteAttachedFile, id)
      .then((data) => {
        successRemoveItem();
        getDataTable();
        toggleLoading(false);

        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.attachedFiles.updateAttachedFile, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  // titulos de la tabla
  const titles = [
    formatterText('table.title.filename', 'Nombre de archivo adjunto'),
    formatterText('table.title.filetype', 'Tipo de archivo adjunto'),
    formatterText('table.title.size', 'Peso máximo del archivo'),
    formatterText('table.title.amount', 'Cantidad de archivos adjuntos'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && file !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createFile}>
                <button className="btn-add">
                  <FormattedMessage id="btn.createfile" defaultMessage="Crear archivo adjunto" />
                </button>
              </Link>
            )}
          </section>
          {permittedActions.consultar && (
            <DynamicTable
              titles={titles}
              data={getDataTable}
              pageName={PAGE_NAMES.Archivos}
              routeToEdit={paths.updateFile}
              canModify={permittedActions.editar}
              handleEditStateItem={handleEditStateItem}
              handleDeleteItem={handleDeleteItem}
              canDeleted={permittedActions.eliminar}
            />
          )}
        </section>
      ) : (
        displayLoading()
      )}
    </>
  );
}

export default File;
