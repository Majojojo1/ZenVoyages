import SelectorMulti from 'common/selects/SelectorMultiCreate';
import { NUMBERREGEX, TEXTREGEX } from 'common/validators/Regex';
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import File from 'models/File';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import endpoints from 'services/api';
import { addItem, deleteItem, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';

export default function CreateFile() {
  const navigate = useNavigate();
  const { id } = useParams();
  // Ejemplo de los datos de un formulario
  const [formData, setFormData] = useState(new File());
  const [tipo_archivo, setType] = useState(null);
  const [selectValues, setSelectValues] = useState([]);
  const [selectValuesInitial, setSelectValuesInitial] = useState([]);
  const { formatterText } = useLangv2();

  // Ayuda al toggle
  const [active, setActive] = useState(true);
  const { COOKIE_USER } = useAxios();
  const { errorProcess, updatedItem, resourceNotFound } = useLangv2();
  const { loading } = useGetData();
  const [existingAssociations, setExistingAssociations] = useState([]);

  useEffect(() => {
  }, [selectValues]);

  useEffect(() => {
    getItemById(endpoints.attachedFiles.getById, id).then((res) => {
      if (res === null) resourceNotFound();
      getItemById(endpoints.attachedFiles.getAssociates, id).then((resp) => {
        const allSelects = resp.map((item) => {
          return { value: item.tipoUsuario.idTipoUsuario, label: item.tipoUsuario.tipoUsuario, idTipoAdjuntoUsuario: item.idTipoAdjuntoUsuario };
        });
        setSelectValuesInitial(allSelects);
        setSelectValues(allSelects);


      });
      setType(res.extension);
      setFormData(res);
      setActive(res.estado);
    }).catch((err)=>{
      console.error(err);
    });
  }, [id]);

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match(TEXTREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  // update the form number
  const handleNumber = (e) => {
    if (e.target.value.match(NUMBERREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
    Date;
  };

  // Esta función se ejecuta al hacer click en el botón de crear
  const handleSubmit = (e) => {
    e.preventDefault();
    const cant = formData.cantidadMaxima || 1;
    const formattedData = {
      ...formData,
      cantidadMaxima: cant,
      extension: tipo_archivo,
      usuarioModificacion: COOKIE_USER,
    };

    const valueDelete = selectValuesInitial.filter(valueInitial => !selectValues.includes(valueInitial));
    const valueCreate = selectValues.filter(valueInitial => !valueInitial?.idTipoAdjuntoUsuario);
    // Actualiza el archivo principal
    const deleteValue = valueDelete.map((item) => deleteItem(endpoints.attachedFiles.deleteAssociates, item.idTipoAdjuntoUsuario));
    updateItem(endpoints.attachedFiles.updateAttachedFile, formattedData)
      .then((res) => {
        // Actualiza las asociaciones relatedUsers       
        const createValue = valueCreate.map((item) => {
          const data = {
            tipoArchivoAdjunto: { idTipoArchivoAdjunto: res.idTipoArchivoAdjunto }, // Usar el ID del archivo principal
            tipoUsuario: { idTipoUsuario: item.value },
            usuarioCreacion: COOKIE_USER,
            cantidad: formattedData.cantidadMaxima,
          };
          return addItem(endpoints.attachedFiles.relatedUsers, data);
        });        

        Promise.all([ ...deleteValue, ...createValue])
          .then(() => {
            updatedItem();
            navigate(paths.files);
          })
          .catch((error) => {
            console.error(error);
            // Manejar errores relacionados con la actualización de asociaciones aquí
          });
      })
      .catch((error) => {
        console.error(error);
        // Manejar errores relacionados con la actualización del archivo principal aquí
      });
    // updateItem(endpoints.attachedFiles.updateAttachedFile, formattedData).then((res) => {
    //   updatedItem();
    //   navigate(paths.files);
    // }).catch(err => errorProcess());
  };

  const selectorData = [
    { value: null, label: 'Seleccione un tipo de documento' },
    { value: '.png', label: 'PNG' },
    { value: '.jpg', label: 'JPG' },
    { value: '.pdf', label: 'PDF' },
    { value: '.doc', label: 'DOC' },
    { value: '.docx', label: 'DOCX' },
    { value: '.xls', label: 'XLS' },
    { value: '.xlsx', label: 'XLSX' },
    { value: '.ppt', label: 'PPT' },
    { value: '.pptx', label: 'PPTX' },
    { value: '.txt', label: 'TXT' },
    { value: '.zip', label: 'ZIP' },
    { value: '.rar', label: 'RAR' },
    { value: '.7z', label: '7Z' },
    { value: '.mp3', label: 'MP3' },
    { value: '.mp4', label: 'MP4' },
    { value: '.avi', label: 'AVI' },
    { value: '.mov', label: 'MOV' },
    { value: '.wmv', label: 'WMV' },
    { value: '.flv', label: 'FLV' },
    { value: '.mkv', label: 'MKV' },
    { value: '.mpg', label: 'MPG' },
    { value: '.mpeg', label: 'MPEG' },
    { value: '.3gp', label: '3GP' },
    { value: '.3g2', label: '3G2' },
    { value: '.gif', label: 'GIF' },
    { value: '.svg', label: 'SVG' },
  ];

  const idCategory = [
    { value: 1, label: formatterText('p.label.title.categoriaCliente') },
    { value: 2, label: formatterText('p.label.title.categoriaTercero') },
    { value: 3, label: formatterText('p.label.title.categoriaProveedor') },
    { value: 4, label: formatterText('p.label.title.categoriaEmpleado') },
  ];



  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.name', 'Nombre del Archivo')}</h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre || ''}
            onChange={handleText}
            placeholder="Archivo adjunto"
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.type', 'Tipo de Archivo')}</h3>
          <select
            name="extension"
            value={tipo_archivo}
            onChange={(e) => setType(e.target.value)}
            required
            disabled={loading}
          >
            {selectorData.map((item) => (
              <option key={item.value} value={item.value}>
                {item.label}
              </option>
            ))}
          </select>
        </section>
        <section className="form-responsive-information__option">
          <h3>  {formatterText('p.max.weight', 'Peso máximo')}       
          {` (Mb)`}
          </h3>
          <input
            className="input-primary"
            type="text"
            name="pesoMaximoArchivo"
            value={formData.pesoMaximoArchivo}
            onChange={handleNumber}
            placeholder="Peso del archivo"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.quantity', 'Cantidad de Archivos')} </h3>
          <input
            className="input-primary"
            type="text"
            name="cantidadMaxima"
            value={formData.cantidadMaxima}
            onChange={handleNumber}
            placeholder="Peso del archivo"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.categories.assosiated', 'Categorias asociadas')}</h3>

          <SelectorMulti
            data={idCategory}
            dataValue={selectValues}
            setterFunction={handleChangeMulti}
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Estado</h3>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">{active ? formatterText('"btn.active') : formatterText('btn.inactive')}</p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                  setFormData({ ...formData, estado: !active ? '1' : '0' });
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          {formatterText('btn.save.changes')}
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.files)}>
        {formatterText('btn.cancel')}
        </button>
      </section>
    </form>
  );
}
