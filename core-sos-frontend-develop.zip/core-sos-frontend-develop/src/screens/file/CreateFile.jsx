import React, { useState } from 'react';
// Import Hooks
import useAxios from 'hooks/useAxios';
import { useNavigate } from 'react-router-dom';
// Import Components
import Selector from 'common/Selector';
import { NUMBERREGEX, TEXTREGEX } from 'common/validators/Regex';
// Import Models
import File from 'models/File';
// Import Services
import SelectorMulti from 'common/selects/SelectorMultiCreate';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import paths from 'services/paths';

import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import useLangv2 from 'hooks/useLangv2';
import { addItem } from 'services/api/methods';
import Swal from 'sweetalert2';

export default function CreateFile() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new File());
  const [selectValues, setSelectValues] = useState([]);
  const [existingAssociations, setExistingAssociations] = useState([]);
  // Ayuda al toggle
  const { COOKIE_USER } = useAxios();
  const { formatterText } = useLangv2();

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match(TEXTREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  // update the form number
  const handleNumber = (e) => {
    if (e.target.value.match(NUMBERREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  // Esta función se ejecuta al hacer click en el botón de crear
  const handleSubmit = (e) => {
    e.preventDefault();
    const formattedData = {
      ...formData,
    };

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text:  formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.attachedFiles.saveAttachedFile, formattedData).then((response) => {
            relatedUsersToid(response.idTipoArchivoAdjunto, resolve, reject);
          });
        });
      },
    });
  };

  const relatedUsersToid = (id, resolve, reject) => {
    const promises = selectValues.map(
      (item) =>
        new Promise((reso, reje) => {
          const data = {
            tipoArchivoAdjunto: { idTipoArchivoAdjunto: id },
            tipoUsuario: { idTipoUsuario: item.value },
            usuarioCreacion: COOKIE_USER,
            cantidad: formData.cantidadMaxima,
          };
          addItem(endpoints.attachedFiles.relatedUsers, data)
            .then((res) => {
              reso(res);
            })
            .catch((err) => {
              reje(err);
            });
        }),
    );
    Promise.all(promises)
      .then((res) => {
        resolve(
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.confirm.created.general',
              'El registro se ha creado correctamente',
            ),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.files),
          }),
        );
      })
      .catch((err) => {
        reject(HandleOnError(formatterText('alert.title.associations.creation.failure')));
        console.log(err);
      });
  };

  const selectorData = [
    { value: null, label: formatterText('alert.title.select.file.type')},
    { value: '.png', label: 'PNG' },
    { value: '.jpg', label: 'JPG' },
    { value: '.pdf', label: 'PDF' },
    { value: '.doc', label: 'DOC' },
    { value: '.docx', label: 'DOCX' },
    { value: '.xls', label: 'XLS' },
    { value: '.xlsx', label: 'XLSX' },
    { value: '.ppt', label: 'PPT' },
    { value: '.pptx', label: 'PPTX' },
    { value: '.txt', label: 'TXT' },
    { value: '.zip', label: 'ZIP' },
    { value: '.rar', label: 'RAR' },
    { value: '.7z', label: '7Z' },
    { value: '.mp3', label: 'MP3' },
    { value: '.mp4', label: 'MP4' },
    { value: '.avi', label: 'AVI' },
    { value: '.mov', label: 'MOV' },
    { value: '.wmv', label: 'WMV' },
    { value: '.flv', label: 'FLV' },
    { value: '.mkv', label: 'MKV' },
    { value: '.mpg', label: 'MPG' },
    { value: '.mpeg', label: 'MPEG' },
    { value: '.3gp', label: '3GP' },
    { value: '.3g2', label: '3G2' },
    { value: '.gif', label: 'GIF' },
    { value: '.svg', label: 'SVG' },
  ];

  const idCategory = [
    { value: 1, label: formatterText('p.label.title.categoriaCliente') },
    { value: 2, label: formatterText('p.label.title.categoriaTercero') },
    { value: 3, label: formatterText('p.label.title.categoriaProveedor') },
    { value: 4, label: formatterText('p.label.title.categoriaEmpleado') },
  ];

  const [tipo_archivo, setType] = useState(null);

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.name', 'Nombre del Archivo')}</h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre || ''}
            onChange={handleText}
            placeholder={formatterText('input.placeholder.attached.file', 'Archivo Adjunto')}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.type', 'Tipo de Archivo')}</h3>
          <Selector
            name="extension"
            data={selectorData}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecione una opción"
              />
            }
            dataValue={tipo_archivo}
            setterFunction={setFormData}
            isRequired={true}
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>
            {formatterText('p.max.weight', 'Peso máximo')}
            {` (Mb)`}
          </h3>
          <input
            className="input-primary"
            type="text"
            name="pesoMaximoArchivo"
            value={formData.pesoMaximoArchivo}
            onChange={handleNumber}
            placeholder={formatterText('input.placeholder.file.weight', 'Peso del Archivo')}
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.file.quantity', 'Cantidad de Archivos')} </h3>
          <input
            className="input-primary"
            type="text"
            name="cantidadMaxima"
            value={formData.cantidadMaxima}
            onChange={handleNumber}
            placeholder="Peso del archivo"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>{formatterText('p.categories.assosiated', 'Categorias asociadas')}</h3>

          <SelectorMulti
            data={idCategory}
            dataValue={selectValues}
            setterFunction={handleChangeMulti}
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          {formatterText('btn.save.changes', 'Guardar cambios')}
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.files)}>
          {formatterText('btn.cancel', 'Cancelar')}
        </button>
      </section>
    </form>
  );
}
