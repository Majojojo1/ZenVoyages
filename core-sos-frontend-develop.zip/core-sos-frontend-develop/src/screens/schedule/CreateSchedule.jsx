import React, { useContext, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import { useNavigate } from 'react-router-dom';
// Import Components
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import CustomAlert from 'components/CustomAlert';
import DatePicker from 'components/pickers/DatePicker';
import { Modal } from 'react-responsive-modal';
import AddTimeZone from './actions/AddTimeZone';
import ModalAssignTechnical from './modals/ModalAssignTechnical';
import ModalTechnicalTZ from './modals/ModalTechnicalTZ';
// Import libs
import HandlerText from 'common/validators/HandlerText';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
// Import Services
import endpoints from 'services/api';
import { addItem, COOKIE_USER } from 'services/api/methods';
import paths from 'services/paths';
// import Models
import Agenda from 'models/Agenda';
// import Styles
import HandleOnError from 'common/validators/HandleOnError';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import 'react-tabs/style/react-tabs.css';

const CreateSchedule = () => {
  return (
    <SearchWrapper>
      <CreateScheduleComponent />
    </SearchWrapper>
  );
}
const CreateScheduleComponent = () => {
  const {
    timeZoneSelected,
    setTimeZoneSelected,
    setSearchResults,
    searchResults = [],
    setDataTable,
  } = useSeachContext();
  const {
    openModalTechnicalToAssign,
    openModalTechnicalToReview,
    setOpenModalTechnicalToAssign,
    setOpenModalTechnicalToReview,
    setTechnicalsToAssing,
  } = useContext(AppContext);

  // clear context time zones
  // useEffect(() => {
  //   setDataTable([]);
  //   setSearchResults([]);
  //   setTimeZoneSelected([]);
  // }, []);

  // use Hook of language v2
  const {
    formatterText,
    noFilledContent,
    errorDataRecovery,
    newItemCreated,
    errorProcess,
    customSB,
    handleRequestError,
  } = useLangv2();

  const titlesTableTimeZone = [
    formatterText('text.shedule.time.zone', 'Franjas horarias'),
    formatterText('table.shedule.view.technical', 'Técnicos asociados'),
    formatterText('table.actions', 'Acciones'),
  ];

  // Modal config
  const onCloseTechnicalToAssign = () => setOpenModalTechnicalToAssign(false);
  const onCloseTechnicalToReview = () => setOpenModalTechnicalToReview(false);
  // useNavigate
  const navigate = useNavigate();
  // useState for the form
  const [formData, setFormData] = useState(new Agenda());

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  // Create an agenda
  const handleSubmit = (e) => {
    e.preventDefault();

    const conditionalCreateAgenda =
      formData.nombre === '' || formData.fechaInicio === '' || formData.fechaFin === '';

    if (conditionalCreateAgenda) {
      noFilledContent();
    } else {
      const DATA = {
        nombre: formData.nombre,
        fechaInicio: dateFormat(formData.fechaInicio, 'isoDateTime'),
        fechaFin: dateFormat(formData.fechaFin, 'isoDateTime'),
        idCoordinadorCreador: {
          idUsuario: COOKIE_USER,
        },
        usuarioCreacion: COOKIE_USER,
      };

      // is possible to searchResults have new time zones so we need to validate
      if (timeZoneSelected.length > 0) {
        createItem(DATA);
      } else {
        customSB(
          'warning',
          'snackbar.error.time.zone.required',
          'Es necesario asociar al menos una franja horaria a la agenda.',
        );
      }
    }
  };

  // Create new agenda
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          //  Here we call the service to create the item
          addItem(endpoints.agenda.addAgenda, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => associateAgendaToTimeZone(res.idAgenda),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError((formatterText(err.response?.data?.message)));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  // Associate a time zone to an agenda
  const associateAgendaToTimeZone = async (idAgenda) => {
    await timeZoneSelected.forEach(async (franja) => {
      const TYPE_ID = typeof franja.idFranjaHorariaAgenda === 'string';
      if (TYPE_ID) {
        const DATA = {
          idFranjaHorariaAgenda: null,
          idAgenda: {
            idAgenda: parseInt(idAgenda),
          },
          idFranjaHoraria: {
            idFranjaHoraria: franja.idFranjaHoraria,
          },
          estado: 1,
          // "fechaCreacion": DATE_CREATED_AT,
          usuarioCreacion: COOKIE_USER,
        };
        await addItem(endpoints.agenda.addAssociationTimezoneSchedule, DATA)
          .then((_) => {
            newItemCreated();
            navigate(paths.schedule);
          })
          .catch((_) => {
            errorProcess();
          });
      }
    });

    // getTimeZoneByIdAgenda(idAgenda);
  };

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="container-wrapForm-content-no-border">
        <section className="wrapForm w100-container-complete">
          <label className="wrapForm__label">
            <span className="warpForm-text">
              <FormattedMessage id="text.shedule.create.name" defaultMessage="Nombre agenda" />
            </span>
            <input
              className="input-primary"
              type="text"
              name="nombre"
              placeholder={formatterText('text.shedule.create.name', 'Nombre agenda')}
              onChange={handleText}
              value={formData.nombre}
              maxLength="45"
            />
          </label>
          <label>
            <span className="warpForm-text">
              <FormattedMessage
                id="text.shedule.create.startdate"
                defaultMessage="Fecha de inicio"
              />
            </span>
            <DatePicker
              name="fechaInicio"
              selectValue={formData.fechaInicio}
              setterFunction={setFormData}
              placeholder={formatterText('text.shedule.create.startdate', 'Fecha de inicio')}
              noIcon={true}
            />
          </label>

          <label>
            <span className="warpForm-text">
              <FormattedMessage
                id="text.shedule.create.enddate"
                defaultMessage="Fecha de finalización"
              />
            </span>
            <DatePicker
              name="fechaFin"
              selectValue={formData.fechaFin}
              setterFunction={setFormData}
              placeholder={formatterText('text.shedule.create.enddate', 'Fecha de finalización')}
              noIcon={true}
              min={formData.fechaInicio}
            />
          </label>
        </section>

        {/* Franjas horaras config */}
        <AddTimeZone />

        <section className="form-responsive-container-information">
          <span className="title-table">
            <FormattedMessage
              id="text.shedule.create.timezone.associated"
              defaultMessage="Franjas horarias del día"
            />
          </span>
          <MultiTableMinimal
            titles={titlesTableTimeZone}
            data={timeZoneSelected}
            type="franjasHorariaSchedule"
            dialog={dialog}
            closeDialog={closeDialog}
            canSearch={true}
          />
        </section>

        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            <FormattedMessage id="btn.save" defaultMessage="Guardar" />
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.schedule)}>
            <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
          </button>
        </section>
      </form>
      {/* techinical to assign */}
      <Modal
        open={openModalTechnicalToAssign}
        onClose={onCloseTechnicalToAssign}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalAssignTechnical />
      </Modal>
      {/* techinical to review */}
      <Modal
        open={openModalTechnicalToReview}
        onClose={() => {
          onCloseTechnicalToReview();
          setTechnicalsToAssing([]);
        }}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalTechnicalTZ />
      </Modal>
    </>
  );
};

export const CreateScheduleWithSearch = (props) => (
  <SearchWrapper>
    <CreateSchedule {...props} />
  </SearchWrapper>
);

export default CreateScheduleWithSearch;
