import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { usePermissionContext } from 'context/PermissionContext';
import React, { useEffect, useState } from 'react';
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
import useLangv2 from '../../hooks/useLangv2';
import ListSchedule from './ListSchedule';
import TableAgeda from './TableAgenda';

const TabScheduleSelect = () => {
  const { formatterText } = useLangv2();

  const tabs = [
    {
      nombre: formatterText('nav.parent.3.child.option.6', 'Agendas'),
      componente: <TableAgeda />,
      idPermiso: MODULES_NAME.schedule.schedule,
    },
    {
      nombre: formatterText('snackbar.coral.availability.tech', 'Disponibilidad de técnicos'),
      componente: <ListSchedule />,
      idPermiso: MODULES_NAME.schedule.availability,
    },
  ];

  // no pasa nada diferente cuando cambio el 0 a 1
  const [selectedTab, setSelectedTab] = useState(tabs[0]);
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.schedule.principal);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    setSelectedTab(tabs[parseInt(localStorage.getItem('indexTab')) || 0]);
  }, [permittedActions]);
  return (
    <section
      className="table-container"
      style={{
        marginTop: '1rem',
      }}
    >
      <Tabs selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                localStorage.setItem('indexTab', index.toString());
                permissionsAccess(tab.idPermiso);
              }}
              key={index}
              className="new-tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {permittedActions.consultar && (tabs.map((tab, index) => (
          <TabPanel
            style={{
              border: '1px solid var(--text-secondary)',
            }}
            key={index}
          >
            {tab.componente}
          </TabPanel>)
        ))}
      </Tabs>
    </section>
  );
};

export default TabScheduleSelect;
