import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import { useNavigate } from 'react-router-dom';
// Import Components
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import CustomAlert from 'components/CustomAlert';
import DatePicker from 'components/pickers/DatePicker';
import { Modal } from 'react-responsive-modal';
import { getItemBetweenDates } from 'services/api/methods';
import AddTimeZone from './actions/AddTimeZone';
import ModalAssignTechnical from './modals/ModalAssignTechnical';
import ModalTechnicalTZ from './modals/ModalTechnicalTZ';
// Import libs
import HandlerText from 'common/validators/HandlerText';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
// Import Services
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { COOKIE_USER, addItem } from 'services/api/methods';
import paths from 'services/paths';
// import Models
import Agenda from 'models/Agenda';
// import Styles
import 'react-tabs/style/react-tabs.css';

const CloneSchedule = () => (
  <SearchWrapper>
    <CloneScheduleComponent />
  </SearchWrapper>
);

const CloneScheduleComponent = () => {
  const {
    timeZoneSelected,
    setTimeZoneSelected,
    setSearchResults,
    searchResults = [],
    setDataTable,
  } = useSeachContext();
  const {
    openModalTechnicalToAssign,
    openModalTechnicalToReview,
    setOpenModalTechnicalToAssign,
    setOpenModalTechnicalToReview,
    setTechnicalsToAssing,
    agendaCloneData,
    selectTimeZoneId,
    techSelectToAssign,
    setTechSelectToAssign,
  } = useContext(AppContext);

  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();

  const [idAgendaToClone, setIdAgendaToClone] = useState(null);
  const [idTimeZones, setIdTimeZones] = useState([]);
  const [body, setBody] = useState([]);
  const [dataReady, setDataReady] = useState(false);

  // clear context time zones
  useEffect(() => {
    // eslint-disable-next-line react-hooks/exhaustive-deps

    const { agendaData, timeZones, technicals } = agendaCloneData;
    if (agendaData === undefined || timeZones === undefined || technicals === undefined) {
      navigate(paths.schedule);
    } else {
      setFormData({
        idUsuario: agendaData.idUsuario,
        nombre: '',
        fechaInicio: agendaData.fechaInicio,
        fechaFin: agendaData.fechaFin,
        concepto: agendaData.concepto,
        estado: agendaData.estado,
      });
      // show loading
      setLoadingProgress(true);

      setTimeZoneSelected(timeZoneSelected);
      setOpenModalTechnicalToAssign(openModalTechnicalToAssign);
      setTechSelectToAssign(techSelectToAssign);
    }

    const idAgendaLocal = JSON.parse(localStorage.getItem('dataUpdate')).idAgenda;

    setIdAgendaToClone(idAgendaLocal);

    const timeZonesData = localStorage.getItem('timeZones');

    if (timeZonesData) {
      const timeZonesArray = JSON.parse(timeZonesData);
      const extractedIds = timeZonesArray.map((item) => item.idFranjaHoraria);
      setIdTimeZones(extractedIds);
      setTimeZoneSelected(timeZonesArray);
      setDataReady(true);
      setTimeZoneSelected(timeZonesArray);

    }
  }, []);

  useEffect(() => {
    if (dataReady) {
      fetchTechForAllIdFranjaHoraria();
    }
  }, [dataReady]);

  // get all technicals by time zones
  const fetchTechForAllIdFranjaHoraria = async () => {
    const fetchDataPromises = idTimeZones.map((idFranjaHoraria) =>
      getItemBetweenDates(
        endpoints.agenda.getAllFranjaHorariaByIdAgenda,
        idFranjaHoraria,
        idAgendaToClone,
      ),
    );

    try {
      const allData = await Promise.all(fetchDataPromises);
      const flattenedData = allData.flat();

      const data = flattenedData.map((element) => ({
        idFranjaHorariaAgendaTecnico: null,
        idAgenda: {
          idAgenda: element.idAgenda,
        },
        idFranjaHoraria: {
          idFranjaHoraria: element.idFranjaHoraria,
        },
        idTecnico: {
          idTecnico: element.idTecnico.idTecnico,
        },
        idTipoAgenda: {
          idTipoAgenda: element.idTipoAgenda.idTipoAgenda,
        },
        usuarioCreacion: element.usuarioCreacion,
      }));

      setBody(data);
    } catch (error) {
      console.error('Error fetching data for idFranjaHoraria array:', error);
      // Handle error if needed
    }
  };

  const fetchDataForIdFranjaHoraria = (idTimeZones, idAgenda) => {
    const updatedBody = body.map((item) => {
      return {
        idFranjaHorariaAgendaTecnico: null,
        idTipoAgenda: {
          idTipoAgenda: item.idTipoAgenda.idTipoAgenda,
        },
        idTecnico: {
          idTecnico: item.idTecnico.idTecnico,
        },
        idAgenda: {
          idAgenda: idAgenda,
        },
        idFranjaHoraria: {
          idFranjaHoraria: item.idFranjaHoraria.idFranjaHoraria.idFranjaHoraria,
        },
        usuarioCreacion: COOKIE_USER,
      };
    });

    const addFranjasPromises = idTimeZones.map((idFranjaHoraria) => {
      const matchingItems = updatedBody.filter(
        (item) => item.idFranjaHoraria.idFranjaHoraria === idFranjaHoraria,
      );

      return addItem(endpoints.agenda.addFranjas, matchingItems);
    });

    Promise.all(addFranjasPromises)
      .then((responses) => {
        setBody(updatedBody);
      })
      .catch((error) => {
        console.error('Error adding Franjas:', error);
      });
  };

  // use Hook of language v2
  const {
    formatterText,
    noFilledContent,
    newItemCreated,
    errorProcess,
    customSB,
    errorDataRecovery,
    handleRequestError,
  } = useLangv2();

  const titlesTableTimeZone = [
    formatterText('text.shedule.time.zone', 'Franjas horarias'),
    formatterText('table.shedule.view.technical', 'Técnicos asociados'),
    formatterText('table.actions', 'Acciones'),
  ];

  // Modal config
  const onCloseTechnicalToAssign = () => setOpenModalTechnicalToAssign(false);
  const onCloseTechnicalToReview = () => setOpenModalTechnicalToReview(false);
  // useNavigate
  const navigate = useNavigate();
  // useState for the form
  const [formData, setFormData] = useState(new Agenda());

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  const handleNameText = (e) => {
    HandlerText(e, formData, setFormData);
    if (e.target.name === 'nombre') {
      setFormData((prevValue) => ({
        ...prevValue,
        [e.target.name]: `${e.target.value}`,
      }));
    }
  };

  // Create an agenda
  const handleSubmit = (e) => {
    e.preventDefault();

    const conditionalCreateAgenda =
      formData.nombre === '' || formData.fechaInicio === '' || formData.fechaFin === '';

    if (conditionalCreateAgenda) {
      noFilledContent();
    } else {
      const DATA = {
        nombre: formData.nombre,
        fechaInicio: dateFormat(formData.fechaInicio, 'isoDateTime'),
        fechaFin: dateFormat(formData.fechaFin, 'isoDateTime'),
        idCoordinadorCreador: {
          idUsuario: COOKIE_USER,
        },
        usuarioCreacion: COOKIE_USER,
      };

      // is possible to timeZoneSelected have new time zones so we need to validate
      if (timeZoneSelected.length > 0) {
        createItem(DATA);
      } else {
        customSB(
          'warning',
          'snackbar.error.time.zone.required',
          'Es necesario asociar al menos una franja horaria a la agenda.',
        );
      }
    }
  };

  // Create new agenda
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          //  Here we call the service to create the item
          addItem(endpoints.agenda.addAgenda, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => associateAgendaToTimeZone(res.idAgenda),
                }),
              );
              fetchDataForIdFranjaHoraria(idTimeZones, res.idAgenda);
            })
            .catch((err) => {
              handleRequestError(err);
            });
        });
      },
    });
  };

  // Associate a time zone to an agenda
  const associateAgendaToTimeZone = async (idAgenda) => {
    await timeZoneSelected.forEach(async (franja) => {
      const DATA = {
        idFranjaHorariaAgenda: null,
        idAgenda: {
          idAgenda: parseInt(idAgenda),
        },
        idFranjaHoraria: {
          idFranjaHoraria: franja.idFranjaHoraria,
        },
        estado: 1,
        usuarioCreacion: COOKIE_USER,
      };
      await addItem(endpoints.agenda.addAssociationTimezoneSchedule, DATA)
        .then((_) => {
          newItemCreated();
        })
        .catch((_) => {
          errorProcess();
        });
    });
    // navigate(paths.schedule);
    navigate(paths.updateSchedule.replace(':id', parseInt(idAgenda)));
  };

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  return (
    <>
      {loadingProgress ? (
        <form onSubmit={handleSubmit} className="container-wrapForm-content-no-border">
          <section className="wrapForm w100-container-complete">
            <label className="wrapForm__label">
              <span className="warpForm-text">
                <FormattedMessage id="text.shedule.create.name" defaultMessage="Nombre agenda" />
              </span>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                placeholder={formatterText('text.shedule.create.name', 'Nombre agenda')}
                onChange={handleNameText}
                // value={`Clone ${formData.nombre}`}
                maxLength="45"
              />
            </label>
            <label>
              <span className="warpForm-text">
                <FormattedMessage
                  id="text.shedule.create.startdate"
                  defaultMessage={formatterText('text.shedule.create.startdate', 'Fecha de inicio')}
                />
              </span>
              <DatePicker
                name="fechaInicio"
                selectValue={formData.fechaInicio}
                setterFunction={setFormData}
                placeholder={formatterText('text.shedule.create.startdate', 'Fecha de inicio')}
                noIcon={true}
              />
            </label>

            <label>
              <span className="warpForm-text">
                <FormattedMessage
                  id="text.shedule.create.enddate"
                  defaultMessage="Fecha de finalización"
                />
              </span>
              <DatePicker
                name="fechaFin"
                selectValue={formData.fechaFin}
                setterFunction={setFormData}
                placeholder={formatterText('text.shedule.create.enddate','Fecha de finalización')}
                noIcon={true}
                min={formData.fechaInicio}
              />
            </label>
          </section>

          {/* Franjas horaras config */}
          <AddTimeZone />

          <section className="form-responsive-container-information">
            <span className="title-table">
              <FormattedMessage
                id="text.shedule.create.timezone.associated"
                defaultMessage="Franjas horarias del día"
              />
            </span>
            <MultiTableMinimal
              titles={titlesTableTimeZone}
              data={timeZoneSelected}
              type="franjasHorariaSchedule"
              dialog={dialog}
              closeDialog={closeDialog}
              canSearch={true}
            />
          </section>

          <section className="form-responsive-container-buttons">
            <button type="submit" className="btn-primary">
              <FormattedMessage id="btn.save" defaultMessage="Guardar" />
            </button>
            <button className="input-cancel" onClick={() => navigate(paths.schedule)}>
              <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
            </button>
          </section>
        </form>
      ) : (
        <DisplayProgress />
      )}
      {/* techinical to assign */}
      <Modal
        open={openModalTechnicalToAssign}
        onClose={onCloseTechnicalToAssign}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalAssignTechnical />
      </Modal>
      {/* techinical to review */}
      <Modal
        open={openModalTechnicalToReview}
        onClose={() => {
          onCloseTechnicalToReview();
          setTechnicalsToAssing([]);
        }}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalTechnicalTZ
          idAgendaToClone={idAgendaToClone}
          setIdAgendaToClone={setIdAgendaToClone}
          body={body}
          setBody={setBody}
        />
      </Modal>
    </>
  );
};

export default CloneSchedule;
