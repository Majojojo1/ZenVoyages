import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
// Import Libs
import { FormattedMessage } from 'react-intl';
// Import Components
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
// Import Services
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { useParams } from 'react-router-dom';
import endpoints from 'services/api';
import { getItemBetweenDates } from 'services/api/methods';

export default function ModalTechnicalTZ() {
  return (
    <SearchWrapper>
      <ModalTechnicalTZComponent />
    </SearchWrapper>
  );
}

function ModalTechnicalTZComponent() {
  const {
    dataTableTechnicalAssigned,
    setDataTableTechnicalAssigned,
    selectTimeZoneId, //selectTimeZoneId: id de franja horaria
  } = useContext(AppContext);
  // get the id from the url
  const { id } = useParams();

  // use Hook of language v2
  const { formatterText, errorDataRecovery } = useLangv2();
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // titles of table
  const titlesTableTimeZone = [
    formatterText('table.shedule.view.technical', 'Técnicos asociados'),
    formatterText('table.actions', 'Acciones'),
  ];

  useEffect(() => {
    getAllTechiniansByTimeZone();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { dataTableTechnical, setDataTableTechnical, setDataTable, dataTable } =
    useSeachContext();

  // get all technicals by time zone
  const getAllTechiniansByTimeZone = () => {
    setLoadingProgress(true);
    getItemBetweenDates(endpoints.agenda.getAllFranjaHorariaByIdAgenda, selectTimeZoneId, id)
      .then((response) => {        
        // variable empty to save the data
        let data = [];
        response.forEach((element) => {
          const IS_TECH = element.idTecnico.idTercero === null;
          if (IS_TECH) {
            data.push({
              id: element.idFranjaHorariaTecnico,
              tech: `${element.idTecnico.idEmpleado.primerNombre.trim()} ${element.idTecnico.idEmpleado.primerApellido.trim()}-${element.idTecnico.idEmpleado.identificacion.trim()}`,
              status: element.idTipoAgenda.idTipoAgenda,
              obj: element,
            });
          } else {
            data.push({
              id: element.idFranjaHorariaTecnico,
              tech: `${element.idTecnico.idTercero.nombre.trim()}-${element.idTecnico.idTercero.correo.trim()}-${element.idTecnico.idTercero.identificacion.trim()}`,
              status: element.idTipoAgenda.idTipoAgenda,
              obj: element,
            });
          }
        });

        //eliminamos item.obj de tableTechToAssign
        const dataTech = data.map((item) => {
          const { obj, ...newItem } = item;
          return newItem;
        });

        // set the data to the table
        setDataTableTechnical(data);
        setDataTableTechnicalAssigned(data);
        setDataTable(data);
        setLoadingProgress(false);
      })
      .catch((_) => {
        errorDataRecovery();
        setLoadingProgress(false);
      });
  };

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  return (
    <div>
      <section className="form-responsive-container-information">
        <span className="title-table">
          <FormattedMessage
            id="text.shedule.title.technical.associated"
            defaultMessage="Técnicos asociados a la franja horaria"
          />
        </span>
        {loadingProgress ? (
          <DisplayProgress />
        ) : (
          <MultiTableMinimal
            titles={titlesTableTimeZone}
            data={dataTableTechnical}
            type="technicalAssign"
            dialog={dialog}
            closeDialog={closeDialog}
            canSearch={true}
          />
        )}
      </section>
    </div>
  );
}
