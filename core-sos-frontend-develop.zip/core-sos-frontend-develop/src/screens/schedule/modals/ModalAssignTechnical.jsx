import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import useToggle from 'hooks/useToggle';
import { useParams } from 'react-router-dom';
// Import Components
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import SelectComboBox from 'common/selects/SelectComboBox';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import Services
import { useSeachContext } from 'context/SearchContext';
import 'react-tabs/style/react-tabs.css';
import endpoints from 'services/api';
import { addItem, getAll, getItemBetweenDates } from 'services/api/methods';

export default function ModalAssignTechnical() {
  const {
    dataTableTechToAssign,
    setDataTableTechToAssign,
    setTableTechToAssign,
    setDataTable,
  } = useSeachContext();
  const {
    selectTimeZoneId,
    techSelectToAssign,
    setOpenModalTechnicalToAssign,
    setOpenModalTechnicalToReview,
  } = useContext(AppContext);
  // use Hook of language v2
  const { formatterText, errorDataRecovery, customSB, handleRequestError } = useLangv2();

  const { id } = useParams();

  const titlesTableTimeZone = [
    formatterText('table.shedule.view.technical', 'Técnicos asociados'),
    formatterText('table.actions', 'Acciones'),
  ];

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  useEffect(() => {
    getAllCountriesServices();
    getAllDeparmentServices();
    getAllMunicipalitieservices();
    getAllTypeDocumentServices();
    handlerFilters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();

  // Get the country for the selector
  const getAllCountriesServices = () => {
    getAll(endpoints.zones.getAllCountries)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idPais,
              label: item.nombrePais,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          countries: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // Get the departments for the selector
  const getAllDeparmentServices = () => {
    getAll(endpoints.zones.getAllDepartments)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idDepartamento,
              label: `${item.nombre}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          departments: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // Get the municipalities for the selector
  const getAllMunicipalitieservices = () => {
    getAll(endpoints.zones.getAllMunicipalities)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idMunicipio,
              label: item.nombre,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          municipalities: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // Get the municipalities for the selector
  const getAllTypeDocumentServices = () => {
    getAll(endpoints.institutions.getAllTypeDocument)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            id: item.idTipoDocumento,
            label: item.nombre,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          typeDocument: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      countries: [],
      departments: [],
      municipalities: [],
      typeDocument: [],
    },
  ]);

  // useToggle
  const [value, toggle] = useToggle();

  // Data from advance search inputs
  const [formFilters, setFormFilters] = useState({
    nombreTecnico: '',
    cargo: '',
    numeroDocumento: '',
  });

  // Handle to search technicals by filters
  const handlerFilters = (e) => {
    setLoadingProgress(true);
    if (e) {
      e.preventDefault();
    }
    getItemBetweenDates(endpoints.agenda.getTechnicalsNoAssignToTimezone, id, selectTimeZoneId)
      .then((response) => {
        let data = [];
        response.forEach((element) => {
          let techNameId = '';
          if (element.idEmpleado === null) {
            techNameId = element.idTercero.nombre + ' - ' + element.idTercero.identificacion;
          } else {
            techNameId =
              element.idEmpleado.primerNombre +
              ' ' +
              element.idEmpleado.primerApellido +
              ' - ' +
              element.idEmpleado.identificacion;
          }

          data.push({
            id: null,
            // tech: RemoveSpaces(element.nombre),
            tech: techNameId,
            status: 1,
            obj: element,
          });
        });
        setDataTable(data);
        setDataTableTechToAssign(data);
        setTableTechToAssign(data);
        setLoadingProgress(false);
      })
      .catch(() => {
        setLoadingProgress(false);
        errorDataRecovery();
      });
  };

  const handleTextFilters = (e) => {
    setFormFilters({
      ...formFilters,
      [e.target.name]: e.target.value,
    });
  };

  const handleSaveTechnicalsToTimeZone = (e) => {
    e.preventDefault();

    if (techSelectToAssign.length === 0) {
      customSB(
        'warning',
        'snackbar.warning.time.zone.technical.selected',
        `Es necesario asociar al menos un técnico a la franja horaria.`,
      );
    } else {
      console.log(techSelectToAssign);
      addItem(endpoints.agenda.addFranjas, techSelectToAssign)
        .then(() => {
          customSB(
            'success',
            'snackbar.success.time.zone.technical.selected',
            `Los técnicos se han asociado correctamente a la franja horaria.`,
          );
          setOpenModalTechnicalToReview(true);
          setOpenModalTechnicalToAssign(false);
        })
        .catch((err) => {
          handleRequestError(err);
        });
    }
  };

  const clearFilters = (e) => {
    e.preventDefault();
    // Clear inputs
    setFormFilters({
      nombreTecnico: '',
      cargo: '',
      numeroDocumento: '',
    });

    // Clear selects
    setSelectValues({
      idCargo: {
        id: 0,
        label: '',
      },
      idPais: {
        id: 0,
        label: '',
      },
      idDepartamento: {
        id: 0,
        label: '',
      },
      idMunicipio: {
        id: 0,
        label: '',
      },
      tipoDocumento: {
        id: 0,
        label: '',
      },
    });
  };

  // State of the labels and ids of the selectors
  const [selectValues, setSelectValues] = useState({
    idCargo: {
      id: 0,
      label: '',
    },
    idPais: {
      id: 0,
      label: '',
    },
    idDepartamento: {
      id: 0,
      label: '',
    },
    idMunicipio: {
      id: 0,
      label: '',
    },
    tipoDocumento: {
      id: 0,
      label: '',
    },
  });

  return (
    <div>
      <div className="link-search-container">
        <p
          className="link-search"
          onClick={() => {
            toggle(!value);
          }}
        >
          {formatterText('text.action.show.advanced.search', 'Búsqueda avanzada')}
        </p>
      </div>

      {value && (
        <section className="wrapForm w-100">
          <label className="wrapForm__label">
            <input
              className="input-primary"
              type="text"
              name="nombreTecnico"
              placeholder={formatterText('input.placeholder.filter.by.tech', 'Filtrar por nombre técnico')}
              onChange={handleTextFilters}
              value={formFilters.nombreTecnico}
              maxLength="45"
              required
            />
          </label>
          <label className="wrapForm__label">
            <input
              className="input-primary"
              type="text"
              name="cargo"
              placeholder={formatterText('input.placeholder.agenda.select.position', 'Filtrar por cargo')}
              onChange={handleTextFilters}
              value={formFilters.cargo}
              maxLength="45"
              required
            />
          </label>
          <SelectComboBox
            name="idPais"
            selectValue={selectValues.idPais}
            setterFunction={(idPais) => setSelectValues({ ...selectedSearch, idPais })}
            data={selectedSearch.countries}
            placeholder={
              <FormattedMessage
                id="input.placeholder.agenda.select.country"
                defaultMessage="Filtrar por país"
              />
            }
          />
          <SelectComboBox
            name="idDepartamento"
            selectValue={selectValues.idDepartamento}
            setterFunction={(idDepartamento) =>
              setSelectValues({ ...selectedSearch, idDepartamento })
            }
            data={selectedSearch.departments}
            placeholder={
              <FormattedMessage
                id="input.placeholder.agenda.select.deparment"
                defaultMessage="Filtrar por departamento"
              />
            }
          />
          <SelectComboBox
            name="idMunicipio"
            selectValue={selectValues.idMunicipio}
            setterFunction={(idMunicipio) => setSelectValues({ ...selectedSearch, idMunicipio })}
            data={selectedSearch.municipalities}
            placeholder={
              <FormattedMessage
                id="input.placeholder.agenda.select.municipality"
                defaultMessage="Filtrar por municipio"
              />
            }
          />
          <SelectComboBox
            name="tipoDocumento"
            selectValue={selectValues.tipoDocumento}
            setterFunction={(tipoDocumento) =>
              setSelectValues({ ...selectedSearch, tipoDocumento })
            }
            data={selectedSearch.typeDocument}
            placeholder={
              <FormattedMessage
                id="input.placeholder.agenda.select.typeDocument"
                defaultMessage="Filtrar por tipo de documento"
              />
            }
          />

          <label className="wrapForm__label">
            <input
              className="input-primary"
              type="text"
              name="numeroDocumento"
              placeholder={formatterText('text.filter.identification', 'Filtrar por identificación')}
              onChange={handleTextFilters}
              value={formFilters.numeroDocumento}
              maxLength="15"
              required
            />
          </label>
          <button className="btn-search" onClick={(e) => handlerFilters(e)}>
          {formatterText('btn.search', 'Buscar')}
          </button>
          <button
            className="btn-search"
            onClick={(e) => {
              clearFilters(e);
            }}
          >
            {formatterText('btn.clean', 'Limpiar')}
          </button>
        </section>
      )}
      <section
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
        }}
      >
        <button
          type="button"
          className="btn btn-primary"
          onClick={(e) => handleSaveTechnicalsToTimeZone(e)}
        >
          {formatterText('btn.end', 'Terminar')}
        </button>
      </section>
      <section className="form-responsive-container-information">
        <span className="title-table">
          <FormattedMessage
            id="text.shedule.title.technical.found"
            defaultMessage="Técnicos encontrados"
          />
        </span>
        {loadingProgress ? (
          <DisplayProgress />
        ) : (
          <MultiTableMinimal
            titles={titlesTableTimeZone}
            data={dataTableTechToAssign}
            type="technicalNoAssign"
            dialog={dialog}
            closeDialog={closeDialog}
            canSearch={true}
          //auxFunction={getAllDataTechnicals}
          />
        )}
      </section>
    </div>
  );
}
