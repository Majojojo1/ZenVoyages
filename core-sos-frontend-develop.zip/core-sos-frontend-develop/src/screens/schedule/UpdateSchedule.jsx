import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import DatePicker from 'components/pickers/DatePicker';
import { MdOutlineFileCopy } from 'react-icons/md';
import { Modal } from 'react-responsive-modal';
import AddTimeZone from './actions/AddTimeZone';
import ModalAssignTechnical from './modals/ModalAssignTechnical';
import ModalTechnicalTZ from './modals/ModalTechnicalTZ';
// Import Libs
import HandlerText from 'common/validators/HandlerText';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import Services
import endpoints from 'services/api';
import { addItem, COOKIE_USER, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';
// import Models
import Agenda from 'models/Agenda';
// import Styles
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import 'react-tabs/style/react-tabs.css';

const UpdateSchedule = () => (
  <SearchWrapper>
    <UpdateScheduleComponent />
  </SearchWrapper>
);

const UpdateScheduleComponent = () => {
  const {
    timeZoneSelected,
    setTimeZoneSelected,
    setSearchResults,
    searchResults = [],
    setDataTable,
  } = useSeachContext();
  const {
    openModalTechnicalToAssign,
    openModalTechnicalToReview,
    setOpenModalTechnicalToAssign,
    setOpenModalTechnicalToReview,
    setTechnicalsToAssing,
    setAgendaCloneData,
    techSelectToAssign,
  } = useContext(AppContext);
  // get the id from the url
  const { id } = useParams();
  // Get data from the API and fill the data
  useEffect(() => {
    getDataAgenda();
    getTimeZoneByIdAgenda();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getDataAgenda();
    getTimeZoneByIdAgenda();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const [duplicateTimeZone, setDuplicateTimeZone] = useState([]);
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // get all data agenda
  const getDataAgenda = () => {
    // show loading
    setLoadingProgress(false);
    getItemById(endpoints.agenda.getAgendaDataByid, id)
      .then((res) => {
        const fechaFinal = new Date(res.fechaFin);
        fechaFinal.setHours(fechaFinal.getHours()+5);
        setFormData({
          idAgenda: res.idAgenda,
          idUsuario: res.idCoordinadorCreador.idUsuario,
          nombre: res.nombre,
          fechaInicio: res.fechaInicio,
          fechaFin: fechaFinal.toISOString(),
          concepto: res.concepto,
          estado: res.estado,
          fechaCreacion: res.fechaCreacion,
          fechaModificacion: res.fechaModificacion,
          usuarioCreacion: res.usuarioCreacion,
          usuarioModificacion: res.usuarioModificacion,
        });
        // show loading
        setLoadingProgress(true);
      })
      .catch(() => {
        errorDataRecovery();
      });
  };

  // get all timezone by id agenda
  const getTimeZoneByIdAgenda = () => {
    getItemById(endpoints.agenda.getAllTimezoneByidAgenda, id)
      .then((response) => {
        let data = [];
        response.forEach((element) => {
          const timeZone = `${element.idFranjaHoraria.nombre} ${element.idFranjaHoraria.idDiaSemana.dia} - ${element.idFranjaHoraria.idHoraInicio.hora} - ${element.idFranjaHoraria.idHoraFin.hora}`;
          data.push({
            idFranjaHorariaAgenda: element.idFranjaHorariaAgenda,
            idFranjaHoraria: element.idFranjaHoraria.idFranjaHoraria,
            timeZone,
          });
        });
        // create a new array with the timezones but set idFranjaHorariaAgenda to null
        let timeZone = data.map((item) => {
          return {
            idFranjaHorariaAgenda: uuidv4(),
            idFranjaHoraria: item.idFranjaHoraria,
            timeZone: item.timeZone,
          };
        });
        // Save the time zones data in localStorage
        localStorage.setItem('timeZones', JSON.stringify(timeZone));
        setDataTable(data);
        setTimeZoneSelected(data);
        setSearchResults(data);
        setDuplicateTimeZone(timeZone);
      })
      .catch((_) => {
        errorDataRecovery();
      });
  };

  // use Hook of language v2
  const {
    formatterText,
    noFilledContent,
    errorDataRecovery,
    newItemCreated,
    errorProcess,
    customSB,
  } = useLangv2();

  const titlesTableTimeZone = [
    formatterText('text.shedule.time.zone', 'Franjas horarias'),
    formatterText('table.shedule.view.technical', 'Técnicos asociados'),
    formatterText('table.actions', 'Acciones'),
  ];

  // Modal config
  const onCloseTechnicalToAssign = () => setOpenModalTechnicalToAssign(false);
  const onCloseTechnicalToReview = () => setOpenModalTechnicalToReview(false);
  // useNavigate
  const navigate = useNavigate();
  // useState for the form
  const [formData, setFormData] = useState(new Agenda());

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  // Create an agenda
  const handleSubmit = (e) => {
    e.preventDefault();

    const conditionalCreateAgenda =
      formData.nombre === '' || formData.fechaInicio === '' || formData.fechaFin === '';

    if (conditionalCreateAgenda) {
      noFilledContent();
    } else {
      const DATA = {
        idAgenda: formData.idAgenda,
        nombre: formData.nombre,
        fechaInicio: dateFormat(formData.fechaInicio, 'isoDateTime'),
        fechaFin: dateFormat(formData.fechaFin, 'isoDateTime'),
        idCoordinadorCreador: {
          idUsuario: formData.idUsuario,
        },
        concepto: formData.concepto,
        estado: formData.estado,
        fechaCreacion: formData.fechaCreacion,
        usuarioCreacion: formData.usuarioCreacion,
        usuarioModificacion: COOKIE_USER,
      };
      // is possible to searchResults have new time zones so we need to validate
      if (searchResults.length > 0) {
        createItem(DATA);
      } else {
        customSB(
          'warning',
          'snackbar.error.time.zone.required',
          'Es necesario asociar al menos una franja horaria a la agenda.',
        );
      }
    }
  };

  // Associate a time zone to an agenda
  const associateAgendaToTimeZone = async (idAgenda) => {
    await searchResults.forEach(async (franja) => {
      const TYPE_ID = typeof franja.idFranjaHorariaAgenda === 'string';
      if (TYPE_ID) {
        const DATA = {
          idFranjaHorariaAgenda: null,
          idAgenda: {
            idAgenda: parseInt(idAgenda),
          },
          idFranjaHoraria: {
            idFranjaHoraria: franja.idFranjaHoraria,
          },
          estado: 1,
          // "fechaCreacion": DATE_CREATED_AT,
          usuarioCreacion: COOKIE_USER,
        };
        await addItem(endpoints.agenda.addAssociationTimezoneSchedule, DATA)
          .then(() => {
            newItemCreated();
          })
          .catch(() => {
            errorProcess();
          });
      }
    });

    getDataAgenda();
  };

  // Update agenda
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          //  Here we call the service to create the item
          updateItem(endpoints.agenda.updateAgenda, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => associateAgendaToTimeZone(res.idAgenda),
                }),
              );
            })
            .catch((err) => {
              reject();
              HandleOnError(
                formatterText(
                  'alert.message.failed.general',
                  'Error al crear el registro, por favor intente nuevamente.',
                ),
              );
            });
        });
      },
    });
  };

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  const cloneShedule = () => {
    setAgendaCloneData({
      agendaData: formData,
      timeZones: duplicateTimeZone,
      technicals: techSelectToAssign,
    });
    navigate(paths.duplicateSchedule);
  };

  return (
    <>
      {loadingProgress ? (
        <form onSubmit={handleSubmit} className="container-wrapForm-content-no-border">
          <section
            style={{
              display: 'flex',
              width: '100%',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
            onClick={(e) => {
              e.preventDefault();
              cloneShedule();
            }}
          >
            <p
              className="p-clone-action"
              style={{
                padding: '1rem',
              }}
            >
              {formatterText('header.title.schedule.clone', 'Clonar agenda')}
            </p>
            <MdOutlineFileCopy size={25} color="gray" cursor="pointer" />
          </section>

          <section className="wrapForm w100-container-complete">
            <label className="wrapForm__label">
              <span className="warpForm-text">
                <FormattedMessage id="text.shedule.create.name" defaultMessage="Nombre agenda" />
              </span>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                placeholder={formatterText('text.shedule.create.name', 'Nombre agenda')}
                onChange={handleText}
                value={formData.nombre}
                maxLength="45"
              />
            </label>
            <label>
              <span className="warpForm-text">
                <FormattedMessage
                  id="text.shedule.create.startdate"
                  defaultMessage="Fecha de inicio"
                />
              </span>
              <DatePicker
                name="fechaInicio"
                selectValue={formData.fechaInicio}
                setterFunction={setFormData}
                placeholder={formatterText('text.shedule.create.startdate', 'Fecha de inicio')}
                noIcon={true}
              />
            </label>

            <label>
              <span className="warpForm-text">
                <FormattedMessage
                  id="text.shedule.create.enddate"
                  defaultMessage="Fecha de finalización"
                />
              </span>
              <DatePicker
                name="fechaFin"
                selectValue={formData.fechaFin}
                setterFunction={setFormData}
                placeholder={formatterText('text.shedule.create.enddate','Fecha de finalización')}
                noIcon={true}
                min={formData.fechaInicio}
              />
            </label>
          </section>
          {/* Franjas horaras config */}
          <AddTimeZone getTimeZoneByIdAgenda={getTimeZoneByIdAgenda} />

          <section className="form-responsive-container-information">
            <span className="title-table">
              <FormattedMessage
                id="text.shedule.create.timezone.associated"
                defaultMessage="Franjas horarias del día"
              />
            </span>
            <MultiTableMinimal
              titles={titlesTableTimeZone}
              data={timeZoneSelected}
              type="franjasHorariaSchedule"
              dialog={dialog}
              closeDialog={closeDialog}
              canSearch={true}
            />
          </section>

          <section className="form-responsive-container-buttons">
            <button type="submit" className="btn-primary">
              <FormattedMessage id="btn.save" defaultMessage="Guardar" />
            </button>
            <button className="input-cancel" onClick={() => navigate(paths.schedule)}>
              <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
            </button>
          </section>
        </form>
      ) : (
        <DisplayProgress />
      )}
      {/* techinical to assign */}
      <Modal
        open={openModalTechnicalToAssign}
        onClose={() => {
          onCloseTechnicalToAssign();
          getTimeZoneByIdAgenda();
        }}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalAssignTechnical />
      </Modal>
      {/* techinical to review */}
      <Modal
        open={openModalTechnicalToReview}
        onClose={() => {
          onCloseTechnicalToReview();
          setTechnicalsToAssing([]);
          getTimeZoneByIdAgenda();
        }}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <ModalTechnicalTZ />
      </Modal>
    </>
  );
};

export default UpdateSchedule;
