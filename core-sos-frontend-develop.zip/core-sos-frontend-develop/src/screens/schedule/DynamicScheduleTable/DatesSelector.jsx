import PropTypes from 'prop-types';
import React from 'react';
// Import Components
import DatePicker from 'components/pickers/DatePicker';
// Import Styles
import styles from './DatesSelector.module.css';

const DatesSelector = ({ setDatesAux, datesAux, getTechnicalsBeweenDates }) => {
  return (
    <section className="wrapForm w-100">
      <section className="form-responsive-container-information">
        {/* input dates */}
        <section className={styles.datesContainer}>
          <section className={styles.datesSelector}>
            <div>
              <DatePicker
                name="fechaInicio"
                selectValue={datesAux.fechaInicio}
                setterFunction={setDatesAux}
                placeholder={'Fecha de inicio'}
                noIcon={true}
              />
            </div>
            <div>
              <DatePicker
                name="fechaFin"
                selectValue={datesAux.fechaFin}
                setterFunction={setDatesAux}
                placeholder={'Fecha de Finalización'}
                noIcon={true}
                // set min when fechaInicio is selected, can selected old dates or same day
                min={datesAux.fechaInicio ? new Date(datesAux.fechaInicio).toISOString() : ''}
                // set max when fechaInicio is selected, only only past dates and a month ahead
                max={
                  datesAux.fechaInicio
                    ? new Date(
                        new Date(datesAux.fechaInicio).getTime() + 30 * 24 * 60 * 60 * 1000,
                      ).toISOString()
                    : ''
                }
              />
            </div>
            <section className={styles.btnSearch}>
              <button className="btn-search" onClick={getTechnicalsBeweenDates}>
                Buscar
              </button>
            </section>
          </section>
        </section>
        <section className={styles.containerData}>
          <p
            style={{
              backgroundColor: '#85EB4E',
              padding: '0.5rem 1rem',
              borderRadius: '0.5rem',
            }}
          >
            Disponible
          </p>
          <p
            style={{
              backgroundColor: '#F1684E',
              padding: '0.5rem 1rem',
              borderRadius: '0.5rem',
            }}
          >
            No disponible
          </p>
        </section>
      </section>
    </section>
  );
};

DatesSelector.propTypes = {
  setDatesAux: PropTypes.func.isRequired,
  datesAux: PropTypes.object.isRequired,
  getTechnicalsBeweenDates: PropTypes.func.isRequired,
};

export default DatesSelector;
