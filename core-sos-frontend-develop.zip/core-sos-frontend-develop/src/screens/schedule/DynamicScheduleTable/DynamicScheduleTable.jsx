import React, { useEffect, useRef } from 'react';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
// Import Libs
// import { FormattedMessage } from "react-intl";
// Import Styles
import 'styles/minimalTable.css';
// Agenda module
import RowTechnical from 'common/minimalTables/schedule/RowTechnical';
import { useSeachContext } from 'context/SearchContext';

export default function DynamicScheduleTable({ titles, data, type, max, canSearch }) {
  const { handleSearch, searchResults = [], setDataTable } = useSeachContext();
  // use Hook of language v2
  const { formatterText } = useLangv2();
  // Choose a row
  const ChooseRow = (item, i) => {
    const TABLE_TYPE = {
      agendaData: <RowTechnical item={item} key={i} />,
    };

    return TABLE_TYPE[type];
  };
  const searchRef = useRef(null);

  useEffect(() => {
    setDataTable(data);
  }, [data]);

  return (
    <>
      <div
        className={max ? 'table-minimal-container width-100' : 'table-minimal-container'}
        style={{
          margin: '0 auto',
          width: '96%',
          marginBottom: '20px',
        }}
      >
        {canSearch && (
          <div style={{ width: '50%' }} className="wrap">
            <div className="search">
              <input
                type="text"
                className="searchTerm spacing-b1"
                // placeholder={
                //   // <FormattedMessage
                //   //   id="placeholder.search.multi.items"
                //   //   defaultMessage="Buscar por palabra"
                //   // />
                // }
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                ref={searchRef}
                onChange={handleSearch}
              />
              <button
                type="button"
                onClick={() => handleSearch({ target: searchRef.current })}
                className="searchButton"
              >
                <img
                  src={require('assets/search.png')}
                  style={{ height: '20px' }}
                  alt="search logo"
                />
              </button>
            </div>
          </div>
        )}
        <TableContainer component={Paper}>
          <Table className="table-minimal">
            <TableHead>
              <TableRow className="infoo">
                {titles.map((title) => (
                  <TableCell align="center" scope="col" key={title}>
                    {title}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>{searchResults.map((item, i) => ChooseRow(item, i))}</TableBody>
          </Table>
        </TableContainer>
      </div>
    </>
  );
}
