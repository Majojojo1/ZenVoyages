import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
// Import hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import useToggle from 'hooks/useToggle';
// Import Components
import SelectComboBox from 'common/selects/SelectComboBox';
import { MdKeyboardArrowDown, MdKeyboardArrowRight } from 'react-icons/md';
import { FormattedMessage } from 'react-intl';
import DatesSelector from './DynamicScheduleTable/DatesSelector';
import DynamicScheduleTable from './DynamicScheduleTable/DynamicScheduleTable';
// Import libs
import HandlerText from 'common/validators/HandlerText';
import dateFormat from 'dateformat';
import moment from 'moment';
import example from './data.example';
// Import services
import { SearchContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { addItem, getAll, getItemBetweenDates, getItemById } from 'services/api/methods';
// Import Styles
import 'react-big-calendar/lib/sass/styles.scss';
import styles from './Schedule.module.css';

export default function ListSchedule() {
  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      technicals: [],
      positions: [],
      countries: [],
      departments: [
        [
          {
            id: 2,
            label: 'Seleccione un país',
          },
        ],
      ],
      municipalities: [],
      typeDocument: [],
    },
  ]);

  // State of the labels and ids of the selectors
  const [selectValues, setSelectValues] = useState({
    idTecnico: {
      id: 0,
      label: '',
    },
    idCargo: {
      id: 0,
      label: '',
    },
    idPais: {
      id: 0,
      label: '',
    },
    idDepartamento: {
      id: 0,
      label: '',
    },
    idMunicipio: {
      id: 0,
      label: '',
    },
    tipoDocumento: {
      id: 0,
      label: '',
    },
  });

  // Get data from the API and fill the data
  useEffect(() => {
    // get data from selets
    getAllTechnicalsServices();
    getAllPositionsServices();
    getAllCountriesServices();
    getAllMunicipalitieservices();
    getAllTypeDocumentServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [datesAux, setDatesAux] = useState({
    fechaInicio: new Date(),
    fechaFin: new Date(),
  });
  const { setTimeZoneSelected } = useContext(SearchContext);
  // clear context time zones
  useEffect(() => {
    setTimeZoneSelected([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Manage select options deparments
  useEffect(() => {
    if (selectValues.idPais.id !== 0) {
      getAllDeparmentByIdCountryServices(selectValues.idPais.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectValues.idPais.id]);

  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // useToggle
  const [value, toggle] = useToggle();

  /**
   * [*] The structure of the data is as follows:
   * {
   *  idAgenda: 45,
   *  idTecnico: 39,
   *  idUsuario: 55,
   *  nombreAgenda: "agenda test 1",
   *  nombreTecnico: "1545432",
   *  identificacionTecnico: "2432",
   *  disponibilidad: 1 // 1 = Disponible, 2 = No Disponible que determina el color de la franja horaria
   *  dayOfWeekToPaint: 1 // 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday, 7 = Sunday
   *  this value is get in time zone data idDiaSemana
   *  resultOfArrayNumbersOfTheHours: [0, 1, 2, 3, 4, 5] // 0 = 00:00, 1 = 01:00, 2 = 02:00, 3 = 03:00, 4 = 04:00, 5 = 05:00
   *  resultOfTimesToPaint: 4 // This case in the funcion calculateTimesToPaint() the result is 4 because if the fechaInicio 2022-10-31 is Monday and the fechaFin 2022-11-27 is Monday,
   *  the result is 4 because the difference between 2022-10-31 is Monday count 1 and review how Monday (days week) havce until 2022-11-27 is Monday and the result is 4
   *  counterTimesToPaint: 0 // this is a counter to paint the times in the table, and when is paint increase the counter
   *  date: "2022-10-31" // this a index of the table when finish the iteration and then repeat the process to paint other day
   * }
   */

  const [TechnicalsData, setTechnicalsData] = useState([]);

  const getTechnicalsBeweenDates = (e) => {
    e.preventDefault();
    setLoadingProgress(true);

    getItemBetweenDates(
      endpoints.agenda.getTechnicalsBetweenDates,
      dateFormat(datesAux.fechaInicio, 'yyyy-mm-dd'),
      dateFormat(datesAux.fechaFin, 'yyyy-mm-dd'),
    )
      .then((response) => {
        generateTimeSlots(response);
      })
      .catch(() => {
        generateTimeSlots(example);
        errorDataRecovery();
        setLoadingProgress(false);
      });
  };

  const determineIfTheDataIsIncluded = (val1, val2) => {
    let result = false;
    val1.forEach((el) => {
      if (val2.includes(el)) {
        result = true;
      }
    });
    return result;
  };

  const determinateDate = (date, counter) => {
    const CURRENT_DATE = new Date(date);

    // increse the counter to add 7 days to the date
    const INCREASE_COUNTER = 7 * counter;
    return new Date(CURRENT_DATE.setDate(CURRENT_DATE.getDate() + INCREASE_COUNTER)).toDateString();
  };

  // this function calculate the times to paint in the table
  const calculateTimesToPaint = (dateStart, dateEnd) => {
    const startDay = new Date(dateStart).getDay(); // obtener el día de la semana para la fecha de inicio (0 = domingo, 1 = lunes, etc.)
    const endDay = new Date(dateEnd).getDay(); // obtener el día de la semana para la fecha final (0 = domingo, 1 = lunes, etc.)
    let timesToPaint = 0; // inicializar un contador para el número de veces a pintar

    // si el día de inicio y el día final son iguales, devuelve 1
    if (startDay === endDay) {
      return 1;
    }

    // si el día de inicio y el día final son diferentes, cuenta el número de veces que ocurre el día de inicio entre las dos fechas
    let currentDate = new Date(dateStart);
    while (currentDate < new Date(dateEnd)) {
      if (currentDate.getDay() === startDay) {
        timesToPaint++;
      }
      currentDate.setDate(currentDate.getDate() + 1); // moverse al día siguiente
    }

    return timesToPaint;
  };

  // this function identify the range of the week to determinate if the dates goes to monday to sunday, if not
  // return the id of the day of the week that are in the range
  const identifyRangeOfTheWeek = (startDate, endDate) => {
    const result = [];
    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      const dayOfWeek = currentDate.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 7) {
        result.push(dayOfWeek);
      }
      currentDate.setDate(currentDate.getDate() + 1);
      if (currentDate > endDate) {
        break;
      }
    }

    return result;
  };

  // use Hook of language v2
  const { fillAtLeastOne, errorDataRecovery } = useLangv2();

  // Update a string to set into the filters
  const handleTextFilters = (e) => {
    HandlerText(e, formFilters, setFormFilters);
  };

  // form to control the text filters data
  const [formFilters, setFormFilters] = useState({
    nombreTecnico: '',
    numeroDocumento: '',
  });

  // Get the position for the selector
  const getAllPositionsServices = () => {
    getAll(endpoints.cargos.getAllCargos)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idCargo,
              label: item.nombre,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          positions: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllTechnicalsServices = () => {
    getAll(endpoints.technical.getAllTechnical)
      .then((res) => {
        // create new array
        const newArray = [];
        console.log('esta es la respuesta de tecicos', res);
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1 && item.idEmpleado) {
            const name = `${item.idEmpleado.primerNombre} ${item.idEmpleado.segundoNombre}`;
            const surname = `${item.idEmpleado.primerNombre}`;
            newArray.push({
              id: item.idTecnico,
              label: `${name} ${surname}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          technicals: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the country for the selector
  const getAllCountriesServices = () => {
    getAll(endpoints.zones.getAllCountries)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idPais,
              label: item.nombrePais,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          countries: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the departments for the selector by id country
  const getAllDeparmentByIdCountryServices = (idCountry) => {
    getItemById(endpoints.zones.getAllDepartmentsByIdCountry, idCountry).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            id: item.idDepartamento,
            label: `${item.nombre}`,
          });
        }
      });
      // set the values of the select
      setDeparmentsData(newArray);
    });
  };

  // Get the municipalities for the selector
  const getAllMunicipalitieservices = () => {
    getAll(endpoints.zones.getAllMunicipalities)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idMunicipio,
              label: item.nombre,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          municipalities: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the municipalities for the selector
  const getAllTypeDocumentServices = () => {
    getAll(endpoints.institutions.getAllTypeDocument)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            id: item.idTipoDocumento,
            label: item.nombre,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          typeDocument: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const { loading, toggleLoading } = useGetData();

  // titles of table
  // const titlesTableTimeZone = [
  //   formatterText("table.shedule.view.technical", "Técnicos asociados"),
  //   formatterText("table.actions", "Acciones"),
  // ];
 

  // Handle to search technicals by filters
  const handlerFilters = (e) => {
    e.preventDefault();
    // toggle(true);

    // if the data is empty, the data is data = {}
    if (
      selectValues.idTecnico.label === '' &&
      selectValues.idCargo.label === '' &&
      selectValues.idPais.label === '' &&
      selectValues.idMunicipio.label === '' &&
      selectValues.tipoDocumento.label === '' &&
      formFilters.numeroDocumento === ''
    ) {
      fillAtLeastOne();
      // toggle(false);

    } else {

      let DATA = {
        // idTecnico: formFilters.nombreTecnico,
        idTecnico: [selectValues.idTecnico.id],
        idCargo: selectValues.idCargo.id !== 0 ? [selectValues.idCargo.id] : [],
        idPais: selectValues.idPais.id !== 0 ? [selectValues.idPais.id] : [],
        idDepartamento:
          selectValues.idDepartamento.id !== 0 ? [selectValues.idDepartamento.id] : [],
        idMunicipio: selectValues.idMunicipio.id !== 0 ? [selectValues.idMunicipio.id] : [],
        idTipoDocumento: selectValues.tipoDocumento.id !== 0 ? [selectValues.tipoDocumento.id] : [],
        identificacion: formFilters.numeroDocumento !== '' ? [formFilters.numeroDocumento] : [],
        fechaIncio:
          dateFormat(datesAux.fechaInicio, 'isoDateTime') ===
          dateFormat(datesAux.fechaFin, 'isoDateTime')
            ? ''
            : dateFormat(datesAux.fechaInicio, 'isoDateTime'),
        fechaFin:
          datesAux.fechaInicio === datesAux.fechaFin
            ? ''
            : dateFormat(datesAux.fechaFin, 'isoDateTime'),
      };

      addItem(endpoints.agenda.getAllTecnicalByAdvancedSearch, DATA)
        .then((response) => {
          // toggle(false);
          generateTimeSlots(response);
          // getTechnicalsByAdvancedSearch(response);
        })
        .catch((err) => {
          // toggle(false);
          errorDataRecovery();
          // console.log(err);
        });
    }
  };

  const generateTimeSlots = (data) => {
    // [1] The date user inputs (datesAux with fechaInicio and fechaFin) calculate/get all dates in the range
    const arrDays = getDaysInRange(datesAux.fechaInicio, datesAux.fechaFin);
    // [1.1] Then the resultOfRange ["01/01/2023", "01/02/2023",  ... "01/31/2023"] is used it to create several array of dates by each day of week:
    const { domingo, lunes, martes, miercoles, jueves, viernes, sabado } = separateDays(arrDays);

    // MondayDaysArr ["02/01/2023", "09/01/2023", "16/01/2023"] --> length = 3
    // TuesdayDaysArr ["03/01/2023", "10/01/2023", "17/01/2023"] --> length = 3

    const MondayDaysArr = lunes;
    const TuesdayDaysArr = martes;
    const WednesdayDaysArr = miercoles;
    const ThursdayDaysArr = jueves;
    const FridayDaysArr = viernes;
    const SaturdayDaysArr = sabado;
    const SundayDaysArr = domingo;

    /**
         * [2] In this step, read all info from the backend to segment and create an new Array of arrays of each tech with their time zone by day of week and hours (at the end exist 7 arrays of each timeZone arrays data)
         Ex:

         techTimeZoneMonday = [{
     idAgenda    111
     nombreAgenda    "Diferentes secciones"
    "idTecnico": 50,
    "idUsuario": 50,
    "nombreTecnico": "Example",
    "identificacion": "123456789",
    "fechaIncio": "2023-01-15"
    "fechaFin": "2023-01-31"
    "idDiaSemana": 1,
     idHoraInicio    "00:00"
     idHoraFin    "23:00"
     idTipoAgenda: 1
},
         {
     idAgenda    110
     nombreAgenda    "Diferentes 2"
    "idTecnico": 50,
    "idUsuario": 50,
    "nombreTecnico": "Example",
    "identificacion": "123456789",
    "fechaInicio": "2023-01-13"
    "fechaFin": "2023-01-31"
    "idDiaSemana": 1,
     idHoraInicio    "18:00"
     idHoraFin    "23:00"
     idTipoAgenda: 1
},
         ... ]

         techTimeZoneTuesday = [{}, {}, ... {}]
         */

    let techObj = data;
    // - sort data variable, organize the data by same idTecnico
    techObj.sort((a, b) => {
      return a.idTecnico - b.idTecnico;
    });

    const {
      techTimeZoneMonday,
      techTimeZoneTuesday,
      techTimeZoneWednesday,
      techTimeZoneThursday,
      techTimeZoneFriday,
      techTimeZoneSaturday,
      techTimeZoneSunday,
    } = segmentTechsByDayOfWeek(techObj);

    // [3] Fun part: iterate each [DAY_WEEK]DaysArr with each techTimeZone[DAY_WEEK]
    // to calculate FranjaHorariaDefinitiva and push of DT

    // [3.1] MondayDaysArr = ["02/01/2023", "09/01/2023", "16/01/2023"]
    // [3.2] techTimeZoneMonday = [{
    //      idAgenda    111
    //      nombreAgenda    "Diferentes secciones"
    //     "idTecnico": 50,
    //     "idUsuario": 50,
    //     "nombreTecnico": "Example",
    //     "identificacion": "123456789",
    //     "fechaIncio": "2023-01-15"
    //     "fechaFin": "2023-01-31"
    //     "idDiaSemana": 1,
    //      idHoraInicio    "00:00"
    //      idHoraFin    "23:00"
    //      idTipoAgenda: 1
    // },

    // DATA_TOTAL: [{}, {}, ... {}]
    let DT = [];

    // iterate each day of week monday
    MondayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneMonday.forEach((techWeekDay) => {
        const FI = dateFormat(`${techWeekDay.fechaInicio}T10:00:00`, 'mm/dd/yyyy');

        // const FI = moment(new Date(techWeekDay.fechaInicio)).format(
        //   "MM/DD/YYYY",
        // );
        const FF = dateFormat(`${techWeekDay.fechaFin}T10:00:00`, 'mm/dd/yyyy');
        // const FF = moment(new Date(techWeekDay.fechaFin)).format("MM/DD/YYYY");
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );

        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });

    // iterate each day of week Tuesday
    TuesdayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneTuesday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);

        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });
    // iterate each day of week Wednesday
    WednesdayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneWednesday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });
    // iterate each day of week Thursday
    ThursdayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneThursday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });
    // iterate each day of week Friday
    FridayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneFriday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });
    // iterate each day of week Saturday
    SaturdayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneSaturday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });
    // iterate each day of week Sunday
    SundayDaysArr.forEach((itemDate) => {
      // [3.2.1] iterate the date to check if is in range
      // FranjaHorariaDefinitiva params: (fechaInicioAgenda, fechaFinAgenda tech.idDiaSemana, item.date, tech)
      techTimeZoneSunday.forEach((techWeekDay) => {
        const FI = moment(new Date(techWeekDay.fechaInicio)).format('MM/DD/YYYY');
        const FF = moment(new Date(techWeekDay.fechaFin)).format('MM/DD/YYYY');
        // [3.2.2] check if the date is in range
        const { isInRange, franjaHorariaDefinitiva } = generateFranjaHorariaDefinitiva(
          FI,
          FF,
          itemDate,
          techWeekDay,
        );
        const totalHours = calculateTotalHours(franjaHorariaDefinitiva);
        // [3.2.3] if is in range then push to DT
        if (isInRange) {
          // [3.2.4] create the object to push to DT
          const obj = {
            ...techWeekDay,
            itemDate,
            totalHours,
            franjaHorariaDefinitiva,
          };

          // [3.2.5] push to DT
          DT.push(obj);
        }
        // [3.2.6] if is not in range then continue
      });
    });

    // sort date by itemDate using moment
    DT.sort((a, b) => {
      const dateA = moment(a, 'YYYY-MM-DD');
      const dateB = moment(b, 'YYYY-MM-DD');
      return dateA.diff(dateB);
    });

    console.log(DT);

    setTechnicalsData(DT);
    setLoadingProgress(false);
  };

  /**
   * @param {string} fechaInicioAgenda
   * @param {string} fechaFinAgenda
   * @param {number} idDiaSemana
   * @param {string} itemDate
   * @param {object} tech
   * @returns {object} {isInRange: boolean, franjaHorariaDefinitiva: []}
   */
  const generateFranjaHorariaDefinitiva = (FIA, FFA, D, TECH) => {
    // [3.2.2] check if the date is in range
    // 1. item.date [ 02/01/2023 ] x
    // 2. item.date [ 16/01/2023 ] o
    // 3. item.date [ 30/01/2023 ] x
    // fechasAgenda [ 15/01/2023    27/01/2023 ]

    // CONDITION: fechaInicioAgenda <= item.date && fechaFinAgenda >= item.date
    if (FIA <= D && FFA >= D) {
      // CASE 2:   T && T =  T
      // TRUE: is in range so calculate FranjaHorariaDefinitiva, using and array of 24 keys to represent 24
      // hours and hours from the timeZone to create an array of string to know how to
      // paint the row and see the details
      const franjaHorariaDefinitiva = generateTimeZones(TECH);
      return {
        isInRange: true,
        franjaHorariaDefinitiva: franjaHorariaDefinitiva,
      };
    } else {
      // CASE 1:   F && T =  F
      // CASE 3:   T && F =  F
      // FALSE: no time zone have that day
      return { isInRange: false, franjaHorariaDefinitiva: [] };
    }
  };

  /**
   *
   * @param {*} timeZone
   * @param {*} techData
   * @param {*} update
   * @param {*} OldTech
   * @returns
   */
  const generateTimeZones = (techData) => {
    /**
     * techData have a structure like this
     * {
     *  "fechaFin: "2023-02-28",
     *  "fechaInicio: "2023-02-01",
     *  "idAgenda": 117,
     *  "idDiaSemana": 1,
     *  "idHoraFin": "23:00",
     *  "idHoraInicio": "18:00",
     *  "idTecnico": 67,
     *  "idTipoAgenda": 2,
     *  "idUsuario": 110,
     *  "identificacion": "54185151848",
     *  "nombreFranjaHoraria": "Franja Lunes Tarde",
     *  "nombreAgenda": "Error",
     *  "nombreTecnico": "Esteban Jair",
     * }
     *
     * Now we need which range of the time zone is available start with idHoraInicio
     * and end with idHoraFin (0 to 23 in hours), and know which hours are available
     * or not available by the idTipoAgenda
     */
    const agendaName = techData.nombreAgenda;
    const IDAgenda = techData.idAgenda;
    const nameTimeZone = techData.nombreFranjaHoraria;
    const hours = Array.from(Array(24).keys());

    // color of the time zone
    const color =
      techData.idTipoAgenda === 1
        ? `A;;${agendaName};;${IDAgenda};;${nameTimeZone}`
        : `I;;${agendaName};;${IDAgenda};;${nameTimeZone}`;
    // split the hours and convert them in int
    const startHour = parseInt(techData.idHoraInicio.split(':')[0]);
    const endHour = parseInt(techData.idHoraFin.split(':')[0]);
    const LIST_HOURS = calculateListHours(startHour, endHour);

    /**
     * iterate by hours to know which hours are available or not available
     * generate an array with the hours available, not available and neutral
     *  the array will be like this
     * [ "0N", "1A", "2I", ..., "23N" ]
     * where N is neutral, A is available and I is not available
     */
    const franjaHorariaDefinitiva = hours.map((hour) => {
      const hourAvailable = LIST_HOURS.includes(hour);
      return hourAvailable ? `${hour}${color}` : `${hour}N`;
    });

    if (techData.clone.length > 0) {
      // if the techData have clones then iterate by the clones
      // to know which hours are available or not available, however
      // verify if that date of the current techData is in range of the clone and collides
      techData.clone.forEach((clone) => {
        const cloneStartHour = parseInt(clone.idHoraInicio.split(':')[0]);
        const cloneEndHour = parseInt(clone.idHoraFin.split(':')[0]);
        const cloneListHours = calculateListHours(cloneStartHour, cloneEndHour);

        const CloneName = clone.nombreAgenda;
        const CloneIDAgenda = clone.idAgenda;
        const CloneNameTimeZone = clone.nombreFranjaHoraria;

        // color of the clone
        const colorClone =
          clone.idTipoAgenda === 1
            ? `A;;${CloneName};;${CloneIDAgenda};;${CloneNameTimeZone}`
            : `I;;${CloneName};;${CloneIDAgenda};;${CloneNameTimeZone}`;

        const collides = verifyCollisionBetweenDates(
          techData.fechaInicio,
          techData.fechaFin,
          clone.fechaInicio,
          clone.fechaFin,
        );

        if (collides) {
          // if the clone collides with the current techData then
          // iterate because the clone is in range of the current techData, so
          // update the franjaHorariaDefinitiva
          const cloneFranjaHorariaDefinitiva = hours.map((hour) => {
            const hourAvailable = cloneListHours.includes(hour);
            return hourAvailable ? `${hour}${colorClone}` : `${hour}N`;
          });

          /**
           *  update the time franjaHorariaDefinitiva of the technical
           * sobreescribiendo las franjas horarias de I se sobreescriben las franjas horarias de A siempre
           */

          cloneFranjaHorariaDefinitiva.forEach((hourSingle) => {
            const hourFormat = hourSingle.split(';;')[0];
            // remove last character
            const HOUR = parseInt(hourFormat.substring(0, hourFormat.length - 1));

            const hourAvailable = cloneListHours.includes(HOUR); // [13, 14, 15] verify if index number is in the list

            const oldTechHour = franjaHorariaDefinitiva[HOUR];
            const hasICurrent = colorClone.split(';;')[0].includes('I');
            try {
              if (hourAvailable) {
                const DECIDE_LAST_DATA = hasICurrent ? `${HOUR}${colorClone}` : oldTechHour;

                const D_T = {
                  N: `${HOUR}${colorClone}`,
                  I: oldTechHour,
                  A: DECIDE_LAST_DATA,
                };
                // get an single value
                const ANALYZE_VALUE = oldTechHour.split(';;')[0];

                // use an includes to know which letter have D_T
                let review = '';
                if (ANALYZE_VALUE.includes('N')) {
                  review = D_T['N'];
                } else if (ANALYZE_VALUE.includes('I')) {
                  review = D_T['I'];
                } else if (ANALYZE_VALUE.includes('A')) {
                  review = D_T['A'];
                }

                franjaHorariaDefinitiva[HOUR] = review;
                // return review;
              } else {
                console.log('no');
                // return oldTechHour;
              }
            } catch (error) {
              console.log(error);
            }
          });
        }
      });

      return franjaHorariaDefinitiva;
    } else {
      return franjaHorariaDefinitiva;
    }
  };

  const segmentTechsByDayOfWeek = (techData) => {
    let daysOfWeek = {
      1: [],
      2: [],
      3: [],
      4: [],
      5: [],
      6: [],
      7: [],
    };
    // [2.0.1] iterate techData
    techData.forEach((tech) => {
      // [2.0.2] iterate each timezone of the tech and push it to the corresponding array
      tech.franjaHoraria.forEach((timeZoneTech) => {
        // before push, verify if the idTecnico exist, BUT verify too the fechaInicio and fechaFin
        // collision of the date of the tech exist it
        try {
          let currentTech = {
            idAgenda: tech.idAgenda,
            nombreAgenda: tech.nombreAgenda,
            idTecnico: tech.idTecnico,
            idUsuario: tech.idUsuario,
            nombreTecnico: tech.nombreTecnico,
            identificacion: tech.identificacionTecnico,
            fechaInicio: tech.fechaInicio,
            fechaFin: tech.fechaFin,
            idDiaSemana: timeZoneTech.idDiaSemana,
            idHoraInicio: timeZoneTech.idHoraInicio,
            idHoraFin: timeZoneTech.idHoraFin,
            idTipoAgenda: timeZoneTech.idTipoAgenda,
            nombreFranjaHoraria: timeZoneTech.nombre,
          };

          // if (tech.fechaInicio === "2024-07-01") {
          // }
          // [2.0.3] verify if the idTecnico exist in the array of the week, get the index
          const techIndex = daysOfWeek[timeZoneTech.idDiaSemana].findIndex(
            (item) => item.idTecnico === tech.idTecnico,
          );

          // [2.0.4] TRUE: save, but in the index of tech duplicate in a child with all data, also
          // dont overwrite the data of older tech in clone
          if (techIndex !== -1) {
            // save the data of the tech in the clone array
            const clone = daysOfWeek[timeZoneTech.idDiaSemana][techIndex].clone;
            daysOfWeek[timeZoneTech.idDiaSemana][techIndex].clone = [...clone, currentTech];
          } else {
            // [2.0.5] FALSE: push the tech to the array of the week
            daysOfWeek[timeZoneTech.idDiaSemana].push({
              ...currentTech,
              clone: [],
            });
          }
        } catch (e) {
          console.log(e);
        }
      });
    });

    // [2.1] return the object with the arrays of each day of week
    return {
      techTimeZoneMonday: daysOfWeek[1],
      techTimeZoneTuesday: daysOfWeek[2],
      techTimeZoneWednesday: daysOfWeek[3],
      techTimeZoneThursday: daysOfWeek[4],
      techTimeZoneFriday: daysOfWeek[5],
      techTimeZoneSaturday: daysOfWeek[6],
      techTimeZoneSunday: daysOfWeek[7],
    };
  };

  /**
   * @param {string} FIC fechaInicioCurrent
   * @param {string} FFC fechaFinCurrent
   * @param {string} FIO fechaInicioOld
   * @param {string} FFO fechaFinOld
   * @return {boolean} collision
   */
  const verifyCollisionBetweenDates = (FIC, FFC, FIO, FFO) => {
    // CASE 1: FIC = "01/01/2023" FFC = "01/31/2021" FIO = "02/02/2021" FFO = "25/02/2021"
    // RESULT: false because the dates of the current tech are not in the range of the old tech
    // CASE 2: FIC = "01/01/2021" FFC = "01/31/2021" FIO = "01/025/2021" FFO = "25/02/2021"
    // RESULT: true because the dates of the current tech are in the range of the old tech
    const startCurrent = moment(FIC, 'YYYY-MM-DD');
    const endCurrent = moment(FFC, 'YYYY-MM-DD');
    const startOld = moment(FIO, 'YYYY-MM-DD');
    const endOld = moment(FFO, 'YYYY-MM-DD');

    return (
      startCurrent.isBetween(startOld, endOld) ||
      endCurrent.isBetween(startOld, endOld) ||
      (startCurrent.isSame(startOld) && endCurrent.isSame(endOld))
    );
  };
  // arrays of weeks
  const getDaysInRange = (startDate, endDate, type = 'days') => {
    try {
      let fromDate = moment(startDate);
      let toDate = moment(endDate);
      let diff = toDate.diff(fromDate, type);
      let range = [];
      for (let i = 0; i <= diff; i++) {
        range.push(moment(startDate).add(i, type).format('MM/DD/YYYY'));
      }
      return range;
    } catch (e) {
      console.log(e);
    }
  };

  // get array of days of the week
  const separateDays = (daysArray) => {
    let daysOfWeek = {
      0: [],
      1: [],
      2: [],
      3: [],
      4: [],
      5: [],
      6: [],
    };

    try {
      daysArray.forEach((dia) => {
        let dayOfWeek = moment(dia).day();
        daysOfWeek[dayOfWeek].push(dia);
      });
      return {
        domingo: daysOfWeek[0],
        lunes: daysOfWeek[1],
        martes: daysOfWeek[2],
        miercoles: daysOfWeek[3],
        jueves: daysOfWeek[4],
        viernes: daysOfWeek[5],
        sabado: daysOfWeek[6],
      };
    } catch (e) {
      console.log(e);
    }
  };

  const generateTimeSlots2 = (data) => {
    let techObj = data;
    // [1] - sort data variable, organize the data by same idTecnico
    techObj.sort((a, b) => {
      return a.idTecnico - b.idTecnico;
    });

    // [2] - split each technical data by idTecnico
    const techObjGrouped = groupByKey(techObj, 'idTecnico');
    // [3] - iterate by each technical group
    let arrayClean = [];

    Object.values(techObjGrouped).forEach((techByGroup) => {
      // [4.1] - save array to control data, this array helps to create an structure like this
      /**
       * data = {
       *  50: [
       *  {id: 50, nam3: "Example"},
       *  {id: 50, nam3: "Example 1"},
       * ]
       * }
       */
      let arrayControl = [];
      // [4] - iterate by technical of each group
      techByGroup.forEach((techDataWithTimeZones) => {
        // [4.2] - tech Data
        const techData = {
          idTecnico: techDataWithTimeZones.idTecnico,
          idUsuario: techDataWithTimeZones.idUsuario,
          nombreTecnico: techDataWithTimeZones.nombreTecnico,
          identificacionTecnico: techDataWithTimeZones.identificacionTecnico,
          fechaInicio: techDataWithTimeZones.fechaInicio,
          fechaFin: techDataWithTimeZones.fechaFin,
          nombreAgenda: techDataWithTimeZones.nombreAgenda,
          idAgenda: techDataWithTimeZones.idAgenda,
        };
        // [5] - iterate by time zone of each technical
        techDataWithTimeZones.franjaHoraria.forEach((timeZoneTech) => {
          // [6] - review if the idTecnico and timeZoneTech.idDiaSemana is included in the arrayControl
          const c = arrayControl.find(
            (e) => e.idTecnico === techData.idTecnico && e.idDiaSemana === timeZoneTech.idDiaSemana,
          );

          if (c) {
            // [7] - if the technical is included in the arrayClean, console.log the technical and the time zone
            // update the definitive timeZone
            updateJsonTechnical(techData, timeZoneTech, arrayControl);
          } else {
            // [8] - if the technical is not included in the arrayClean, then add the technical and the time zone to the arrayClean
            const tech = createJsonTechnical(techData, timeZoneTech);
            arrayControl.push(tech);
          }
        });
      });
      // [9] - create the first structure of the data
      arrayClean.push(arrayControl);
    });

    let DF = [];

    Object.values(arrayClean).forEach((techGroups) => {
      Object.values(techGroups).forEach((tech) => {
        DF.push(tech);
      });
    });

    // sort date by idDiaSemana start with 1 and end to 7
    DF.sort((a, b) => {
      return a.idDiaSemana - b.idDiaSemana;
    });

    console.log(DF);

    setTechnicalsData(DF);
    setLoadingProgress(false);
  };

  // split each technical data by idTecnico
  const groupByKey = (arr, key) => {
    return arr.reduce((result, currentValue) => {
      (result[currentValue[key]] = result[currentValue[key]] || []).push(currentValue);
      return result;
    }, {});
  };

  // function to create the first data structure
  const createJsonTechnical = (techData, timeZoneTech) => {
    /**
     * {
     *    "idTecnico": 50,
     *    "idUsuario": 50,
     *    "nombreTecnico": "Example",
     *    "identificacion": "123456789",
     *    "fechaIncio": "2021-05-01T00:00:00.000Z",
     *    "fechaFin": "2021-05-01T00:00:00.000Z",
     *    "idDiaSemana": 1,
     *    "FranjaHorariaDefinitiva": []
     *
     * }
     * */
    let franjaHorariaDefinitiva = generateTimeZones(timeZoneTech, techData, false, []);

    const totalHours = calculateTotalHours(franjaHorariaDefinitiva);

    // use dateFormat to set dates yyyy/mm/dd
    const startDate = dateFormat(techData.fechaInicio, 'yyyy/mm/dd');
    const endDate = dateFormat(techData.fechaFin, 'yyyy/mm/dd');

    const arrayDays = getDatesForDayOfWeek(startDate, endDate, timeZoneTech.idDiaSemana);

    let techObj = {
      idTecnico: techData.idTecnico,
      idUsuario: techData.idUsuario,
      nombreTecnico: techData.nombreTecnico,
      identificacionTecnico: techData.identificacionTecnico,
      fechaInicio: techData.fechaInicio,
      fechaFin: techData.fechaFin,
      idDiaSemana: timeZoneTech.idDiaSemana,
      franjaHorariaDefinitiva,
      arrayDays,
      totalHours,
    };
    return techObj;
  };

  const getDatesForDayOfWeek = (startDate, endDate, idDayOfWeek) => {
    let momentStartDate = moment(startDate);
    let momentEndDate = moment(endDate);
    let result = [];
    let currentDate = momentStartDate.clone().startOf('week');
    while (currentDate.isSameOrBefore(momentEndDate)) {
      if (currentDate.day() === idDayOfWeek) {
        result.push(currentDate.clone().format('YYYY-MM-DD'));
      }
      currentDate.add(1, 'week');
    }
    return result;
  };

  const updateJsonTechnical = (techData, timeZoneTech, arrayControl) => {
    /**
     * this function will update the timeZone of the technical
     */
    // find the technical in the arrayControl
    const index = arrayControl.findIndex(
      (e) => e.idTecnico === techData.idTecnico && e.idDiaSemana === timeZoneTech.idDiaSemana,
    );
    let franjaHorariaDefinitiva = generateTimeZones(
      timeZoneTech,
      techData,
      true,
      arrayControl[index],
    );

    /**
     *  enter in franjaHorariaDefinitiva and calculate the total hours,
     * the best way is to read all the data in the array and calculate the total hours.
     * Ex: ["0N", "1A", ..., "23I"]
     * the array can goes to 23 and need to count all, but if the string have letter N,
     * don't count the hours, if the string have letter A, count the hours, if the string have letter I,
     * count the hours.
     */
    const totalHours = calculateTotalHours(franjaHorariaDefinitiva);

    const arrayDays = arrayControl[index].arrayDays;

    let techObj = {
      idTecnico: techData.idTecnico,
      idUsuario: techData.idUsuario,
      nombreTecnico: techData.nombreTecnico,
      identificacionTecnico: techData.identificacionTecnico,
      fechaInicio: techData.fechaInicio,
      fechaFin: techData.fechaFin,
      idDiaSemana: timeZoneTech.idDiaSemana,
      franjaHorariaDefinitiva,
      arrayDays,
      totalHours,
    };
    arrayControl[index] = techObj;
  };

  const calculateTotalHours = (FHD) => {
    const result = FHD.reduce((acc, curr) => {
      if (!curr.includes('N')) {
        acc += 1;
      }
      return acc;
    }, 0);

    return result;
  };

  /**
   * list of the hours to include in the table
   * @param startHour
   * @param endHour
   * @returns {[]}
   */
  const calculateListHours = (startHour, endHour) => {
    const hours = []; // inicializa una matriz para almacenar las horas

    // si la hora de inicio es mayor que la hora final, significa que el rango de horas va de un día al siguiente (por ejemplo, 22:00 - 01:00)
    if (startHour > endHour) {
      // agrega las horas desde la hora de inicio hasta el final del día (23:00, 00:00, 01:00, etc.)
      for (let i = startHour; i <= 23; i++) {
        hours.push(i);
      }
      // agrega las horas desde el inicio del día hasta la hora final (00:00, 01:00, 02:00, etc.)
      for (let i = 0; i <= endHour; i++) {
        hours.push(i);
      }
    } else {
      // si la hora de inicio es menor que la hora final, simplemente agrega las horas entre las horas de inicio y final
      for (let i = startHour; i <= endHour; i++) {
        hours.push(i);
      }
    }

    return hours;
  };

  // Handle to clear the select
  const handlerClear = (e) => {
    e.preventDefault();
    // Clear selects
    setSelectValues({
      idCargo: {
        id: 0,
        label: '',
      },
      idPais: {
        id: 0,
        label: '',
      },
      idDepartamento: {
        id: 0,
        label: '',
      },
      idMunicipio: {
        id: 0,
        label: '',
      },
      tipoDocumento: {
        id: 0,
        label: '',
      },
    });

    // Clear inputs
    setFormFilters({
      nombreTecnico: '',
      numeroDocumento: '',
    });
  };

  const [deparmentsData, setDeparmentsData] = useState([]);
  return (
    <>
      <div
        className="advance-search"
        style={{
          padding: '1rem',
        }}
      >
        <p
          onClick={() => {
            toggleLoading(!loading);
          }}
        >
          {loading ? (
            <MdKeyboardArrowDown size={22} color="gray" cursor="pointer" />
          ) : (
            <MdKeyboardArrowRight size={22} color="gray" cursor="pointer" />
          )}
          <FormattedMessage
            id="text.action.show.advanced.search"
            defaultMessage="Búsqueda avanzada"
          />
        </p>
      </div>
      {/* This value need to be in false first because Selects need to have data */}
      {loading && (
        <>
          <section className="wrapForm w-100">
            <label className={styles['selects-advanced-space']}>
              {/* <input
                className="input-primary"
                type="text"
                name="nombreTecnico"
                placeholder="Filtrar por nombre técnico"
                onChange={handleTextFilters}
                value={formFilters.nombreTecnico}
                maxLength="45"
                required
              /> */}

              <SelectComboBox
                name="idTecnico"
                selectValue={selectValues.idTecnico}
                setterFunction={(idTecnico) => setSelectValues({ ...selectValues, idTecnico })}
                data={selectedSearch.technicals}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.technical"
                    defaultMessage="Filtrar por técnico"
                  />
                }
              />
            </label>
            <label className={styles['selects-advanced-space']}>
              <SelectComboBox
                name="idCargo"
                selectValue={selectValues.idCargo}
                setterFunction={(idCargo) => setSelectValues({ ...selectValues, idCargo })}
                data={selectedSearch.positions}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.position"
                    defaultMessage="Filtrar por cargo"
                  />
                }
              />
            </label>
            <label className={styles['selects-advanced-space']}>
              <SelectComboBox
                name="idPais"
                selectValue={selectValues.idPais}
                setterFunction={(idPais) => setSelectValues({ ...selectValues, idPais })}
                data={selectedSearch.countries}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.country"
                    defaultMessage="Filtrar por país"
                  />
                }
              />
            </label>
            <label className={styles['selects-advanced-space']}>
              <SelectComboBox
                name="idDepartamento"
                selectValue={selectValues.idDepartamento}
                setterFunction={(idDepartamento) =>
                  setSelectValues({ ...selectValues, idDepartamento })
                }
                data={deparmentsData}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.deparment"
                    defaultMessage="Filtrar por departamento"
                  />
                }
              />
            </label>
            <label className={styles['selects-advanced-space']}>
              <SelectComboBox
                name="idMunicipio"
                selectValue={selectValues.idMunicipio}
                setterFunction={(idMunicipio) => setSelectValues({ ...selectValues, idMunicipio })}
                data={selectedSearch.municipalities}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.municipality"
                    defaultMessage="Filtrar por municipio"
                  />
                }
              />
            </label>
            <label className={styles['selects-advanced-space']}>
              <SelectComboBox
                name="tipoDocumento"
                selectValue={selectValues.tipoDocumento}
                setterFunction={(tipoDocumento) =>
                  setSelectValues({ ...selectValues, tipoDocumento })
                }
                data={selectedSearch.typeDocument}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.typeDocument"
                    defaultMessage="Filtrar por tipo de documento"
                  />
                }
              />
            </label>
            <label className="wrapForm__label">
              <input
                className="input-primary"
                type="text"
                name="numeroDocumento"
                placeholder="Filtrar por identificación"
                onChange={handleTextFilters}
                value={formFilters.numeroDocumento}
                maxLength="15"
                required
              />
            </label>
          </section>
          <section className="schedule-avanced-search">
            <button
              className={value ? 'input-cancel' : 'btn-search'}
              onClick={(e) => handlerFilters(e)}
              disabled={value}
            >
              {value ? 'Cargando...' : 'Buscar'}
            </button>
            <button className="input-cancel" onClick={(e) => handlerClear(e)}>
              Limpiar
            </button>
          </section>
        </>
      )}
      <DatesSelector
        setDatesAux={setDatesAux}
        datesAux={datesAux}
        getTechnicalsBeweenDates={getTechnicalsBeweenDates}
      />

      {TechnicalsData.length > 0 ? (
        <DynamicScheduleTable
          titles={titlesTableAgenda}
          data={TechnicalsData}
          type="agendaData" // the row
          canSearch={true}
          max={true}
        />
      ) : (
        loadingProgress && <DisplayProgress />
      )}
    </>
  );
}
