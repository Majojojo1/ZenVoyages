import SelectComboBox from 'common/selects/SelectComboBox';
import useLangv2 from 'hooks/useLangv2';
import useListSchedule from 'hooks/useListSchedule';
import { SelectedFieldModel } from 'models/Schedule/ListSchedule';
import React, { useState } from 'react';
import DynamicScheduleTable from './DynamicScheduleTable/DynamicScheduleTable';

import HandleInput from 'common/validators/HandleInput';
import { IDREGEX } from 'common/validators/Regex';
import DatePicker from 'components/pickers/DatePicker';
import dateFormat from 'dateformat';
import useAvailabilityTechnicians from 'hooks/useAvailabilityTechnicians';
import useToggle from 'hooks/useToggle';
import _, { isEmpty } from 'lodash';
import { useEffect } from 'react';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { addItem } from 'services/api/methods';
import styles from './Schedule.module.css';

const ListScheduleComponent = () => {
  //hooks
  const { fieldValues, getAllStatesByCountry } = useListSchedule();
  const { getDaysInRange, separateDays, segmentTechsByDayOfWeek, processDayOfWeek } =
    useAvailabilityTechnicians();
  const { formatterText, handleRequestError } = useLangv2();
  const [value] = useToggle();

  //variables
  const [selectedField, setSelectedField] = useState(new SelectedFieldModel());
  const [formData, setFormData] = useState({
    numeroDocumento: '',
    fechaInicio: dateFormat(new Date(), 'isoDateTime'),
    fechaFin: dateFormat(new Date(), 'isoDateTime'),
  });
  const [isEnable, setIsEnable] = useState(true);
  const [technicalsDataTable, setTechnicalsDataTable] = useState([]);

  const handleTextFilters = (e) => {
    HandleInput(e, IDREGEX, formData, setFormData);
  };

  const handlerClear = () => {
    const now = new Date();
    setFormData({
      numeroDocumento: '',
      fechaIncio: dateFormat(now, 'isoDateTime'),
      fechaFin: dateFormat(now, 'isoDateTime'),
    });
    setSelectedField(new SelectedFieldModel());
  };

  const handlerFilters = (e) => {
    e.preventDefault();
    const searchDataRequest = _searchData();
    //consumo de endpoint
    handleSearch(searchDataRequest);
  };

  const handleSearch = (request) => {
    addItem(endpoints.agenda.getAllTecnicalByAdvancedSearch, request)
      .then((resp) => {
        console.log(resp);
        _rangeDays(resp);
      })
      .catch((error) => handleRequestError(error));
  };

  const _rangeDays = (response) => {
    const days = getDaysInRange(formData.fechaInicio, formData.fechaFin);
    const sortTechnicians = _.sortBy(response, 'idTecnico');
    const allData = _daysOfWeek(days, sortTechnicians);
    const sortAllData = _.sortBy(allData, (obj) => obj.itemDate).filter((elem) => !isEmpty(elem));
    setTechnicalsDataTable(sortAllData.flat());
    console.log(sortAllData.flat());
  };

  // funciones auxiliares
  const _titlesTableAgenda = () => {
    // Crea un array de títulos para las horas (de 00 a 23)
    const hourTitles = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}`);
    let titles = [
      formatterText('table.title.technician.name', 'Nombre técnico'),
      formatterText('table.title.id', 'Identificación'),
      ...hourTitles,
      formatterText('table.hours'),
      formatterText('table.date'),
      formatterText('table.actions'),
    ];

    return titles;
  };

  const _searchData = () => {
    const fieldsSearch = {
      idTecnico: [],
      idCargo: [],
      idPais: [],
      idDepartamento: [],
      idMunicipio: [],
      idTipoDocumento: [],
      identificacion: [],
      fechaIncio: '',
      fechaFin: '',
    };

    for (const key in selectedField) {
      if (selectedField.hasOwnProperty(key) && selectedField[key].hasOwnProperty('id')) {
        if (selectedField[key].id !== 0) {
          fieldsSearch[key] = [selectedField[key].id];
        }
      }
    }
    if (!isEmpty(formData.numeroDocumento)) {
      fieldsSearch.identificacion = [formData.numeroDocumento];
    }
    if (formData.fechaInicio) {
      fieldsSearch.fechaIncio = _dates(formData.fechaInicio);
    }
    if (formData.fechaFin) {
      fieldsSearch.fechaFin = _dates(formData.fechaFin);
    }

    return fieldsSearch;
  };

  const _dates = (date) => {
    return dateFormat(date, 'isoDateTime');
  };

  const _daysOfWeek = (days, sortedTechnicians) => {
    const { domingo, lunes, martes, miercoles, jueves, viernes, sabado } = separateDays(days);
    const {
      techTimeZoneMonday,
      techTimeZoneTuesday,
      techTimeZoneWednesday,
      techTimeZoneThursday,
      techTimeZoneFriday,
      techTimeZoneSaturday,
      techTimeZoneSunday,
    } = segmentTechsByDayOfWeek(sortedTechnicians);
    // Procesar datos para cada día de la semana
    const processedMondayData = processDayOfWeek(lunes, techTimeZoneMonday, 'techTimeZoneMonday');
    const processedTuesdayData = processDayOfWeek(
      martes,
      techTimeZoneTuesday,
      'techTimeZoneTuesday',
    );
    const processedWednesdayData = processDayOfWeek(
      miercoles,
      techTimeZoneWednesday,
      'techTimeZoneWednesday',
    );
    const processThursdayData = processDayOfWeek(
      jueves,
      techTimeZoneThursday,
      'techTimeZoneThursday',
    );
    const processFridayData = processDayOfWeek(viernes, techTimeZoneFriday, 'techTimeZoneFriday');
    const processSaturdayData = processDayOfWeek(
      sabado,
      techTimeZoneSaturday,
      'techTimeZoneSaturday',
    );
    const porcessSundayData = processDayOfWeek(domingo, techTimeZoneSunday, 'techTimeZoneSunday');

    const allData = {
      ...processedMondayData,
      ...processedTuesdayData,
      ...processedWednesdayData,
      ...processThursdayData,
      ...processFridayData,
      ...processSaturdayData,
      ...porcessSundayData,
    };

    return allData;
  };

  useEffect(() => {
    getAllStatesByCountry(selectedField.idPais.id);
  }, [selectedField.idPais.id]);

  useEffect(() => {
    if (selectedField.idTipoDocumento.id !== 0) {
      setIsEnable(false);
    } else {
      setFormData({ ...formData, numeroDocumento: '' });
      setIsEnable(true);
    }
  }, [selectedField.idTipoDocumento.id]);

  return (
    <>
      <section className="wrapForm">
        <section className="wrapForm w-100">
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idTecnico"
              selectValue={selectedField.idTecnico}
              setterFunction={(idTecnico) => setSelectedField({ ...selectedField, idTecnico })}
              data={fieldValues.technicals}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.technical"
                  defaultMessage="Filtrar por técnico"
                />
              }
            />
          </label>
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idCargo"
              selectValue={selectedField.idCargo}
              setterFunction={(idCargo) => setSelectedField({ ...selectedField, idCargo })}
              data={fieldValues.positions}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.position"
                  defaultMessage="Filtrar por cargo"
                />
              }
            />
          </label>
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idPais"
              selectValue={selectedField.idPais}
              setterFunction={(idPais) => setSelectedField({ ...selectedField, idPais })}
              data={fieldValues.countries}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.country"
                  defaultMessage="Filtrar por país"
                />
              }
            />
          </label>
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idDepartamento"
              selectValue={selectedField.idDepartamento}
              setterFunction={(idDepartamento) =>
                setSelectedField({ ...selectedField, idDepartamento })
              }
              data={fieldValues.states}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.deparment"
                  defaultMessage="Filtrar por departamento"
                />
              }
            />
          </label>
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idMunicipio"
              selectValue={selectedField.idMunicipio}
              setterFunction={(idMunicipio) => setSelectedField({ ...selectedField, idMunicipio })}
              data={fieldValues.municipalities}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.municipality"
                  defaultMessage="Filtrar por municipio"
                />
              }
            />
          </label>
          <label className={styles['selects-advanced-space']}>
            <SelectComboBox
              name="idTipoDocumento"
              selectValue={selectedField.idTipoDocumento}
              setterFunction={(idTipoDocumento) =>
                setSelectedField({ ...selectedField, idTipoDocumento })
              }
              data={fieldValues.typeDocument}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.agenda.select.typeDocument"
                  defaultMessage="Filtrar por tipo de documento"
                />
              }
            />
          </label>
          <label className="wrapForm__label">
            <input
              className="input-primary"
              type="text"
              name="numeroDocumento"
              placeholder={formatterText(
                'text.filter.identification',
                'Filtrar por identificación',
              )}
              onChange={handleTextFilters}
              disabled={isEnable}
              value={formData.numeroDocumento}
              maxLength="15"
              required
            />
          </label>

          <label className="wrapForm__label">
            <DatePicker
              name="fechaInicio"
              selectValue={formData.fechaInicio}
              setterFunction={setFormData}
              placeholder={formatterText('text.shedule.create.startdate')}
              noIcon={true}
            />
          </label>
          <label className="wrapForm__label">
            <DatePicker
              name="fechaFin"
              selectValue={formData.fechaFin}
              setterFunction={setFormData}
              placeholder={formatterText('text.shedule.create.enddate')}
              noIcon={true}
            />
          </label>
        </section>

        <section className="schedule-avanced-search">
          <button
            className={value ? 'input-cancel' : 'btn-search'}
            onClick={handlerFilters}
            disabled={value}
          >
            {value ? 'Cargando...' : formatterText('btn.search', 'Buscar')}
          </button>
          <button className="input-cancel" onClick={handlerClear}>
            <FormattedMessage id="btn.clean" defaultMessage="Limpiar" />
          </button>
        </section>

        <section className={styles.containerData}>
          <label className={styles['selects-advanced-space']}>
            <p
              style={{
                backgroundColor: '#85EB4E',
                padding: '0.5rem 1rem',
                borderRadius: '0.5rem',
              }}
            >
              <FormattedMessage
                id="text.conversion.schedule.available"
                defaultMessage={'Disponible'}
              />
            </p>
            <p
              style={{
                backgroundColor: '#F1684E',
                padding: '0.5rem 1rem',
                borderRadius: '0.5rem',
              }}
            >
              <FormattedMessage
                id="text.conversion.schedule.unavailable"
                defaultMessage={'No disponible'}
              />
            </p>
          </label>
        </section>
      </section>

      <DynamicScheduleTable
        titles={_titlesTableAgenda()}
        data={technicalsDataTable}
        type="agendaData" // the row
        canSearch={true}
        max={true}
      />
    </>
  );
};
export default ListScheduleComponent;
