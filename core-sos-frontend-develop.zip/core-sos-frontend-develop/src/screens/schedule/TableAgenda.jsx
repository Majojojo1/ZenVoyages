import React, { useEffect, useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
// Import Libs
import { downloadTable } from 'components/utils/ExportJsonFile';
import SortDataByDate from 'components/utils/SortDataByDate';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import Services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteItem, getAll, getItemById } from 'services/api/methods';
import paths from 'services/paths';

const TableAgenda = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <TableAgendaComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const TableAgendaComponent = () => {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  const userName = JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN';

  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  // useContext de búsqueda
  const { setDataTable } = useSeachContext();

  const [agendas, setAgendas] = useState(null);

  const [dataReady, setDataReady] = useState(false);


  // titulos de la tabla
  const titles = [
    formatterText('text.shedule.create.name', 'Nombre Agenda'),
    formatterText('text.shedule.create.startdate', 'Fecha Inicio'),
    formatterText('text.shedule.create.enddate', 'Fecha Fin'),
    formatterText('text.shedule.create.createdate', 'Fecha Creación'),
    formatterText('table.actions', 'Acciones'),
  ];

  const [dataExcel, setDataExcel] = useState([]);
  const [downloaded, setDownloaded] = useState(false);

  const toggleDownloaded = () => setDownloaded((prev) => !prev);

  const { permissionsAccess, permittedActions, crear, editar, eliminar, consultar, exportar, permissions } =
    usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(18);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);


  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // get data from the table
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAll(endpoints.agenda.getAllAgenda)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortDataByDate(newArray, 'desc');
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
        setAgendas(sortedArray);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!err);
        handleClick();
      });
  };

  // this function structure the items of the table
  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idAgenda,
      nombre: item.nombre,
      fechaInicio: item.fechaInicio.split('T')[0],
      fechaFin: item.fechaFin.split('T')[0],
      fechaCreacion:
        dateFormat(item.fechaCreacion, 'yyyy/mm/dd - h:MM:ss TT') || 'No tiene un valor',
      objeto: item,
    });
  };

  const handleDownloadItem = async (id) => {
    await dataTableExcel(id);
  };

  const constructDataExcel = async (url, item) => {
    try {
      const resp = await getAll(url);
      let newData = [];

      resp.forEach((elem) => {
        const technical = `${elem.idTecnico?.idEmpleado?.primerNombre} ${elem.idTecnico?.idEmpleado?.primerApellido}`;
        const typeSchedule = elem.idTipoAgenda?.nombre;
        newData.push({
          fechaInicio: item.idFranjaHoraria.idHoraInicio.hora,
          fechaFin: item.idFranjaHoraria.idHoraFin.hora,
          nombreFranja: item.idFranjaHoraria.nombre,
          diaSemana: item.idFranjaHoraria.idDiaSemana.dia,
          tipoAgenda: typeSchedule || 'Sin datos',
          tecnico: technical || 'Sin datos',
        });
      });
      setDataExcel((prev) => [...prev, newData]);
      console.log('Aquí creamos data', dataExcel);
    } catch (error) {
      console.log('constructExcel', error);
    }
  };


  const downloadDataExcel = async () => {
    try {
      await downloadTable({ moduleName: 'Agendas', userName: userName, dataTable: dataExcel });
    } catch (error) {
      console.log('descargamos ', error);
    } finally {
      console.log('aqui limpiamos', dataExcel);
    }
  };

  const dataTableExcel = async (id) => {
    try {
      const data = await getItemById(endpoints.agenda.getAllTimezoneByidAgenda, id);
      const promises = data.map(async (item) => {
        const url = endpoints.agenda.getAllFranjaHorariaByIdAgenda(
          item.idFranjaHoraria.idFranjaHoraria,
          item.idAgenda.idAgenda
        );
        return constructDataExcel(url, item);
      });
      const responses = await Promise.all(promises);
      if (responses) setDataReady(true);
      if (dataReady) {
        await downloadDataExcel();
      }
    } catch (error) {
      console.error('Error en dataTableExcel:', error);
    }
  };


  useEffect(() => {
    if (dataReady) {
      downloadDataExcel();
      setDataExcel([]);
      setDataReady(false);
    }
  }, [dataReady]);

  // this function delete an item
  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteItem(endpoints.agenda.deleteAgenda, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          const sortedArray = SortDataByDate(newArray, 'desc');
          setDataTable(sortedArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const renderMessage = () => {
    return error ? (
      displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
    ) : (
      displayLoading()
    )
  };
  
  return (
    <>
      {!loading && agendas !== null ? (
        <section className="table-container">
          <section className="userOptions">
            <Search
              placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
              width="50%"
            />

            <Link to={paths.createSchedule}>
              <button className="btn-add">
                {formatterText('header.title.schedule.create', 'Crear agenda')}
              </button>
            </Link>
          </section>

          <FormattedMessage id="table.name.search.service" defaultMessage="Servicios">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Agendas}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleDownloadItem={handleDownloadItem}
                routeToEdit={paths.updateSchedule}
                canDeleted={permittedActions.eliminar}
                canModify={permittedActions.editar}
                canDownload={permittedActions.exportar}
              />
            )}
          </FormattedMessage>
        </section>
      ) : renderMessage()}
    </>
  );
};

export default TableAgenda;
