import React, { useEffect, useState } from "react";
// import Hooks
import useLangv2 from "hooks/useLangv2";
// Import Components
import SelectorGrid from "common/selects/SelectorGrid";
// Import Libs
import HandlerText from "common/validators/HandlerText";
import PropTypes from "prop-types";
import { FormattedMessage } from "react-intl";
// Import Services
import endpoints from "services/api";
import {
  COOKIE_USER,
  DATE_CREATED_AT,
  addItem,
  getAll,
} from "services/api/methods";
// Import styles
import styles from "./CreateTimeZone.module.css";

export default function CreateTimeZone({ getAllTimeZone, hideComponent }) {
  // use Hook of language v2
  const {
    formatterText,
    noFilledContent,
    newItemCreated,
    errorDataRecovery,
    customSB,
  } = useLangv2();
  // Form data state
  const [formData, setFormData] = useState({
    nombre: "",
  });

  useEffect(() => {
    getAllDayWeek();
    getAllHoursDay();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      dayWeek: [],
      startHour: [],
      endHour: [],
    },
  ]);

  // selects ids state
  const [selectIds, setSelectIds] = useState({
    idDiaSemana: {
      value: 0,
    },
    idHoraInicio: {
      value: 0,
    },
    idHoraFin: {
      value: 0,
    },
  });

  // Get all day week for select
  const getAllDayWeek = () => {
    getAll(endpoints.agenda.getAllHoraDiaAgenda)
      .then((res) => {
        // variable empty to save the data
        let data = [];
        res.forEach((element) => {
          // special keys to the table
          data.push({
            value: element.idHoraDia,
            label: element.hora,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          startHour: data,
        }));
        setSearchSelected((prev) => ({
          ...prev,
          endHour: data,
        }));
      })
      .catch((_) => {
        errorDataRecovery();
      });
  };

  // Get all day week for select
  const getAllHoursDay = () => {
    getAll(endpoints.agenda.getAllDiaSemanaAgenda)
      .then((res) => {
        let data = [];
        res.forEach((element) => {
          // special keys to the table
          data.push({
            value: element.idDiaSemana,
            label: element.dia,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          dayWeek: data,
        }));
      })
      .catch((_) => {
        errorDataRecovery();
      });
  };

  // const create time zone
  const createTimeZone = (e) => {
    e.preventDefault();

    if (
      formData.nombre === "" ||
      selectIds.idDiaSemana.value === 0 ||
      selectIds.idHoraInicio.value === 0 ||
      selectIds.idHoraFin.value === 0
    ) {
      noFilledContent();
      return;
    }
    if (selectIds.idHoraInicio.value === selectIds.idHoraFin.value) {
      customSB(
        "warning",
        "snackbar.warning.input.same.data.agenda.hours",
        "La hora de inicio no puede ser igual a la hora de fin."
      );
      return;
    }

    if(selectIds.idHoraInicio.value > selectIds.idHoraFin.value) {
      customSB(
        "warning",
        "snackbar.warning.input.same.data.agenda.hours",
        "La hora de final no puede ser menor a la hora de fin."
      );
      return;
    }


    const DATA = [
        {
          idFranjaHoraria: null,
          nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
          idDiaSemana: {
            idDiaSemana: selectIds.idDiaSemana.value,
          },
          idHoraInicio: {
            idHoraDia: selectIds.idHoraInicio.value,
          },
          idHoraFin: {
            idHoraDia: selectIds.idHoraFin.value,
          },
          estado: 1,
          fechaCreacion: DATE_CREATED_AT,
          usuarioCreacion: COOKIE_USER,
        },
      ];

    addItem(endpoints.agenda.addTimeZone, DATA)
        .then((_) => {
          newItemCreated();
          getAllTimeZone();
          hideComponent(false);
        })
        .catch((_) => {
          customSB(
            "error",
            "snackbar.error.data.time.zone.validation",
            "Error: Es posible que ya exista el nombre del registro o fallo en realizar el proceso. Intentalo en otro momento."
          );
        });
      
    
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  return (
    <section>
      <span className="title-table">
        <FormattedMessage
          id="text.shedule.create.time.zone"
          defaultMessage="Crear franja horaria"
        />
      </span>
      <section className="wrapForm w100-container-complete">
        <label className="wrapForm__label">
          <span className="warpForm-text">
            <FormattedMessage
              id="text.shedule.name.time.zone"
              defaultMessage="Nombre de la franja"
            />
          </span>
          <input
            type="text"
            className="input-default"
            name="nombre"
            placeholder={formatterText(
              "text.shedule.name.time.zone",
              "Nombre de la franja"
            )}
            onChange={handleText}
            value={formData.nombre}
            maxLength="45"
          />
        </label>

        <label className="wrapForm__label">
          <span className="warpForm-text">
            <FormattedMessage
              id="text.shedule.day.week.time.zone"
              defaultMessage="Día de la semana"
            />
          </span>
          <SelectorGrid
            name="idDiaSemana"
            data={selectedSearch.dayWeek}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecciona una opción"
              />
            }
            dataValue={selectIds.idDiaSemana}
            setterFunction={setSelectIds}
          />
        </label>
        <label className="wrapForm__label">
          <span className="warpForm-text">
            <FormattedMessage
              id="text.shedule.start.time.zone"
              defaultMessage="Franja de inicio"
            />
          </span>
          <SelectorGrid
            name="idHoraInicio"
            data={selectedSearch.startHour}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecciona una opción"
              />
            }
            dataValue={selectIds.idHoraInicio}
            setterFunction={setSelectIds}
          />
        </label>
        <label className="wrapForm__label">
          <span className="warpForm-text">
            <FormattedMessage
              id="text.shedule.end.time.zone"
              defaultMessage="Franja fin"
            />
          </span>
          <SelectorGrid
            name="idHoraFin"
            data={selectedSearch.endHour}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecciona una opción"
              />
            }
            dataValue={selectIds.idHoraFin}
            setterFunction={setSelectIds}
          />
        </label>
      </section>
      <section className={styles["form-responsive-container-buttons"]}>
        <button
          className="btn-action-primary"
          onClick={(e) => createTimeZone(e)}
        >
          <FormattedMessage id="btn.create" defaultMessage="Crear" />
        </button>
      </section>
    </section>
  );
}

CreateTimeZone.propTypes = {
  getAllTimeZone: PropTypes.func,
  hideComponent: PropTypes.func,
};
