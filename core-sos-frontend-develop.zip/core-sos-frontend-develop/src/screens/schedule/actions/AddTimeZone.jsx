import React, { useEffect, useState } from 'react';
// Import Contexts
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import { useParams } from 'react-router-dom';
// Import Components
import SelectorGrid from 'common/selects/SelectorGrid';
import { useSeachContext } from 'context/SearchContext';
// Import Libs
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { v4 as uuidv4 } from 'uuid';
// Import Services
import endpoints from 'services/api';
import { COOKIE_USER, addItem, getAll } from 'services/api/methods';
import CreateTimeZone from './CreateTimeZone';
// Import styles
import styles from './AddTimeZone.module.css';

export default function AddTimeZone({ getTimeZoneByIdAgenda }) {
  const {
    timeZoneSelected,
    setTimeZoneSelected,
  } = useSeachContext();
  // get the id from the url
  const { id } = useParams();
  // use Hook of language v2
  const { noFilledContent, errorDataRecovery, newItemCreated, errorProcess, elementRepeated } =
    useLangv2();

  const [show, setShow] = useState(false);
  // Value that select use
  const [selectTimeZone, setSelectTimeZone] = useState([]);
  // selects ids state
  const [selectIds, setSelectIds] = useState({
    idFranjaHoraria: {
      value: 0,
      label: '',
    },
  });

  useEffect(() => {
    getAllTimeZone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Get all timeZones for select
  const getAllTimeZone = () => {
    getAll(endpoints.agenda.getAllTimezone)
      .then((response) => {
        // variable empty to save the data
        let data = [];
        response.forEach((element) => {
          // special keys to the table
          data.push({
            value: element.idFranjaHoraria,
            label: `${element.nombre} - ${element.idDiaSemana.dia} ${element.idHoraInicio.hora} -${element.idHoraFin.hora} `,
          });
        });
        // set the data to the table
        setSelectTimeZone(data);
      })
      .catch((_) => {
        errorDataRecovery();
      });
  };

  // add timeZone to the schedule without save
  const addTimeZone = (e) => {
    e.preventDefault();
    let REPEATED_TIME_ZONE = timeZoneSelected?.some(repeatTimeZone);
    if (selectIds.idFranjaHoraria.value === 0) {
      noFilledContent();
    } else {
      if (id) {
        REPEATED_TIME_ZONE = timeZoneSelected?.some(repeatTimeZone);
        if (REPEATED_TIME_ZONE) {
          elementRepeated();
        } else {
        const DATA = {
          idFranjaHorariaAgenda: null,
          idAgenda: {
            idAgenda: parseInt(id),
          },
          idFranjaHoraria: {
            idFranjaHoraria: selectIds.idFranjaHoraria.value,
          },
          estado: 1,
          usuarioCreacion: COOKIE_USER,
        };
        associateAgendaToTimeZone(DATA);
      }
      } else {
        REPEATED_TIME_ZONE = timeZoneSelected?.some(repeatTimeZone);
        if (REPEATED_TIME_ZONE) {
          elementRepeated();
        } else {
          setTimeZoneSelected((prevTimeZoneSelected) => [
            ...(prevTimeZoneSelected || []),
            {
              timeZone: selectIds.idFranjaHoraria.label,
              idFranjaHoraria: selectIds.idFranjaHoraria.value,
              idFranjaHorariaAgenda: uuidv4(),
            },
          ]);
        }
      }
    }
  };

  // Associate a time zone to an agenda
  const associateAgendaToTimeZone = (DATA) => {
    addItem(endpoints.agenda.addAssociationTimezoneSchedule, DATA)
      .then((_) => {
        newItemCreated();
        getTimeZoneByIdAgenda();
      })
      .catch((_) => {
        errorProcess();
      });
  };

  // find if the timeZone is repeated
  const repeatTimeZone = (el) => {
    return el.idFranjaHoraria === selectIds.idFranjaHoraria.value;
  };

  return (
    <section>
      <span className="title-table">
        <FormattedMessage
          id="text.shedule.associate.time.zone.schedule"
          defaultMessage="Asociar franjas horarias a la agenda"
        />
      </span>
      <section className={styles.wrapForm}>
        <label className={styles.dFlex}>
          <span className={styles.wrapFormText}>
            <FormattedMessage id="text.shedule.time.zone" defaultMessage="Franjas horarias" />
          </span>
          <section className={styles.labelSelect}>
            <SelectorGrid
              name="idFranjaHoraria"
              data={selectTimeZone}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecciona una opción"
                />
              }
              dataValue={selectIds.idFranjaHoraria}
              setterFunction={setSelectIds}
            />
          </section>
          <button className={styles['btn-action-primary']} onClick={(e) => addTimeZone(e)}>
            <FormattedMessage id="text.associate" defaultMessage="Asociar" />
          </button>
          <button
            className={styles['btn-action-primary']}
            onClick={(e) => {
              e.preventDefault();
              setShow(!show);
            }}
          >
            {show ? (
              <FormattedMessage id="text.hide" defaultMessage="Ocultar" />
            ) : (
              <FormattedMessage
                id="text.shedule.create.time.zone"
                defaultMessage="Crear franja horaria"
              />
            )}
          </button>
        </label>
      </section>

      {show && <CreateTimeZone getAllTimeZone={getAllTimeZone} hideComponent={setShow} />}
    </section>
  );
}

AddTimeZone.propTypes = {
  getTimeZoneByIdAgenda: PropTypes.func,
};
