import React, { useEffect } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { useLocation } from 'react-router';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
// Import libs
import Axios from 'axios';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const UsersTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <UsersTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function UsersTableComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { searchResults = [], setDataTable } = useSeachContext();
  // hook useLocation
  const location = useLocation();

  // use Hook of language v2
  const { formatterText, successRemoveItem, handleRequestError } = useLangv2();

  // titulos de la tabla
  const titles = [
    formatterText('table.title.user', 'Usuario'),
    formatterText('table.title.role', 'Rol(es)'),
    formatterText('table.title.email', 'Correo electrónico'),
    formatterText('table.title.creationD', 'Fecha de creación'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessUsers = () => {
    permissionsAccess(MODULES_NAME.user);
  };

  // función para cargar datos
  const getDataTable = async () => {
    // show loading
    toggleLoading(true);

    return getAll(endpoints.users.getAllUsers)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        if (Axios.isCancel(error)) {
          console.log('axios request cancelled', error.message);
        } else {
          console.log(err);
          // mostrar error
          toggleError(!error);
          handleClick();
        }
      });
  };

  const handleDeleteItem = (rowId) => {
    const deletePromise = new Promise((res, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then(async () => {
          await getDataTable();
          res(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deletePromise;
  };

  const handleStructureItems = (newArray, item) => {
    let roles = '';
    let permissions = '';
    let definiteString = '';
    if (item.roles.length > 0) {
      item.roles.forEach((role) => {
        permissions += '(';
        roles += role.nombre + ', ';

        role.permisos.forEach((permiso) => {
          permissions += permiso.nombre + ', ';
        });
        permissions += ')';
      });
      definiteString += `${roles} ${permissions}`;
    } else {
      roles = '';
    }

    let created_at =
      item.fechaRegistro !== ''
        ? dateFormat(item.fechaRegistro, 'yyyy/mm/dd - h:MM:ss TT')
        : 'Sin fecha';

    let mail = item.correo !== '' ? item.correo : 'Sin correo';
    newArray.push({
      id: item.idUsuario,
      nombre: item.usuario !== '' ? item.usuario : 'Sin nombre',
      roles: roles !== '' ? roles.slice(0, -2) : 'Sin rol(es)',
      mail,
      created_at,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  useEffect(() => {
    getDataTable();
  }, []);

  useEffect(() => {
    permissionsAccessUsers();
  }, [permissions]);

  return (
    <>
      {!loading ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createUser}>
                <button className="btn-add">
                  <FormattedMessage id="btn.create.user" defaultMessage="Crear Usuario" />
                </button>
              </Link>
            )}

            {permittedActions.exportar && (
              <ExportJsonFile
                moduleName="Usuario"
                userName={
                  JSON.parse(localStorage.getItem('userData')).usuario
                    ? JSON.parse(localStorage.getItem('userData')).usuario
                    : 'ADMIN'
                }
                dataTable={searchResults}
              />
            )}
          </section>
          {permittedActions.consultar && (
            <FormattedMessage id="table.name.search.users" defaultMessage="Usuarios">
              {(placeholder) => (
                <div className="tab-container">
                  <DynamicTable
                    titles={titles}
                    pageName={PAGE_NAMES.Usuarios}
                    data={getDataTable}
                    handleDeleteItem={handleDeleteItem}
                    handleEditStateItem={handleEditStateItem}
                    routeToEdit={paths.updateUser}
                    canDeleted={permittedActions.eliminar}
                    canModify={permittedActions.editar}
                  />
                </div>
              )}
            </FormattedMessage>
          )}
        </section>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
}

export default UsersTable;
