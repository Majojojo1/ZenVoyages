import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';

import { langContext } from 'context/langContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import { useNavigate } from 'react-router-dom';
// Import Components
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
// Import Libs
import Cookie from 'js-cookie';
// Import Services
import endpoints from 'services/api';
import { getNotifiByUser, getProfileImage, getUserInfo, getUserNoti, updateAndCreateNotify, updateUser } from 'services/api/users';
import paths from 'services/paths';
// Import Styles
import SelectorMulti from "common/SelectorMulti";
import MIME_TYPE from 'common/utils/MimeType';
import useGetData from "hooks/useGetData";
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';
import 'styles/editProfile.css';
import { updateLenguage } from "services/api/auth";

export default function Edit() {
  const navigate = useNavigate();
  // Llamo a la variable global de avatar
  const { imagUrlValue, setImgUrlValue, userInfo } = useContext(AppContext);
  const [file, setFile] = useState(null);
  // manage petitions
  const { fetchData, COOKIE_USER } = useAxios();
  const [userDataValue] = userInfo;
  const idioma = useContext(langContext);
  const { formatterText } = useLangv2();
  const reader = new FileReader();
  const [formData, setFormData] = useState(userDataValue);
  const [selectedSearchCountries, setSearchSelectedCountries] = useState([]);
  const { loading, toggleLoading } = useGetData();
  const [selectValues, setSelectValues] = useState([]);
  const [selectedMarketAssociate, setSelectedMarketAssociate] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    getInitData();
    getDataNotifi();
    getNotiByUser(Cookie.get('idUsuario'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getDataNotifi = () => {
    toggleLoading(true);
    getUserNoti()
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCategoriaServicio,
              label: item.nombre,
              description: item.descripcion,
              code: item.code,
              status: item.estado,
              dateRegister: item.fechaRegistro,
              dateModify: item.fechaModificacion,
              userCreation: item.usuarioCreacion,
              userModify: item.usuarioModificacion,
              isFixed: true,
            });
          }
        });
        setSearchSelectedCountries(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const getNotiByUser = (id) => {   
    getNotifiByUser(id)
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          newArray.push({
            value: item.idCategoriaServicio,
            label: item.nombre,
            description: item.descripcion,
            code: item.codigo,
            status: item.estado,
            dateRegister: item.fechaRegistro,
            dateModify: item.fechaModificacion,
            userCreation: item.usuarioCreacion,
            userModify: item.usuarioModificacion,
            isFixed: true,
          });
        });
        setSelectValues(newArray);
        setSelectedMarketAssociate(newArray);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const getInitData = () => {
    getUserInfo(Cookie.get('idUsuario'))
      .then((res) => {
        getDataAttachedFiles();
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, " "),
    });
  };

  const handleChangeLang = (e) => {
    idioma.establecerLenguaje(e.target.value.trim());
    let lenguage;

    if (e.target.value.trim() == "en-US") {
      lenguage = "en";
    } else if (e.target.value.trim() == "en-ES") {
      lenguage = "es";
    }
    
    let jsonData = {
      idUsuario: Cookie.get('idUsuario'),
      lenguage: lenguage,
    };
    
    setIsLoading(true);
    
    updateLenguage(jsonData)
      .then((res) => {
        setIsLoading(false);
    
        if (res) {
          CustomAlert('short_msg', {
            icon: 'success',
            title: 'Idioma cambiado',
            text: 'Su idioma ha sido cambiado con éxito',
            confirmButtonColor: '#FFC954',
          });
          idioma.establecerLenguaje(e.target.value.trim());
          
        }
      })
      .catch((err) => {
        setIsLoading(false);
    
        CustomAlert("short_msg", {
          icon: "error",
          title: `Error`,
          text: "Verifique el enlace de restablecer de contraseña.",
        });
      });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    updateUserData();
    createAndUpdateNotify();
  };

  const updateUserData = () => {
    updateUser(formData)
      .then((res) => {
        if (res) {
          onSuccess('Datos actualizados');
        } else {
          HandleOnError('No se pudo actualizar los datos');
        }
      })
      .catch((err) => {
        console.error(err);
        HandleOnError('Error al actualizar los datos');
      });
  };

  const createAndUpdateNotify = () => {
    const requestData = {
      idCategoriaUsuario: Cookie.get('idUsuario'),
      categoriaServicio: selectValues.map(item => ({
        idCategoriaServicio: item.value,
        nombre: item.label,
        descripcion: item.description, // Agrega la descripción del item si está disponible
        codigo: item.code, // Agrega el código del item si está disponible
        estado: item.status, // Agrega el estado del item si está disponible
        fechaRegistro: item.dateRegister, // Agrega la fecha de registro del item si está disponible
        fechaModificacion: item.dateModify, // Agrega la fecha de modificación del item si está disponible
        usuarioCreacion: item.userCreation, // Agrega el usuario de creación del item si está disponible
        usuarioModificacion: item.userModify, // Agrega el usuario de modificación del item si está disponible
      })),
    };
    updateAndCreateNotify(requestData)
      .then((res) => {
        if (res) {
          onSuccess('Datos actualizados');
        } else {
          HandleOnError('No se pudo actualizar los datos');
        }
      })
      .catch((err) => {
        console.error(err);
        HandleOnError('Error al actualizar los datos');
      });
  };

  const onSuccess = (sucess) => {
    CustomAlert('short_msg', {
      icon: 'success',
      title: 'Acción realizada correctamente',
      text: sucess,
    });
  };

  function uploadImage(e) {
    const TYPE_IMAGE = {
      'image/png': true,
      'image/jpg': true,
      'image/jpeg': true,
    };

    // try catch para que no se cargue la imagen si no se selecciona ninguna
    try {
      let imageSize = e.target.files[0].size;
      // limita el tamaño de la imagen a 2MB
      if (imageSize < 2000000) {
        const typeImg = e.target.files[0].type;
        if (TYPE_IMAGE[typeImg]) {
          uploadNewFileFn(e);
        } else {
          HandleOnError('El tipo de imagen no es válido (Solo se permite PNG y JPG)');
        }
      } else {
        HandleOnError('El archivo supera 2MB');
      }
    } catch (error) {
      console.error('error', error);
    }
  }

  const uploadProfileImage = (file) => {
    fetchData({
      url: endpoints.UploadFiles.save,
      method: 'post',
      body: {
        idOrigen: COOKIE_USER,
        idTipoOrigenArchivo: 4,
        archivos: [file],
      },
    }).then(() => {
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
        text: formatterText('alert.title.confirm.add.files'),
        confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
        allowOutsideClick: false,
        executeFunction: () => {
          getInitData();
          setImgUrlValue(file);
        },
      });
    });
  };

  const uploadNewFileFn = (e) => {
    const selectedFile = e.target.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const archivo = event.target.result.split('base64,')[1];
      const extensionArchivo =
        selectedFile.name.lastIndexOf('.') > -1
          ? selectedFile.name.substring(
            selectedFile.name.lastIndexOf('.') + 1,
            selectedFile.name.length,
          )
          : '';

      const name = selectedFile.name.substring(0, selectedFile.name.lastIndexOf('.'));
      setFile(selectedFile);
      uploadProfileImage({
        archivo,
        extensionArchivo: `.${extensionArchivo}`,
        name,
      });
    };

    reader.readAsDataURL(selectedFile);
  };

  const getDataAttachedFiles = () => {
    getProfileImage().then((resp) => {
      setFile(`data:${MIME_TYPE[resp.ext]};base64,${resp.image}`);
    });
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };


  return (
    <form className="edit-profile" onSubmit={handleSubmit}>
      <section className="edit-profile-container-header">
        <section className="edit-profile-header__img">
          <img
            src={file || userDataValue?.avatarUrl || 'https://png.pngtree.com/png-vector/20190710/ourlarge/pngtree-user-vector-avatar-png-image_1541962.jpg'} />
          <label className="file-input-label">
            <input type="file" title=" " onChange={uploadImage} accept="image/png, image/jpeg" />
          </label>
          {/* <p>Cambiar foto de perfil</p> */}
        </section>

        <section className="edit-profile-header__name">
          {/* <h2>
            {formData.nombre ? formData.nombre : "No hay nombre asociado"}
          </h2> */}
          <h2>
            {formData.usuario !== null
              ? formatterText('table.title.user', 'Usuario: ') + ': ' + formData.usuario
              : 'No hay nombre asociado'}
          </h2>
          {/* <p>Usuario: {formData.usuario}</p> */}
        </section>

        <section className="edit-profile-header__language">
          <h3>{formatterText('p.lang', 'Idioma del Aplicativo')}</h3>
          <select
            name="lang"
            id="lang"
            value={localStorage.getItem('lang')}
            onChange={handleChangeLang}
            className="global-select"
          >
            <option value="en-ES">
              <FormattedMessage id="nav.text.language.spanish" defaultMessage="Español" />
            </option>
            <option value="en-US">
              <FormattedMessage id="nav.text.language.english" defaultMessage="Ingles" />
            </option>
          </select>
        </section>
      </section>

      <section className="edit-profile-container-information">
        <section className="edit-profile-information__option">
          <h3>{formatterText('p.email', 'Correo electrónico')}</h3>
          <input
            className="input-primary"
            type="email"
            name="correo"
            value={formData.correo}
            onChange={handleChange}
          />
        </section>
        <section className="edit-profile-information__option">
          <h3>{formatterText('p.password', 'Contraseña')}</h3>
          <p onClick={() => navigate(paths.changePassword)}>
            {formatterText('header.title.change.password.principal', 'Cambiar contraseña')}
          </p>
        </section>
        <br></br>
        <section className="edit-profile-information__option">
          <h3>{formatterText('p.notifiassigned', 'Notificaciones Asignadas')}</h3>
          <section className="edit-profile-information__option">
            <SelectorMulti
              data={selectedSearchCountries}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
              isRequired={true}
            />
          </section>
        </section>
      </section>
      <br></br>
      <br></br>
      <section className="edit-profile-container-buttons">
        <button type="submit" className="btn-primary">
          {formatterText('btn.save.changes', 'Guardar cambios')}
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.home)}>
          {formatterText('btn.cancel', 'Cancelar')}
        </button>
      </section>
    </form>
  );
}
