import React, { useEffect, useState } from 'react';
// Import Hooks
import CustomAlert from 'components/CustomAlert';
import { useAuth } from 'hooks/useAuth';
import useAxios from 'hooks/useAxios';
import { COOKIE_USER } from 'services/api/methods';
import { getUserInfo } from 'services/api/users';

// Import Services
import endpoints from 'services/api';
// Import Styles
import useLangv2 from 'hooks/useLangv2';
import { IoMdEye, IoMdEyeOff } from 'react-icons/io';
import { FormattedMessage } from 'react-intl';
import 'styles/loginRecover.css';

export default function ChangePassword() {
  const auth = useAuth();

  useEffect(() => {
    getUserInfoById();
  }, []);
  // manage axios hook
  const { fetchData } = useAxios();

  // passwords states
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    newPasswordConfirm: '',
  });
  const { formatterText } = useLangv2();
  const [currentPassword, setCurrentPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(false);
  const [passwordCurrentShown, setPasswordCurrentShown] = useState(false);
  const [passwordNewShown, setPasswordNewShown] = useState(false);
  const [passwordConfirmedShown, setPasswordConfirmedShown] = useState(false);
  const togglePasswordCurrentVisiblity = () => setPasswordCurrentShown(!passwordCurrentShown);
  const togglePasswordNewVisibilty = () => setPasswordNewShown(!passwordNewShown);
  const togglePasswordConfirmedVisibilty = () => setPasswordConfirmedShown(!passwordConfirmedShown);
  const restorePassword = (e) => {
    e.preventDefault();
    setErrorMessage(false);
    if (formData.newPassword === formData.newPasswordConfirm) {
      //  create an expression to validate if the password have at least 1 number, at least 1 letter uppercase and at special character
      const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
      if (regex.test(formData.newPassword)) {
        const Username = JSON.parse(localStorage.getItem('userData')).usuario;

        setIsLoading(true);

        const DATA = {
          Username,
          OldPassword: formData.currentPassword,
          NewPassword: formData.newPasswordConfirm,
        };
        fetchData({
          url: endpoints.auth.changePassword,
          method: 'post',
          body: DATA,
          typeConfig: 'form',
        }).then((data) => {
          const { response, loading } = data;
          setIsLoading(loading);
          if (response) {
            CustomAlert('confirm_msg', {
              icon: 'success',
              title:formatterText('title.user.passwordChanged.success'),
              text: formatterText('title.user.passwordChanged'),
              confirmButtonText: formatterText('title.user.passwordstMatch.log.in'),
              allowOutsideClick: false,
              executeFunction: () => auth.logout(),
            });
          } else {
            setIsLoading(false);
            CustomAlert('short_msg', {
              icon: 'error',
              title: `Error`,
              text: formatterText('title.user.currentPasswordMismatch'),
            });
          }
        });
        setErrorMessage(false);
      } else {
        setErrorMessage(true);
      }
    } else {
      CustomAlert('short_msg', {
        icon: 'error',
        title: `Error`,
        text: formatterText('title.user.passwordsDoNotMatch'),
      });
      setIsLoading(false);
    }
  };

  const getUserInfoById = () => {
    getUserInfo(COOKIE_USER)
      .then((res) => {
        setCurrentPassword(res.clave);
      })
      .catch((err) => {
        console.log('Error', err);
      });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  return (
    <section className="recover-password">
      <form className="recover-password-container" onSubmit={restorePassword} autoComplete="off">
        <h5 className="recover-password-title"><FormattedMessage id="ChangeFirstPassword.text1" defaultMessage="Cambia tu contraseña"/></h5>

        <div className="pass-wrapper">
          <input
            className="input-passwords"
            type={passwordCurrentShown ? 'text' : 'password'}
            placeholder={formatterText('title.user.currentPassword')}
            name="currentPassword"
            onChange={handleChange}
            maxLength="50"
            required
          />
          {passwordCurrentShown ? (
            <IoMdEye size={30} className="eye-icon" onClick={togglePasswordCurrentVisiblity} />
          ) : (
            <IoMdEyeOff size={30} className="eye-icon" onClick={togglePasswordCurrentVisiblity} />
          )}
        </div>
        <div className="pass-wrapper">
          <input
            className="input-passwords"
            type={passwordNewShown ? 'text' : 'password'}
            placeholder={formatterText('title.user.newPassword')}
            name="newPassword"
            onChange={handleChange}
            maxLength="50"
            required
          />
          {passwordNewShown ? (
            <IoMdEye size={30} className="eye-icon" onClick={togglePasswordNewVisibilty} />
          ) : (
            <IoMdEyeOff size={30} className="eye-icon" onClick={togglePasswordNewVisibilty} />
          )}
        </div>
        <div className="pass-wrapper mb-5">
          <input
            className="input-passwords"
            type={passwordConfirmedShown ? 'text' : 'password'}
            placeholder={formatterText('title.user.confirmNewPassword')}
            name="newPasswordConfirm"
            onChange={handleChange}
            maxLength="50"
            required
          />
          {passwordConfirmedShown ? (
            <IoMdEye size={30} className="eye-icon" onClick={togglePasswordConfirmedVisibilty} />
          ) : (
            <IoMdEyeOff size={30} className="eye-icon" onClick={togglePasswordConfirmedVisibilty} />
          )}
        </div>

       <button type="submit" className="btn-primary"  disabled={isLoading}>
       {isLoading ? `${formatterText('title.user.loading')}` : `${formatterText('title.user.changePassword')}`}
        </button>
        {errorMessage && (
          <ul className="error-message">
            <li>{formatterText('title.user.passwordRequirements')}</li>
            <li>{formatterText('title.user.passwordRequirement1')}</li>
            <li>{formatterText('title.user.passwordRequirement2')}</li>
            <li>{formatterText('title.user.passwordRequirement3')}</li>
            <li>{formatterText('title.user.passwordRequirement4')}</li>
          </ul>
        )}
      </form>
    </section>
  );
}
