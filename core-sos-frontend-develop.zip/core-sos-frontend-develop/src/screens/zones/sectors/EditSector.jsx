import PermissionSelector from 'common/PermissionSelector';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import { CODEREGEX, TEXTREGEX } from 'common/validators/Regex';
import {
  validateDuplicateSector,
  validateDuplicateSectorCode,
} from 'common/validators/ValidateDuplicates';
import CustomAlert from 'components/CustomAlert';
import Cookie from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  getAllMunicipalities,
  getAllSectors,
  getSectorById,
  updateSector,
} from 'services/api/zones';
import paths from 'services/paths';
import Swal from 'sweetalert2';

import { FilterActive } from 'common/validators/FilterActives';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';

const EditSector = () => {
  const { setDataTable } = useSeachContext();
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    codigoSector: '',
    nombre: '',
    estado: '',
    kilometros: '',
    idMunicipio: {},
    fechaCreacion: '',
    fechaModificacion: '',
    usuarioCreacion: '',
    usuarioModificacion: '',
    observaciones: ''
  });
  // use Hook of language v2
  const { formatterText } = useLangv2();
  const [toggleSelector, setToggleSelector] = useState(false);
  const [selectedPermisosModulos, setSelectedPermisosModulos] = useState([]);
  const [permisosModulos, setPermisosModulos] = useState([]);
  const [allPermisos, setAllPermisos] = useState([]);
  const [active, setActive] = useState(true);

  const handleChange = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };

  const handleNameChange = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handleOpcionesChange = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handleKilometerChange = (e) => {
    const regex = `^[.0-9]*$`;
    if (e.target.value.match(regex) != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const getMunicipalities = () => {
    getAllMunicipalities()
      .then((resp) => {
        const municipalities = FilterActive(resp);
        getSectorData(municipalities);
      })
      .catch(console.error);
  };

  const getSectorData = (municipalities) => {
    getSectorById(id)
      .then((sector) => {
        const isActive = sector.estado === 1;

        const selectedMunicipalities = municipalities.filter(
          (permiso) => sector.idMunicipio.idMunicipio === permiso.idMunicipio,
        );

        const noselectedMunicipalities = municipalities.filter(
          (permiso) => sector.idMunicipio.idMunicipio !== permiso.idMunicipio,
        );

        setActive(isActive);
        setSelectedPermisosModulos(selectedMunicipalities);
        setPermisosModulos(noselectedMunicipalities);
        setDataTable(noselectedMunicipalities);
        setAllPermisos(noselectedMunicipalities);
        setFormData({
          ...formData,
          idSector: sector.idSector,
          codigoSector: sector.codigoSector,
          nombre: sector.nombre,
          estado: sector.estado,
          kilometros: sector.kilometros,
          fechaCreacion: sector.fechaCreacion,
          fechaModificacion: sector.fechaModificacion,
          usuarioCreacion: sector.usuarioCreacion,
          observaciones:sector.observaciones
        });
      })
      .catch(console.error);
  };

  const handleRemoveRole = (e, permisosModulo) => {
    e.preventDefault();
    const selected = selectedPermisosModulos.filter(
      (currentPermisosModulo) => currentPermisosModulo.idMunicipio !== permisosModulo.idMunicipio,
    );
    setSelectedPermisosModulos(selected);
    setPermisosModulos([...permisosModulos, permisosModulo]);
    setDataTable([...permisosModulos, permisosModulo]);
  };

  const handleAddRole = (permiso) => {
    const newPermisosModulos = permisosModulos.filter(
      (currentRol) => currentRol.idMunicipio !== permiso.idMunicipio,
    );
    setDataTable(newPermisosModulos);
    setPermisosModulos(newPermisosModulos);
    let selected = [...selectedPermisosModulos, permiso];
    setSelectedPermisosModulos(selected);
    setToggleSelector(!toggleSelector);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const validate = validateDuplicateSectorCode(
      formData.codigoSector,
      'El código del sector ya existe',
      () => getAllSectors(),
      true,
    );
    if (selectedPermisosModulos.length < 1) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: `Debes añadir un municipio al sector`,
        text: 'Completa todos los campos',
      });
    } else {
      const fechaAct = new Date();
      const data = {
        ...formData,
        // usuarioCreacion: Cookie.get("idUsuario"),
        estado: active ? '1' : '0',
        codigoSector: formData.codigoSector.toUpperCase(),
        idMunicipio: {
          ...selectedPermisosModulos[0],
        },
        fechaModificacion: fechaAct,
        usuarioModificacion: Cookie.get('idUsuario'),
      };
      if (
        validateDuplicateSector(
          data,
          'El sector ya existe en este municipio',
          () => getAllSectors(),
          true,
        )
      ) {
        Swal.fire({
          title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
          text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
          icon: 'question',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          showLoaderOnConfirm: true,
          cancelButtonColor: '#d33',
          confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
          allowOutsideClick: false,
          cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
          preConfirm: () => {
            return new Promise((resolve, reject) => {
              updateSector(data)
                .then((res) => {
                  resolve(
                    CustomAlert('confirm_msg', {
                      icon: 'success',
                      title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                      text: formatterText(
                        'alert.message.confirm.updated.general',
                        'El registro se ha actualizado correctamente',
                      ),
                      confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                      allowOutsideClick: false,
                      executeFunction: () => navigate(paths.zones),
                    }),
                  );
                })
                .catch((err) => {
                  if (err.response?.data?.message) {
                    HandleOnError(formatterText(err.response?.data?.message));
                  } else {
                    HandleOnError(formatterText(
                      'snackbar.error.process.failed.general',
                      'Error al realizar el proceso. Intentalo en otro momento.',
                    ),);
                  }
                });
            });
          },
        });
      }
    }
  };

  useEffect(() => {
    getMunicipalities();
  }, []);  

  return (
    <form className="edit-profile" onSubmit={handleSubmit}>
      <section className="edit-profile-container-information">
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.sector" defaultMessage="Nombre del sector" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleNameChange}
            placeholder={formatterText('p.sector', 'Nombre del sector')}
            maxLength={50}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </h3>
          <label
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              color: '#747474',
            }}
          >
            <p className="form-responsive-toggle">
              {active
                ? formatterText('p.active', 'Activo')
                : formatterText('p.unActive', 'No activo')}
            </p>
            <label className="switch">
              <input
                checked={!!active}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="codigoSector"
            value={formData.codigoSector}
            onChange={handleChange}
            placeholder={formatterText(
              'input.placeholder.sectorCode',
              'Ingrese el código del sector',
            )}
            autoComplete="off"
            maxLength={40}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.asMunicipality" defaultMessage="Municipio asociado" />
          </h3>

          <div>
            <div className="input-select-option-custom inputRole">
              {selectedPermisosModulos.length < 1 && (
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    setToggleSelector(!toggleSelector);
                  }}
                  className="add-role"
                >
                  <FormattedMessage id="p.addMunicipality" defaultMessage="Añadir municipio +" />
                </button>
              )}

              {selectedPermisosModulos.map((rol, index) => (
                <button
                  key={`${index + 0}`}
                  onClick={(e) => handleRemoveRole(e, rol)}
                  className="role-item"
                >
                  {rol.nombre} - {rol.codigoMunicipio} - {rol.idDepartamento.nombre}
                </button>
              ))}
            </div>
            {toggleSelector && <PermissionSelector handleAdd={handleAddRole} sector={true} />}
          </div>
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage
              id="p.km.cHToSector"
              defaultMessage="Kilómetros de distancia entre alcaldía y sector"
            />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="kilometros"
            value={formData.kilometros}
            onChange={handleKilometerChange}
            autoComplete="off"
            placeholder={formatterText('input.placeholder.km', 'Ingrese los kilómetros')}
            maxLength={40}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="warpForm-text">
            <FormattedMessage
              id="p.obser"
              defaultMessage="Observaciones"
            />
          </h3>
          <textarea
            className="input-textarea-sm"
            name="observaciones"
            onChange={handleOpcionesChange}
            value={formData.observaciones}
            placeholder={formatterText('input.placeholder.observation', 'Ingrese las observaciones')}
            required
          />
        </section>
      </section>
      <section className="edit-profile-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.save.changes" defaultMessage="Guardar cambios" />
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.sector)}>
          <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
};

export const EditSectorWithSearch = (props) => (
  <SearchWrapper>
    <EditSector {...props} />
  </SearchWrapper>
);

export default EditSectorWithSearch;
