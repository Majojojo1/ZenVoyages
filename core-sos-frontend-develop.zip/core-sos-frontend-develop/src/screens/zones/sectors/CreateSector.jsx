import PermissionSelector from 'common/PermissionSelector';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import { CODEREGEX, TEXTREGEX } from 'common/validators/Regex';
import { validateDuplicateSector } from 'common/validators/ValidateDuplicates';
import CustomAlert from 'components/CustomAlert';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import Cookie from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { useNavigate } from 'react-router-dom';
import { addSector, getAllMunicipalities, getAllSectors } from 'services/api/zones';
import paths from 'services/paths';
import Swal from 'sweetalert2';
const CreateSector = () => (
  <SearchWrapper>
    <CreateSectorComponent />
  </SearchWrapper>
);
const CreateSectorComponent = () => {
  const { setDataTable } = useSeachContext();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    codigoSector: '',
    nombre: '',
    estado: 1,
    kilometros: '',
    idMunicipio: {},
    fechaCreacion: '',
    fechaModificacion: '',
    usuarioCreacion: '',
    usuarioModificacion: '',
    observaciones: ''
  });
  const [toggleSelector, setToggleSelector] = useState(false);
  const [selectedPermisosModulos, setSelectedPermisosModulos] = useState([]);
  const [permisosModulos, setPermisosModulos] = useState([]);
  const [allPermisos, setAllPermisos] = useState([]);
  const [active, setActive] = useState(true);

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const handleChange = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };

  const handleNameChange = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handleOpcionesChange = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handleKilometerChange = (e) => {
    const regex = `^[\.0-9]*$`;
    if (e.target.value.match(regex) != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const getMunicipalities = () => {
    getAllMunicipalities()
      .then((municipalities) => {
        console.log(municipalities);
        const newMunicipalities = [];
        municipalities.forEach((municipality) => {
          if (municipality.estado === 1) {
            newMunicipalities.push(municipality);
          }
        });
        setPermisosModulos(newMunicipalities);
        setDataTable(newMunicipalities);
        setAllPermisos(newMunicipalities);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleRemoveRole = (e, permisosModulo) => {
    e.preventDefault();
    const selected = selectedPermisosModulos.filter(
      (currentPermisosModulo) => currentPermisosModulo.idMunicipio !== permisosModulo.idMunicipio,
    );
    setSelectedPermisosModulos(selected);
    setPermisosModulos([...permisosModulos, permisosModulo]);
    setDataTable([...permisosModulos, permisosModulo]);
  };

  const handleAddRole = (permiso) => {
    const newPermisosModulos = permisosModulos.filter(
      (currentRol) => currentRol.idMunicipio !== permiso.idMunicipio,
    );
    setDataTable(newPermisosModulos);
    setPermisosModulos(newPermisosModulos);
    let selected = [...selectedPermisosModulos, permiso];
    setSelectedPermisosModulos(selected);
    setToggleSelector(!toggleSelector);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedPermisosModulos.length < 1) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: `${formatterText('message.municipality.required')}`,
        text: formatterText('message.fill.all.fields'),
      });
    } else {
      const data = {
        ...formData,
        usuarioCreacion: Cookie.get('idUsuario'),
        estado: '1',
        codigoSector: formData.codigoSector.toUpperCase(),
        idMunicipio: {
          ...selectedPermisosModulos[0],
        },
      };
      if (validateDuplicateSector(data, 'El sector ya existe', () => getAllSectors())) {
        // if (validateDuplicateSectorCode(data.codigoSector, "El código ya existe", () => getAllSectors())) {
        Swal.fire({
          title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
          text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
          icon: 'question',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          showLoaderOnConfirm: true,
          cancelButtonColor: '#d33',
          confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
          allowOutsideClick: false,
          cancelButtonText:  formatterText('alert.button.cancel.general', 'Cancelar'),
          preConfirm: () => {
            return new Promise((resolve, reject) => {
              addSector(data)
                .then((res) => {
                  resolve(
                    CustomAlert('confirm_msg', {
                      icon: 'success',
                      title:  formatterText('alert.title.confirm.general', 'Operación exitosa'),
                      text: formatterText(
                        'alert.message.confirm.created.general',
                        'El registro se ha creado correctamente',
                      ),
                      confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                      allowOutsideClick: false,
                      executeFunction: () => navigate(paths.zones),
                    }),
                  );
                })
                .catch((err) => {
                  if (err.response?.data?.message) {
                    HandleOnError(formatterText(err.response?.data?.message));
                  } else {
                    HandleOnError(formatterText(
                      'snackbar.error.process.failed.general',
                      'Error al realizar el proceso. Intentalo en otro momento.',
                    ),);
                  }
                });
            });
          },
        });
        // }
      }
    }
  };

  useEffect(() => {
    getMunicipalities();
  }, []);

  return (
    <form className="edit-profile" onSubmit={handleSubmit}>
      <section className="edit-profile-container-information">
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.sector" defaultMessage="Nombre del sector" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleNameChange}
            placeholder={formatterText('p.sector', 'Nombre del sector')}
            maxLength={50}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="codigoSector"
            value={formData.codigoSector}
            onChange={handleChange}
            placeholder={formatterText(
              'input.placeholder.sectorCode',
              'Ingrese el código del sector',
            )}
            autoComplete="off"
            maxLength={40}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.asMunicipality" defaultMessage="Municipio asociado" />
          </h3>

          <div>
            <div className="input-select-option-custom inputRole">
              {selectedPermisosModulos.length < 1 && (
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    setToggleSelector(!toggleSelector);
                  }}
                  className="add-role"
                >
                  <FormattedMessage id="p.addMunicipality" defaultMessage="Añadir municipio +" />
                </button>
              )}

              {selectedPermisosModulos.map((rol, index) => (
                <button
                  key={`${index + 0}`}
                  onClick={(e) => handleRemoveRole(e, rol)}
                  className="role-item"
                >
                  {rol.nombre} - {rol.codigoMunicipio} - {rol.idDepartamento.nombre}
                </button>
              ))}
            </div>
            {toggleSelector && <PermissionSelector handleAdd={handleAddRole} sector={true} />}
          </div>
        </section>
        <section className="edit-profile-information__option">
          <h3 className="warpForm-text">
            <FormattedMessage
              id="p.km.cHToSector"
              defaultMessage="Kilómetros de distancia entre alcaldía y sector"
            />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="kilometros"
            value={formData.kilometros}
            onChange={handleKilometerChange}
            autoComplete="off"
            placeholder={formatterText('input.placeholder.km', 'Ingrese los kilómetros')}
            maxLength={40}
            required
          />
        </section>
        <section className="edit-profile-information__option">
          <h3 className="warpForm-text">
            <FormattedMessage

              id="p.obser"
              defaultMessage="Observaciones"
            />
          </h3>
          <textarea
            className="input-textarea-sm"
            name="observaciones"
            onChange={handleOpcionesChange}
            value={formData.observaciones}
            placeholder={formatterText('input.placeholder.observation', 'Ingrese las observaciones')}
            required
          />
        </section>
      </section>
      <section className="edit-profile-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.save.changes" defaultMessage="Guardar cambios" />
        </button>
        <button
          className="input-cancel"
          onClick={() => {
            navigate(paths.zones);
          }}
        >
          <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
};

export default CreateSector;
