  import DynamicTable from "components/zones/DynamicTable";
import { PAGES } from "constants/lang/services/services/pages";
import { useSeachContext } from 'context/SearchContext';
import dateFormat from "dateformat";
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import React, { useEffect, useState } from "react";
import { getAllMunicipalities } from "services/api/zones";

const Municipalities = () => {
  const [municipalities, setMunicipalities] = useState([]);
  const { setDataTable, searchResults = [], setSearchResults } = useSeachContext();
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  useEffect(() => {
    (async () => {
      toggleLoading(true);
      await getData();
      toggleLoading(false);
    })();
  }, []);

  const getData = () => {    
    getAllMunicipalities()
      .then((data) => {
        let newArray = [];
        data.forEach((item) =>
          newArray.push({
            codigoMunicipio: item.codigoMunicipio,
            nombre: item.nombre,
            prefijo: item.prefijo,
            estado: item.estado,
            kilometros: item.kilometros,
            codigoDepartamento: item.idDepartamento.codigoDepartamento,
            nombrePais: item.idDepartamento.idPais.nombrePais,
            fechaCreacion: dateFormat(
              item.fechaCreacion,
              "yyyy/mm/dd - h:MM:ss TT",
            ),
            fechaModificacion: dateFormat(
              item.fechaModificacion,
              "yyyy/mm/dd - h:MM:ss TT",
            ),
            id: item.idMunicipio,
            objeto: item.idDepartamento,
            usuarioCreacion: item.usuarioCreacion,
            fc: item.fechaCreacion,
            uc: item.usuarioCreacion,
            zonaHorariaGmt:parseInt(item.zonaHorariaGmt),
          }),
        );
        setMunicipalities(newArray);
        setDataTable(newArray); 
        setSearchResults(newArray);       
      })
      .catch((err) => {
        toggleError(!error);
        console.log(err);
        handleClick();
      });
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const titles = [
    formatterText("table.title.muniCode", "Código municipio"),
    formatterText("table.title.muniName", "Nombre municipio"),
    formatterText("table.title.countryPrefix", "Prefijo"),
    formatterText("table.title.state", "Estado"),
    formatterText("table.title.km", "Kilómetros"),
    formatterText("table.title.departmentCode","Código departamento"),
    formatterText("table.title.countryName", "Nombre país"),
    formatterText("table.title.creationD", "Fecha creación"),
    formatterText("table.title.modificationDate", "Fecha modificación"),
  ];

  return (
    <>
      {!loading ? (
        <div className="tab-container">
          {!loading && (
            <DynamicTable
              titles={titles}
              data={searchResults}
              setMunicipalities= {setMunicipalities}
              getData={getData}
              pageName={PAGES.Municipalidades}
            />
          )}
        </div>
      ) : error ? (
        displayMessage(
          "error",
          "Ha ocurrido un error, intentalo más tarde.",
          "toast.error.general",
        )
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default Municipalities;
