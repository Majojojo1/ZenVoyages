import React, { useEffect, useState } from "react";
// Import Contexts
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
// Import Components
import DynamicTable from "components/zones/DynamicTable";
// Import Libs
import dateFormat from "dateformat";
// Import Services
import { PAGES } from "constants/lang/services/services/pages";
import { useSeachContext } from 'context/SearchContext';
import { getAllDepartments } from "services/api/zones";

const Departments = () => {
  const [departments, setDepartments] = useState([]);
  const { setDataTable, dataTable, searchResults= [], setSearchResults } = useSeachContext();

  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();


  const getData = () => {
    getAllDepartments()
      .then((data) => {
        let newArray = [];
        data.forEach((item) =>
          newArray.push({
            codigoDepartamento: item.codigoDepartamento,
            nombre: item.nombre,
            codigoPais: item.idPais.codigoPais,
            estado: item.estado,
            fechaCreacion: dateFormat(
              item.fechaCreacion,
              "yyyy/mm/dd - h:MM:ss TT",
            ),
            fechaModificacion: item.fechaModificacion != null? dateFormat(
              item.fechaModificacion,
              "yyyy/mm/dd - h:MM:ss TT",
            ): dateFormat(
              item.fechaCreacion,
              "yyyy/mm/dd - h:MM:ss TT",
            ),
            id: item.idDepartamento,
            objeto: item.idPais,
            usuarioCreacion: item.usuarioCreacion,
            fc: item.fechaCreacion,
            uc: item.usuarioCreacion,
          }),
        );

        setDepartments(newArray);
        setDataTable(newArray);
        setSearchResults(newArray);
        
      })
      .catch((err) => {
        toggleError(!error);
        console.log(err);
        handleClick();
      });
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const titles = [
    formatterText("table.title.departmentCode", "Código departamento"),
    formatterText("table.title.departmentName", "Nombre departamento"),
    formatterText("table.title.countryCode", "Código país"),
    formatterText("table.title.state", "Estado"),
    formatterText("table.title.creationD", "Fecha creación"),
    formatterText("table.title.modificationDate", "Fecha modificación"),
  ];

  useEffect(() => {
    (async () => {
      toggleLoading(true);
      await getData();
      toggleLoading(false);
    })();
  }, []);

  return (
    <>
      {!loading ? (
        <div className="tab-container">
          {!loading && (
            <DynamicTable
              titles={titles}
              data={searchResults}
              getData={getData}
              pageName={PAGES.Departamentos}
            />
          )}
        </div>
      ) : error ? (
        displayMessage(
          "error",
          "Ha ocurrido un error, intentalo más tarde.",
          "toast.error.general",
        )
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default Departments;
