import React, { useEffect, useMemo, useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';

import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import UploadFile from 'components/utils/UploadFile';
// Import Libs
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import Screens
import Countries from './tabs/Countries';
import Departments from './tabs/Departments';
import Municipalities from './tabs/Municipalities';
import Sectors from './tabs/Sectors';
// Import Services
import paths from 'services/paths';
// Import Styles
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import 'styles/tab.css';

const ZonesComponent = () => {
  // use Hook of language v2

  const { searchResults = [], setSearch } = useSeachContext();
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.zoneCatalog.principal);
  };

  const tabs = useMemo(
    () => [
      {
        id: 0,
        nombre: <FormattedMessage id="tab.title.countries" defaultMessage="Países" />,
        names: 'Países',
        route: null,
        componente: <Countries />,
        exportExcel: permittedActions.exportar,
        uploadExcel: permittedActions.importar,
        idPermiso: MODULES_NAME.zoneCatalog.countries,
      },
      {
        id: 1,
        nombre: <FormattedMessage id="titles.page.name.dinamic.table.departamentos" defaultMessage="Departamentos" />,
        names: 'Departamentos',
        route: null,
        componente: <Departments />,
        exportExcel: permittedActions.exportar,
        uploadExcel: permittedActions.importar,
        idPermiso: MODULES_NAME.zoneCatalog.states,
      },
      {
        id: 2,
        nombre: <FormattedMessage id="tab.title.municipalities" defaultMessage="Municipios" />,
        names: 'Municipios',
        route: null,
        componente: <Municipalities />,
        exportExcel: permittedActions.exportar,
        uploadExcel: permittedActions.importar,
        idPermiso: MODULES_NAME.zoneCatalog.cities,
      },
      {
        id: 3,
        nombre: <FormattedMessage id="tab.title.sectors" defaultMessage="Sectores" />,
        names: 'Sectores',
        route: paths.createSector,
        nombreLink: <FormattedMessage id="btn.create.sector" defaultMessage="Crear Sector" />,
        componente: (
          <Sectors canDeleted={permittedActions.eliminar} canModify={permittedActions.editar} />
        ),
        create: permittedActions.crear,
        exportExcel: permittedActions.exportar,
        uploadExcel: permittedActions.importar,
        idPermiso: MODULES_NAME.zoneCatalog.sectors,
      },
    ],
    [permittedActions.editar, permittedActions.eliminar],
  );

  // Select tab
  const [selectedTab, setSelectedTab] = useState(tabs[0]);

  // Index Tab
  const [indexTabSectors] = useState(Number(localStorage.getItem('Zones')) || 0);

  useEffect(() => {
    setSearch('');
  }, [selectedTab]);

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    tabs[parseInt(JSON.parse(localStorage.getItem('indexTabSectors'))) || 0];
  }, [permittedActions]);

  return (
    <section className="table-container">
      <section className="userOptions">
        {permittedActions.consultar && (
          <Search
            placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
            width="50%"
          />
        )}
        {permittedActions.exportar && (
          <ExportJsonFile
            moduleName={selectedTab.names}
            userName={JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN'}
            dataTable={searchResults}
          />
        )}
        {permittedActions.importar && (
          <UploadFile currentZone={formatterText(selectedTab.nombre.props.id)} />
        )}
        {permittedActions.crear && selectedTab.create && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.route}>
            <button className="btn-add">{selectedTab.nombreLink}</button>
          </Link>
        )}
      </section>
      <Tabs defaultIndex={indexTabSectors} onSelect={index => localStorage.setItem('Zones', index)} selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                localStorage.setItem('indexTabSectors', index.toString());
                //permissionsAccess(tab.idPermiso);
              }}
              key={`tab_${index + 1}`}
              className="tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {permittedActions.consultar &&
          tabs.map((tab, index) => (
            <TabPanel key={`tab_panel_${index + 1}`}>{tab.componente}</TabPanel>
          ))}
      </Tabs>
    </section>
  );
};



const Zones = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ZonesComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

export default Zones;
