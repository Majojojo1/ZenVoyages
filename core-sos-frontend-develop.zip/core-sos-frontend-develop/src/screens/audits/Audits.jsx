import DynamicTable from 'components/zones/DynamicTable';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import React, { useEffect, useState } from 'react';
// Import Hooks
import Search from 'common/Search';
import dateFormat from 'dateformat';
import useAxios from 'hooks/useAxios';
import useProgress from 'hooks/useProgress';
// Import Components
import SelectorMulti from 'common/SelectorMulti';
import { MdKeyboardArrowDown, MdKeyboardArrowRight } from 'react-icons/md';
// Import Libs
import { FormattedMessage } from 'react-intl';
// Import services
import endpoints from 'services/api';
// hook para cargar los datos
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import DateTimePicker from 'components/pickers/DateTimePicker';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import { PAGES } from 'constants/lang/services/services/pages';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { addItem, getAll } from 'services/api/methods';
import 'styles/tab.css';

const Audits = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <AuditComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const AuditComponent = () => {
  const { rowsPerPage, setRowsPerPage, page, setPage } = useSeachContext();

  // hook to loading data
  const { toggleLoading } = useGetData();
  const [audits, setAudits] = useState([]);
  // const [leakedData, setLeakedData] = useState([]);
  const { setDataTable, dataTable, leakedData, setLeakedData } = useSeachContext();
  // Estados de los permisosModulos
  const [readAudit, setReadAudit] = useState(true);

  // Helps to loading data table
  const { loadingProgress, setLoadingProgress } = useProgress();
  const { cancelRequest } = useAxios();
  const [permissionsData, setPermissions] = useState([]);
  const [modulesData, setModules] = useState([]);
  const [userData, setUserData] = useState([]);

  // use Hook of language v2
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const titles = [
    formatterText('table.title.userPerform', 'Usuario que realizó la acción'),
    formatterText('table.title.date&TimePerform', 'Fecha y hora en que se realizó la acción'),
    formatterText('table.title.modulePerform', 'Módulo del sistema donde se realizó la acción'),
    formatterText('table.title.permissionPerform', 'Permiso usado para realizar la acción'),
    formatterText('table.title.ipPerform', 'Ip desde donde se realizó la acción'),
    formatterText('table.title.sqlExePerform', 'Nota'),
  ];

  const [formData, setFormData] = useState({
    ip: '',
  });

  const [advancedSearch, setAdvancedSearch] = useState(false);
  const [multiPermissions, setMultiPermissions] = useState([]);
  const [multiModules, setMultiModules] = useState([]);
  const [multiQueries, setMultiQueries] = useState([]);
  const [multiUsers, setMultiUsers] = useState([]);
  const [dates, setDates] = useState({
    fecha_inicio: null,
    fecha_fin: null,
    fecha_registro: null,
  });

  useEffect(() => {
    permissionsAccess(MODULES_NAME.audit);
  }, [permissions]);

  const getAllUsers = () => {
    getAll(endpoints.users.getAllUsers).then((res) => {
      let newArray = [];
      res.forEach((item) => {
        newArray.push({
          id: item.idUsuario,
          label: `${item.usuario}`,
        });
      });
      setUserData(newArray);
    });
  };

  const getAllPermissions = () => {
    getAll(endpoints.audit.getPermissions).then((res) => {
      let newArray = [];
      res.forEach((item) => {
        newArray.push({
          id: item.idpermiso,
          label: `${item.nombre}`,
        });
      });
      setPermissions(newArray);
    });
  };

  const getAllModules = () => {
    getAll(endpoints.audit.getModules).then((res) => {
      let newArray = [];
      res.forEach((item) => {
        newArray.push({
          id: item.idModulo,
          label: `${item.nombre}`,
        });
      });
      setModules(newArray);
    });
  };

  const searchAdvance = (e) => {
    e.preventDefault();
    setLoadingProgress(true);

    const timeZone = 'America/Bogota';

    // Users
    const USR = multiUsers.map((item) => {
      return item.id;
    });

    // Dates
    const FR_FI = dates.fecha_inicio;
    const FR_FF = dates.fecha_fin;
    let RANGE_DATE = '';

    if (FR_FI === null && FR_FF === null) {
      RANGE_DATE = null;
    } else {
      RANGE_DATE = {
        fecha_inicio: dateFormat(FR_FI, 'isoDate'),
        hora_inicio: dateFormat(FR_FI, 'isoTime'),
        fecha_fin: dateFormat(FR_FF, 'isoDate'),
        hora_fin: dateFormat(FR_FF, 'isoTime'),
      };
    }

    // Permissions
    const PERM = multiPermissions.map((item) => {
      return item.id;
    });

    // Modules
    const MOD = multiModules.map((item) => {
      console.log(item);

      return item.id;
    });

    // Queries
    const QUERY = multiQueries.map((item) => {
      return { query: item.query };
    });

    const BODY = {
      usuarios: USR.length === 0 ? null : USR,
      fecha_registro: dates.fecha_registro,
      fechaInicio: `${RANGE_DATE.fecha_inicio} ${RANGE_DATE.hora_inicio}`,
      fechaFin: `${RANGE_DATE.fecha_fin} ${RANGE_DATE.hora_fin}`,
      permisos: PERM.length === 0 ? null : PERM,
      modulos: MOD.length === 0 ? null : MOD,
      ip: formData.ip === '' ? null : formData.ip,
      query: QUERY.length === 0 ? null : QUERY,
      pageNumber: page,
      rowsPerPage: rowsPerPage,
    };
    // show loading
    toggleLoading(true);
    addItem(endpoints.audit.getAuditsQuery, BODY)
      .then((response) => {
        let newArray = [];
        // Math.max(0, Math.ceil(count / rowsPerPage) - 1))
        let pages = Math.max(0, Math.ceil(response.cantidadRegistros / rowsPerPage) - 1);
        // setPage(pages);
        response.datosAuditoria.forEach((item) =>
          newArray.push({
            // usuario: item.idUsuario.usuario,
            usuario: item.usuario,
            fechaRegistro: dateFormat(item.fechaRegistro, 'yyyy/mm/dd - HH:MM TT', { timeZone }),
            // modulo: item.idModulo.nombre,
            modulo: item.nombreModulo,
            // permiso: item.idPermiso.nombre,
            permiso: item.nombrePermiso,
            ip: item.ip,
            query: item.nota ? item.nota : 'No hay nota',
          }),
        );
        newArray.reverse();
        setDataTable(newArray);
        // show loading
        setLoadingProgress(false);
        toggleLoading(false);
        setAudits(newArray);
      })
      .catch((resp) => setLoadingProgress(false));
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleChangeMulti = (val) => {
    setMultiPermissions(val);
  };

  const handleChangeModules = (val) => {
    setMultiModules(val);
  };

  const handleChangeUsers = (val) => {
    setMultiUsers(val);
  };

  useEffect(() => {
    getAllUsers();
    getAllPermissions();
    getAllModules();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div className="table-container">
        {permittedActions.consultar && (
          <section className="advance-search">
            <p
              onClick={(e) => {
                e.preventDefault();
                setAdvancedSearch(!advancedSearch);
              }}
            >
              {advancedSearch ? (
                <MdKeyboardArrowDown size={22} color="gray" cursor="pointer" />
              ) : (
                <MdKeyboardArrowRight size={22} color="gray" cursor="pointer" />
              )}
              <FormattedMessage
                id="text.action.show.advanced.search"
                defaultMessage="Búsqueda avanzada"
              />
            </p>
          </section>
        )}

        {advancedSearch && (
          <>
            <section className="grid-container-3c">
              <label className="d-flex">
                <span className="text-inline">{formatterText('table.title.user')}</span>
                <section className="w100-container">
                  <SelectorMulti
                    data={userData}
                    dataValue={multiUsers}
                    setterFunction={handleChangeUsers}
                  />
                </section>
              </label>
              <label className="d-flex">
                <DateTimePicker
                  name="fecha_inicio"
                  value={dates.fecha_inicio}
                  onChange={(data) => setDates({ ...dates, ...data })}
                  placeholder={formatterText('title.service.startDate.audit')}
                />
              </label>
              <label className="d-flex">
                <DateTimePicker
                  name="fecha_fin"
                  value={dates.fecha_fin}
                  onChange={(data) => setDates({ ...dates, ...data })}
                  placeholder={formatterText('title.service.endDate')}
                />
              </label>
              <label className="d-flex">
                <span className="text-inline">
                  <FormattedMessage id="Audit.text1" defaultMessage="Permisos" />
                </span>
                <section className="w100-container">
                  <SelectorMulti
                    data={permissionsData}
                    dataValue={multiPermissions}
                    setterFunction={handleChangeMulti}
                  />
                </section>
              </label>
              <label className="d-flex">
                <span className="text-inline">
                  <FormattedMessage id="Audit.text2" defaultMessage="Módulos" />
                </span>
                <section className="w100-container">
                  <SelectorMulti
                    data={modulesData}
                    dataValue={multiModules}
                    setterFunction={handleChangeModules}
                  />
                </section>
              </label>
              <label className="d-flex">
                <input
                  type="text"
                  className="input-default-3c"
                  name="ip"
                  placeholder="IP"
                  value={formData.ip}
                  onChange={handleChange}
                />
              </label>
            </section>
            <section
              style={{
                marginBottom: '2rem',
              }}
            >
              <button
                className={`${dates.fecha_inicio == null ? 'disabled' : '' } btn-search`}
                onClick={(e) => searchAdvance(e)}
                disabled={dates.fecha_inicio == null}
              >
                {loadingProgress ? (
                  <FormattedMessage id="btn.loading" defaultMessage="Cargando..." />
                ) : (
                  <FormattedMessage id="btn.search" defaultMessage="Buscar" />
                )}
              </button>
            </section>
          </>
        )}

        {permittedActions.consultar && (
          <>
            <section className="userOptions">
              <Search placeholder={formatterText('input.placeholder.search.audit.table')} width="50%" />
              {permittedActions.exportar && (
                <ExportJsonFile
                  moduleName={'auditorías'}
                  userName={
                    JSON.parse(localStorage.getItem('userData')).usuario
                      ? JSON.parse(localStorage.getItem('userData')).usuario
                      : 'ADMIN'
                  }
                  dataTable={leakedData}
                />
              )}
            </section>
            <DynamicTable titles={titles} pageName={PAGES.Auditorías} data={audits} setLeakedData={setLeakedData}/>
          </>
        )}
      </div>
    </>
  );
};

export default Audits;
