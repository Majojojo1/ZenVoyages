import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useLang from 'hooks/useLang';
import { useNavigate } from 'react-router-dom';
// Import Components
import Table from 'common/minimalTables/TableMinimal';
import defaultSelect from 'common/selects/default.select.style';
import CustomAlert from 'components/CustomAlert';
import { Modal } from 'react-responsive-modal';
import UpdateModalItem from './UpdateModalItem';
// Import Libs
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import Model
import CategoryService from 'models/CategoryService';
// Import Services
import axios from 'axios';
import { FilterActive } from 'common/validators/FilterActives';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { CODEREGEX, TEXTREGEX, SPACING, TEXTREGEXMIN } from 'common/validators/Regex';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import Select from 'react-select';
import endpoints from 'services/api';
import { addItem, getAll } from 'services/api/methods';
import paths from 'services/paths';

export default function CreateServiceCategory() {
  return (
    <SearchWrapper>
      <CreateServiceCategoryComponent />
    </SearchWrapper>
  );
}

function CreateServiceCategoryComponent() {
  // Modal config
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  // Call context TableMinimalContext
  const { currentDataTable, setCurrentDataTable } = useContext(TableMinimalContext);

  // Set contextMinimalTable empty
  useEffect(() => {    
    getCategories();
    getProductCategories();
  }, []);

  const { setDataTable, dataTable } = useSeachContext();

  //  Call hook of language
  const { formatterText } = useLang();

  const {
    handleRequestError,
  } = useLangv2();

  // title of minimal table
  const titlesTableSubCategories = [
    formatterText('p.name.type.service', 'Nombre tipo de servicio'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.categoryProduct', 'Categorías de productos'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new CategoryService());
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idTipoServicio: uuidv4(),
    nombre: '',
    codigo: '',
    categorias: [],
    estado: 1,
    descripcion: '',
  });

  const [categories, setCategories] = useState();
  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    createItem(formData);
  };

  // Obtener las categorias
  const getCategories = () => {
    getAll(endpoints.productCategoryService.getAll).then((resp) => {
      let cat = resp.map((elem) => ({
        label: elem.idCategoriaProductoTipoServicio,
        value: {
          id: elem.idCategoriaProductoTipoServicio,
          idCatProd: elem.idCategoriaProducto,
          idServ: elem.idTipoServicio,
        },
      }));
      setCategories(cat);
    });
  };

  // Call the service POST
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.create.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.serviceCategory.addServiceCategory, data)
            .then((res) => {
              associateTypeService(res.idCategoriaServicio, resolve, reject);
            })
            .catch((err) => {
              handleRequestError(err);
              Swal.close();
            });
        });
      },
    });
  };
  // Call the service POST to associate Type Service
  const associateTypeService = (idM, resolve, reject) => {
    if (dataTable.length > 0) {
      let bodyarray = [];
      const promesas = dataTable.map((item) => {
        let data = {
          nombre: item.nombre,
          idCategoriaServicio: {
            idCategoriaServicio: idM,
          },
          descripcion: item.descripcion,
          codigo: item.codigo,
        };
        return addItem(endpoints.typeService.addTypeService, data)
          .then((response) => {
            if (item.categorias.length > 0) {
              const categorias = item.categorias[0].split(', ');
              const catId = categorias.map((cat) => {
                const partes = cat.split(' - ');
                return { label: partes[0], value: partes[1] };
              });
              catId.map((id) => {
                bodyarray.push({
                  idCategoriaProductoTipoServicio: null,
                  idCategoriaProducto: id.value,
                  idTipoServicio: response.idTipoServicio,
                  usuarioCreacion: Cookie.get('idUsuario'),
                });
              });
            }
          })
          .catch((err) => {
            handleRequestError(err);
          });
      });
      Promise.all(promesas)
        .then((_) => {
          if (bodyarray.length > 0) {
            addItem(endpoints.productCategoryService.saveMultiple, bodyarray)
              .then((res) => {
                resolve(
                  CustomAlert('confirm_msg', {
                    icon: 'success',
                    title: formatterText('alert.title.confirm.general'),
                    text: formatterText('alert.message.associations.general'),
                    confirmButtonText: formatterText('alert.button.continue'),
                    allowOutsideClick: false,
                    executeFunction: () => navigate(paths.services),
                  }),
                );
              })
              .catch((err) => {
                handleRequestError(err);
                Swal.close();
              });
          } else {
            resolve(
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general'),
                text: formatterText('alert.message.associations.general'),
                confirmButtonText: formatterText('alert.button.continue'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.services),
              }),
            );
          }
        })
        .catch((err) => {
          handleRequestError(err);
        });
    } else {
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general'),
          text: formatterText('alert.message.confirm.created.general'),
          confirmButtonText: formatterText('alert.button.continue'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.services),
        }),
      );
    }
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const [cat, setCat] = useState([]);
  const [productCategory, setProductCategory] = useState([]);

  // Add a product in the dynamic minimal table
  const handleAddItemMinimal = () => {
    if (!!currentItemMinimal.nombre && !!currentItemMinimal.codigo) {
      let filter = currentDataTable.filter(
        (item) =>
          item.codigo.toString().toLowerCase() ===
          currentItemMinimal.codigo.toString().toLowerCase(),
      );

      if (filter.length > 0) {
        HandleOnError(formatterText('p.label.title.codigoExistenteElemento'));
      } else {
        const categorias = currentItemMinimal.categorias.map((cat) => ({
          label: cat.label.toString(),
          value: cat.value.toString(),
        }));

        const categoriasArray = categorias.map(
          ({ label, value }) => `${label} - ${value.toString()}`,
        );
        const categoriasString = categoriasArray.join(', ');

        const newItems = [
          {
            idTipoServicio: currentItemMinimal.idTipoServicio,
            nombre: currentItemMinimal.nombre,
            codigo: currentItemMinimal.codigo,
            categorias: [categoriasString],
            estado: currentItemMinimal.estado,
            descripcion: currentItemMinimal.descripcion,
          },
        ];

        setDataTable((prevData) => [...prevData, ...newItems]);
        setCat([categorias]);
        setProductCategory((prevData) => [...prevData, categorias]);
        setCurrentDataTable((prevData) => [...prevData, ...newItems]);
        setCurrentItemMinimal({
          idTipoServicio: uuidv4(),
          nombre: '',
          codigo: '',
          categorias: [],
          estado: 1,
          descripcion: '',
        });
        setSelectValues([]);
      }
    } else {
      HandleOnError('Debes completar todos los campos');
    }
  };

  const handleChangeSubCategory = (e) => {
    switch (e.target.name) {
      case 'codigo':
        HandleInput(e, CODEREGEX, currentItemMinimal, setCurrentItemMinimal, false);
        break;
      case 'descripcion':
        HandlerTextDescription(e, currentItemMinimal, setCurrentItemMinimal);
        break;
      default:
        HandleInput(e, TEXTREGEX, currentItemMinimal, setCurrentItemMinimal, true);
        break;
    }
  };

  const handleSelectChange = (e) => {
    setSelectValues(e);
    setCurrentItemMinimal({
      ...currentItemMinimal,
      categorias: e,
    });
  };

  // State of the labels and ids of the selectors
  const [selectValues, setSelectValues] = useState([]);

  const [productCategories, setProductCategories] = useState([]);

  const getProductCategories = () => {
    axios(endpoints.productCategory.getAllProductCategory).then((response) => {
      setProductCategories(
        FilterActive(response.data).map((obj) => ({
          label: obj.nombre,
          value: obj.idCategoriaProducto,
        })),
      );
    });
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          <p className="wrap-form-title">
            {formatterText('table.title.category.service', 'Categoría de servicio')}
          </p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                {formatterText('p.name.service.category', '777Nombre de categoría de servicio')}
              </h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleText}
                placeholder={formatterText(
                  'input.placeholder.service.category',
                  'Nombre de categoría de servicio',
                )}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                {formatterText('table.title.description', 'Descripción')}
              </h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('table.title.description', 'Descripción')}
                maxLength="200"
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.code', 'Código')}</h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handlerTextCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
                required
              />
            </section>
          </section>
          {currentDataTable.length > 0 && (
            <>
              <p className="wrap-form-title">
                {formatterText('p.service.type.associates', 'Tipos de servicio asociados')}
              </p>
              <section className="form-responsive-container-information">
                <Table
                  titles={titlesTableSubCategories}
                  data={currentDataTable}
                  type="typeCategoryService"
                  handleOpen={handleOpen}
                  labelTable={formatterText('p.service.type.associates.footer')}
                  canSearch={true}
                />
              </section>
            </>
          )}
          <p className="wrap-form-title">
            {formatterText('table.title.service.type', '+ Agregar tipo de servicio')}
          </p>
          <section
            className="grid-container-2c"
            style={{
              width: '87%',
              margin: '0 auto',
            }}
          >
            <label className="d-flex">
              <h3 className="text-inline">
                {formatterText('p.name.type.service', 'Nombre tipo de servicio')}
              </h3>
              <section className="w100-container">
                <input
                  className="input-default-3c"
                  type="text"
                  name="nombre"
                  value={currentItemMinimal.nombre}
                  onChange={handleChangeSubCategory}
                  placeholder={formatterText('p.name.type.service', 'Nombre tipo de servicio')}
                  maxLength="55"
                />
              </section>
            </label>
            <label className="d-flex">
              <h3 className="text-inline">{formatterText('table.title.code', 'Código')}</h3>
              <section className="w100-container">
                <input
                  className="input-default-3c"
                  type="text"
                  name="codigo"
                  value={currentItemMinimal.codigo}
                  onChange={handleChangeSubCategory}
                  placeholder={formatterText(
                    'input.placeholder.enter.up.characters',
                    'Ingresa hasta 45 caracteres',
                  )}
                  maxLength="45"
                />
              </section>
            </label>
          </section>
          <section className="wrapForm">
            <label className="wrapForm__label">
              <h3 className="p-styles">
                {formatterText('table.title.description', 'Descripción')}
              </h3>
              <textarea
                className="input-primary-textarea width-80"
                type="text"
                name="descripcion"
                value={currentItemMinimal.descripcion}
                onChange={handleChangeSubCategory}
                placeholder={formatterText('p.description.subcategory', 'Subcategory description')}
                maxLength="200"
              />
            </label>

            <label className="wrapForm__label">
              <h3 className="text-inline">
                {formatterText('p.product.category', 'Categoria de productos')}
              </h3>
              <section className="w100-container">
                <Select
                  name="categoryType"
                  id="categoryType"
                  isMulti
                  styles={defaultSelect}
                  options={productCategories}
                  value={selectValues}
                  onChange={handleSelectChange}
                  noOptionsMessage={() => {
                    <FormattedMessage
                      id="select.placeholder.no.options"
                      defaultMessage="No se encontraron opciones"
                    />;
                  }}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                />
              </section>
            </label>
          </section>
          <input
            onClick={handleAddItemMinimal}
            type="button"
            className="btn-primary btn-primary-center"
            value={formatterText('btn.assign.service.type', 'Asignar tipo de servicio')}
          />
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            {formatterText('btn.create.service.category', 'Crear categoría de servicio')}
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.services)}>
            {formatterText('btn.cancel', 'Cancelar')}
          </button>
        </section>
      </form>
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >     
        <UpdateModalItem productCategories={productCategories} onClose={handleClose} cat={cat} />

      </Modal>
    </>
  );
}
