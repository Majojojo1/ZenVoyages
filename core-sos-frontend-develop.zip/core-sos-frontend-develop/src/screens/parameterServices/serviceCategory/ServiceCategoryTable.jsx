import React, { useEffect } from 'react';
// Import Context
import { useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import SortData from 'components/utils/SortData';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import useLang from 'hooks/useLang';
import useLangv2 from 'hooks/useLangv2';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';


const ServiceCategoryTable = ({ permisos }) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setSearchResults, setDataTable } = useSeachContext();
  //  Call hook of language
  const { formatterText } = useLang();
  const { handleRequestError } = useLangv2();

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    getAll(endpoints.serviceCategory.getAllServiceCategory)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        const sortedArray = SortData(newArray, 'asc');
        setSearchResults(sortedArray);
        setDataTable(sortedArray);      

      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.serviceCategory.deleteServiceCategory, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          const sortedArray = SortData(newArray, 'asc');
          setSearchResults(sortedArray);
          setDataTable(sortedArray);
          getDataTable();

          resolve(true);
        })
        .catch((err) => {
          handleRequestError(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.serviceCategory.updateServiceCategory, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idCategoriaServicio,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const titles = [
    formatterText('table.name.CategoryService', 'Nombre Categoría de servicio'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading ? (
       
          <FormattedMessage
            id="table.name.search.productCategory"
            defaultMessage="Categoría de producto"
          >
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Categorías}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateCategoryService}
                canDeleted={permisos.eliminar}
                canModify={permisos.editar}
              />
            )}
          </FormattedMessage>
        
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ServiceCategoryTable;
