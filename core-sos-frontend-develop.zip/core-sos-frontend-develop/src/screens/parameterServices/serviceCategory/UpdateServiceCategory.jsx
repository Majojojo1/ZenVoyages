import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useLang from 'hooks/useLang';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Table from 'common/minimalTables/TableMinimal';
import HandlerText from 'common/validators/HandlerText';
import CustomAlert from 'components/CustomAlert';
import UpdateModalItem from './UpdateModalItem';


// Import libs
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import model
import CategoryService from 'models/CategoryService';
// Import de services
import axios from 'axios';
import SelectorMulti from 'common/selects/SelectorMultiCreate';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { CODEREGEX, TEXTREGEXMIN, SPACING } from 'common/validators/Regex';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import useAxios from 'hooks/useAxios';
import endpoints from 'services/api';
import { addItem, getAll, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';
const style = {
  position: 'absolute',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  height: 100,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

export default function UpdateServiceCategory() {
  return (
    <SearchWrapper>
      <UpdateServiceCategoryComponent />
    </SearchWrapper>
  );
}
function UpdateServiceCategoryComponent() {
  // Modal config
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  // Manage axios requests
  const { COOKIE_USER } = useAxios();

  const { dataTable, setDataTable } = useSeachContext();

  // Hooks to get the params
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  // toggle state
  const [active, setActive] = useState(true);
  const [categories, setCategories] = useState([]);
  const [product, setProduct] = useState({
    idTipoCategoria: '',
    nombre: '',
    codigo: '',
    categorias: [],
    estado: 1,
    descripcion: '',
    idCategoriaServicio: '',
    idTipoServicio: '',
  });

  // Call context TableMinimalContext
  const { currentDataTable, setResultsTableSearch, setCurrentDataTable } =
    useContext(TableMinimalContext);

  //  Call hook of language
  const { formatterText } = useLang();
  const { newItemCreated, resourceNotFound, handleRequestError } = useLangv2();

  const titlesTableSubCategories = [
    formatterText('p.name.type.service', 'Nombre tipo de servicio'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.categoryProduct', 'Categorías de productos'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new CategoryService());
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idTipoServicio: uuidv4(),
    nombre: '',
    codigo: '',
    categorias: [],
    estado: 1,
    descripcion: '',
  });

  // Set contextMinimalTable empty
  useEffect(() => {
    // Fill the data to update in the fields
    const id = getDataToUpdate();
    getProductCategories();
    getCategories();

  }, []);

  useEffect(() => {
    getCategoryById(id);
  }, [id]);

  useEffect(() => {
    getDataFromMinimalTable(id);
  }, [id]);

  const getDataToUpdate = () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    if (dataUpdate) {
      setFormData(dataUpdate);
      setActive(dataUpdate.estado);
      return dataUpdate.idCategoriaServicio;
    } else {
      navigate(paths.services);
    }
  };

  const getCategoryById = (id) => {
    getItemById(endpoints.serviceCategory.getCategoryServiceById, id)
      .then((res) => {
        if (res === null) {
          setFormData({
            nombre: '',
            descripcion: '',
            codigo: '',

          });
          resourceNotFound();

        } else {
          setFormData(res);
          setActive(res.estado);
        }

      }).catch((err) => {
        console.error(err);
      });
  };

  const getDataFromMinimalTable = (id) => {
    getItemById(endpoints.typeService.newGetTypeServiceByCategory, id)
      .then((res) => {
        let newArray = [];
        if (res.tipoServicio !== null) {
          res?.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          setDataTable(newArray);
          setCurrentDataTable(newArray);
          setResultsTableSearch(newArray);
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const handleStructureItems = (newArray, item) => {
    const categorias = item?.categoriaProducto?.map((categoria) => categoria?.nombre);

    if (categorias && categorias.length > 0) {
      const categoriasString = categorias.join(', ');

      newArray.push({
        idTipoServicio: item.tipoServicio.idTipoServicio || null,
        nombre: item.tipoServicio.nombre,
        descripcion: item.tipoServicio.descripcion,
        codigo: item.tipoServicio.codigo,
        estado: parseInt(item.tipoServicio.estado),
        categorias: [categoriasString],
        objeto: {
          nombre: item.tipoServicio.nombre,
          descripcion: item.tipoServicio.descripcion,
          codigo: item.tipoServicio.codigo,
          estado: item.tipoServicio.estado,
          categorias: [categoriasString],
        },
      });
    }
  };

  const getCategories = () => {
    getAll(endpoints.productCategoryService.getAll).then((resp) => {
      let cat = resp.map((elem) => ({
        label: elem.idCategoriaProductoTipoServicio,
        value: {
          idCatProd: elem.idCategoriaProducto,
          idServ: elem.idTipoServicio,
        },
      }));
      setCategories(cat);
    });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    let data = {
      ...formData,
      estado: active ? 1 : 0,
      usuarioModificacion: Cookie.get('idUsuario'),
    };
    putItem(data);
  };

  // Call the service POST
  const putItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.update.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateItem(endpoints.serviceCategory.updateServiceCategory, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general'),
                  text: formatterText('alert.message.confirm.updated.general'),
                  confirmButtonText: formatterText('alert.button.continue'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.services),
                }),
              );
            })
            .catch((err) => {
              if (err.response.status === 500 || err.response.status === 400) {
                reject(HandleOnError(formatterText('alert.message.code.error.general')));
              } else {
                reject(HandleOnError(formatterText('alert.message.failed.general')));
              }
              console.error(err);
            });
        });
      },
    });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };


  // Add a product in the dynamic minimal table
  const handleAddItemMinimal = async () => {   
    if (!!currentItemMinimal.nombre && !!currentItemMinimal.codigo && !!product.categorias.length) {
      let filter = currentDataTable.filter(
        (item) =>
          item.codigo.toString().toLowerCase() ===
          currentItemMinimal.codigo.toString().toLowerCase(),
      );

      if (filter.length > 0) {
        HandleOnError(formatterText('p.label.title.codigoExistenteElemento'));
      } else {
        const categorias = currentItemMinimal.categorias.map((cat) => ({
          label: cat.label.toString(),
          value: cat.value.toString(),
        }));

        const newItems = categorias.map(({ label }) => ({
          idTipoServicio: currentItemMinimal.idTipoServicio,
          nombre: currentItemMinimal.nombre,
          codigo: currentItemMinimal.codigo,
          categorias: [label],
          estado: currentItemMinimal.estado,
          descripcion: currentItemMinimal.descripcion,
        }));

        try {
          const body = {
            nombre: currentItemMinimal.nombre,
            idCategoriaServicio: {
              idCategoriaServicio: parseInt(id),
            },
            descripcion: currentItemMinimal.descripcion,
            codigo: currentItemMinimal.codigo,
          };
          let tipoServRes = 0;
          await addItem(endpoints.typeService.addTypeService, body)
          .then(
            (res) => {              
            tipoServRes = res.idTipoServicio
            newItemCreated();
            
          }).catch((err) => {
            handleRequestError(err);            
            return;
          });
          const promises = currentItemMinimal.categorias.map((item) => {
            const body2 = [
              {
                idCategoriaProductoTipoServicio: null,
                idCategoriaProducto: item.value,
                idTipoServicio: tipoServRes,
                usuarioCreacion: COOKIE_USER,
              },
            ];
            const promise = addItem(endpoints.productCategoryService.saveMultiple, body2)
              .catch(
                (error) => {
                  throw error;
                },
              );
            return promise;
          });

          const results = await Promise.all(promises);
          const errors = results.filter((result) => result.error !== '200');
          if (errors) {
            console.error(errors);
          }
          getDataFromMinimalTable(id);
          setCurrentItemMinimal({
            nombre: '',
            codigo: '',
            categorias: [],
            descripcion: '',
            estado: 1,
            idTipoServicio: uuidv4(),
          });
          setSelectValues([]);          
        } catch (error) {
          handleRequestError(error);          
        }
      }
    } else {
      HandleOnError('Debes completar todos los campos');
    }
  };
  // handle to subCategoryProduct
  const handleChangeSubCategory = (e) => {
    HandleInput(e, SPACING, currentItemMinimal, setCurrentItemMinimal);
  };

  const handlerTextDescriptionSubcategory = (e) => {
    HandlerTextDescription(e, currentItemMinimal, setCurrentItemMinimal);
  };

  const handleChangeSubCategoryCode = (e) => {
    HandleInput(e, CODEREGEX, currentItemMinimal, setCurrentItemMinimal);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handleSelectChange = (e) => {
    setSelectValues(e);
    setProduct((prevItem) => ({
      ...prevItem,
      categorias: e,
    }));

    setCurrentItemMinimal({
      ...currentItemMinimal,
      categorias: e,
    });
  };
  // State of the labels and ids of the selectors
  const [selectValues, setSelectValues] = useState([]);

  const [productCategories, setProductCategories] = useState([]);

  const getProductCategories = () => {
    axios(endpoints.productCategory.getAllProductCategory).then((response) => {
      setProductCategories(
        response.data
          .filter((item) => item.estado === 1)
          .map((obj) => ({
            label: obj.nombre,
            value: obj.idCategoriaProducto,
          })),
      );
      setLoading(false);
    });
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          <p className="wrap-form-title">
            {formatterText('table.title.category.service', 'Categoría de servicio')}
          </p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                {formatterText('p.name.service.category', 'Nombre de categoría de servicio')}
              </h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleChangeSubCategoryCode}
                placeholder={formatterText(
                  'input.placeholder.service.category',
                  'Nombre de categoría de servicio',
                )}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                {formatterText('table.title.description', 'Descripción')}
              </h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder="Descripción"
                maxLength="200"
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.code', 'Código')}</h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handlerTextCode}
                placeholder="Ingresa hasta 45 caracteres"
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.state', 'Estado')}</h3>
              <label className="form-responsive-label">
                <p className="form-responsive-toggle">
                  {active
                    ? formatterText('p.active', 'Activo')
                    : formatterText('p.unActive', 'No activo')}
                </p>
                <label className="switch">
                  <input
                    checked={active}
                    onChange={() => {
                      setActive(!active);
                    }}
                    type="checkbox"
                  />
                  <span className="slider round"></span>
                </label>
              </label>
            </section>
          </section>
          {dataTable.length > 0 && (
            <>
              <p className="wrap-form-title">
                {formatterText('p.service.type.associates', 'Tipos de servicio asociados')}
              </p>
              <section className="form-responsive-container-information">
                <Table
                  titles={titlesTableSubCategories}
                  data={dataTable}
                  type="typeCategoryService"
                  handleOpen={handleOpen}
                  labelTable={formatterText('p.service.type.associates.footer')}
                  canSearch={true}
                  isEdit={true}
                  categories={categories}
                  getDataMiniTable={getDataFromMinimalTable}
                />
              </section>
            </>
          )}
          <p className="wrap-form-title">
            {formatterText('table.title.service.type', '+ Agregar tipo de servicio')}
          </p>
          <section className="wrapForm">
            <label className="wrapForm__label">
              <h3 className="p-styles">
                {formatterText('p.name.type.service', 'Nombre tipo de servicio')}
              </h3>
              <input
                className="input-primary width-60"
                type="text"
                name="nombre"
                value={currentItemMinimal.nombre}
                onChange={handleChangeSubCategory}
                placeholder={formatterText('p.name.type.service', 'Nombre tipo de servicio')}
                maxLength="55"
              />
            </label>
            <label className="wrapForm__label">
              <h3 className="p-styles">{formatterText('table.title.code', 'Código')}</h3>
              <input
                className="input-primary width-50"
                type="text"
                name="codigo"
                value={currentItemMinimal.codigo}
                onChange={handleChangeSubCategoryCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
              />
            </label>
            <label className="wrapForm__label">
              <h3 className="p-styles">
                {formatterText('table.title.description', 'Descripción')}
              </h3>
              <textarea
                className="input-primary-textarea width-80"
                type="text"
                name="descripcion"
                value={currentItemMinimal.descripcion}
                onChange={handlerTextDescriptionSubcategory}
                placeholder={formatterText('p.description.subcategory', 'Subcategory description')}
                maxLength="200"
              />
            </label>
            <label className="wrapForm__label">
              <h3 className="p-styles">
                {formatterText('p.product.category', 'Categoria de productos')}
              </h3>
              <SelectorMulti
                name="categoryType"
                id="categoryType"
                data={productCategories}
                dataValue={selectValues}
                setterFunction={handleSelectChange}
              />
            </label>
          </section>
          <input
            onClick={handleAddItemMinimal}
            type="button"
            className="btn-primary btn-primary-center"
            value={formatterText('btn.assign.service.type', 'Asignar tipo de servicio')}
          />
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            {formatterText('btn.save.changes', 'Guardar cambios')}
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.services)}>
            {formatterText('btn.cancel', 'Cancelar')}
          </button>
        </section>
      </form>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="parent-modal-title"
        aria-describedby="parent-modal-description"
      >
        <Box sx={{ ...style, width: '90%', height: '80%' }}>
          <UpdateModalItem
            productCategories={productCategories}
            onClose={handleClose}
            loadingCategories={loading}
            setLoadingCategories={setLoading}
            selectValues={selectValues}
            setSelectValues={setSelectValues}
            getDataFromMinimalTable={getDataFromMinimalTable}
            id={id}
          />
        </Box>
      </Modal>
    </>
  );
}
