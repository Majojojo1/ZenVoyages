import React, { useContext, useEffect, useState } from "react";
// Import Context
import { TableMinimalContext } from "context/TableMinimalContext";
// Import Hooks
import useLang from "hooks/useLang";
import useLangv2 from "hooks/useLangv2";
// Import Components
import CustomAlert from "components/CustomAlert";
// Import libs
import Cookie from "js-cookie";
// Import services
import SelectorMulti from "common/selects/SelectorMultiCreate";
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { TEXTREGEXMIN, TEXTREGEX } from "common/validators/Regex";
import { useSeachContext } from "context/SearchContext";
import endpoints from "services/api";
import { getItemById, updateItem } from "services/api/methods";

export default function UpdateModalItem({
  onClose,
  productCategories,
  selectValues,
  setSelectValues,
  loadingCategories,
  getDataFromMinimalTable,
  id,
  cat
}) {
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idTipoCategoria: "",
    nombre: "",
    codigo: "",
    categorias: [],
    estado: 1,
    descripcion: "",
    idCategoriaServicio: "",
    idTipoServicio: "",
  });

  const [loading, setLoading] = useState(true);
  // useLanguage
  const { formatterText } = useLang();
  const { noFilledContent, updatedItem } = useLangv2();
  const [products, setProducts] = useState([]);

  const {
    modalData,
    setModalData,
    currentDataTable,
    setCurrentDataTable,
    setResultsTableSearch,
  } = useContext(TableMinimalContext);

  const { dataTable, setDataTable } = useSeachContext();

  //  create useEffect clean function
  useEffect(() => {
    setCurrentItemMinimal(modalData);
    dataProductCategories(id);
  }, []);

  useEffect(() => {
    if (!loadingCategories && productCategories.length > 0) {
      setLoading(false);
    }
  }, [loadingCategories, productCategories]);

  const handleChangeInput = (e) => {
    HandleInput(e, TEXTREGEX, currentItemMinimal, setCurrentItemMinimal);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, currentItemMinimal, setCurrentItemMinimal);
  };

  const handleChangeInputCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, currentItemMinimal, setCurrentItemMinimal);
  };

  const handleUpdateMinimalModal = (e) => {
    e.preventDefault();
    if (modalData.nombre !== ""
      && modalData.codigo !== "") {
      if (typeof currentItemMinimal.idTipoServicio === "number") {
        let data = {
          idCategoriaServicio: parseInt(id),
          idTipoServicio: currentItemMinimal.idTipoServicio,
          idUsuario: parseInt(Cookie.get("idUsuario")),
          nombre: currentItemMinimal.nombre,
          descripcion: currentItemMinimal.descripcion,
          codigo: currentItemMinimal.codigo,
          idCategoriaProducto: products.map(
            (item) => item.value,
          ),
        };
        updateItem(endpoints.typeService.updateTypeServiceProductCategory, data)
          .then(() => {
            onClose();
            CustomAlert("confirm_msg", {
              icon: "success",
              title: formatterText("alert.title.confirm.general"),
              text: formatterText("alert.message.confirm.updated.general"),
              confirmButtonText: formatterText("alert.button.continue"),
              allowOutsideClick: false,
              executeFunction: () => updateTable(),
            });
            updatedItem();
          })
          .catch((err) => {
            HandleOnError(
              "No se pudo actualizar el elemento porque el codigo ya existe",
            );
            console.error(err);
            onClose();
          });
      } else {
        updateStructure();
      }
    } else {
      noFilledContent();
    }
  };

  // Update the structure of the table after search the item to update
  const updateStructure = () => {

    // Filter if the current modal data have the same id
    let filterId = currentDataTable.filter(
      (item) => item.idTipoServicio !== modalData.idTipoServicio
    );
    // Filter if the current modal data have the same code
    let filterCode = currentDataTable.filter(
      (item) =>
        item.codigo === modalData.codigo &&
        item.idTipoServicio !== modalData.idTipoServicio,
    );

    if (filterCode.length > 0) {
      onClose();
      HandleOnError(
        formatterText('p.label.title.codigoExistenteElemento'),
      );
    } else {

      const categorias = products.map((cat) => ({
        label: cat.label.toString(),
        value: cat.value.toString(),
      }));

      let categoriasArray = [];

      if (id) {
        categoriasArray = categorias.map(({ label }) => label);

      } else {
        categoriasArray = categorias.map(
          ({ label, value }) => `${label} - ${value.toString()}`,
        );

      };
      const categoriasString = categoriasArray.join(', ');

      let data = {
        idTipoServicio: currentItemMinimal.idTipoServicio,
        nombre: currentItemMinimal.nombre,
        descripcion: currentItemMinimal.descripcion,
        codigo: currentItemMinimal.codigo,
        estado: 1,
        categorias: [categoriasString],
      };

      setDataTable([...filterId, data]);
      setModalData(dataTable);
      setResultsTableSearch([...filterId, data]);
      onClose();
    }
  };

  const updateTable = () => {
    currentDataTable.forEach((item) => {
      if (item.idTipoServicio === modalData.idTipoServicio) {
        let dataLeft = currentDataTable.filter((item) => {
          return item.idTipoServicio !== modalData.idTipoServicio;
        });

        dataLeft = dataLeft.map((item) => {
          if (item.idTipoServicio === currentItemMinimal.idTipoServicio) {
            return {
              ...item,
              categorias: currentDataTable.categorias
            };
          }
          return item;
        });

        setCurrentDataTable(dataLeft);
        setResultsTableSearch(dataLeft);
        setCurrentItemMinimal({
          categorias: [],
        });
      }
      getDataFromMinimalTable(id);
      onClose();
      setCurrentItemMinimal({
        categorias: [],
      });
    });
  };

  const dataProductCategories = (id) => {
    if (id) {
      getItemById(endpoints.typeService.newGetTypeServiceByCategory, id)
        .then((res) => {
          if (res.tipoServicio !== null) {
            res?.forEach((item) => {
              const categorias = item?.categoriaProducto?.map((categoria) => ({
                label: categoria?.nombre,
                value: categoria?.idCategoriaProducto, 
              }));         
              setProducts(categorias);
            });
          }
        })
        .catch((err) => {
          console.error(err);
        });
    } else {
      const categories = modalData.categorias;
      const categoryArray = categories[0].split(',').map((category) => {
        const [label, value] = category.trim().split(' - ');
        return { value: value.trim(), label: label.trim() };
      });
      setProducts(categoryArray);

    }
  };

  return (
    <form className="form-responsive" onSubmit={handleUpdateMinimalModal}>
      <section className="form-responsive-container-information">
        <label className="form-responsive-information__option">
          <h3>Nombre tipo de servicio</h3>
          <input
            className="input-primary width-50"
            type="text"
            name="nombre"
            value={currentItemMinimal.nombre}
            onChange={handleChangeInput}
            placeholder="Nombre tipo de servicio"
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>Código</h3>
          <input
            className="input-primary width-50"
            type="text"
            name="codigo"
            value={currentItemMinimal.codigo}
            onChange={handleChangeInputCode}
            placeholder="Ingresa hasta 45 caracteres"
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>Descripción</h3>
          <textarea
            className="input-primary-textarea width-50"
            type="text"
            name="descripcion"
            value={currentItemMinimal.descripcion}
            onChange={handlerTextDescription}
            placeholder="Descripción del tipo de servicio"
            maxLength="200"
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>Categoria de productos</h3>
          <SelectorMulti
            name="categoryType"
            id="categoryType"
            data={productCategories}
            isLoading={loading}
            dataValue={products}
            setterFunction={setProducts}
          />
        </label>
        <input
          type="submit"
          className="width-100-fix"
          value="Actualizar tipo de servicio"
        />
        <input
          type="button"
          className="width-100-fix input-cancel"
          value="Cancelar"
          onClick={onClose}
        />
      </section>
    </form>
  );
}
