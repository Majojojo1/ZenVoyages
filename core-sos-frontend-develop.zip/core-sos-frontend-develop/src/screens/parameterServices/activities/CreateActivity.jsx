import React, { useContext, useEffect, useState } from 'react';
// Import Context
import DynamicTable from 'common/DynamicTable/DynamicHead';
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import { useNavigate } from 'react-router-dom';
// Import Components
import { Formiz, FormizStep, useForm } from '@formiz/core';
import { isMaxLength } from '@formiz/validations';
import Search from 'common/Search';
import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import Table from 'common/minimalTables/Table';
import Selector from 'common/selects/Selector';
import SelectorGrid from 'common/selects/SelectorGrid';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import CustomAlert from 'components/CustomAlert';
import Select from 'react-select';
// Import Libs
import SortData from 'components/utils/SortData';
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import Services
import endpoints from 'services/api';
import { addItem, deleteItem, getAll, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';
import customStyles2 from './generic.style.select';

import HandlerNumbers from 'common/validators/HandlerNumbers';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { isUndefined } from 'lodash';


export default function CreateActivity() {
  return (
    <SearchWrapper>
      <CreateActivityComponent />
    </SearchWrapper>
  );
}

function CreateActivityComponent() {
  const {
    toggleError,
    error,
    handleClick,
    searchResultsSorted = [],
    search = '',
    setSearchResults,
    searchResults = [],
    setDataTable,
    dataTable,
    table = [],
    setTable,
    resultsFound,
    displayMessage,
    setResultFound,
    setActivitiesResults,
    // getAllFormsClientsByTypeServicesActivity,
    activitiesResults = [],
  } = useSeachContext();
  // Formiz object
  const myForm = useForm();

  // show or hide the section
  const [show, setShow] = useState(true);
  // toggle state
  const [active, setActive] = useState(true);

  const [actionToggle, setActionToggle] = useState(false);

  // Form information
  const [currentDataForm, setCurrentDataForm] = useState(null);

  // Call context TableMinimalContext
  const {
    currentDataTable,
    setCurrentDataTable,
    resultsTableSearch = [],
    setResultsTableSearch,
  } = useContext(TableMinimalContext);
  const navigate = useNavigate();
  // useLanguage
  const { formatterText, noFilledContent } = useLangv2();
  // Current data table
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    tiempoActividad: '',
    descripcion: '',
    idActividad: {
      value: 0,
    },
    idEtapaServicio: {
      value: 0,
    },
    actividadTecnica: {
      value: 0,
    },
  });
  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      categoriasServicios: [],
      tipoServicio: [],
      actividadesServicios: [],
      etapaServicios: [],
      typeServicesActivity: [],
      formsAssociate: [],
      clientsAssociate: [],
    },
  ]);

  // Table 1 tab
  const titlesTableActivites = [
    formatterText('label.text.nameActivity', 'Nombre de la actividad'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.sku', 'SKU'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  // Table 2 tab
  const titlesTableCostProduct = [
    formatterText('column.name.related.activity'),
    formatterText('column.name.service.type'),
    formatterText('column.name.service.stage'),
    formatterText('column.name.manage.by.technician'),
    formatterText('column.name.activity.time'),
    formatterText('column.name.description'),
    formatterText('column.name.actions')
  ];

  // Table 3 tab
  const titlesTableTypeServiceActivity = [
    formatterText('column.name.form.name'),
    formatterText('column.name.form.description'),
    formatterText('column.name.form.code'),
    formatterText('column.name.form.client.associated'),
    formatterText('column.name.form.client.identification'),
    formatterText('column.name.actions'),
  ];

  // Helps to loading select data
  const { loading, toggleLoading } = useGetData();
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // Helps to load Select data
  const [auxData, setAuxData] = useState({
    idTipoServicioActividad: uuidv4(),
    idCategoriaServicio: 0,
    idTipoServicio: 0,
    idActividad: 0,
    idEtapaServicio: 0,
    actividadTecnica: 0,
    idTypeServiceActivity: 0,
    idFormulario: 0,
    idCliente: 0,
  });

  // función para cargar datos de la tabla de formularios
  const getAllFormsClientsByTypeServicesActivity = async (idActividad, idCliente) => {
    setLoadingProgress(true);

    try {
      let url = '';
      if (
        (isUndefined(idActividad) && isUndefined(idCliente)) ||
        (idActividad === 0 && idCliente === 0)
      ) {
        url = `${endpoints.activityformClient.getFormClientByActivity(-1, -1)}`;
      } else {
        url = `${endpoints.activityformClient.getFormClientByActivity(
          idActividad || 0,
          idCliente || 0,
        )}`;
      }
      const response = await getAll(url);

      let data = response.map((element) => ({
        id: element.formularioClientePojo.idActividadFormularioCliente,
        name: element.formularioClientePojo.nombreFormulario,
        description: element.formularioClientePojo.descripcionFormulario,
        code: element.formularioClientePojo.codigoFormulario,
        client: element.formularioClientePojo.nombreRazonSocialCliente,
        clienteId: element.formularioClientePojo.identificacionCliente,
      }));

      setActivitiesResults(data);
      setLoadingProgress(false);
      return data;
    } catch (error) {
      setLoadingProgress(false);
      return [];
    }
  };

  // función para cargar datos de la tabla de actividades
  const getDataTable = () => {


    getAll(endpoints.activitiesServices.getAllActivitiesServicesBasic)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        const sortedArray = SortData(newArray, 'asc');
        setSearchResults(sortedArray);
        setDataTable(newArray);

      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idActividad,
      nombre: item.nombre,
      descripcion: item.descripcion,
      sku1: item.sku,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  // Call services to fill in the selects
  useEffect(() => {
    // Tab 1
    getAllCategoriesServices();
    getAllActivitiesServices();
    getAllStageServices();
    // Tab 2
    getAllTypeServicesActivity();
    getAllFormsWithActiveState();
    getAllClientsToAssociate();
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  const allGets = () => {
    // Tab 1
    getAllCategoriesServices();
    getAllActivitiesServices();
    getAllStageServices();
    // Tab 2
    getAllTypeServicesActivity();
    getAllFormsWithActiveState();
    getAllClientsToAssociate();
    getAllActivitiesTypeServicesById();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  };

  // Get all type Services Activity by id
  useEffect(() => {
    const updatedResultsTableSearch = getAllFormsClientsByTypeServicesActivity(
      auxData.idTypeServiceActivity.value,
      auxData.idCliente.value,
    );
    setResultsTableSearch(updatedResultsTableSearch);
  }, [auxData.idTypeServiceActivity, auxData.idCliente]);

  // // Get the type of service by id category service
  useEffect(() => {
    if (auxData.idTipoServicio !== 0) {
      getAllActivitiesTypeServicesById();
    }
    // this only is call when the id Type Service change
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auxData.idTipoServicio]);

  useEffect(() => {
    if (auxData.idCategoriaServicio !== 0) {
      // this only is call when the id Category Service change, and render the element in the selector
      getAllTypeServicesById(auxData.idCategoriaServicio);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auxData.idCategoriaServicio]);

  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteItem(endpoints.activitiesServices.deleteActivitiesBasic, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateItem(endpoints.activitiesServices.updateActivitiesService, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  // Get the data of all category services to the selector
  const getAllCategoriesServices = () => {
    toggleLoading(true);

    getAll(endpoints.serviceCategory.getAllServiceCategory)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCategoriaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          categoriasServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  // Get the data of all type category Activity to the selector
  const getAllTypeServicesActivity = () => {
    toggleLoading(true);

    getAll(endpoints.typoServiceActivities.getAllTypoServiceActivities)
      .then((res) => {
        // create new array
        const newArray = [
          {
            value: 0,
            label: 'Ninguno',
          },
        ];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: item.idTipoServicioActividad,
            label: `${item.idTipoServicio.nombre} - ${item.idActividad.nombre} - ${item.idEtapaServicio.nombre}`,
            isFixed: true,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          typeServicesActivity: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all forms with only active state to the selector
  const getAllFormsWithActiveState = () => {
    getAll(endpoints.activityformClient.getAllFormWithTrueState)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: item.idFormulario,
            label: `${item.nombre} - ${item.codigo}`,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          formsAssociate: newArray,
        }));
        setTable(newArray);
        setResultFound(newArray);
      })

      .catch((err) => {
        console.log(err);
      });
  };

  // Get the data of all clients to the selector
  const getAllClientsToAssociate = () => {
    getAll(endpoints.clients.getAllClients)
      .then((res) => {
        // create new array
        const newArray = [
          {
            value: 0,
            label: 'Ninguno',
          },
        ];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCliente,
              label: `${item.nombreRazonSocial} - ${item.identificacion}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          clientsAssociate: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the data of all Activities services to the selector
  const getAllActivitiesServices = () => {
    // loading select
    toggleLoading(true);

    getAll(endpoints.activitiesServices.getAllActivitiesServicesBasic)
      .then((res) => {
        // create new array
        const newArray = [];
        const aux = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idActividad,
              label: `${item.nombre} - ${item.sku}`,
              isFixed: true,
            });
            aux.push({
              id: item.idActividad,
              name: item.nombre,
              sku: item.sku,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          actividadesServicios: newArray,
        }));
        setCurrentDataForm(aux);

        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all Stage services to the selector
  const getAllStageServices = () => {
    toggleLoading(true);

    getAll(endpoints.stageServices.getAllStageServices)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idEtapaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          etapaServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all activities type services when have id type service
  const getAllActivitiesTypeServicesById = () => {
    setLoadingProgress(true);
    getItemById(
      endpoints.typoServiceActivities.getTypeServiceActivitiesByTypeService,
      auxData.idTipoServicio.value,
    )
      .then((res) => {
        // create new array
        const newArray = [];

        res.forEach((item) => {
          newArray.push({
            ...item,
            idTipoServicioActividad: item.idTipoServicioActividad,
            idTipoServicio: {
              idTipoServicio: `${item.idTipoServicio.nombre} - ${item.idTipoServicio.codigo}`,
              id: item.idTipoServicio.idTipoServicio,
            },
            idActividad: {
              idActividad: `${item.idActividad.nombre} - ${item.idActividad.sku}`,
              id: item.idActividad.idActividad,
            },
            idEtapaServicio: {
              idEtapaServicio: `${item.idEtapaServicio.nombre} - ${item.idEtapaServicio.codigo}`,
              id: item.idEtapaServicio.idEtapaServicio,
            },
            actividadTecnica: item.actividadTecnica,
            orden: item.orden,
          });
        });

        // sort the array by the order field
        newArray.sort((a, b) => a.orden - b.orden);
        setCurrentDataTable(newArray);
        setLoadingProgress(false);
      })
      .catch((err) => {
        console.log(err);
        setLoadingProgress(false);
      });
  };

  // Get all type service by id category service
  const getAllTypeServicesById = (selectValue) => {
    // Set the value of datas into []
    setCurrentDataTable([]);
    setCurrentItemMinimal([]);

    getItemById(endpoints.typeService.getTypeServiceByCategory, selectValue.value)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idTipoServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, currentItemMinimal, setCurrentItemMinimal);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    // create a regex to valid the number
    HandlerNumbers(e, currentItemMinimal, setCurrentItemMinimal);

    // if (e.target.value.match(NUMBERREGEX)) {
    setCurrentItemMinimal({
      ...currentItemMinimal,
      idTipoServicio: auxData.idTipoServicio,
      idActividad: auxData.idActividad,
      idEtapaServicio: auxData.idEtapaServicio,
      actividadTecnica: auxData.actividadTecnica,
      [e.target.name]: e.target.value,
    });
    // }
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (values) => {
    if (actionToggle) {
      handleSubmitUpdateActivity(values);
    } else {
      let data = {
        nombre: values.nombre.replaceAll(/\s{2,}/gi, ' '),
        descripcion: values.descripcion ? values.descripcion.replaceAll(/\s{2,}/gi, ' ') : '',
        sku: values.sku.replaceAll(/\s{2,}/gi, ' '),
        iva: '0', //values.iva.replaceAll(/\s{2,}/gi, ' '),
        usuarioCreacion: Cookie.get('idUsuario'),
      };
      createItem(data);
    }
  };

  // Create an activiy
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addItem(endpoints.activitiesServices.addActivitiesService, data)
            .then((_) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    getDataTable();
                    allGets();
                  }, // Deuda tecnica (?), posiblemente toque retirarlo
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError((formatterText(err.response?.data?.message)));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  const clean = () => {
    setCurrentItemMinimal({
      tiempoActividad: '',
      descripcion: '',
      idActividad: {
        value: 0,
      },
      idEtapaServicio: {
        value: 0,
      },
      actividadTecnica: {
        value: 0,
      },
      idTipoServicioActividad: uuidv4(),
    });
    setAuxData((prevAuxData) => ({
      ...prevAuxData,
      idTipoServicioActividad: uuidv4(),
      idActividad: 0,
      idEtapaServicio: 0,
      actividadTecnica: 0,
      idCliente: 0,
    }));
  };
  // Associate an activity to a type service
  const associateTipoServiciosActividades = (item, onClean) => {
    // Define the order
    let order = currentDataTable.length + 1;
    // Structure the body
    let data = {
      idTipoServicioActividad: null,
      idTipoServicio: {
        idTipoServicio: item.idTipoServicio.value,
      },
      idActividad: {
        idActividad: item.idActividad.value,
      },
      idEtapaServicio: {
        idEtapaServicio: item.idEtapaServicio.value,
      },
      orden: order,
      tiempoActividad: item.tiempoActividad,
      actividadTecnica: item.actividadTecnica.value,
      descripcion: item.descripcion,
    };

    // Call the service
    addItem(endpoints.typoServiceActivities.addTypeServiceActivities, data)
      .then((response) => {
        data = {
          ...data,
          idTipoServicio: {
            idTipoServicio: item.idTipoServicio.label,
          },
          idActividad: {
            idActividad: item.idActividad.label,
          },
          idEtapaServicio: {
            idEtapaServicio: item.idEtapaServicio.label,
          },
          idTipoServicioActividad: response.idTipoServicioActividad,
        };
        setShow(false);
        setTimeout(() => {
          setShow(true);
        }, 100);
        setCurrentDataTable([...currentDataTable, data]);
        // Set data
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.created.general',
            'El registro se ha creado correctamente',
          ),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => {
            onClean();

            console.log('Se creo correctamente: ', response.idTipoServicioActividad);
            getAllActivitiesTypeServicesById();
          },
        });
      })
      .catch((err) => {
        if (err.response.status === 412) {
          HandleOnError(err.response.data.message);
        } else {
          HandleOnError(
            formatterText(
              'alert.message.failed.general',
              'Error al crear el registro, po favor intente nuevamente.',
            ),
          );
          clean();
        }
      });
  };

  // Add new association
  const handleAddItemMinimal = () => {
    if (
      currentItemMinimal.tiempoActividad !== undefined &&
      currentItemMinimal.idActividad.value !== undefined &&
      currentItemMinimal.idEtapaServicio.value !== undefined &&
      currentItemMinimal.actividadTecnica.value !== undefined
    ) {
      associateTipoServiciosActividades(currentItemMinimal, clean);
      setCurrentItemMinimal({
        tiempoActividad: '',
        descripcion: '',
        idTipoServicioActividad: uuidv4(),
        idActividad: {
          value: '',
        },
        idEtapaServicio: {
          value: '',
        },
      });
    } else {
      noFilledContent();
    }
  };

  // Create new association in the 3 tab
  const handleAddActivityFormClient = () => {
    console.log('data formulario', auxData);
    const data = {
      idActividadFormularioCliente: null,
      idFormulario: auxData.idFormulario.value,
      idTipoServicioActividad: auxData.idTypeServiceActivity.value,
      idCliente: auxData.idCliente.value,
      usuarioCreacion: parseInt(Cookie.get('idUsuario')),
    };

    addItem(endpoints.activityformClient.addActivityFormClient, data)
      .then((_) => {
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.created.general',
            'El registro se ha creado correctamente',
          ),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => {
            getAllFormsClientsByTypeServicesActivity(
              auxData.idTypeServiceActivity.value,
              auxData.idCliente.value,
            );
            navigate(paths.services);
          },
        });
        setSearchSelected([]);
      })
      .catch((err) => {
        if (err.response.status === 412 || err.response.status === 400) {
          HandleOnError(
            formatterText(
              'alert.message.failed.repeat.value.general',
              'Ya se encuentra un formulario asociado al cliente',
            ),
          );
        } else {
          HandleOnError(formatterText('Error al crear el registro, por favor intente nuevamente.'));
        }
      });
  };

  // Delete an association of the table Activity Form Client
  const handleDelete = (row) => {
    deleteItem(endpoints.activityformClient.deleteActivityFormClient, row.id)
      .then(() => {
        getAllFormsClientsByTypeServicesActivity(
          auxData.idTypeServiceActivity.value,
          auxData.idCliente.value,
        );
      })
      .catch((error) => {
        console.log(error);
      });
    closeDialog();
  };

  // dialog state
  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  // close dialog
  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  // This function is executed when the create button is clicked
  const handleSubmitUpdateActivity = (values) => {
    let data = {
      idActividad: currentDataForm.idActividad,
      nombre: values.nombre,
      descripcion: values.descripcion ? values.descripcion : '',
      sku: values.sku,
      estado: active ? '1' : '0',
      fechaCreacion: currentDataForm.fechaCreacion,
      usuarioCreacion: currentDataForm.usuarioCreacion,
      usuarioModificacion: Cookie.get('idUsuario'),
    };
    putItem(data);
  };

  // Updtae an activity
  const putItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          updateItem(endpoints.activitiesServices.updateActivitiesService, data)
            .then((_) => {
              // aqui se llama el servicio para asociar el producto con el proveedor
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    setActionToggle(!actionToggle);
                    setCurrentDataForm(null);
                    getDataTable();
                    allGets();
                  }, // Deuda tecnica (?), posiblemente toque retirarlo
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError((formatterText(err.response?.data?.message)));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  return (

    <div className="centered-form">
      <Formiz onValidSubmit={handleSubmit} connect={myForm}>
        <form
          noValidate
          onSubmit={myForm.submit}
          className="container-wrapForm"
          style={{ minHeight: '16rem' }}
        >
          <div className="new-container-wrapForm__tabs">
            {myForm.steps.map((step) => (
              <button
                key={step.name}
                className={`new-tab-option ${step.name === myForm?.currentStep?.name ? 'is-active' : ''
                  }`}
                type="button"
                onClick={() => myForm.goToStep(step.name)}
              >
                {step.label}
                {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
              </button>
            ))}
          </div>

          <div className="container-wrapForm-content">
            <FormizStep
              name="step1"
              label={formatterText(
                'text.title.activity.information',
                'Información de la actividad',
              )}
            >
              <section
                className="grid-container-1c zero-gap"
                style={{
                  width: '90%',
                  margin: '0 auto',
                }}
              >
                <InputFieldResponsive
                  type="text"
                  name="nombre"
                  labelText={formatterText('label.text.nameActivity', 'Nombre de la actividad')}
                  placeholder={formatterText('label.text.activity', 'Actividad')}
                  validateInput="text"
                  required={formatterText(
                    'p.nameActivity.is.required',
                    'El nombre de la actividad es requerida',
                  )}
                  defaultValue={currentDataForm ? currentDataForm.nombre : ''}
                  validations={[
                    {
                      rule: isMaxLength(45),
                      message: formatterText(
                        'input.placeholder.max.45.chars',
                        'Ingrese hasta 45 caracteres',
                      ),
                    },
                  ]}
                />
                <InputFieldResponsive
                  type="text"
                  name="descripcion"
                  labelText={formatterText('table.title.description', 'Descripción')}
                  placeholder={formatterText(
                    'input.placeholder.max.200.chars',
                    'Ingrese hasta 200 caracteres',
                  )}
                  validateInput="text"
                  defaultValue={currentDataForm ? currentDataForm.descripcion : ''}
                  validations={[
                    {
                      rule: isMaxLength(200),
                      message: formatterText(
                        'input.placeholder.max.200.chars',
                        'Ingrese hasta 200 caracteres',
                      ),
                    },
                  ]}
                  styleName="input-textarea"
                  asArea={true}
                />
                <InputFieldResponsive
                  type="text"
                  name="sku"
                  labelText="Sku"
                  placeholder="Sku"
                  validateInput="text"
                  required={formatterText('p.sku.is.required', 'El Sku es requerido')}
                  defaultValue={currentDataForm ? currentDataForm.sku : ''}
                />

                {actionToggle && (
                  <label className="d-flex">
                    <span className="text-inline">
                      {formatterText('table.title.state', 'Estado')}
                    </span>
                    <section className="w100-container">
                      <label className="container-toggle-label">
                        <p className="form-responsive-toggle">
                          {active
                            ? formatterText('p.active', 'Activo')
                            : formatterText('p.unActive', 'No activo')}
                        </p>
                        <label className="switch">
                          <input
                            checked={!!active}
                            onChange={() => {
                              setActive(!active);
                            }}
                            type="checkbox"
                          />
                          <span className="slider round"></span>
                        </label>
                      </label>
                    </section>
                  </label>
                )}
              </section>
              <div className="demo-form__footer">
                <section className="form-responsive-container-buttons">
                  {!actionToggle ? (
                    <button type="submit" style={{ padding: '0px' }} className="btn-primary">
                      {formatterText('text.create.activity', 'Crear Actividad')}
                    </button>
                  ) : (
                    <button type="submit" style={{ padding: '0px' }} className="btn-primary">
                      {formatterText('btn.save.changes', 'Guardar cambios')}
                    </button>
                  )}

                  {actionToggle && (
                    <button
                      className="input-cancel"
                      onClick={() => {
                        setActionToggle(!actionToggle);
                        setCurrentDataForm(null);
                      }}
                    >
                      {formatterText('btn.cancel', 'Cancelar')}
                    </button>
                  )}

                  <button className="input-cancel" onClick={() => navigate(paths.services)}>
                    {formatterText('btn.exit', 'Salir')}
                  </button>
                </section>
              </div>
              <section className="form-responsive-container-information">
                <div style={{ width: '90%', marginTop: '15px', marginBottom: '15px' }}>
                  {!loading ? (
                    <>
                      <section className="userOptions">
                        <Search
                          placeholder={formatterText(
                            'placeholder.search.multi.items',
                            'Buscar por palabra',
                          )}
                          width="50%"
                        />
                      </section>
                      <FormattedMessage
                        id="table.name.search.product"
                        defaultMessage="Actividades"
                      >
                        {(placeholder) => (
                          <DynamicTable
                            titles={titlesTableActivites}
                            pageName={PAGE_NAMES.Actividad}
                            getData={getDataTable} //
                            handleDeleteItem={handleDeleteItem}
                            handleEditStateItem={handleEditStateItem}
                            routeToEdit={paths.updateActivityService}
                            canDeleted={true}
                            canModify={true}
                            functions={{
                              setActive,
                              setCurrentDataForm,
                              myForm,
                              currentDataForm,
                              setActionToggle,
                            }}
                          />
                        )}
                      </FormattedMessage>
                    </>
                  ) : error ? (
                    displayMessage(
                      'error',
                      'Ha ocurrido un error, intentalo más tarde.',
                      'toast.error.general',
                    )
                  ) : (
                    <DisplayProgress />
                  )}
                </div>
              </section>
            </FormizStep>
            <FormizStep name="step2" label="Asignar actividades a servicios">
              <form>
                <p className="wrap-form-title">
                  {formatterText('label.text.activity', 'Actividad')}
                </p>
                <section
                  className="grid-container-1c"
                  style={{
                    width: '95%',
                    margin: '0 auto',
                  }}
                >
                  <label className="d-flex">
                    <span className="text-inline-large">
                      {formatterText('table.title.category.service', 'Categoría de servicio')}
                    </span>
                    <section className="w100-container">
                      <Selector
                        name="idCategoriaServicio"
                        data={selectedSearch.categoriasServicios}
                        placeholder={
                          <FormattedMessage
                            id="input.placeholder.select"
                            defaultMessage="Selecione una opción"
                          />
                        }
                        dataValue={auxData.idCategoriaServicio}
                        setterFunction={setAuxData}
                        isLoading={loading}
                        isRequired={true}
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline-large">
                      {formatterText('table.title.type.service', 'Tipo de servicio')}
                    </span>
                    <section className="w100-container">
                      <Selector
                        name="idTipoServicio"
                        data={selectedSearch.tipoServicio}
                        placeholder={
                          <FormattedMessage
                            id="input.placeholder.select"
                            defaultMessage="Selecione una opción"
                          />
                        }
                        dataValue={auxData.idTipoServicio}
                        setterFunction={setAuxData}
                        isLoading={loading}
                        isRequired={true}
                      />
                    </section>
                  </label>
                </section>
                {currentDataTable.length > 0 ? (
                  <>
                    <p className="wrap-form-title">
                      {formatterText('p.activities.associated', 'Actividades asociadas')}
                    </p>
                    <section className="form-responsive-container-information">
                      <Table
                        data={currentDataTable}
                        titles={titlesTableCostProduct}
                        type="associationActivities"
                        showTH={true}
                      />
                    </section>
                  </>
                ) : (
                  loadingProgress && <DisplayProgress />
                )}
                <p className="wrap-form-title">{formatterText('column.name.assign.activity')}</p>
                <section
                  className="grid-container-2c"
                  style={{
                    width: '95%',
                    margin: '0 auto',
                  }}
                >
                  {show && (
                    <>
                      <label className="d-flex">
                        <span className="text-inline">{formatterText('column.name.related.activity.label')}</span>
                        <section className="w100-container">
                          <Select
                            styles={customStyles2}
                            onChange={(selectedOption) => {
                              setAuxData({
                                ...auxData,
                                idActividad: selectedOption,
                              });
                              setCurrentItemMinimal({
                                ...currentItemMinimal,
                                idActividad: selectedOption,
                              });
                            }}
                            value={auxData.idActividad}
                            noOptionsMessage={() =>
                              formatterText(
                                'select.placeholder.no.options',
                                'No se encontraron opciones',
                              )
                            }
                            options={selectedSearch.actividadesServicios}
                            placeholder={
                              loading ? (
                                <FormattedMessage
                                  id="input.loading"
                                  defaultMessage="Cargando..."
                                />
                              ) : (
                                <FormattedMessage
                                  id="input.placeholder.select"
                                  defaultMessage="Selecione una opción"
                                />
                              )
                            }
                          />
                        </section>
                      </label>
                      <label className="d-flex">
                        <span className="text-inline">{formatterText('column.name.service.stage.label')}</span>
                        <section className="w100-container">
                          <Select
                            styles={customStyles2}
                            onChange={(selectedOption) => {
                              setAuxData({
                                ...auxData,
                                idEtapaServicio: selectedOption,
                              });
                              setCurrentItemMinimal({
                                ...currentItemMinimal,
                                idEtapaServicio: selectedOption,
                              });
                            }}
                            value={auxData.idEtapaServicio}
                            noOptionsMessage={() =>
                              formatterText(
                                'select.placeholder.no.options',
                                'No se encontraron opciones',
                              )
                            }
                            options={selectedSearch.etapaServicios}
                            placeholder={
                              loading ? (
                                <FormattedMessage
                                  id="input.loading"
                                  defaultMessage="Cargando..."
                                />
                              ) : (
                                <FormattedMessage
                                  id="input.placeholder.select"
                                  defaultMessage="Selecione una opción"
                                />
                              )
                            }
                          />
                        </section>
                      </label>
                      <label className="d-flex">
                        <span className="text-inline">{formatterText('column.name.manage.by.technician.label')}</span>
                        <section className="w100-container">
                          <Select
                            styles={customStyles2}
                            onChange={(selectedOption) => {
                              setAuxData({
                                ...auxData,
                                actividadTecnica: selectedOption,
                              });
                              setCurrentItemMinimal({
                                ...currentItemMinimal,
                                actividadTecnica: selectedOption,
                              });
                            }}
                            value={auxData.actividadTecnica}
                            noOptionsMessage={() =>
                              formatterText(
                                'select.placeholder.no.options',
                                'No se encontraron opciones',
                              )
                            }
                            options={[
                              {
                                label: 'No',
                                value: 0,
                              },
                              {
                                label: 'Sí',
                                value: 1,
                              },
                            ]}
                            placeholder={
                              loading ? (
                                <FormattedMessage
                                  id="input.loading"
                                  defaultMessage="Cargando..."
                                />
                              ) : (
                                <FormattedMessage
                                  id="input.placeholder.select"
                                  defaultMessage="Selecione una opción"
                                />
                              )
                            }
                          />
                        </section>
                      </label>
                      <label className="d-flex">
                        <span className="text-inline">
                          {formatterText('column.name.activity.time.label')}
                        </span>
                        <section className="w100-container">
                          <input
                            className="input-default-3c"
                            type="text"
                            name="tiempoActividad"
                            value={currentItemMinimal.tiempoActividad}
                            onChange={handleNumber}
                            placeholder={formatterText('column.name.activity.time.label')}
                            maxLength="20"
                          />
                        </section>
                      </label>
                      <label className="d-flex">
                        <span className="text-inline">{formatterText('column.name.description.label')}</span>
                        <section className="w100-container">
                          <textarea
                            className="input-textarea"
                            name="descripcion"
                            value={currentItemMinimal.descripcion}
                            onChange={handlerTextDescription}
                            placeholder={formatterText('table.title.description', 'Descripción')}
                            maxLength="200"
                          />
                        </section>
                      </label>
                    </>
                  )}
                </section>
                <section
                  className="form-responsive-container-buttons"
                  style={{
                    margin: '1rem 0rem',
                  }}
                >
                  <input
                    onClick={handleAddItemMinimal}
                    type="button"
                    className="btn-action-primary"
                    value={formatterText('column.name.add.activity')}
                  />
                  <button
                    className="btn-action-cancel"
                    onClick={() => navigate(paths.services)}
                    style={{
                      margin: '0px',
                    }}
                  >
                    {formatterText('column.name.cancel')}
                  </button>
                </section>
              </form>
            </FormizStep>
            <FormizStep name="step3" label="Formularios asociados">
              <form>
                {activitiesResults.length > 0 ? (
                  <section className="form-responsive-container-information">
                    <span className="title-table">{formatterText('column.name.related.forms')}</span>
                    <MultiTableMinimal
                      titles={titlesTableTypeServiceActivity}
                      data={activitiesResults}
                      type="typeServiceActivity"
                      handleDelete={handleDelete}
                      dialog={dialog}
                      setDialog={setDialog}
                      closeDialog={closeDialog}
                      canSearch={true}
                    />
                  </section>
                ) : (
                  loadingProgress && <DisplayProgress />
                )}

                <p className="wrap-form-title">{formatterText('column.name.assign.form')}</p>
                <section className="grid-container-1c">

                  <section className="form-responsive-container-information">
                    <section className="form-responsive-information__option">
                      <h3>{formatterText('column.name.activity.service.type')}</h3>
                      <SelectorGrid
                        name="idTypeServiceActivity"
                        data={selectedSearch.typeServicesActivity}
                        placeholder={
                          <FormattedMessage
                            id="input.placeholder.select"
                            defaultMessage="Selecione una opción"
                          />
                        }
                        shortWidth={true}
                        dataValue={auxData}
                        setterFunction={setAuxData}
                        isLoading={loading}
                        isRequired={false}
                      />
                    </section>
                  </section>

                  <section className="d-flex d-ajc">
                    <h3 className="text-inline">{formatterText('column.name.form')}</h3>
                    <SelectorGrid
                      name="idFormulario"
                      data={selectedSearch.formsAssociate}
                      placeholder={
                        <FormattedMessage
                          id="input.placeholder.select"
                          defaultMessage="Selecione una opción"
                        />
                      }
                      shortWidth={true}
                      dataValue={auxData}
                      setterFunction={setAuxData}
                      isLoading={loading}
                      isRequired={false}
                    />
                  </section>
                  <section className="d-flex d-ajc">
                    <h3 className="text-inline">{formatterText('column.name.client.associated')}</h3>
                    <SelectorGrid
                      name="idCliente"
                      data={selectedSearch.clientsAssociate}
                      placeholder={
                        <FormattedMessage
                          id="input.placeholder.select"
                          defaultMessage="Selecione una opción"
                        />
                      }
                      shortWidth={true}
                      dataValue={auxData}
                      setterFunction={setAuxData}
                      isLoading={loading}
                      isRequired={false}
                    />
                  </section>
                </section>
                <section
                  className="form-responsive-container-buttons"
                  style={{
                    margin: '1rem 0rem',
                  }}
                >
                  <input
                    onClick={handleAddActivityFormClient}
                    type="button"
                    className="btn-action-primary"
                    value={formatterText('column.name.add.form')}
                  />
                  <button
                    className="btn-action-cancel"
                    onClick={() => navigate(paths.services)}
                    style={{
                      margin: '0px',
                    }}
                  >
                    {formatterText('column.name.cancel')}
                  </button>
                </section>
              </form>
            </FormizStep>
          </div>
        </form>
      </Formiz>
    </div>
  );
}
