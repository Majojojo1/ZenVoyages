import React from 'react';
// Import Context
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
// Import libs
import SortData from 'components/utils/SortData';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
// Import Services
import { useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { deleteItem, updateItem } from 'services/api/methods';
import paths from 'services/paths';


const ServiceActivityTable = ({
  setActive,
  setCurrentDataForm,
  myForm,
  currentDataForm,
  setActionToggle,
  edit,
  
}) => {
  const {getDataTable, resultsFound, setResultFound, setSearchResults, toggleError, handleClick, setDataTable, setTable, loading, toggleLoading, error, displayMessage, handleStructureItems } =
    useSeachContext();
  // use Hook of language v2
  const { formatterText } = useLangv2();



  // Helps to loading data table
  const { DisplayProgress } = useProgress();

  // useEffect(() => {
  //   getDataTable();
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, []);


  //   // función para cargar datos de la tabla de actividades
  //   const getDataTable = () => {
  //     // show loading
  //     toggleLoading(true);

  //     getAll(endpoints.activitiesServices.getAllActivitiesServicesBasic)
  //       .then((data) => {
  //         let newArray = [];
  //         data.forEach((item) => {
  //           handleStructureItems(newArray, item);
  //         });
  //         const sortedArray = SortData(newArray, 'asc');
  //         // setSearchResults(sortedArray);
  //         setResultFound(sortedArray);
  //         setDataTable(newArray);  //
  //         // show loading
  //         toggleLoading(false);
  //       })
  //       .catch((err) => {
  //         console.log(err);
  //         // mostrar error
  //         toggleError(!error);
  //         handleClick();
  //       });
  //   };



  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteItem(endpoints.activitiesServices.deleteActivitiesBasic, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          SortData(newArray, 'asc');
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateItem(endpoints.activitiesServices.updateActivitiesService, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const titles = [
    formatterText('label.text.nameActivity', 'Nombre de la actividad'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.sku', 'SKU'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading ? (
        <>
          <section className="userOptions">
            <Search
              placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
              width="50%"
            />
          </section>
          <FormattedMessage id="table.name.search.product" defaultMessage="Actividades">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={placeholder}
                getData={getDataTable} //
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateActivityService}
                canDeleted={true}
                canModify={true}
                functions={{
                  setActive,
                  setCurrentDataForm,
                  myForm,
                  currentDataForm,
                  setActionToggle,
                  edit,
                }}
              />
            )}
          </FormattedMessage>
        </>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        <DisplayProgress />
      )}
    </>
  );
};

ServiceActivityTable.propTypes = {
  setActive: PropTypes.func,
  setCurrentDataForm: PropTypes.func,
  myForm: PropTypes.object,
  currentDataForm: PropTypes.object,
  setActionToggle: PropTypes.func,
  edit: PropTypes.bool,
};

export default ServiceActivityTable;
