import React, { useEffect } from 'react';
// Import Context
import { useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
// Import libs
import SortData from 'components/utils/SortData';
import { FormattedMessage } from 'react-intl';
// Import services

import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const ActivityTable = () => {
  const titles = [
    <FormattedMessage
      key={'categoria_asociada'}
      id="tab.title.assciated.category"
      defaultMessage="Categoría asociada"
    />,
    <FormattedMessage
      key={'tipo_servicio'}
      id="table.title.type.service"
      defaultMessage="Tipo de servicio"
    />,
    <FormattedMessage
      key={'etapa_servicio'}
      id="text.service.stage"
      defaultMessage="Etapa del servicio"
    />,
    <FormattedMessage
      key={'nombre_actividad'}
      id="tab.title.activityname"
      defaultMessage="Nombre Actividad"
    />,
    <FormattedMessage
      key={'descripcion'}
      id="table.title.description"
      defaultMessage="Descripción"
    />,
    'SKU',
    /*  "IVA", */
    <FormattedMessage
      key={'minutos_desarrollo'}
      id="tab.title.developtime"
      defaultMessage="Minutos de desarrollo"
    />,
    <FormattedMessage
      key={'aspectos_tecnicos'}
      id="tab.title.technicalaspects"
      defaultMessage="Aspectos técnico"
    />,
    <FormattedMessage key={'estado'} id="table.title.state" defaultMessage="Estado" />,
  ];

  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.activitiesServices.deleteActivitiesService, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          SortData(newArray, 'ActivitySpecial');
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.activitiesServices.updateActivitiesService, body)
        .then((res) => {
          console.log(res);
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idActividad,
      categoriaAsociada: item.categoriaAsociada,
      tipoServicios: item.tipoServicios,
      etapaServicios: item.etapaServicios,
      nombre: item.nombre,
      descripcion: item.descripcion,
      sku: item.sku,
      /*    iva: item.iva ? item.iva : "", */
      tiempoDesarrollo: item.tiempoDesarrollo,
      actividadTecnica: item.actividadTecnica === 1 ? 'Si' : 'No',
      estado: item.estado,
      objeto: { ...item },
    });
  };

  // función para cargar datos
  const getDataTable = () => {
    getAll(endpoints.activitiesServices.getAllActivitiesServices)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        const sortedArray = SortData(newArray, 'ActivitySpecial');
        setDataTable(newArray);

      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {!loading ? (
       
          <FormattedMessage id="table.name.search.product" defaultMessage="Categoría de producto">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Actividades}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateActivityService}
              />
            )}
          </FormattedMessage>
       
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ActivityTable;
