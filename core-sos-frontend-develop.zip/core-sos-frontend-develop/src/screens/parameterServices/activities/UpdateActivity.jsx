import React, { useContext, useEffect, useState } from 'react';
// Import Context
import MultiTableMinimal from 'common/minimalTables/MultiTableMinimal';
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLang from 'hooks/useLang';
import useProgress from 'hooks/useProgress';
import { useNavigate } from 'react-router-dom';
// Import Components
import { Formiz, FormizStep, useForm } from '@formiz/core';
import { isMaxLength } from '@formiz/validations';
import { InputField } from 'common/InputField';
import Table from 'common/minimalTables/Table';
import Selector from 'common/selects/Selector';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
// Import libs
import HandlerText from 'common/validators/HandlerText';
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import services
import endpoints from 'services/api';
import { addItem, deleteItem, getAll, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';

//TABLE CONTEXT
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { isUndefined } from 'lodash';
import ServiceActivityTable from './ServiceActivityTable';

// Table 2 tab
const titlesTableCostProduct = [
  'Actividad relacionada',
  'Tipo de servicio',
  'Etapa de servicio',
  'Gestionar por técnico',
  'Tiempo de actividad',
  'Descripción',
  'Acciones',
];

// Table 3 tab
const titlesTableTypeServiceActivity = [
  'Nombre formulario',
  'Descripción',
  'Código formulario',
  'Cliente asociado',
  'Identificación cliente',
  'Acciones',
];

const UpdateActivity = () => {
  return (
    <SearchWrapper>
      <UpdateActivityComponent />
    </SearchWrapper>
  );
};

function UpdateActivityComponent() {
  const { searchResults = [], setDataTable } = useSeachContext();

  // Formiz object
  const myForm = useForm();

  // Call context TableMinimalContext
  const { currentDataTable, setCurrentDataTable } = useContext(TableMinimalContext);
  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();
  // Form information
  const [currentDataForm, setCurrentDataForm] = useState(null);
  // Current data table
  const [currentItemMinimal, setCurrentItemMinimal] = useState([]);
  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      categoriasServicios: [],
      tipoServicio: [],
      actividadesServicios: [],
      etapaServicios: [],
      typeServicesActivity: [],
      formsAssociate: [],
      clientsAssociate: [],
    },
  ]);

  // Helps to loading select data
  const { loading, toggleLoading } = useGetData();
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // Helps to load Select data
  const [auxData, setAuxData] = useState({
    idTipoServicioActividad: uuidv4(),
    idCategoriaServicio: 0,
    idTipoServicio: 0,
    idActividad: 0,
    idEtapaServicio: 0,
    actividadTecnica: 0,
    idTypeServiceActivity: 0,
    idFormulario: 0,
    idCliente: 0,
  });
  // toggle state
  const [active, setActive] = useState(true);

  // Call local storage to get data to update
  useEffect(() => {
    getDataToUpdate();
    // Tab 1
    getAllCategoriesServices();
    getAllActivitiesServices();
    getAllStageServices();
    // Tab 2
    getAllTypeServicesActivity();
    getAllFormsWithActiveState();
    getAllClientsToAssociate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Get all type Services Activity by id
  useEffect(() => {
    getAllFormsClientsByTypeServicesActivity(
      auxData.idTypeServiceActivity.value,
      auxData.idCliente.value,
    );
  }, [auxData.idTypeServiceActivity, auxData.idCliente]);

  // Get the activities by id type service
  useEffect(() => {
    if (selectedSearch.tipoServicio !== 0) {
      getAllActivitiesTypeServicesById();
    }
    // this only is call when the id Type Service change
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auxData.idTipoServicio]);

  // Get the type of service by id category service
  useEffect(() => {
    if (auxData.idCategoriaServicio !== 0) {
      // this only is call when the id Category Service change, and render the element in the selector
      getAllTypeServicesById(auxData.idCategoriaServicio);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auxData.idCategoriaServicio]);

  // get data from the localstorage
  const getDataToUpdate = () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));

    if (dataUpdate) {
      // set state
      setActive(dataUpdate.estado);
      // set form
      setCurrentDataForm(dataUpdate);
    } else {
      navigate(paths.services);
    }
  };

  // Get the data of all category services to the selector
  const getAllCategoriesServices = () => {
    toggleLoading(true);

    getAll(endpoints.serviceCategory.getAllServiceCategory)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCategoriaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          categoriasServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all type category Activity to the selector
  const getAllTypeServicesActivity = () => {
    toggleLoading(true);

    getAll(endpoints.typoServiceActivities.getAllTypoServiceActivities)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: item.idTipoServicioActividad,
            label: `${item.idTipoServicio.nombre} - ${item.idActividad.nombre} - ${item.idEtapaServicio.nombre}`,
            isFixed: true,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          typeServicesActivity: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all forms with only active state to the selector
  const getAllFormsWithActiveState = () => {
    getAll(endpoints.activityformClient.getAllFormWithTrueState)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: item.idFormulario,
            label: `${item.nombre} - ${item.codigo}`,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          formsAssociate: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the data of all clients to the selector
  const getAllClientsToAssociate = () => {
    getAll(endpoints.clients.getAllClients)
      .then((res) => {
        // create new array
        const newArray = [
          {
            value: 0,
            label: 'Ninguno',
          },
        ];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCliente,
              label: `${item.nombreRazonSocial} - ${item.identificacion}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          clientsAssociate: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the data of all Activities services to the selector
  const getAllActivitiesServices = () => {
    // loading select
    toggleLoading(true);

    getAll(endpoints.activitiesServices.getAllActivitiesServicesBasic)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idActividad,
              label: `${item.nombre} - ${item.sku}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          actividadesServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all Stage services to the selector
  const getAllStageServices = () => {
    toggleLoading(true);

    getAll(endpoints.stageServices.getAllStageServices)
      .then((res) => {
        // console.log(res);
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idEtapaServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          etapaServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Get the data of all activities type services when have id type service
  const getAllActivitiesTypeServicesById = () => {
    setLoadingProgress(true);
    console.log(auxData);
    getItemById(
      endpoints.typoServiceActivities.getTypeServiceActivitiesByTypeService,
      auxData.idTipoServicio,
    )
      .then((res) => {
        // create new array
        const newArray = [];

        res.forEach((item) => {
          newArray.push({
            ...item,
            idTipoServicioActividad: item.idTipoServicioActividad,
            idTipoServicio: {
              idTipoServicio: `${item.idTipoServicio.nombre} - ${item.idTipoServicio.codigo}`,
              id: item.idTipoServicio.idTipoServicio,
            },
            idActividad: {
              idActividad: `${item.idActividad.nombre} - ${item.idActividad.sku}`,
              id: item.idActividad.idActividad,
            },
            idEtapaServicio: {
              idEtapaServicio: `${item.idEtapaServicio.nombre} - ${item.idEtapaServicio.codigo}`,
              id: item.idEtapaServicio.idEtapaServicio,
            },
            actividadTecnica: item.actividadTecnica,
            orden: item.orden,
          });
        });

        // sort the array by the order field
        newArray.sort((a, b) => a.orden - b.orden);
        setCurrentDataTable(newArray);
        setLoadingProgress(false);
      })
      .catch((err) => {
        console.log(err);
        setLoadingProgress(false);
      });
  };

  // Get all type service by id category service
  const getAllTypeServicesById = (selectValue) => {
    // Set the value of datas into []
    setCurrentDataTable([]);
    setCurrentItemMinimal([]);

    getItemById(endpoints.typeService.getTypeServiceByCategory, selectValue.value)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idTipoServicio,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, currentItemMinimal, setCurrentItemMinimal);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    // create a regex to valid the number
    const regex = /^[0-9]*$/;
    if (e.target.value.match(regex) !== null) {
      setCurrentItemMinimal({
        ...currentItemMinimal,
        idTipoServicio: auxData.idTipoServicio,
        idActividad: auxData.idActividad,
        idEtapaServicio: auxData.idEtapaServicio,
        actividadTecnica: auxData.actividadTecnica,
        [e.target.name]: e.target.value,
      });
    }
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (values) => {
    let data = {
      idActividad: currentDataForm.idActividad,
      nombre: values.nombre,
      descripcion: values.descripcion ? values.descripcion : '',
      sku: values.sku,
      estado: active ? '1' : '0',
      fechaCreacion: currentDataForm.fechaCreacion,
      usuarioCreacion: currentDataForm.usuarioCreacion,
      usuarioModificacion: Cookie.get('idUsuario'),
    };
    putItem(data);
  };

  // Updtae an activity
  const putItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.update.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: async () => {
        try {
          await updateItem(endpoints.activitiesServices.updateActivitiesService, data);

          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general'),
            text: formatterText('alert.message.confirm.updated.general'),
            confirmButtonText: formatterText('alert.button.continue'),
            allowOutsideClick: false,
            // TODO: revisar
            executeFunction: () => console.log(), // Deuda tecnica (?), posiblemente toque retirarlo
          });
        } catch (error) {
          HandleOnError(formatterText('alert.message.failed.general'));
          console.log(error);
        }
      },
    });
  };

  // Associate an activity to a type service
  const associateTipoServiciosActividades = (item) => {
    // Define the order
    let order = currentDataTable.length + 1;
    // Structure the body
    let data = {
      idTipoServicioActividad: null,
      idTipoServicio: {
        idTipoServicio: item.idTipoServicio.value,
      },
      idActividad: {
        idActividad: item.idActividad.value,
      },
      idEtapaServicio: {
        idEtapaServicio: item.idEtapaServicio.value,
      },
      orden: order,
      tiempoActividad: item.tiempoActividad,
      actividadTecnica: item.actividadTecnica.value,
      descripcion: item.descripcion,
    };

    // Call the service
    addItem(endpoints.typoServiceActivities.addTypeServiceActivities, data)
      .then((response) => {
        data = {
          ...data,
          idTipoServicio: {
            idTipoServicio: item.idTipoServicio.label,
          },
          idActividad: {
            idActividad: item.idActividad.label,
          },
          idEtapaServicio: {
            idEtapaServicio: item.idEtapaServicio.label,
          },
          idTipoServicioActividad: response.idTipoServicioActividad,
        };
        setCurrentDataTable([...currentDataTable, data]);

        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general'),
          text: formatterText('alert.message.confirm.created.general'),
          confirmButtonText: formatterText('alert.button.continue'),
          allowOutsideClick: false,
          executeFunction: () =>
            console.log('Se creo correctamente: ', response.idTipoServicioActividad),
        });
      })
      .catch((err) => {
        if (err.response.status === 412) {
          HandleOnError('Intenta con otros datos');
        } else {
          HandleOnError(formatterText('alert.message.failed.general'));
        }
        console.log(err);
      });
  };

  // Add new association
  const handleAddItemMinimal = () => {
    if (currentItemMinimal.tiempoActividad !== '' && currentDataTable.length >= 1) {
      associateTipoServiciosActividades(currentItemMinimal);
      // Set data
      setCurrentItemMinimal({
        tiempoActividad: '',
        descripcion: '',
        idTipoServicioActividad: uuidv4(),
      });
    } else {
      HandleOnError(formatterText('alert.message.failed.data'));
    }
  };

  // Create new association in the 3 tab
  const handleAddActivityFormClient = () => {
    const data = {
      idActividadFormularioCliente: null,
      idFormulario: auxData.idFormulario.value,
      idCliente: auxData.idCliente.value === 0 ? null : auxData.idCliente.value,
      idTipoServicioActividad: auxData.idTypeServiceActivity.value,
      usuarioCreacion: parseInt(Cookie.get('idUsuario')),
    };

    addItem(endpoints.activityformClient.addActivityFormClient, data)
      .then((_) => {
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general'),
          text: formatterText('alert.message.confirm.created.general'),
          confirmButtonText: formatterText('alert.button.continue'),
          allowOutsideClick: false,
          executeFunction: () =>
            getAllFormsClientsByTypeServicesActivity(
              auxData.idTypeServiceActivity.value,
              auxData.idCliente.value,
            ),
        });
      })
      .catch((err) => {
        if (err.response.status === 412 || err.response.status === 400) {
          HandleOnError(formatterText('alert.message.failed.repeat.value.general'));
        } else {
          HandleOnError(formatterText('alert.message.failed.general'));
        }
        console.log(err);
      });
  };

  // Get all Forms Clients By Activity
  const getAllFormsClientsByTypeServicesActivity = (idActividad, idCliente) => {
    setLoadingProgress(true);
    // Call the service
    let url = '';
    if (
      (isUndefined(idActividad) && isUndefined(idCliente)) ||
      (idActividad === 0 && idCliente === 0)
    ) {
      url = endpoints.activityformClient.getFormClientByActivity(-1, -1);
    } else {
      url = endpoints.activityformClient.getFormClientByActivity(idActividad || 0, idCliente || 0);
    }
    getAll(url)
      .then((response) => {
        let data = [];
        response.forEach((element) => {
          data.push({
            id: element.idActividadFormularioCliente,
            name: element.nombreFormulario,
            description: element.descripcionFormulario,
            code: element.codigoFormulario,
            client: element.nombreRazonSocialCliente,
            clienteId: element.identificacionCliente,
          });
        });
        setDataTable(data);
        setCurrentDataTable(data);
        setLoadingProgress(false);
      })
      .catch((err) => {
        console.log(err);
        setLoadingProgress(false);
      });
  };

  // Delete an association of the table Activity Form Client
  const handleDelete = (row) => {
    deleteItem(endpoints.activityformClient.deleteActivityFormClient, row.id)
      .then(() => {
        getAllFormsClientsByTypeServicesActivity(
          auxData.idTypeServiceActivity.value,
          auxData.idCliente.value,
        );
      })
      .catch((error) => {
        console.log(error);
      });
    closeDialog();
  };

  // dialog state
  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  // close dialog
  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  // Display errors

  return (
    <>
      <div className="centered-form">
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form
            noValidate
            onSubmit={myForm.submit}
            className="container-wrapForm"
            style={{ minHeight: '16rem' }}
          >
            {currentDataForm && (
              <>
                <div className="new-container-wrapForm__tabs">
                  {myForm.steps.map((step) => (
                    <button
                      key={step.name}
                      className={`new-tab-option ${
                        step.name === myForm.currentStep.name ? 'is-active' : ''
                      }`}
                      type="button"
                      onClick={() => myForm.goToStep(step.name)}
                    >
                      {step.label}
                      {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                    </button>
                  ))}
                </div>

                <div className="container-wrapForm-content">
                  <FormizStep name="step1" label="Información de la actividad">
                    <section className="form-responsive-container-information">
                      <InputField
                        type="text"
                        name="nombre"
                        labelText="Nombre de la actividad"
                        placeholder="Nombre de la actividad"
                        validateInput="text"
                        required="El nombre de la actividad es requerida"
                        defaultValue={currentDataForm ? currentDataForm.nombre : ''}
                        validations={[
                          {
                            rule: isMaxLength(45),
                            message:
                              'El nombre de la actividad debe tener como máximo 45 caracteres',
                          },
                        ]}
                        styleName="input-primary-wrap-large"
                      />
                      <InputField
                        type="text"
                        name="descripcion"
                        labelText="Descripción"
                        placeholder="Descripción"
                        validateInput="text"
                        defaultValue={currentDataForm ? currentDataForm.descripcion : ''}
                        validations={[
                          {
                            rule: isMaxLength(200),
                            message:
                              'La descripción de la actividad debe tener como máximo 200 caracteres',
                          },
                        ]}
                        styleName="input-primary-wrap-large"
                      />
                      <InputField
                        type="text"
                        name="sku"
                        labelText="Sku"
                        placeholder="Sku"
                        validateInput="text"
                        required="El Sku es requerido"
                        defaultValue={currentDataForm ? currentDataForm.sku : ''}
                        styleName="input-primary-wrap-large"
                      />

                      <label className="wrapForm__label">
                        <span className="warpForm-text">Estado</span>
                        <label className="form-responsive-label input-primary-wrap-toggle">
                          <p className="form-responsive-toggle">
                            {active ? 'Activo' : 'No activo'}
                          </p>
                          <label className="switch">
                            <input
                              checked={active ? true : false}
                              onChange={() => {
                                setActive(!active);
                              }}
                              type="checkbox"
                            />
                            <span className="slider round"></span>
                          </label>
                        </label>
                      </label>

                      <div className="demo-form__footer">
                        <section className="form-responsive-container-buttons">
                          <button type="submit" style={{ padding: '0px' }} className="btn-primary">
                            Guardar cambios
                          </button>
                          <button className="input-cancel" onClick={() => navigate(paths.services)}>
                            Cancelar
                          </button>
                        </section>
                      </div>

                      <div style={{ width: '90%', marginTop: '15px' }}>
                        <ServiceActivityTable
                          setActive={setActive}
                          setCurrentDataForm={setCurrentDataForm}
                          myForm={myForm}
                          currentDataForm={currentDataForm}
                          edit={true}
                          setActionToggle={null}
                        />
                      </div>
                    </section>
                  </FormizStep>
                  <FormizStep name="step2" label="Asignar actividades a servicios">
                    <form>
                      <p className="wrap-form-title">Actividad</p>
                      <section className="form-responsive-container-information">
                        <section className="form-responsive-information__option">
                          <h3>Categoría de servicio</h3>
                          <Selector
                            name="idCategoriaServicio"
                            data={selectedSearch.categoriasServicios}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData.idCategoriaServicio}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={true}
                          />
                        </section>
                        <section className="form-responsive-information__option">
                          <h3>Tipo de servicio</h3>
                          <Selector
                            name="idTipoServicio"
                            data={selectedSearch.tipoServicio}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData.idTipoServicio}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={true}
                          />
                        </section>
                      </section>
                      {currentDataTable.length > 0 ? (
                        <>
                          <p className="wrap-form-title">Actividades asociadas</p>
                          <section className="form-responsive-container-information">
                            <Table
                              data={currentDataTable}
                              titles={titlesTableCostProduct}
                              type="associationActivities"
                            />
                          </section>
                        </>
                      ) : (
                        loadingProgress && <DisplayProgress />
                      )}
                      <p className="wrap-form-title">+ Asignar actividad</p>
                      <section className="wrapForm w-100">
                        <label className="wrapForm__label">
                          <h3 className="spacing-r1">Actividad relacionada</h3>
                          <Selector
                            name="idActividad"
                            data={selectedSearch.actividadesServicios}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </label>
                        <label className="wrapForm__label">
                          <h3 className="spacing-r1">Etapa del servicio</h3>
                          <Selector
                            name="idEtapaServicio"
                            data={selectedSearch.etapaServicios}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </label>
                        <label className="wrapForm__label">
                          <h3 className="spacing-r1">Gestionar por técnico</h3>
                          <Selector
                            name="actividadTecnica"
                            data={[
                              {
                                label: 'No',
                                value: 0,
                              },
                              {
                                label: 'Sí',
                                value: 1,
                              },
                            ]}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </label>
                        <label className="wrapForm__label">
                          <h3 className="spacing-r1">Tiempo para el desarrollo de la actividad</h3>
                          <input
                            className="input-primary"
                            type="text"
                            name="tiempoActividad"
                            value={currentItemMinimal.tiempoActividad}
                            onChange={handleNumber}
                            placeholder="Tiempo para el desarrollo de la actividad"
                            maxLength="20"
                          />
                        </label>
                        <label className="wrapForm__label">
                          <h3 className="spacing-r1">Descripción</h3>
                          <input
                            className="input-primary"
                            type="text"
                            name="descripcion"
                            value={currentItemMinimal.descripcion}
                            onChange={handleText}
                            placeholder="Descripción"
                            maxLength="200"
                          />
                        </label>
                      </section>
                      <input
                        onClick={handleAddItemMinimal}
                        type="button"
                        className="btn-primary btn-primary-center"
                        value="Agregar actividad"
                      />
                    </form>
                  </FormizStep>
                  <FormizStep name="step3" label="Formularios asociados">
                    <form>
                      <section className="form-responsive-container-information">
                        <section className="form-responsive-information__option">
                          <h3>Actividad</h3>
                          <Selector
                            name="idCategoriaServicio"
                            data={selectedSearch.categoriasServicios}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData.idCategoriaServicio}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={true}
                            disabled={true}
                          />
                        </section>
                        <section className="form-responsive-information__option">
                          <h3>Tipo de servicio</h3>
                          <Selector
                            name="idTipoServicio"
                            data={selectedSearch.tipoServicio}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData.idTipoServicio}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={true}
                            disabled={true}
                          />
                        </section>
                      </section>
                      {searchResults.length > 0 ? (
                        <section className="form-responsive-container-information">
                          <span className="title-table">Formulario asociados</span>
                          <MultiTableMinimal
                            titles={titlesTableTypeServiceActivity}
                            data={searchResults}
                            type="typeServiceActivity"
                            handleDelete={handleDelete}
                            dialog={dialog}
                            setDialog={setDialog}
                            closeDialog={closeDialog}
                            canSearch={true}
                          />
                        </section>
                      ) : (
                        loadingProgress && <DisplayProgress />
                      )}
                      <p className="wrap-form-title">+ Asignar formulario</p>
                      <section className="form-responsive-container-information">
                        <section className="form-responsive-information__option">
                          <h3>Tipo servicio actividad</h3>
                          <Selector
                            name="idTypeServiceActivity"
                            data={selectedSearch.typeServicesActivity}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </section>
                        <section className="form-responsive-information__option">
                          <h3>Formulario</h3>
                          <Selector
                            name="idFormulario"
                            data={selectedSearch.formsAssociate}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </section>
                        <section className="form-responsive-information__option">
                          <h3>Cliente al que está asociado</h3>
                          <Selector
                            name="idCliente"
                            data={selectedSearch.clientsAssociate}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecione una opción"
                              />
                            }
                            dataValue={auxData}
                            setterFunction={setAuxData}
                            isLoading={loading}
                            isRequired={false}
                          />
                        </section>
                      </section>
                      <input
                        onClick={handleAddActivityFormClient}
                        type="button"
                        className="btn-primary btn-primary-center"
                        value="Agregar formulario"
                      />
                    </form>
                  </FormizStep>
                  <input type="submit" id="submit-form" style={{ visibility: 'hidden' }} />
                </div>
              </>
            )}
          </form>
        </Formiz>

        {/*     <div className="demo-form__footer">
          <section className="form-responsive-container-buttons">
            <button style={{ padding: "0px" }} className="btn-primary">
              <label className="btn-wrap-add" for="submit-form" tabindex="0">
                Guardar cambios
              </label>
            </button>

            <button
              className="input-cancel"
              onClick={() => navigate(paths.services)}
            >
              Cancelar
            </button>
          </section>
        </div> */}
      </div>
    </>
  );
}

export default UpdateActivity;
