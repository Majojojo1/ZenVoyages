import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLang from 'hooks/useLang';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import Table from 'common/minimalTables/TableMinimal';
import Selector from 'common/selects/Selector';
import defaultSelect from 'common/selects/default.select.style';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerText from 'common/validators/HandlerText';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { TEXTREGEXMIN, SPACING } from 'common/validators/Regex';
import CustomAlert from 'components/CustomAlert';
import { addItem, getAll, getItemById, updateItem } from 'services/api/methods';
// Import Libs
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import { Modal } from 'react-responsive-modal';
import Select from 'react-select';
import Swal from 'sweetalert2';
// Import Services
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { getUnidadMedida } from 'services/api/institutions';
import paths from 'services/paths';
import UpdateModalItem from './UpdateModalItem';


export default function UpdateListPrice() {
  return (
    <SearchWrapper>
      <UpdateListPriceComponent />
    </SearchWrapper>
  );
}

function UpdateListPriceComponent() {
  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();

  // Modal config
  const [open, setOpen] = useState(false);
  const [valueMinimalPrice, setMinimalPrice] = useState('');
  const [valueTax, setValueTax] = useState('');
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  // Call context TableMinimalContext
  const { currentDataTable, setCurrentDataTable, setResultsTableSearch } =
    useContext(TableMinimalContext);
  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();
  const titlesTableCostProduct = [
    formatterText('p.label.title.tipoServicio'),
    formatterText('p.label.title.actividadAsociada'),
    formatterText('p.label.title.unidadMedida'),
    formatterText('p.label.title.valor'),
    formatterText('p.label.title.impuesto'),
    formatterText('p.label.title.acciones'),
  ];
  const { newItemCreated, resourceNotFound, handleRequestError } = useLangv2();
  const [service, setService] = useState([]);
  // Example of form data
  const [formData, setFormData] = useState([]);
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idPrecioAsociado: 0,
    idTipoServicio: 1,
    idActividadAsociada: 0,
    valor: 0,
    impuesto: 0,
    idUnidadMedida: 0,
  });
  const { id } = useParams();
  // Los valores que usará el select
  const [selectedSearch, setSearchSelected] = useState([
    {
      tipoServicio: [],
      actividadAsociada: [],
      unidadMedida: [],
      valor: 0,
    },
  ]);
  // espera a que cargue los valores del multiselect
  const [auxData, setAuxData] = useState({
    idActividadAsociada: 0,
    idTipoServicio: 0,
    idUnidadMedida: 0,
  });

  const { setDataTable } = useSeachContext();

  const [currentCode, setCurrentCode] = useState('');
  // toggle state
  const [active, setActive] = useState(true);

  useEffect(() => {
    getMonedas();
    getUnitMeasure();
    getTypoService();
    getDataToUpdate();
    getMinimalTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getPriceListById(id);
    getMinimalTableFromApi();
  }, [id]);

  //Cuando todo termine de cargar, se agrega el valor de la moneda al AuxData
  useEffect(() => {
    monedaDefault();
  }, [loading]);
  //No borrar, es para una respuetsa visual al usuario (imposibildiad de seleccionar con el select por comando)
  const printMoneda = JSON.parse(localStorage.getItem('dataUpdate'));
  //Guardar en el auxData el valor de la moneda que esta en localSotorage, pues esta sera la que se usara
  //para poder hacer post
  const monedaDefault = () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    setAuxData((prev) => ({
      ...prev,
      idMoneda: {
        value: dataUpdate.idMoneda.idMoneda,
        label: `${dataUpdate.idMoneda.nombre} (${dataUpdate.idMoneda.codigo})`,
        isFixed: true,
      },
    }));
  };

  const getMonedas = () => {
    toggleLoading(true);
    getAll(endpoints.listPrices.getAllMonedas)
      .then((res) => {
        let newArray = [];
        // iterate response and get only the values that are active
        res.map((item) => {
          if (item.estado === 1) {
            let data = {
              value: item.idMoneda,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            };
            newArray.push(data);
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          tipoMonedas: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const getDataToUpdate = () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    if (dataUpdate) {
      setActive(dataUpdate.estado);
      setFormData(dataUpdate);
      setCurrentCode(dataUpdate.codigo);
    } else {
      navigate(paths.services);
    }
  };

  const getPriceListById = (id) => {
    getItemById(endpoints.listPrices.getListPriceById, id)
      .then((res) => {      
        if(res === null){
          setFormData({       
            nombre: '',
            moneda: '',
            codigo: '',
            descripcion: '',           
            estado: 0,
          });         
          resourceNotFound();          
        }else {
          setActive(res.estado);
          setFormData(res);
          setCurrentCode(res.codigo);
        }
      }).catch((err) => {
        console.log(err);
      });
  };

  const getTypoService = () => {
    toggleLoading(true);
    getAll(endpoints.typeService.getAllTypeService)
      .then((res) => {
        // create new array
        const newArray = [];

        // iterate response and get only the values that are active
        res?.forEach((item) => {
          if (item?.estado === 1) {
            newArray.push({
              value: item?.idTipoServicio,
              label: item?.nombre,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));
        setService((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const formatCurrencyToRequest = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1].slice(0, 2)}`;
    }

    return formattedValue;
  };

  const formatIvaToRequest = (value) => {
    const roundedValue = Number(value).toFixed(2);
    const parts = roundedValue.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1]}`;
    }

    return formattedValue;
  };

  const getDataToMinimlTable = async (idList) => {
    toggleLoading(true);

    try {
      const res = await getAll(
        endpoints.associatePrices.getAssociatePricesByListPrice(idList),
      );

      let newArray = [];
      console.log(res);
      // iterate response and get only the values that are active
      res?.map((item) => {
        let data = {
          idTipoServicio: {
            value: item.idTipoServicioActividad.idTipoServicio.idTipoServicio,
            label: `${item.idTipoServicioActividad.idTipoServicio.nombre}`,
          },
          idUnidadMedida: {
            value: item.idUnidadMedida.idUnidadMedida,
            label: `${item.idUnidadMedida.descripcion} - ${item.idUnidadMedida.abreviatura}`,
          },
          idActividadAsociada: {
            value: item.idTipoServicioActividad.idActividad.idActividad,
            label: `${item.idTipoServicioActividad.idActividad.nombre} - ${item.idTipoServicioActividad.idActividad.sku}`,
          },
          idPrecioAsociado: item.idListaPreciosActividadDetalle,
          valor: formatCurrency(item.valor.toString()),
          impuesto: formatIvaToTable(item?.impuesto?.toString()),
          idTipoServicioActividad: item.idTipoServicioActividad.idTipoServicioActividad,
        };

        newArray.push(data);
      });

      setCurrentDataTable(newArray);
      setResultsTableSearch(newArray);
      toggleLoading(false);
      setDataTable(newArray);
    } catch (err) {
      console.error(err);
      toggleLoading(false);
    }

  }

  const getMinimalTable = async () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    const idListaPrecio = dataUpdate.idListaPreciosActividad;
    getDataToMinimlTable(idListaPrecio);

  };

  const getMinimalTableFromApi = async () => {   
    getDataToMinimlTable(id);
  };

  const getUnitMeasure = () => {
    toggleLoading(true);
    getUnidadMedida()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idUnidadMedida,
              label: `${item.descripcion} - ${item.abreviatura}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          unidadMedida: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  const handleInputCarac = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  const handleCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCostoChange = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setMinimalPrice(costoFormateado);

    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: `$${costoConDosDecimales}`,
    });
  };

  const handleIvaChange = (event) => {
    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setValueTax(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  const formatIvaToTable = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `,${parts[1]}`;
    }

    return formattedValue;
  };

  // This function is executed when the create button is clicked
  const handleSubmit = async (e) => {
    let state = 0;
    if (active) {
      state = 1;
    }
    e.preventDefault();
    let data = {
      ...formData,
      idMoneda: auxData.idMoneda.value,
      usuarioModificacion: parseInt(Cookie.get('idUsuario')),
      estado: state,
    };
    updateProduct(data);
  };
  const updateProduct = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.create.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise(() => {
          // this service create the item
          updateItem(endpoints.listPrices.updateListPrice, data)
            .then(() => {
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general'),
                text: formatterText('alert.message.associations.general'),
                confirmButtonText: formatterText('alert.button.continue'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.services),
              });
            })
            .catch((err) => {
              console.log(err);
              if (err === 412) {
                HandleOnError(formatterText('El código está repetido'));
              } else {
                HandleOnError(formatterText(err.response.data.message));
              }
            });
        });
      },
    });
  };

  const handleAddItemMinimal = (e) => {
    e.preventDefault();
    toggleLoading(true);
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    const idListaPrecio = dataUpdate.idListaPreciosActividad;
    // Comprobar con current SI EL DATO NO ESTA NULL O 0 Para poder asociar
    if (
      !(
        currentItemMinimal.valor === '$NaN' ||
        currentItemMinimal.valor === 0 ||
        typeof currentItemMinimal.valor === 'undefined'
      ) &&
      !Number.isNaN(currentItemMinimal.impuesto) &&
      auxData.idTipoServicio !== 0 &&
      !(
        auxData.idUnidadMedida.value === 0 || typeof auxData.idUnidadMedida.value === 'undefined'
      ) &&
      !(
        auxData.idActividadAsociada.value === 0 ||
        typeof auxData.idActividadAsociada.value === 'undefined'
      )
    ) {
      let filter = currentDataTable.filter(
        (item) =>
          item.idActividadAsociada.value === auxData.idActividadAsociada.value &&
          item.idUnidadMedida.value === auxData.idUnidadMedida.value,
      );
      if (filter.length >= 1) {
        toggleLoading(false);
        CustomAlert('short_msg', {
          icon: 'error',
          title: 'Oops...',
          text: formatterText('p.label.title.valorRepetido'),
        });
      } else {
        sendPut(idListaPrecio);
      }
    } else {
      toggleLoading(false);
      CustomAlert('short_msg', {
        icon: 'error',
        title: 'Oops...',
        text: formatterText('p.label.title.ingreseTodosLosDatos'),
      });
    }
  };

  const sendPut = (idListaPrecio) => {
    //Envio del primer dato, con auxData para evitar bug de version anterior
    const ACTIVITY_IDS = auxData.idActividadAsociada?.value.split('-');
    const data1 = {
      idListaPreciosActividadDetalle: null,
      idListaPreciosActividad: idListaPrecio,
      idTipoServicio: auxData.idTipoServicio.value,
      idActividad: parseInt(ACTIVITY_IDS[0]),
      idTipoServicioActividad: parseInt(ACTIVITY_IDS[1]),
      idUnidadMedida: auxData.idUnidadMedida.value,
      valor: Number(formatCurrencyToRequest(valueMinimalPrice.replace(',', '.'))),
      impuesto: formatIvaToRequest(valueTax.replace(',', '.')),
    };

    addItem(endpoints.associatePrices.addAssociate, data1)
      .then((res) => {
        setCurrentItemMinimal({
          idTipoServicio: currentItemMinimal.idTipoServicio,
          idUnidadMedida: currentItemMinimal.idUnidadMedida,
          idActividadAsociada: currentItemMinimal.idActividadAsociada,
          idPrecioAsociado: res.idListaPreciosActividadDetalle,
        });
        let data2 = {
          idTipoServicio: auxData.idTipoServicio,
          idUnidadMedida: auxData.idUnidadMedida,
          idActividadAsociada: auxData.idActividadAsociada,
          valor: `$${formatCurrencyToRequest(valueMinimalPrice.replace('.', ','))}`,
          impuesto: currentItemMinimal.impuesto,
          idPrecioAsociado: res.idListaPreciosActividadDetalle,
        };

        getMinimalTable();
        setCurrentDataTable([...currentDataTable, data2]);
        setResultsTableSearch([...currentDataTable, data2]);
        setMinimalPrice('');
        toggleLoading(false);
        setSelectedOption({
          idUnidadMedida: {
            value: 0,
            label: 'Seleccione una unidad de medida',
          },
          idTipoServicio: {
            value: 0,
            label: 'Seleccione un tipo de servicio',
          },
          idActividadAsociada: {
            value: 0,
            label: 'Seleccione una actividad asociada',
          },
        });
        setValueTax('');
        newItemCreated();
      })
      .catch((err) => {
        toggleLoading(false);
        handleRequestError(err);        
      });
  };

  //FIX ERROR SPRINT 7
  useEffect(() => {
    if (auxData.idTipoServicio !== 0) {
      setCurrentItemMinimal((prev) => ({
        ...prev,
        idActividadAsociada: 0,
      }));
      setSearchSelected((prev) => ({
        ...prev,
        actividadesServicios: [],
      }));
      setAuxData((prev) => ({
        ...prev,
        idActividadAsociada: 0,
      }));
      getAllActivitiesById(auxData.idTipoServicio);
    }
  }, [auxData.idTipoServicio]);

  // Get all type service by id category service
  const getAllActivitiesById = (selectValue) => {
    // Set the value of datas into []
    getItemById(
      endpoints.typoServiceActivities.getTypeServiceActivitiesByTypeService,
      selectValue.value,
    )
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: `${item.idActividad.idActividad}-${item.idTipoServicioActividad}`,
            label: `${item.idActividad.nombre} - ${item.idEtapaServicio.nombre}`,
            isFixed: true,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          actividadesServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  //CUSTOM STYLES
  const customStyles = {
    control: (base) => ({
      ...base,
      border: '0px !important',
      'font-family': 'inherit',
      'font-size': '14px',
      height: '40px',
      padding: '0 6px',
      'max-width': '100%',
      'min-width': '225px',
      'box-shadow': '0px 4px 8px rgba(0, 174, 142, 0.2)',
      'border-radius': '70px !important',
    }),
  };
  const [selectedOption, setSelectedOption] = useState({
    idUnidadMedida: {
      value: null,
      label: 'Seleccione una unidad de medida',
    },
    idTipoServicio: {
      value: null,
      label: 'Seleccione un tipo de servicio',
    },
    idActividadAsociada: {
      value: null,
      label: 'Seleccione una actividad asociada',
    },

    impuesto: {
      value: null,
      label: 'Seleccione un impuesto asociado',
    },
  });

  const formatIvaField = (value) => {
    return `${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  const formatCurrency = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `$${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `,${parts[1]}`;
    }

    return formattedValue;
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          <p className="wrap-form-title">{formatterText('p.label.title.price.list')}</p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.price.list.name')}</h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleInputCarac}
                placeholder={formatterText('p.label.title.price.list.name')}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.currency')}</h3>
              <Selector
                customStyles={customStyles}
                name="idMoneda"
                data={selectedSearch.tipoMonedas}
                placeholder={`${printMoneda?.idMoneda?.nombre} - ${printMoneda?.idMoneda?.codigo}`}
                dataValue={auxData.idMoneda}
                setterFunction={setAuxData}
                isLoading={loading}
                selectValue={auxData.idMoneda}
                isRequired={false}
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.descripcion')}</h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('p.label.title.descripcionProducto')}
                maxLength="200"
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.codigo')}</h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handleCode}
                placeholder={formatterText('p.label.title.ingresaCaracteres')}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.state')}</h3>
              <label className="form-responsive-label">
                <p className="form-responsive-toggle">{active ? 'Activo' : 'No activo'}</p>
                <label className="switch">
                  <input
                    checked={active ? true : false}
                    onChange={() => {
                      setActive(!active);
                    }}
                    type="checkbox"
                  />
                  <span className="slider round"></span>
                </label>
              </label>
            </section>
          </section>
          {!loading
            ? currentDataTable.length > 0 && (
              <>
                <p className="wrap-form-title">{formatterText('p.label.title.preciosAsociados')}</p>
                <section className="form-responsive-container-information">
                  <Table
                    titles={titlesTableCostProduct}
                    data={currentDataTable}
                    type="associatePrices"
                    handleOpen={handleOpen}
                    labelTable={formatterText('p.label.title.listaPrecios')}
                    canSearch={true}
                    isEdit={true}
                  />
                </section>
              </>
            )
            : error
              ? displayMessage(
                'error',
                'Ha ocurrido un error, intentalo más tarde.',
                'toast.error.general',
              )
              : displayLoading()}
          <p className="wrap-form-title">{formatterText('p.label.title.asociarPrecio')}</p>
          <section
            className="grid-container-2c"
            style={{
              width: '95%',
              margin: '0 auto',
            }}
          >
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.tipoServicio')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idTipoServicio: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idTipoServicio: selectedOption,
                    }));
                  }}
                  value={selectedOption.idTipoServicio}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.tipoServicio}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.actividadAsociada')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idActividadAsociada: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idActividadAsociada: selectedOption,
                    }));
                  }}
                  value={selectedOption.idActividadAsociada}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.actividadesServicios}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.unidadMedida')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idUnidadMedida: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idUnidadMedida: selectedOption,
                    }));
                  }}
                  value={selectedOption.idUnidadMedida}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.unidadMedida}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.valor')}</span>
              <section className="w100-container">
                <input
                  name="valor"
                  defaultValue={valueMinimalPrice}
                  className="input-default-3c"
                  type="text"
                  value={formatCurrency(valueMinimalPrice)}
                  onChange={handleCostoChange}
                  placeholder={formatterText('p.label.title.valor')}
                  maxLength="20"
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.impuesto')}</span>
              <section className="w100-container">
                <input
                  name="impuesto"
                  defaultValue={valueTax}
                  className="input-default-3c"
                  type="text"
                  value={formatIvaField(valueTax)}
                  onChange={handleIvaChange}
                  placeholder={formatterText('p.label.title.impuesto')}
                  maxLength="20"
                />
              </section>
            </label>
          </section>
          <section className="form-responsive-container-buttons">
            <input
              onClick={handleAddItemMinimal}
              type="button"
              className="btn-primary btn-primary-center"
              value="Asociar precio"
            />
          </section>
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            {formatterText('p.label.title.actualizarListaPrecios')}
          </button>
          <button className="input-cancel" type="cancel" onClick={() => navigate(paths.services)}>
           {formatterText('p.label.title.cancelar')}
          </button>
        </section>
      </form>
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <UpdateModalItem
          dataTypeService={selectedSearch.tipoServicio}
          typeService={service}
          dataUnits={selectedSearch.unidadMedida}
          onClose={handleClose}
          refetch={getMinimalTable}
          valueTax={valueTax}
          setResultsTableSearch={setResultsTableSearch}
          auxData={auxData}
          setAuxData={setAuxData}
        />
      </Modal>
    </>
  );
}
