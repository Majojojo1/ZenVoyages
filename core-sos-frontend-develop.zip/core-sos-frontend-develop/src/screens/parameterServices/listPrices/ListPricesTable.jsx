import React, { useContext, useEffect } from 'react';
import { FormattedMessage } from 'react-intl';
///Imports para la tabla dinamica
import { useSeachContext } from 'context/SearchContext';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
// hook para cargar los datos
import useGetData from 'hooks/useGetData';
// // Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { TableMinimalContext } from 'context/TableMinimalContext';
import useLangv2 from 'hooks/useLangv2';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const ListPricesTable = ({permisos}) => {
  const { formatterText, handleRequestError } = useLangv2();

  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setCurrentDataTable, setResultsTableSearch } = useContext(TableMinimalContext);
  const { setDataTable, setSearchResults } = useSeachContext();

  const titles = [
    formatterText('tab.title.pricelist.name', 'Nombre'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.currency', 'Moneda'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  // función para cargar datos
  const getDataTable = () => { 
    getAll(endpoints.listPrices.getAllListPrices)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        newArray.sort((a, b) => (a.nombre.toLowerCase() > b.nombre.toLowerCase() ? 1 : -1));
        setDataTable(newArray);       
      
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.listPrices.deleteListPrice, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    let data = {
      ...body,
      codigo: body.codigo,
      descripcion: body.descripcion,
      estado: body.estado,
      idListaPreciosActividad: body.idListaPreciosActividad,
      idMoneda: body.idMoneda.idMoneda,
      nombre: body.nombre,
      usuarioModificacion: body.usuarioModificacion,
    };

    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.listPrices.updateListPrice, data)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idListaPreciosActividad,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      moneda: `${item.idMoneda.nombre} - ${item.idMoneda.codigo}`,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  return (
    <>
      {!loading ? (     
          <FormattedMessage id="table.name.search.product" defaultMessage="Categoría de producto">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Precios}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateListPriceService}
                canDeleted={permisos.eliminar}
                canModify={permisos.editar}
              />
            )}
          </FormattedMessage>
       
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ListPricesTable;
