import Selector from 'common/selects/Selector';
import rawCurrency from 'common/utils/rawCurrency';
import HandleOnError from 'common/validators/HandleOnError';
import CustomToast from 'components/CustomToast';
import { useSeachContext } from 'context/SearchContext';
import { TableMinimalContext } from 'context/TableMinimalContext';
import useGetData from 'hooks/useGetData';
import useLang from 'hooks/useLang';
import useLangv2 from 'hooks/useLangv2';
import Cookie from 'js-cookie';
import React, { useContext, useEffect, useState } from 'react';
import endpoints from 'services/api';
import { getItemById, updateItem } from 'services/api/methods';

export default function UpdateModalItem({
  dataTypeService,
  dataUnits,
  onClose,
  refetch = null,
  typeService,
  valueTax,
  setResultsTableSearch,
}) {
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idPrecioAsociado: '',

    idTipoServicio: '',
    label_idTipoServicio: '',

    idActividadAsociada: '',
    label_idActividadAsociada: '',

    idUnidadMedida: '',
    label_idUnidadMedida: '',

    idListPrice: '',
    valor: '',
  });
  // useLanguage
  const { formatterText } = useLang();
  const { updatedItem } = useLangv2();

  const { toggleLoading, } = useGetData();

  const { OnMessage } = CustomToast();
  const { modalData, setModalData, currentDataTable, setCurrentDataTable } = useContext(TableMinimalContext);

  const { dataTable, setDataTable } = useSeachContext();

  // espera a que cargue los valores del multiselect
  const [auxData, setAuxData] = useState({
    idTipoServicio: 0,
    idActividadAsociada: 0,
    idUnidadMedida: 0,
  });
  const [valueMinimalPriceModal, setMinimalPriceModal] = useState('');
  const [valueTaxModal, setValueTaxModal] = useState('');
  const [selectedSearch, setSearchSelected] = useState([
    {
      tipoServicio: [],
      actividadAsociada: [],
      unidadMedida: [],
      valor: 0,
    },
  ]);
  //  create useEffect clean function
  useEffect(() => {
    setCurrentItemMinimal({
      idPrecioAsociado: modalData?.idPrecioAsociado,

      idTipoServicio: modalData?.idTipoServicio.value,
      label_idTipoServicio: modalData.idTipoServicio.label,

      idActividadAsociada: modalData?.idActividadAsociada.value,
      label_idActividadAsociada: modalData.idActividadAsociada.label,

      idUnidadMedida: modalData?.idUnidadMedida.value,
      label_idUnidadMedida: modalData?.idUnidadMedida.label,

      valor: modalData.valor,
      idListPrice: modalData.idListPrice ? modalData.idListPrice : '',
    });
    setAuxData({
      idTipoServicio: {
        value: modalData.idTipoServicio.value,
        label: modalData.idTipoServicio.label,
      },
      idActividadAsociada: {
        value: modalData.idActividadAsociada.value,
        label: modalData.idActividadAsociada.label,
      },
      idUnidadMedida: {
        value: modalData.idUnidadMedida.value,
        label: modalData.idUnidadMedida.label,
      },
    });
    setMinimalPriceModal(modalData?.valor?.replace('$', '')?.replace(/\./g, ''));
    setValueTaxModal(modalData?.impuesto?.toString());
  }, []);

  useEffect(() => {
    if (auxData.idTipoServicio !== 0) {
      getAllActivitiesById(auxData.idTipoServicio);
    }
  }, [auxData.idTipoServicio]);

  // Get all type service by id category service
  const getAllActivitiesById = (selectValue) => {
    // Set the value of datas into []
    getItemById(
      endpoints.typoServiceActivities.getTypeServiceActivitiesByTypeService,
      selectValue.value,
    )
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: `${item.idActividad.idActividad}-${item.idTipoServicioActividad}`,
            label: `${item.idActividad.nombre}`,
            isFixed: true,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          actividadesServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const handleUpdateModalData = (e) => {
    e.preventDefault();
    if (modalData.valor !== '') {
      if (typeof modalData.idPrecioAsociado === 'number') {
        putStructure();
      } else {
        putStructureOnCreate();
      }
    } else {
      console.error('Debes completar todos los campos');
    }
  };

  console.log(currentItemMinimal);


  const putStructureOnCreate = () => {
    // Filter if the current modal data have the same id
    const filterId = currentDataTable.filter(
      (item) => item.idActividadAsociada.value !== modalData?.idActividadAsociada.value,
    );   

    const { idTipoServicio, idUnidadMedida, idActividadAsociada } = auxData;
    console.log(auxData);
    const isDuplicate = currentDataTable.some(
      (item) =>
        item.idActividadAsociada.value === idActividadAsociada &&
        item.idUnidadMedida.value === idUnidadMedida,
    );
    const updatedItemData = {
      idPrecioAsociado: currentItemMinimal.idPrecioAsociado,
      idTipoServicio: idTipoServicio,
      idUnidadMedida: idUnidadMedida,
      idActividadAsociada: idActividadAsociada,
      valor: `$${formatCurrencyFromModalToTable(currentItemMinimal.valor.replace('.', ',').replace('$', ''))}`,
      impuesto: formatCurrencyFromModalToTable(valueTaxModal.replace(',', '.')),
    };

    if (!isDuplicate) {
      setDataTable([...filterId, updatedItemData]);
      setCurrentDataTable([...filterId, updatedItemData]);
      setResultsTableSearch([dataTable]);
      updatedItem();
      onClose();
    } else {
      CustomAlert('short_msg', {
        icon: 'error',
        title: 'Oops...',
        text: 'Existe algun valor repetido ya asociado en la tabla, intentelo nuevamente',
      });
    }
  };

  const displayToast = (type, msg) => {
    OnMessage(type, msg);
  };

  const putStructure = () => {
    const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
    const idListaPrecio = dataUpdate.idListaPreciosActividad;
    currentDataTable.forEach((item) => {
      if (item.idPrecioAsociado === modalData.idPrecioAsociado) {
        const ACTIVITY_IDS =
          typeof auxData.idActividadAsociada?.value === 'string'
            ? auxData.idActividadAsociada.value.split('-')
            : modalData.idActividadAsociada.value;

        let data = {
          idListaPreciosActividadDetalle: modalData.idPrecioAsociado,
          idListaPreciosActividad: idListaPrecio,
          idTipoServicio: auxData.idTipoServicio.value,
          idActividad: parseInt(ACTIVITY_IDS[0]) || modalData.idActividadAsociada.value,
          idTipoServicioActividad: parseInt(ACTIVITY_IDS[1]) || modalData.idTipoServicioActividad,
          idUnidadMedida: auxData.idUnidadMedida.value,
          valor: parseFloat(rawCurrency(currentItemMinimal.valor)),
          impuesto: formatCurrencyFromModalToTable(valueTaxModal.replace(',', '.')),

          fechaCreacion: new Date(),
          usuarioCreacion: parseInt(Cookie.get('idUsuario')),
          usuarioModificacion: parseInt(Cookie.get('idUsuario')),
        };
        // aqui se llama el servicio para editar
        updateItem(endpoints.associatePrices.updateAssociate, data)
          .then((res) => {
            let data2 = {
              idTipoServicio: res.idTipoServicio,
            };
            setCurrentDataTable([...currentDataTable, data2]);
            setResultsTableSearch([...currentDataTable, data2]);
            updatedItem();

            refetch && refetch();
            onClose();
            displayToast('success', 'Se actualizó el registro correctamente.');
          })
          .catch((err) => {
            if ((err.response.status === 400)) {
              toggleLoading(false);
              HandleOnError(formatterText(err.response.data.message));
            } else {
              HandleOnError(formatterText('alert.message.failed.general'));
            }
          });
      }
    });
  };
  // Get all type service by id category service
  const [selectedOption, setSelectedOption] = useState({
    idUnidadMedida: {
      value: null,
      label: 'Seleccione una unidad de medida',
    },
    idTipoServicio: {
      value: null,
      label: 'Seleccione un tipo de servicio',
    },
    idActividadAsociada: {
      value: null,
      label: 'Seleccione una actividad asociada',
    },

    impuesto: {
      value: null,
      label: 'Seleccione un impuesto asociado',
    },
  });

  // update the form number
  const handleNumber = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setMinimalPriceModal(costoFormateado);
    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: costoConDosDecimales,
    });
  };

  const formatCurrencyFromModal = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1]}`;
    }
    const splitDecimal = formattedValue.split(',');
    const intPart = splitDecimal[0];
    const floatPart = splitDecimal[1];

    if(floatPart)
    {
      formattedValue = intPart + ',' + floatPart.substring(0, 2);
    }

    return formattedValue;
  };

  const handleIvaChange = (event) => {
    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setValueTaxModal(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  const formatIvaField = (event) => {
    console.log('valor',event.target.value)
    const valor= `${event.target.value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
    console.log(valor)
    event.target.value=valor
  };

  const formatCurrencyFromModalToTable = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1].slice(0, 2)}`;
    }

    return formattedValue;
  };

  return (
    <form className="form-responsive" onSubmit={handleUpdateModalData}>
      <section className="form-responsive-container-information">
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.label.title.tipoServicio')}</h3>
          <Selector
            name="idTipoServicio"
            onChange={(selectedOption) => {
              setSelectedOption((prev) => ({
                ...prev,
                idTipoServicio: selectedOption,
              }));
              setAuxData((prev) => ({
                ...prev,
                idTipoServicio: selectedOption,
              }));
            }}
            data={typeService?.tipoServicio}
            placeholder="Seleccione otro tipo de servicio"
            dataValue={auxData}
            setterFunction={setAuxData}
            selectValue={auxData.idTipoServicio}
            isRequired={false}
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.label.title.actividadAsociada')}</h3>
          <Selector
            name="idActividadAsociada"
            data={selectedSearch.actividadesServicios}
            placeholder={currentItemMinimal.label_idActividadAsociada}
            dataValue={auxData}
            onChange={(selectedOption) => {
              setSelectedOption((prev) => ({
                ...prev,
                idActividadAsociada: selectedOption,
              }));
              setAuxData((prev) => ({
                ...prev,
                idActividadAsociada: selectedOption,
              }));
            }}
            setterFunction={setAuxData}
            selectValue={auxData.idActividadAsociada}
            isRequired={false}
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.label.title.unidadMedida')}</h3>
          <Selector
            name="idUnidadMedida"
            onChange={(selectedOption) => {
              setSelectedOption((prev) => ({
                ...prev,
                idUnidadMedida: selectedOption,
              }));
              setAuxData((prev) => ({
                ...prev,
                idUnidadMedida: selectedOption,
              }));
            }}
            data={dataUnits}
            placeholder={currentItemMinimal.label_idUnidadMedida}
            dataValue={auxData}
            setterFunction={setAuxData}
            selectValue={auxData.idUnidadMedida}
            isRequired={false}
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.label.title.valor')}</h3>
          <input
            className="input-primary"
            type="text"
            name="valor"
            value={formatCurrencyFromModal(valueMinimalPriceModal)}
            onChange={handleNumber}
            placeholder="Valor"
            maxLength="20"
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.label.title.impuesto')}</h3>
          <input
            className="input-primary"
            type="text"
            name="iva"
            onChange={handleIvaChange}
            maxLength="6"
            onBlur={formatIvaField}
            value={valueTaxModal}
          />
        </label>
        <input
          type="submit"
          className="width-100-fix"
          value={formatterText('p.label.title.updateList')}
          onClick={handleUpdateModalData}
        />
        <input
          type="button"
          className="width-100-fix input-cancel"
          value={formatterText('p.label.title.cancelar')}
          onClick={onClose}
        />
      </section>
    </form>
  );
}
