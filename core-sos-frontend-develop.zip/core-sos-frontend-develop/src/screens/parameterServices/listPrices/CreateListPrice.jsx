import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLang from 'hooks/useLang';
import { useNavigate } from 'react-router-dom';
// Import Components
import Table from 'common/minimalTables/TableMinimal';
import Selector from 'common/selects/Selector';
import defaultSelect from 'common/selects/default.select.style';
import HandlerText from 'common/validators/HandlerText';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { TEXTREGEXMIN, SPACING } from 'common/validators/Regex';
import { validateDuplicateCode } from 'common/validators/ValidateDuplicates';
import { Modal } from 'react-responsive-modal';

import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import UpdateModalItem from './UpdateModalItem';
// Import Libs
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Select from 'react-select';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import Services
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { getUnidadMedida } from 'services/api/institutions';
import { addItem, getAll, getItemById } from 'services/api/methods';
import paths from 'services/paths';



export default function CreateProduct() {
  return (
    <SearchWrapper>
      <CreateProductComponent />
    </SearchWrapper>
  );
}

function CreateProductComponent() {
  // Modal config
  const [open, setOpen] = useState(false);
  const [valueMinimalPrice, setMinimalPrice] = useState('');
  const [valueTax, setValueTax] = useState('');

  // Call context TableMinimalContext
  const {
    currentDataTable = [],
    setCurrentDataTable,
    setResultsTableSearch,
  } = useContext(TableMinimalContext);

  const { dataTable, setDataTable, setSearchResults } = useSeachContext();

  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();
  const titlesTableCostProduct = [
    formatterText('p.label.title.tipoServicio'),
    formatterText('p.label.title.actividadAsociada'),
    formatterText('p.label.title.unidadMedida'),
    formatterText('p.label.title.valor'),
    formatterText('p.label.title.impuesto'),
    formatterText('p.label.title.acciones'),
  ];
  // Example of form data
  const [formData, setFormData] = useState({
    nombre: '',
    codigo: '',
  });
  const [currentItemMinimal, setCurrentItemMinimal] = useState({
    idPrecioAsociado: uuidv4(),
    idTipoServicio: 0,
    idActividadAsociada: 0,
    valor: 0,
    impuesto: 0,
    idUnidadMedida: 0,
  });
  // Los valores que usará el select
  const [selectedSearch, setSearchSelected] = useState([
    {
      tipoServicio: [],
      actividadAsociada: [],
      unidadMedida: [],
      valor: 0,
      actividadesServicios: [],
    },
  ]);

  const [auxData, setAuxData] = useState({
    idTipoServicio: 0,
    idActividadAsociada: 0,
    valor: 0,
    idUnidadMedida: 0,
    idMoneda: 0,
  });

  // espera a que cargue los valores del multiselect
  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();

  const [selectedOption, setSelectedOption] = useState({
    idUnidadMedida: {
      value: null,
      label: formatterText('p.label.title.seleccioneUnidadMedida'),
    },
    idTipoServicio: {
      value: null,
      label: formatterText('p.label.title.seleccioneTipoServicio'),
    },
    idActividadAsociada: {
      value: null,
      label: formatterText('p.label.title.seleccioneActividadAsociada'),
    },
  });

  const [service, setService] = useState([]);

  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  useEffect(() => {
    getMonedas();
    getUnitMeasure();
    getTypeService();
  }, []);

  const getMonedas = () => {
    toggleLoading(true);
    getAll(endpoints.listPrices.getAllMonedas)
      .then((res) => {
        let newArray = [];
        // iterate response and get only the values that are active
        res.map((item) => {
          let data = {
            value: item.idMoneda,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          };
          return newArray.push(data);
        });
        setSearchSelected((prev) => ({
          ...prev,
          tipoMonedas: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };
  const getUnitMeasure = () => {
    toggleLoading(true);
    getUnidadMedida()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idUnidadMedida,
              label: `${item.descripcion} - ${item.abreviatura}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          unidadMedida: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getTypeService = () => {
    toggleLoading(true);
    getAll(endpoints.typeService.getAllTypeService)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idTipoServicio,
              label: `${item.nombre}`,
              isFixed: true,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));
        setService((prev) => ({
          ...prev,
          tipoServicio: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const formatCurrencyToRequest = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1].slice(0, 2)}`;
    }

    return formattedValue;
  };

  const formatIvaToRequest = (value) => {
    const roundedValue = Number(value).toFixed(2);
    const parts = roundedValue.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1]}`;
    }
    return formattedValue;
  };

  const getAllActivitiesById = (selectValue) => {
    // Set the value of datas into []
    getItemById(
      endpoints.typoServiceActivities.getTypeServiceActivitiesByTypeService,
      selectValue.value,
    )
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          newArray.push({
            value: `${item.idActividad.idActividad}-${item.idTipoServicioActividad}`,
            label: `${item.idActividad.nombre} - ${item.idEtapaServicio.nombre}`,
            isFixed: true,
          });
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          actividadesServicios: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  const handleCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handleInputCarac = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCostoChange = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setMinimalPrice(costoFormateado);

    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: `$${costoConDosDecimales}`,
    });
  };

  const handleIvaChange = (event) => {
    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setValueTax(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrentItemMinimal({
      ...currentItemMinimal,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    let data = {
      ...formData,
      idMoneda: auxData.idMoneda.value,
      usuarioCreacion: Cookie.get('idUsuario'),
    };
    if (
      validateDuplicateCode(formData.codigo, 'Codigo ya existente', () =>
        getAll(endpoints.listPrices.getAllListPrices),
      )
    ) {
      createProduct(data);
    }
  };

  const createProduct = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.create.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addItem(endpoints.listPrices.addListPrice, data)
            .then((res) => {
              // aqui se llama el servicio para asociar el producto con el proveedor
              associateSinglePrice(res.idListaPreciosActividad, resolve, reject);
            })
            .catch((err) => {
              reject(HandleOnError(formatterText('alert.message.failed.general')));
              console.error(err);
            });
        });
      },
    });
  };

  const associateSinglePrice = (id, resolve, reject) => {
    // FIX: associations
    if (dataTable.length >= 1) {
      const promesas = dataTable.map(
        (item) =>
          new Promise((resl, rej) => {
            const ACTIVITY_IDS = item.idActividadAsociada?.value.split('-');
            let data = {
              idListaPreciosActividadDetalle: null,
              idListaPreciosActividad: id,
              idTipoServicio: item.idTipoServicio.value,
              idActividad: parseInt(ACTIVITY_IDS[0]),
              idTipoServicioActividad: parseInt(ACTIVITY_IDS[1]),
              idUnidadMedida: item.idUnidadMedida.value,
              valor: parseFloat(formatCurrencyToRequest(item.valor.replace('$', '').replace(/,/g, '').slice(0, -2)) + '.'
                + parseFloat(formatCurrencyToRequest(item.valor.replace('$', '').slice(-2)))),
              impuesto: Number(formatIvaToRequest(item.impuesto.replace(',', '.'))),
            };
            addItem(endpoints.associatePrices.addAssociate, data)
              .then((res) => {
                setCurrentItemMinimal({
                  idTipoServicio: currentItemMinimal.idTipoServicio,
                  idUnidadMedida: currentItemMinimal.idUnidadMedida,
                  idActividadAsociada: currentItemMinimal.idActividadAsociada,
                  idPrecioAsociado: res.idListaPreciosActividadDetalle,
                });
                setCurrentDataTable([...currentDataTable, data]);
                setResultsTableSearch([...currentDataTable, data]);
                setMinimalPrice('');
                resl(res);
                toggleLoading(false);
              })
              .catch((err) => {
                rej(err);
              });
          }),
      );
      Promise.all(promesas)
        .then((_) => {
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general'),
            text: formatterText('alert.message.associations.general'),
            confirmButtonText: formatterText('alert.button.continue'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.services),
          });
        })
        .catch((err) => {
          if (err.response.status === 412 || err.response.status === 400) {
            HandleOnError(err.response.data);
          } else {
            HandleOnError(formatterText('alert.message.failed.general'));
          }
          console.error(err);
        });
    } else {
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: formatterText('alert.title.confirm.general'),
        text: formatterText('alert.message.associations.general'),
        confirmButtonText: formatterText('alert.button.continue'),
        allowOutsideClick: false,
        executeFunction: () => navigate(paths.services),
      });
    }
  };

  const clearFields = () => {
    const defaultOptionUnitMedida = {
      value: 0,
      label: formatterText('p.label.title.seleccioneUnidadMedida'),
    };

    const defaultOptionServicio = {
      value: 0,
      label: formatterText('p.label.title.seleccioneTipoServicio'),
    };

    const defaultOptionActivity = {
      value: 0,
      label: formatterText('p.label.title.seleccioneActividadAsociada'),
    };

    setSelectedOption({
      idUnidadMedida: defaultOptionUnitMedida,
      idTipoServicio: defaultOptionServicio,
      idActividadAsociada: defaultOptionActivity,
    });
    setValueTax('');
    setMinimalPrice('');
  };

  const updateDataTables = (newDataRow, newItemMinimal) => {
    setCurrentDataTable((prevDataTable) => [...prevDataTable, newDataRow]);

    setCurrentItemMinimal(newItemMinimal);

    setResultsTableSearch({ ...newDataRow, idPrecioAsociado: uuidv4() });
    setDataTable([...dataTable, newDataRow]);
    setSearchResults([...currentDataTable, { ...newItemMinimal, ...newDataRow }]);
  };
  const handleAddItemMinimal = () => {
    const { idTipoServicio, idUnidadMedida, idActividadAsociada } = auxData;
    const { valor: currentItemValor, impuesto: currentItemImpuesto } = currentItemMinimal;

    const isValidInput =
      currentItemValor &&
      currentItemImpuesto &&
      idTipoServicio &&
      idUnidadMedida &&
      idActividadAsociada;

    if (isValidInput) {
      clearFields();
      const isDuplicate = dataTable.some(
        (item) =>
          item.idActividadAsociada.value === idActividadAsociada.value &&
          item.idUnidadMedida.value === idUnidadMedida.value &&
          item.idTipoServicio.value === idTipoServicio.value,
      );

      if (isDuplicate) {
        CustomAlert('short_msg', {
          icon: 'error',
          title: 'Oops...',
          text: formatterText('p.label.title.valorRepetido'),
        });
      } else {
        const formattedValue = `${formatCurrencyToRequest(currentItemValor.replace('.', ','))}`;
        const formattedTax = formatIvaToRequest(valueTax.replace(',', '.'));

        const newDataRow = {
          idTipoServicio,
          idActividadAsociada,
          idUnidadMedida,
          valor: formattedValue,
          impuesto: formattedTax,
        };

        const newItemMinimal = {
          ...currentItemMinimal,
          idTipoServicio,
          idUnidadMedida,
          idActividadAsociada,
          idPrecioAsociado: uuidv4(),
          valor: formattedValue,
        };

        // Actualiza currentDataTable utilizando una función de actualización
        updateDataTables(newDataRow, newItemMinimal);
      }
    } else {
      CustomAlert('short_msg', {
        icon: 'error',
        title: 'Oops...',
        text:formatterText('p.label.title.ingreseTodosLosDatos')
      });
    }
  };

  //FIX Sprint 7
  useEffect(() => {
    if (auxData.idTipoServicio !== 0) {
      setCurrentItemMinimal((prev) => ({
        ...prev,
        idActividadAsociada: 0,
      }));
      setSearchSelected((prev) => ({
        ...prev,
        actividadesServicios: [],
      }));
      setAuxData((prev) => ({
        ...prev,
        idActividadAsociada: 0,
      }));
      getAllActivitiesById(auxData.idTipoServicio);
    }
  }, [auxData.idTipoServicio]);

  const formatIvaField = (value) => {
    return `${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  const formatCurrency = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `$${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `,${parts[1]}`;
    }

    return formattedValue;
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          <p className="wrap-form-title">{formatterText('p.label.title.price.list')}</p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.price.list.name')}</h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleInputCarac}
                placeholder={formatterText('p.label.title.price.list.name')}
                maxLength="45"
                required
              />
            </section>

            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.currency')}</h3>
              <Selector
                name="idMoneda"
                data={selectedSearch.tipoMonedas}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.select"
                    defaultMessage="Selecione una opción"
                  />
                }
                dataValue={auxData.idMoneda}
                setterFunction={setAuxData}
                isLoading={loading}
                selectValue={auxData.idMoneda}
                isRequired={true}
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.descripcion')}</h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('p.label.title.descripcionProducto')}
                maxLength="200"
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('p.label.title.codigo')}</h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handleCode}
                placeholder={formatterText('p.label.title.ingresaCaracteres')}
                maxLength="45"
                required
              />
            </section>
          </section>
          {!loading
            ? dataTable.length > 0 && (
              <>
                <p className="wrap-form-title">{formatterText('p.label.title.preciosAsociados')}</p>
                <section className="form-responsive-container-information">
                  <Table
                    titles={titlesTableCostProduct}
                    data={dataTable}
                    type="associatePrices"
                    labelTable={formatterText('p.label.title.listaPrecios')}
                    handleOpen={handleOpen}
                    canSearch={true}
                    isEdit={true}
                  />
                </section>
              </>
            )
            : error
              ? displayMessage(
                'error',
                'Ha ocurrido un error, intentalo más tarde.',
                'toast.error.general',
              )
              : displayLoading()}
          <p className="wrap-form-title">{formatterText('p.label.title.asociarPrecio')}</p>

          <section
            className="grid-container-2c"
            style={{
              width: '95%',
              margin: '0 auto',
            }}
          >
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.tipoServicio')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idTipoServicio: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idTipoServicio: selectedOption,
                    }));
                  }}
                  value={selectedOption.idTipoServicio}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.tipoServicio}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.actividadAsociada')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idActividadAsociada: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idActividadAsociada: selectedOption,
                    }));
                  }}
                  value={selectedOption.idActividadAsociada}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.actividadesServicios}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.unidadMedida')}</span>
              <section className="w100-container">
                <Select
                  styles={defaultSelect}
                  onChange={(selectedOption) => {
                    setSelectedOption((prev) => ({
                      ...prev,
                      idUnidadMedida: selectedOption,
                    }));
                    setAuxData((prev) => ({
                      ...prev,
                      idUnidadMedida: selectedOption,
                    }));
                  }}
                  value={selectedOption.idUnidadMedida}
                  noOptionsMessage={() => formatterText('select.placeholder.no.options')}
                  options={selectedSearch.unidadMedida}
                  placeholder={
                    loading ? (
                      <FormattedMessage id="input.loading" defaultMessage="Cargando..." />
                    ) : (
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    )
                  }
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.valor')}</span>
              <section className="w100-container">
                <input
                  name="valor"
                  // defaultValue={valueMinimalPrice}
                  className="input-default-3c"
                  type="text"
                  value={formatCurrency(valueMinimalPrice)}
                  onChange={handleCostoChange}
                  placeholder={formatterText('p.label.title.valor')}
                  maxLength="20"
                />
              </section>
            </label>
            <label className="d-flex">
              <span className="text-inline">{formatterText('p.label.title.impuesto')}</span>
              <section className="w100-container">
                <input
                  name="impuesto"
                  // defaultValue={valueTax}
                  className="input-default-3c"
                  type="text"
                  value={formatIvaField(valueTax)}
                  onChange={handleIvaChange}
                  placeholder={formatterText('p.label.title.impuesto')}
                  maxLength="20"
                />
              </section>
            </label>
          </section>
          <section className="form-responsive-container-buttons">
            <input
              onClick={handleAddItemMinimal}
              type="button"
              className="btn-primary btn-primary-center"
              value={formatterText('p.label.button.asociarPrecio')}
            />
          </section>
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            {formatterText('p.label.title.crearListaPrecios')}
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.services)}>
            {formatterText('p.label.title.cancelar')}
          </button>
        </section>
      </form>
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <UpdateModalItem
          dataTypeService={selectedSearch.tipoServicio}
          typeService={service}
          dataUnits={selectedSearch.unidadMedida}
          onClose={handleClose}
          valueTax={valueTax}
          setResultsTableSearch={setResultsTableSearch}
          auxData={auxData}
          setAuxData={setAuxData}
        />
      </Modal>
    </>
  );
}
