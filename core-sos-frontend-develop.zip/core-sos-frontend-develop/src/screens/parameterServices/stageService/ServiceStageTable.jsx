import React, { useEffect } from 'react';
// Import Context
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import SortData from 'components/utils/SortData';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods/index';
import paths from 'services/paths';


const ServiceStageTable = ({permisos}) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  // función para cargar datos
  const getDataTable = () => {   
    getAll(endpoints.stageServices.getAllStageServices).then((data) => {
      let newArray = [];
      data.forEach((item) => {
        handleStructureItems(newArray, item);
      });
      const sortedArray = SortData(newArray, 'asc');
      setDataTable(sortedArray);
     
      
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.stageServices.deleteStageService, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          const sortedArray = SortData(newArray, 'asc');
          setDataTable(sortedArray);

          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.stageServices.updateStageService, body)
        .then((res) => {          
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: parseInt(item.idEtapaServicio),
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      color: item.color,
      estado: parseInt(item.estado),
      objeto: { ...item },
    });
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const titles = [
    formatterText('table.title.service.stage', 'Nombre etapa de servicio'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.color', 'Color'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading ? (
       
          <FormattedMessage
            id="table.name.search.productCategory"
            defaultMessage="Categoría de producto"
          >
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Etapas}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateStageService}
                canDeleted={permisos.eliminar}
                canModify={permisos.editar}
              />
            )}
          </FormattedMessage>
       
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ServiceStageTable;
