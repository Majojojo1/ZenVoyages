import HandlerText from "common/validators/HandlerText";
import CustomAlert from "components/CustomAlert";
// import useLang from "hooks/useLang";
import useLangv2 from "hooks/useLangv2";
import Cookie from "js-cookie";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import paths from "services/paths";
import Swal from "sweetalert2";
// Call service
import endpoints from "services/api";
import { getItemById, updateItem } from "services/api/methods";
// Picker imports
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, SPACING, TEXTREGEXMIN } from "common/validators/Regex";
import hexRgb from "hex-rgb";
import { SketchPicker } from "react-color";
import { FormattedMessage } from "react-intl";
import "styles/colorPicker.css";

export default function UpdateStage() {
  const navigate = useNavigate();
  // toggle state
  const [active, setActive] = useState(true);
  // useLanguage (update to v2)
  // const { formatterText } = useLang();

  // use Hook of language v2
  const { formatterText, resourceNotFound } = useLangv2();
  // Example of form data
  const [formData, setFormData] = useState([]);
  // Stage of the picker
  const [colorHexCode, setColorHexCode] = useState("#000000");
  // RBG color
  const [colorRGB, setColorRGB] = useState({
    red: 0,
    green: 0,
    blue: 0,
    alpha: 1,
  });
  // Stage of the container picker
  const [displayColorPicker, setDisplayColorPicker] = useState(false);
  const { id } = useParams();

  useEffect(() => {
    getStageById(id);
  }, [id]);

  useEffect(() => {
    getDataToUpdate();
  }, []);

  const getDataToUpdate = () => {
    const dataUpdate = JSON.parse(localStorage.getItem("dataUpdate"));

    if (dataUpdate) {
      setFormData({
        ...dataUpdate,
        id: dataUpdate.id,
        nombre: dataUpdate.nombre,
        descripcion: dataUpdate.descripcion,
        codigo: dataUpdate.codigo,
        estado: dataUpdate.estado,
      });
      setColorHexCode(dataUpdate.color);
      setActive(dataUpdate.estado);
      setColorRGB(hexRgb(dataUpdate.color));
    } else {
      navigate(paths.services);
    }
  };

  const getStageById = (id) => {
    getItemById(endpoints.stageServices.getStageServiceById, id)
      .then((res) => {
        if (res === null) {
          setFormData({
            id: '',
            nombre: '',
            descripcion: '',
            codigo: '',
            estado: '',
          });
          setColorHexCode('');
          setActive('');
          resourceNotFound();
        } else {
          setFormData({
            ...res,
            id: res.id,
            nombre: res.nombre,
            descripcion: res.descripcion,
            codigo: res.codigo,
            estado: res.estado,
          });
          setColorHexCode(res.color);
          setActive(res.estado);
          setColorRGB(hexRgb(res.color));
        }
      }).catch((err) => {
        console.log(err);
      });
  };

  // Handle to show the color picker
  const handleClick = (e) => {
    e.preventDefault();
    setDisplayColorPicker(!displayColorPicker);
  };

  // Handle to close the color picker
  const handleClose = () => {
    setDisplayColorPicker(false);
  };

  // Update the name or text of the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handleInputCaracter = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
    // setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();

    let data = {
      ...formData,
      estado: active ? "1" : "0",
      color: colorHexCode,
      usuarioModificacion: Cookie.get("idUsuario"),
      codigo: formData.codigo.toLowerCase(),
    };
    putItem(data);
  };

  const putItem = (data) => {
    Swal.fire({
      title: formatterText("alert.title.general"),
      text: formatterText("alert.description.create.general"),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText("alert.button.confirm.general"),
      allowOutsideClick: false,
      cancelButtonText: formatterText("alert.button.cancel.general"),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateItem(endpoints.stageServices.updateStageService, data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText("alert.title.confirm.general"),
                  text: formatterText("alert.message.confirm.created.general"),
                  confirmButtonText: formatterText("alert.button.continue"),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.services),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError((formatterText(err.response?.data?.message)));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage
              id="table.title.service.stage"
              defaultMessage="Nombre etapa de servicio"
            />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleInputCaracter}
            placeholder={formatterText(
              "table.title.service.stage",
              "Nombre etapa de servicio",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </h3>
          <textarea
            className="input-primary-textarea"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder="Descripción"
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handlerTextCode}
            placeholder={formatterText(
              "input.placeholder.max.45.chars",
              "Ingrese hasta 45 caracteres",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.color" defaultMessage="Color" />
          </h3>

          <div className="color-picker-container">
            <h3 className="color-picker-text">{colorHexCode}</h3>
            <button className="btn-container-container" onClick={handleClick}>
              <div
                style={{
                  width: "36px",
                  height: "14px",
                  borderRadius: "2px",
                  background: `rgba(${colorRGB.red}, ${colorRGB.green}, ${colorRGB.blue}, ${colorRGB.alpha})`,
                }}
              />
            </button>
            {displayColorPicker ? (
              <div className="picker-position">
                <div className="picker-position-cover" onClick={handleClose} />
                <SketchPicker
                  color={colorHexCode}
                  onChange={(e) => {
                    setColorHexCode(e.hex);
                    setColorRGB(hexRgb(e.hex));
                  }}
                />
              </div>
            ) : null}
          </div>
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </h3>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.save" defaultMessage="Guardar" />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.services)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancel" />
        </button>
      </section>
    </form>
  );
}
