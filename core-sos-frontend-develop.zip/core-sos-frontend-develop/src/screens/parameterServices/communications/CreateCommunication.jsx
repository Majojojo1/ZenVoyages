import Selector from "common/selects/Selector";
import HandleInput from "common/validators/HandleInput";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import HandleOnError from "common/validators/HandleOnError";
import { CODEREGEX, TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
import ProviderType from "models/ProviderType";
import React, { useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate } from "react-router-dom";
import { addProviderType } from "services/api/providerType";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function CreateCommunication() {
  // useLanguage
  const { formatterText } = useLangv2();
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new ProviderType());

  // Update a string to set into the form
  const handleText = (e) => {
    // if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
    //   setFormData({ ...formData, [e.target.name]: e.target.value });
    // }
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
    // setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCode = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };
  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    createProviderType(formData);
  };

  const createProviderType = (data) => {
    Swal.fire({
      title: "Atención, estás seguro de realizar esta acción",
      text: "Se va a crear un nuevo registro",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: `Guardar cambios`,
      allowOutsideClick: false,
      cancelButtonText: "Cancelar",
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addProviderType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: "Operación exitosa",
                  text: "Se creo el tipo de proveedor correctamente",
                  confirmButtonText: "Continuar",
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              reject(
                HandleOnError(
                  "No se pudo crear el tipo de proveedor, es posible que el código ya exista",
                ),
              );
              console.log(err);
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3>Nombre de la comunicación</h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder="Nombre de la comunicación"
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Descripción</h3>
          <input
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handleChange}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <label className="form-responsive-information__option">
          <h3>Tipo de comunicación</h3>
          <Selector
            name="idProveedor"
            data={[]}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecione una opción"
              />
            }
            // isLoading={loading}
            isRequired={true}
          />
        </label>
        <section className="form-responsive-information__option">
          <h3>Código</h3>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleCode}
            placeholder="Ingresa hasta 45 caracteres"
            maxLength="45"
            required
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          Crear comunicación
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.services)}
        >
          Cancelar
        </button>
      </section>
    </form>
  );
}
