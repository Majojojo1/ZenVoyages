import HandleInput from "common/validators/HandleInput";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import HandleOnError from "common/validators/HandleOnError";
import { CODEREGEX, TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
import Cookie from "js-cookie";
import ProviderType from "models/ProviderType";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { updateProviderType } from "services/api/providerType";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function UpdateProviderType() {
  // useLanguage
  const { formatterText } = useLangv2();
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new ProviderType());
  // toggle state
  const [active, setActive] = useState(true);

  useEffect(() => {
    // Aqui se puede llamar a una función que obtiene los datos del localstorage
    getDataProviderType();
  }, []);

  const getDataProviderType = () => {
    const providerType = JSON.parse(localStorage.getItem("dataUpdate"));

    if (providerType) {
      setFormData({
        idTipoProveedor: providerType.idTipoProveedor,
        nombre: providerType.nombre,
        descripcion: providerType.descripcion,
        codigo: providerType.codigo,
        estado: providerType.estado,
        fechaRegistro: providerType.fechaRegistro,
        fechaModificacion: providerType.fechaModificacion,
        usuarioCreacion: providerType.usuarioCreacion,
        usuarioModificacion: providerType.usuarioModificacion,
      });
      setActive(providerType.estado);
    } else {
      navigate(paths.parameters);
    }
  };

  // actualiza el nombre o un texto del formulario
  const handleText = (e) => {
    // if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
    //   setFormData({ ...formData, [e.target.name]: e.target.value });
    // }
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, CODEREGEX, formData, setFormData);
    // setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
    putProviderType(data);
  };

  const putProviderType = (data) => {
    Swal.fire({
      title: "Atención, estás seguro de realizar esta acción",
      text: "Se va a crear un nuevo registro",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: `Guardar cambios`,
      allowOutsideClick: false,
      cancelButtonText: "Cancelar",
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateProviderType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: "Operación exitosa",
                  text: "Se actualizo el tipo de proveedor correctamente",
                  confirmButtonText: "Continuar",
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              reject(
                HandleOnError(
                  "No se pudo actualizar el tipo de proveedor, es posible que el código ya exista",
                ),
              );
              console.log(err);
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3>Nombre tipo proveedor</h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder="Nombre tipo proveedor"
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Descripción</h3>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Código</h3>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder="Ingresa hasta 45 caracteres"
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Estado</h3>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active ? "Activo" : "No activo"}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          Crear tipo de proveedor
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          Cancelar
        </button>
      </section>
    </form>
  );
}
