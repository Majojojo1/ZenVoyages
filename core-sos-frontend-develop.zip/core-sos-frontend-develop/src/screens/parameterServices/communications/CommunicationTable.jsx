import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
// paths to routes
import paths from 'services/paths';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
// hook para cargar los datos
import useGetData from 'hooks/useGetData';

import { useSeachContext } from 'context/SearchContext';
import {
  deleteProviderType,
  getAllProviderTypes,
  updateProviderType,
} from 'services/api/providerType';

const CommunicationTable = () => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  const [parameters, setParameters] = useState(null);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAllProviderTypes()
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        setParameters(newArray);
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (column) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteProviderType(column.id)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setParameters(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateProviderType(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idTipoProveedor,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo2: '',
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const titles = [
    'Nombre comunicación',
    'Descripción',
    'Tipo de comunicación',
    'Código',
    'Estado',
    'Acciones.',
  ];

  const renderMessage = () => {
    return error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();
  };

  return (
    <>
      {!loading && parameters !== null ? (
        <>
          <FormattedMessage id="table.name.search.providerType" defaultMessage="Tipos de proveedor">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={placeholder}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateProviderType}
                canDeleted={true}
                canModify={true}
              />
            )}
          </FormattedMessage>
        </>
      ) : (
        renderMessage()
      )}
    </>
  );
};

export default CommunicationTable;
