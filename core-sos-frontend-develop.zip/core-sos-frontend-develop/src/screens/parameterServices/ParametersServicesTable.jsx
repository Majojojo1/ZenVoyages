import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import UploadExcel from 'components/utils/UploadExcel';

// Import Libs
import { Link } from 'react-router-dom';
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
// Import Services
import endpoints from 'services/api';
import { uploadFile } from 'services/api/methods';
import paths from 'services/paths';
// Import Screens
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { FormattedMessage } from 'react-intl';
import ActivityTable from 'screens/parameterServices/activities/ActivityTable';
import FormTable from 'screens/parameterServices/form/FormTable';
import ListPricesTable from 'screens/parameterServices/listPrices/ListPricesTable';
import ServiceCategoryTable from 'screens/parameterServices/serviceCategory/ServiceCategoryTable';
import ServiceStageTable from 'screens/parameterServices/stageService/ServiceStageTable';
import { excelListPrices } from 'services/api/listPrices';

const ServicesTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ServicesTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const ServicesTableComponent = () => {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  // Call context TableMinimalContext
  const { setCurrentDataTable } = useContext(TableMinimalContext);

  const { setSearch, searchResults = [] } = useSeachContext();

  const [excelListData, setExcelList] = useState([]);

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.serviceParameters.principal);
  };
  const tabs = [
    {
      id: paths.categoryServices,
      nombre: (
        <FormattedMessage id="text.category.services" defaultMessage="Categoría de servicios" />
      ),
      route: paths.createCategoryService,
      nombreLink: (
        <FormattedMessage
          id="btn.create.category.service"
          defaultMessage="Crear categoría de servicio"
        />
      ),
      componente: <ServiceCategoryTable permisos={permittedActions} />,
      exportExcel: permittedActions.exportar,
      uploadExcel: permittedActions.importar,
      diligenceForm: null,
      idPermiso: MODULES_NAME.serviceParameters.serviceCategory,
    },
    {
      id: paths.stagesServices,
      nombre: <FormattedMessage id="text.services.stage" defaultMessage="Etapas de servicios" />,
      route: paths.createStageService,
      nombreLink: (
        <FormattedMessage
          id="header.title.service.parameter.service.stage.create"
          defaultMessage="Crear etapa de servicio"
        />
      ),
      componente: <ServiceStageTable permisos={permittedActions} />,
      exportExcel: permittedActions.exportar,
      uploadExcel: permittedActions.importar,
      diligenceForm: null,
      idPermiso: MODULES_NAME.serviceParameters.serviceStages,
    },
    {
      id: 'Gestion Actividades',
      nombre: (
        <FormattedMessage
          id="header.title.service.parameter.activity.update"
          defaultMessage="Gestión de Actividades"
        />
      ),
      route: paths.createActivityService,
      nombreLink: (
        <FormattedMessage
          id="header.title.service.parameter.activity.create"
          defaultMessage="Gestionar actividad"
        />
      ),
      componente: <ActivityTable permisos={permittedActions} />,
      exportExcel: permittedActions.exportar,
      uploadExcel: null,
      diligenceForm: null,
      idPermiso: MODULES_NAME.serviceParameters.manageActivities,
    },
    {
      id: paths.listPriceServices,
      nombre: <FormattedMessage id="text.pricelist" defaultMessage="Listado de precios" />,
      route: paths.createListPriceService,
      nombreLink: (
        <FormattedMessage
          id="header.title.service.parameter.price.list.create"
          defaultMessage="Crear listado de precios"
        />
      ),
      componente: <ListPricesTable permisos={permittedActions} />,
      exportExcel: permittedActions.exportar,
      uploadExcel: permittedActions.importar,
      diligenceForm: null,
      idPermiso: MODULES_NAME.serviceParameters.listPrices,
    },
    {
      id: paths.formServices,
      nombre: <FormattedMessage id="text.title.forms" defaultMessage="Formularios" />,
      route: paths.createFormService,
      routeExtra: paths.formDiligence,
      nombreLink: (
        <FormattedMessage
          id="header.title.service.parameter.form.create"
          defaultMessage="Crear formulario"
        />
      ),
      componente: <FormTable permisos={permittedActions} />,
      exportExcel: null,
      uploadExcel: null,
      diligenceForm: permittedActions.crear,
      idPermiso: MODULES_NAME.serviceParameters.forms,
    },
  ];

  // Select tab
  const [selectedTab, setSelectedTab] = useState(tabs[0]);
  // Index Tab
  const [indexTabServices, setIndexTabServices] = useState(Number(localStorage.getItem('ParametersServicesTable')) || 0);

  //Reemplace la logica para poder reutilizarla segun los tabs, para que apunte al endpoint correspondiente
  const selectEndpoint = (body) => {
    if (selectedTab.nombre.props.defaultMessage === 'Listado de precios') {
      const ItemPromise = new Promise((resolve, reject) => {
        uploadFile(endpoints.listPrices.uploadFileListPrice, body)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      return ItemPromise;
    } else {
      const ItemPromise = new Promise((resolve, reject) => {
        uploadFile(endpoints.costProductProvider.uploadFileCostProvider, body)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      return ItemPromise;
    }
  };

  const getExcelListPriceData = () => {
    let dataTableList = [];
    excelListPrices().then((data) => {
      data.forEach((element) => {
        dataTableList.push({
          codigo: element.idListaPreciosActividad.codigo,
          sku: element.idTipoServicioActividad.idActividad.sku,
          etapaServicio: element.idTipoServicioActividad.idEtapaServicio,
          tipoServicio: element.idTipoServicioActividad.idTipoServicio.nombre,
          abreviatura: element.idUnidadMedida.abreviatura,
          valor: element.valor,
          impuesto: element.impuesto,
        });
        setExcelList(dataTableList);
      });
    });
  };

  useEffect(() => {
    setCurrentDataTable([]);
    getExcelListPriceData();
    localStorage.setItem('indexTabServices', 0);
    localStorage.setItem('ClientParametersTable', 0);
    localStorage.setItem('ParametersServicesTable', 0);
    const index = Number(localStorage.getItem('ParametersServicesTable'));
    setIndexTabServices(index);
  }, []);

  const clickTab = (tab, index) => {
    localStorage.setItem('indexTabServices', index.toString());
    setSelectedTab(tab);
    permissionsAccess(tab.idPermiso);
  };

  useEffect(() => {
    setSearch('');
  }, [selectedTab]);

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    setSelectedTab(tabs[parseInt(localStorage.getItem('indexTabServices')) || 0]);
  }, [permittedActions]);

  return (
    <section className="table-container">
      <section className="userOptions">
        {permittedActions.consultar && (
          <Search
            placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
            width="50%"
          />
        )}
        {permittedActions.crear && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.route}>
            <button className="btn-add">{selectedTab.nombreLink}</button>
          </Link>
        )}
        {selectedTab.exportExcel && (
          <ExportJsonFile
            moduleName={selectedTab.id.replace('/', '')}
            userName={
              JSON.parse(localStorage.getItem('userData')).usuario
                ? JSON.parse(localStorage.getItem('userData')).usuario
                : 'ADMIN'
            }
            dataTable={
              selectedTab.id.replace('/', '') === 'precios' ? excelListData : searchResults
            }
          />
        )}
        {selectedTab.uploadExcel && (
          <UploadExcel
            ActionFunction={selectEndpoint}
            currentText={selectedTab.id.replace('/', '')}
            currentRestrict={formatterText('file.structure.price.list')}
          />
        )}
        {selectedTab.diligenceForm && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.routeExtra}>
            <button className="btn-add">
              <FormattedMessage id="btn.form.filled" defaultMessage="Formularios Diligenciados" />
            </button>
          </Link>
        )}
      </section>
      <Tabs defaultIndex={indexTabServices} onSelect={index => localStorage.setItem('ParametersServicesTable', index)} selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab onClick={() => clickTab(tab, index)} key={`${index + 1}`} className="tab-option">
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {permittedActions.consultar &&
          tabs.map((tab, index) => (
            <TabPanel key={`tab-${index}:${tab.title}`}>{tab.componente}</TabPanel>
          ))}
      </Tabs>
    </section>
  );
};

export default ServicesTable;
