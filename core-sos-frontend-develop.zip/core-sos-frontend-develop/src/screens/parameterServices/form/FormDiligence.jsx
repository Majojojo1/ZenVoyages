import React, { useEffect, useState } from "react";
// Import Context
// Import Hooks
// Import Components
// Import libs
// Import services
import Logo from "assets/logo.png";
import { pdfFromReact } from "generate-pdf-from-react-html";
import endpoints from "services/api";
import { getAll } from "services/api/methods/index";
import "styles/printForms.css";

const data = {
  encuesta: "Encuesta 1",
  descripcion: "Descripcion 1",
  version: "Version 1",
  tecnico: "Tecnico 1",
  id: "1",
  fechaInicio: "2021-01-01",
  fechaCita: "2021-01-01",
  fechaFin: "2021-01-01",
  cantidadDias: "1",
  empresa: "Empresa 1",
  cliente: "Cliente 1",
  origen: "Origen 1",
  destino: "Destino 1",
};

const Header = (encuesta, descripcion) => {
  encuesta = encuesta.encuesta;
  descripcion = descripcion.descripcion;
  return (
    <>
      <div className="flexSpace1">
        <img src={Logo} className="logo" />
        <div className="containerHeader">
          <div className="flex">
            <div className="textContainterPrincipal">Encuesta :</div>
            <div className="textContainerSecondary">{encuesta}</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Descripcion :</div>
            <div className="textContainerSecondary">{descripcion}</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Version :</div>
            <div className="textContainerSecondary">Verision 1</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Tecnico :</div>
            <div className="textContainerSecondary">Tecnico 1</div>
          </div>
          <div>{data.id}</div>
        </div>
        <div className="containerRightHeader">
          <div className="containerRightHeader2">Expediente</div>
          <div className="containerRightHeader2">
            <p>Prueba : 123-123</p>
          </div>
        </div>
      </div>
      <hr className="line" />
    </>
  );
};

const Body = (fechaCita, fechaFin) => {
  fechaCita = fechaCita.fechaCita;
  fechaFin = fechaFin.fechaFin;

  return (
    <>
      <div className="flexSpace">
        <div className="bodyContainerPrincipal">Fecha inicio :</div>
        <div className="bodyContainerSecondary">{data.fechaInicio}</div>
        <div className="bodyContainerPrincipal">Fecha Cita :</div>
        <div className="bodyContainerSecondary">{fechaCita}</div>
        <div className="bodyContainerPrincipal">Fecha Fin :</div>
        <div className="bodyContainerSecondary">{fechaFin}</div>
      </div>
      <div className="flexSpace">
        <div className="bodyContainerPrincipal">Cant Dias :</div>
        <div className="bodyContainerSecondary">{data.cantidadDias}</div>
        <div className="bodyContainerPrincipal">Empresa :</div>
        <div className="bodyContainerSecondary">{data.empresa}</div>
        <div className="bodyContainerPrincipal">Cliente :</div>
        <div className="bodyContainerSecondary">{data.cliente}</div>
      </div>
      <div className="flexSpace">
        <div className="thirdBodyContainerPrincipal">Origen :</div>
        <div className="thirdBodyContainerSecondary">{data.origen}</div>
        <div className="thirdBodyContainerPrincipal">Destino :</div>
        <div className="thirdBodyContainerSecondary">{data.destino}</div>
      </div>
    </>
  );
};

const TittleForm = () => {
  return (
    <div className="tittleForm">
      <div className="leftForm">Descripción</div>
      <div className="rightForm"></div>
    </div>
  );
};

const DocumentToPrint = (data) => {
  data = data.data;
  return (
    <>
      <Header encuesta={data.encuesta} descripcion={data.descripcion} />
      <div className="center">
        <Body fechaCita={data.fechaCita} fechaFin={data.fechaFin} />
        <TittleForm />
        {data.respuestas.map((formResponse) => {
          return (
            <div className="flexSpace">
              <div className="rightForm">{formResponse.pregunta}</div>
              <div className="rightForm">{formResponse.respuesta}</div>
            </div>
          );
        })}
      </div>
    </>
  );
};
const titles = [
  "Nombre formulario",
  "Descripción",
  "Código",
  "Estado",
  "Acciones",
];

const FormDiligence = () => {
  useEffect(() => {
    promiseGetDataTable();
  }, []);

  const [dataTable, setDataTable] = useState([]);
  const [loading, setLoading] = useState(true);

  const promiseGetDataTable = () => {
    getAll(endpoints.formulariosDiligenciados.getAll).then((data) => {
      const newArray = [];
      //TODO: recorrer la respuesta con un forEach
      //TODO: llenar un array del id del formulario, la respuesta del formulario y la pregunta del formulario
      data.forEach((element) => {
        newArray.push({
          fechaCita: element?.idServicio?.fechaCita,
          horaCita: element?.idServicio?.idHoraCita.hora,
          fechaFin: element?.idServicio?.fechaCitaFin,
          horaCitaFin: element?.idServicio?.idHoraCitaFin.hora,
          idFormulario: element?.idFormulario.idFormulario,
          encuesta: element.idFormulario?.nombre,
          descripcion: element?.idFormulario?.descripcion,
          respuesta: element?.respuesta,
          idPreguntaFormulario: element?.idPreguntaFormulario?.titulo,
        });
      });
      //TODO: Crear un nuevo array en donde va a recorrer el array anterior y va a agrupar por id del formulario
      const newArray2 = [];
      newArray.forEach((element) => {
        const index = newArray2.findIndex(
          (item) => item.idFormulario === element.idFormulario
        );
        if (index === -1) {
          newArray2.push({
            encuesta: element.encuesta,
            descripcion: element.descripcion,
            idFormulario: element.idFormulario,
            fechaCita: element.fechaCita,
            horaCita: element.horaCita,
            fechaFin: element.fechaFin,
            horaCitaFin: element.horaCitaFin,
            respuestas: [
              {
                pregunta: element.idPreguntaFormulario,
                respuesta: element.respuesta,
              },
            ],
          });
        } else {
          newArray2[index].respuestas.push({
            pregunta: element.idPreguntaFormulario,
            respuesta: element.respuesta,
          });
        }
      });
      setDataTable(newArray2);
      setLoading(false);
    });
  };

  return (
    <>
      {" "}
      {!loading && (
        <>
          {dataTable.map((data, index) => {
            let name = `printmePls${index}`;
            return (
              <>
                <div
                  style={{
                    display: "none",
                  }}
                >
                  <div className={name}>
                    <DocumentToPrint data={data} />
                  </div>
                </div>

                <button onClick={() => pdfFromReact(`.${name}`, "test", "l")}>
                  DESCARGAR AI DIO MIO
                </button>
              </>
            );
          })}
        </>
      )}
    </>
  );
};

export default FormDiligence;
