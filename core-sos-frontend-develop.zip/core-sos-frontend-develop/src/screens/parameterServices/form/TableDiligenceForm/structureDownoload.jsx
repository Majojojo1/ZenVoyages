import React from "react";
import Logo from "assets/logo.png";
import { pdfFromReact } from "generate-pdf-from-react-html";
import "styles/printForms.css";

const data = {
  encuesta: "Encuesta 1",
  descripcion: "Descripcion 1",
  version: "Version 1",
  tecnico: "Tecnico 1",
  id: "1",
  fechaInicio: "2021-01-01",
  fechaCita: "2021-01-01",
  fechaFin: "2021-01-01",
  cantidadDias: "1",
  empresa: "Empresa 1",
  cliente: "Cliente 1",
  origen: "Origen 1",
  destino: "Destino 1",
};

const formResponses = [
  {
    pregunta: "Pregunta 1",
    respuesta: "Respuesta 1",
  },
  {
    pregunta: "Pregunta 2",
    respuesta: "Respuesta 2",
  },
  {
    pregunta: "Pregunta 3",
    respuesta: "Respuesta 3",
  },
  {
    pregunta: "Pregunta 4",

    respuesta: "Respuesta 4",
  },
  {
    pregunta: "Pregunta 5",
    respuesta: "Respuesta 5",
  },
];

const Header = (encuesta, descripcion) => {
  encuesta = encuesta.encuesta;
  descripcion = descripcion.descripcion;
  return (
    <>
      <div className="flexSpace1">
        <img src={Logo} className="logo" />
        <div className="containerHeader">
          <div className="flex">
            <div className="textContainterPrincipal">Encuesta :</div>
            <div className="textContainerSecondary">{encuesta}</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Descripcion :</div>
            <div className="textContainerSecondary">{descripcion}</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Version :</div>
            <div className="textContainerSecondary">Verision 1</div>
          </div>
          <div className="flex">
            <div className="textContainterPrincipal">Tecnico :</div>
            <div className="textContainerSecondary">Tecnico 1</div>
          </div>
          <div>{data.id}</div>
        </div>
        <div className="containerRightHeader">
          <div className="containerRightHeader2">Expediente</div>
          <div className="containerRightHeader2">
            <p>Prueba : 123-123</p>
          </div>
        </div>
      </div>
      <hr className="line" />
    </>
  );
};

const Body = (fechaCita, fechaFin) => {
  fechaCita = fechaCita.fechaCita;
  fechaFin = fechaFin.fechaFin;

  return (
    <>
      <div className="flexSpace">
        <div className="bodyContainerPrincipal">Fecha inicio :</div>
        <div className="bodyContainerSecondary">{data.fechaInicio}</div>
        <div className="bodyContainerPrincipal">Fecha Cita :</div>
        <div className="bodyContainerSecondary">{fechaCita}</div>
        <div className="bodyContainerPrincipal">Fecha Fin :</div>
        <div className="bodyContainerSecondary">{fechaFin}</div>
      </div>
      <div className="flexSpace">
        <div className="bodyContainerPrincipal">Cant Dias :</div>
        <div className="bodyContainerSecondary">{data.cantidadDias}</div>
        <div className="bodyContainerPrincipal">Empresa :</div>
        <div className="bodyContainerSecondary">{data.empresa}</div>
        <div className="bodyContainerPrincipal">Cliente :</div>
        <div className="bodyContainerSecondary">{data.cliente}</div>
      </div>
      <div className="flexSpace">
        <div className="thirdBodyContainerPrincipal">Origen :</div>
        <div className="thirdBodyContainerSecondary">{data.origen}</div>
        <div className="thirdBodyContainerPrincipal">Destino :</div>
        <div className="thirdBodyContainerSecondary">{data.destino}</div>
      </div>
    </>
  );
};

const TittleForm = () => {
  return (
    <div className="tittleForm">
      <div className="leftForm">Descripción</div>
      <div className="rightForm"></div>
    </div>
  );
};

const DocumentToPrint = (data) => {
  data = data.data;
  return (
    <>
      <Header encuesta={data.encuesta} descripcion={data.descripcion} />
      <div className="center">
        <Body fechaCita={data.fechaCita} fechaFin={data.fechaFin} />
        <TittleForm />
        {data.respuestas.map((formResponse) => {
          return (
            <div className="flexSpace">
              <div className="rightForm">{formResponse.pregunta}</div>
              <div className="rightForm">{formResponse.respuesta}</div>
            </div>
          );
        })}
      </div>
    </>
  );
};
const titles = [
  "Nombre formulario",
  "Descripción",
  "Código",
  "Estado",
  "Acciones",
];

const StructureDownload = () => {
  return (
    <>
      <div
        style={{
          display: "none",
        }}
      >
        <div className="printmePls"></div>
      </div>
      <DocumentToPrint data={data} />
      <button onClick={() => pdfFromReact(`.printmePls`, "test", "l")}>
        DESCARGAR AI DIO MIO
      </button>
    </>
  );
};

export default StructureDownload;
