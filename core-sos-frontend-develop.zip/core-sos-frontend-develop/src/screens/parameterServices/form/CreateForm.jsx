import { Formiz, FormizStep, useForm } from "@formiz/core";
import { isMaxLength } from "@formiz/validations";
import { InputField } from "common/InputField";
import HandleOnError from "common/validators/HandleOnError";
import CustomAlert from "components/CustomAlert";
import useLang from "hooks/useLang";
import React, { useEffect, useState } from "react";
import { QuizzBuilder } from "react-quizz-spanish";
import "react-quizz-spanish/lib/assets/antd.css";
import { defaultMessages } from "react-quizz-spanish/lib/translations/TranslatedText";
import { useNavigate } from "react-router-dom";
import endpoints from "services/api";
import { addItem } from "services/api/methods";
import paths from "services/paths";
import Swal from "sweetalert2";
import en_text from "./en-US.json";
import es_text from "./es-ES.json";

export default function CreateForm() {
  // Formiz object
  const myForm = useForm();
  // Modal config
  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();

  let lang = localStorage.getItem("lang").slice(-2);
  const language = {
    ES: es_text,
    US: en_text,
  };
  const outAux = language[lang] || language["ES"];
  const [selectLang, setSelectLang] = useState(outAux);
  const [loading, setLoading] = useState(false);
  defaultMessages["es"] = selectLang;

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      lang = localStorage.getItem("lang").slice(-2);
      setSelectLang(outAux);
      setLoading(false);
    }, 0);
  }, [lang]);

  // This function is executed when the create button is clicked
  const handleSubmit = (values) => {
    let data = {
      nombre: values.nombre,
      descripcion: values.descripcion || "",
      codigo: values.code.toLowerCase(),
    };
    createForm(data);
  };

  const createForm = (data) => {
    Swal.fire({
      title: formatterText("alert.title.general"),
      text: formatterText("alert.description.create.general"),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText("alert.button.confirm.general"),
      allowOutsideClick: false,
      cancelButtonText: formatterText("alert.button.cancel.general"),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.formServices.addFormService, data)
            .then((res) => {
              if (form.length > 0) {
                createQuestion(res.idFormulario, resolve, reject);
              } else {
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: "Operación exitosa",
                  text: "Se creo el formulario correctamente",
                  confirmButtonText: "Continuar",
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.services),
                  //
                });
              }
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError((formatterText(err.response?.data?.message)));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  const getIdByElement = (element) => {
    switch (element) {
      case "Select":
        return 1;
      case "Checkboxes":
        return 2;
      case "RadioButtons":
        return 3;
      case "MultiLineInput":
        return 4;
      case "DatePicker":
        return 6;
      default:
        return 5;
    }
  };

  const createQuestion = (id, resolve, reject) => {
    const promises = form.map((item, index) => {
      const question = {
        idFormulario: id,
        orden: index + 1,
        titulo: item.questions.es,
        descripcion: item.questions.es,
        obligatoria: item.required === true ? 1 : 0,
      };

      addItem(endpoints.formServices.addQuestionForm, question)
        .then((res) => {
          if (item.options !== undefined) {
            item.options.map((options) => {
              if (Object.keys(options).length > 0) {
                console.log(item.element);
                console.log(getIdByElement(item.element));
                const optionsQuestion = {
                  idTipoObjetoFormulario: getIdByElement(item.element),
                  idPreguntaFormulario: res.idPreguntaFormulario,
                  orden: index + 1,
                  descripcion: options.text.es,
                };
                return addItem(
                  endpoints.formServices.addOptionsQuestion,
                  optionsQuestion,
                ).then((resl) => {
                  resolve(resl);
                });
              }
            });
          } else {
            const optionsQuestion = {
              idTipoObjetoFormulario: getIdByElement(item.element),
              idPreguntaFormulario: res.idPreguntaFormulario,
              orden: index + 1,
              descripcion: "W/O OPTIONS",
            };
            return addItem(
              endpoints.formServices.addOptionsQuestion,
              optionsQuestion,
            ).then((resl) => {
              resolve(resl);
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    });
    Promise.all(promises)
      .then(() => {
        CustomAlert("confirm_msg", {
          icon: "success",
          title: formatterText('alert.title.confirm.general'),
          text: formatterText('alert.message.confirm.created.general'),
          confirmButtonText: formatterText('alert.button.continue'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.services),
          //
        });
      })
      .catch((err) => {
        if (err.response.status === 400 || err.response.status === 420) {
          reject(HandleOnError(formatterText('alert.message.code.error.general')));
        } else {
          reject(HandleOnError(formatterText('alert.message.failed.general')));
        }
        console.log(err);
      });
  };

  const [form, setForm] = useState([]);

  const handleSubmits = () => {
    console.log(form);
  };

  return (
    
      <div className="centered-form">
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form
            noValidate
            onSubmit={myForm.submit}
            className="container-wrapForm"
            style={{ minHeight: "16rem" }}
          >
            <div className="new-container-wrapForm__tabs">
              {myForm.steps.map((step) => (
                <button
                  key={step.name}
                  className={`new-tab-option ${
                    step.name === myForm.currentStep.name ? "is-active" : ""
                  }`}
                  type="button"
                  onClick={() => myForm.goToStep(step.name)}
                >
                 {formatterText(step.label)}
                  {!step.isValid && step.isSubmitted && (
                    <small className="mr-2">⚠️</small>
                  )}
                </button>
              ))}
            </div>

            <div className="container-wrapForm-content">
              <FormizStep name="step1" label="column.name.form.title.step">
                <section className="wrapForm">
                  <InputField
                    type="text"
                    name="nombre"
                    labelText={formatterText('column.name.form.name')}
                    placeholder={formatterText('column.name.form.name')}
                    validateInput="text"
                    required={formatterText('column.name.form.required.name.form')}
                    validations={[
                      {
                        rule: isMaxLength(45),
                        message:
                          "El nombre del formulario debe tener como máximo 45 caracteres",
                      },
                    ]}
                    styleName="input-primary"
                  />
                  <InputField
                    type="text"
                    asArea={true}
                    name="descripcion"
                    labelText={formatterText('table.title.description')}
                    placeholder={formatterText('table.title.description')}
                    validateInput="text"
                    validations={[
                      {
                        rule: isMaxLength(200),
                        message:
                          "La descripción debe tener como máximo 200 caracteres",
                      },
                    ]}
                    styleName="input-textarea"
                  />

                  <InputField
                    type="text"
                    name="code"
                    labelText={formatterText('table.title.code')}
                    placeholder={formatterText('table.title.code')}
                    validateInput="code-lower-case"
                    required={formatterText('table.title.code.required')}
                    styleName="input-primary"
                  />
                </section>
              </FormizStep>
              <FormizStep name="step2" label="column.name.form.title.step2">
                <p className="wrap-form-title">{formatterText('column.name.form')}</p>
                {!loading && <QuizzBuilder language="es" onChange={setForm} />}
              </FormizStep>
            </div>
            <div className="demo-form__footer">
              <section className="form-responsive-container-buttons">
                <button type="submit" className="btn-primary" id="submit-form">
                  {formatterText('header.title.service.parameter.form.create')}
                </button>

                <button
                  className="input-cancel"
                  onClick={() => navigate(paths.services)}
                >
                 {formatterText('question.swal.title.edit.cancel')}
                </button>
              </section>
            </div>
          </form>
        </Formiz>
      </div>   
  );
}
