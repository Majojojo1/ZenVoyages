import { Button } from "antd";
import React, { useState, useEffect } from "react";
import { Quiz } from "react-quizz-spanish";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import { defaultMessages } from "react-quizz-spanish/lib/translations/TranslatedText";
import es_text from "./es-ES.json";
import en_text from "./en-US.json";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "80vw",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  height: "80vh",
  p: 4,
  overflow: "auto",
};

export default function ({ data }) {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  let lang = localStorage.getItem("lang").slice(-2);
  const language = {
    ES: es_text,
    US: en_text,
  };
  const outAux = language[lang];
  const [selectLang, setSelectLang] = useState(outAux);
  const [loading, setLoading] = useState(false);
  defaultMessages["es"] = selectLang;

  useEffect(() => {
    setLoading(true);
    console.log("selectLang", selectLang);
    setTimeout(() => {
      lang = localStorage.getItem("lang").slice(-2);
      setSelectLang(outAux);
      setLoading(false);
    }, 0);
  }, [lang]);

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Quiz
            language="es"
            data={data}
            /* onSubmit={() => console.log("form submit values", data)} */
            submitButton={false}
          />
          <Button onClick={handleClose}>Cerrar formulario</Button>
        </Box>
      </Modal>
    </>
  );
}
