import React, { useContext, useEffect, useState } from 'react';
// Import Hooks
import useGetData from 'hooks/useGetData';
// Import Components
import DynamicHeadNotifications from './DynamicTableNotificacion/DynamicHeadNotifications';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import services
import { ContextUse } from './ContextAlert';

const Alerts = ({ isEmployee }) => {
  // hook to loading data
  const { loading, error, displayMessage, displayLoading } = useGetData();

  const { state, _SetDispatch, DeterminateTypeUser } = useContext(ContextUse);
  const [updated, setUpdated]= useState(false);

  const setCurrentPage = (page) => {
    _SetDispatch({ type: 'CURRENT_PAGE_ALERT', payload: page });
  };

  const setRowsPerPage = (rows) => {
    _SetDispatch({ type: 'ROWS_PER_PAGE', payload: rows });
  };

  const titles = [
    <FormattedMessage key="tab.title.dates" id="tab.title.dates" defaultMessage="Fecha / Hora" />,
    <FormattedMessage
      key="tab.title.ticket"
      id="tab.title.ticket"
      defaultMessage="Ticket"
    />,
    <FormattedMessage
      key="tab.title.category"
      id="tab.title.category"
      defaultMessage="Categoria"
    />,
    <FormattedMessage key="tab.title.message" id="tab.title.message" defaultMessage="Mensaje" />,
    <FormattedMessage
      key="table.name.search.client"
      id="table.name.search.client"
      defaultMessage="Cliente"
    />,
    <FormattedMessage key="table.title.city" id="table.title.city" defaultMessage="Ciudad" />,
    <FormattedMessage
      key="tab.title.date.markasread"
      id="tab.title.date.markasread"
      defaultMessage="Leído el"
    />,
    <FormattedMessage
      key="tab.title.markasread"
      id="tab.title.markasread"
      defaultMessage="Marcar como leida"
    />,
  ];

  const renderMessage = () => {
    return error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();
  };
  useEffect(()=>{DeterminateTypeUser()}, [updated===true])

  return (
    <>
      {!loading ? (
        <FormattedMessage id="tab.title.notifications">
          {() => (
            <DynamicHeadNotifications
              titles={titles}
              getData={DeterminateTypeUser}
              page={state.currentPageAlert}
              rowsPerPage={state.rowsPerPage}
              setPage={setCurrentPage}
              setRowsPerPage={setRowsPerPage}
              data={state.filteredAlert}
              totalData={state.currentCountAlert}
              updated = {setUpdated}
            />
          )}
        </FormattedMessage>
      ) : (
        renderMessage()
      )}
    </>
  );
};

export default Alerts;
