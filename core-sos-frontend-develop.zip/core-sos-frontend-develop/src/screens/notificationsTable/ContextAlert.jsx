import dateFormat from 'dateformat';
import useAxios from 'hooks/useAxios';
import _ from 'lodash';
import React, { createContext, useEffect, useReducer, useState } from 'react';
import endpoints from 'services/api';
import { alertsByUser, getCountAlertPanel } from 'services/api/alerts';
import { getAll } from 'services/api/methods';
import { countNotificationsByUser, notificationsByUser } from 'services/api/notifications';

export const ContextUse = createContext();

export function ContextAlert({ children }) {
  const { COOKIE_USER } = useAxios();

  const [indexTabServices] = useState(
    parseInt(JSON.parse(localStorage.getItem('indexNotification')) || 0),
  );
  let interval = null;

  useEffect(() => {
    getAll(endpoints.notificationsTable.getTimeToAutoRefresh)
      .then((data) => {
        setInterval(data);
      })
      .catch((err) => console.log(err));
    return () => {
      clearInterval(interval);
    };
  }, []);

  const setInterval = (data) => {
    if (data) {
      clearInterval(data);
    }else{
      return;
    }
  };

  const hashIndexTabServices = {
    0: 'Alert',
    1: 'Notification',
  };

  const initialState = {
    currentNotification: [],
    currentAlert: [],
    filteredNotification: [],
    filteredAlert: [],
    textToFilter: '',
    currentCountNotification: 0,
    currentCountAlert: 0,
    currentPageNotification: 0,
    currentPageAlert: 0,
    tabSelected: hashIndexTabServices[indexTabServices],
    rowsPerPage: 25,
  };

  const hashReducer = {
    CURRENT_NOTIFICATION: 'currentNotification',
    CURRENT_ALERT: 'currentAlert',
    CURRENT_COUNT_NOTIFICATION: 'currentCountNotification',
    CURRENT_COUNT_ALERT: 'currentCountAlert',
    CURRENT_PAGE_NOTIFICATION: 'currentPageNotification',
    CURRENT_PAGE_ALERT: 'currentPageAlert',
    TAB_SELECTED: 'tabSelected',
    ROWS_PER_PAGE: 'rowsPerPage',
    TEXT_TO_FILTER: 'textToFilter',
    FILTERED_NOTIFICATION: 'filteredNotification',
    FILTERED_ALERT: 'filteredAlert',
  };

  const reducer = (state, action) => {
    return { ...state, [hashReducer[action.type]]: action.payload };
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  const _SetDispatch = (data) => {
    dispatch({
      type: data.type,
      payload: data.payload,
    });
  };

  const DeterminateTypeUser = () => {
    getDataByType();
  };

  const getTotalRecords = () => {
    hashCount[state.tabSelected]({
      idUser: `${COOKIE_USER}`,
      type: state.tabSelected,
    }).then((data) => {
      _SetDispatch({
        payload: data,
        type: hashCurrentCount[state.tabSelected],
      });
    });
  };

  const getRecords = () => {
    hashEndpoint[state.tabSelected]({
      idUser: `${COOKIE_USER}`,
      registersPerPage: `${state.rowsPerPage}`,
      currentPage: `${hashCurrentPage[state.tabSelected]}`,
    })
      .then((data) => {
        filter(FormmatedTable(data));
        _SetDispatch({
          payload: FormmatedTable(data),
          type: hashTabSave[state.tabSelected],
        });
      })
      .catch((err) => console.log(err));
  };
  const getDataByType = () => {
    getTotalRecords();
    getRecords();
  };

  const FormmatedTable = (datos) => {
    let formmatedData = [];
    datos.forEach((item) => {      
      const [fecha, hora] = item.fechaHoraNotificacion.split('T');
      formmatedData.push({
        idAgendaNotificacion: item.idAgendaNotificacion,
        idServicio: item.idServicio,
        // format the date to show in the table  with the format dd/mm/yyyy hh:mm:ss , the date is in the format yyyy-mm-ddThh:mm:ss-GMT
        'Fecha / Hora': `${fecha} ${hora.split('+')[0]}`,
        ticket: item.idServicio.ticket,
        Categoria: item.idTipoNotificacion.tipo,
        Mensaje: item.descripcion,
        Cliente: item.nombreCliente || 'No disponible',
        Ciudad: item.nombreCiudadServicio || 'No disponible',
        fechaLeido: `${dateFormat(item.fechaHoraLeidoPanel, 'isoDate')} ${dateFormat(
          item.fechaHoraLeido,
          'isoTime',
        )}`,
        leido: item.fechaHoraLeidoPanel,
      });
    });
    const sortedData = _.orderBy(formmatedData, 'Fecha / Hora', 'asc');
    return sortedData;
  };

  const hashEndpoint = {
    Notification: notificationsByUser,
    Alert: alertsByUser,
  };

  const hashCount = {
    Notification: countNotificationsByUser,
    Alert: getCountAlertPanel,
  };

  const hashTabSave = {
    Notification: `CURRENT_NOTIFICATION`,
    Alert: `CURRENT_ALERT`,
  };

  const hashCurrentCount = {
    Notification: `CURRENT_COUNT_NOTIFICATION`,
    Alert: `CURRENT_COUNT_ALERT`,
  };

  const hashCurrentPage = {
    Notification: state.currentPageNotification,
    Alert: state.currentPageAlert,
  };

  const hashDataToFilter = {
    Notification: state.currentNotification,
    Alert: state.currentAlert,
  };

  React.useEffect(() => {
    DeterminateTypeUser();
  }, [state.tabSelected, state.rowsPerPage, state.currentPageNotification, state.currentPageAlert]);

  React.useEffect(() => {
    filter();
  }, [state.textToFilter]);

  const filter = (dataGetted = null) => {
    //filtrar por texto y por hashIndexTabServices[indexTabServices] (alert o notification)
    let data = [];
    if (state.textToFilter === '' || state.textToFilter.length < 3) {
      if (dataGetted !== null) {
        _SetDispatch({
          payload: dataGetted,
          type: `FILTERED_${state.tabSelected.toUpperCase()}`,
        });
        return;
      }
    }
    hashDataToFilter[state.tabSelected].forEach((item) => {
      //make a filter by text using item.Categoria , item.Mensaje , item.Cliente , item.Ciudad only     
      if (
        item['Categoria'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['Mensaje'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['Cliente'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['Ciudad'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['fechaLeido'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['Fecha / Hora'].toLowerCase().includes(state.textToFilter.toLowerCase()) ||
        item['ticket'].toLowerCase().includes(state.textToFilter.toLowerCase())
      ) {
        data.push(item);
      }
    });
    _SetDispatch({
      payload: data,
      type: `FILTERED_${state.tabSelected.toUpperCase()}`,
    });
  };

  return (
    <ContextUse.Provider
      value={{
        state,
        _SetDispatch,
        DeterminateTypeUser,
      }}
    >
      {children}
    </ContextUse.Provider>
  );
}
