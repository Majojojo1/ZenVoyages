import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { ContextAlert, ContextUse } from './ContextAlert';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Search from 'common/Search';
import { MdAutorenew } from 'react-icons/md';
// Import Libs
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
// Import Screens
import { FormattedMessage } from 'react-intl';
import Alerts from 'screens/notificationsTable/Alerts';
import Notifications from 'screens/notificationsTable/Notifications';

const PanelNotifications = () => {
  return (
    <SearchWrapper>
      <ContextAlert>
        <PanelNotificationsComponent />
      </ContextAlert>
    </SearchWrapper>
  );
};

const tabs = [
  {
    nombre: <FormattedMessage id="tab.title.alerts" defaultMessage="Alertas" />,
    componente: <Alerts />,
    reduce: 'Alert',
  },
  {
    nombre: <FormattedMessage id="tab.title.notifications"/>,
    componente: <Notifications />,
    reduce: 'Notification',
  },
];

const PanelNotificationsComponent = () => {
  // Call context TableMinimalContext
  // use Hook of language v2
  const { formatterText } = useLangv2();
  // Select tab
  const { state, _SetDispatch, DeterminateTypeUser } = useContext(ContextUse);

  const [selectedTab, setSelectedTab] = useState(
    tabs[parseInt(JSON.parse(localStorage.getItem('indexNotification'))) || 0],
  );
  // Index Tab
  const [indexTabServices] = useState(
    parseInt(JSON.parse(localStorage.getItem('indexNotification')) || 0),
  );

  const { search, setSearch } = useSeachContext();

  useEffect(() => {
    _SetDispatch({ type: 'TEXT_TO_FILTER', payload: search });
  }, [search]);
  useEffect(() => {
    setSearch('');
  }, [selectedTab]);

  return (
    <section className="table-container">
      <section className="userOptions">
        <Search
          placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
          width="50%"
        />
        <button
          type="submit"
          className="searchButton"
          style={{
            borderRadius: '5px',
            //rotate 90deg
            transform: 'rotate(90deg)',
          }}
        >
          <MdAutorenew className="icon-refresh" onClick={DeterminateTypeUser} />
        </button>
      </section>
      <Tabs defaultIndex={indexTabServices} selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                _SetDispatch({ type: 'TEXT_TO_FILTER', payload: '' });
                _SetDispatch({ payload: tab.reduce, type: `TAB_SELECTED` });
                _SetDispatch({ type: 'ROWS_PER_PAGE', payload: 10 });
                localStorage.setItem('indexNotification', index.toString());
              }}
              key={`${index + 1}`}
              className="new-tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {tabs.map((tab, index) => (
          <TabPanel key={`${index + 0}`}>{tab.componente}</TabPanel>
        ))}
      </Tabs>
    </section>
  );
};

export default PanelNotifications;
