import React, { useEffect, useState } from 'react';
// Import Contexts
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import endpoints from 'services/api';
// Import Components
import WarningDialog from 'components/tableOptions/WarningDialog';
// Mui Cell row style
import TableRow from '@mui/material/TableRow';
import { MdOutlineCheckBox, MdOutlineCheckBoxOutlineBlank } from 'react-icons/md';
// Icons for cell
import TableCell from '@mui/material/TableCell';
import { useSeachContext } from 'context/SearchContext';
import { getItemById } from 'services/api/methods';

        
const DynamicRowNotifications = ({ titles, columns, handleDeleteItem, setUpdated }) => {
  // Modal config
  const [changeState, setChangeState] = useState(columns.leido);

  // use Hook of language v2
  const { formatterText } = useLangv2();
  // eslint-disable-next-line no-unused-vars
  const { searchResults = [] } = useSeachContext();

  const [stateAux, setStateAux] = useState(columns.estado);
  // eslint-disable-next-line no-unused-vars
  const [loading, setLoading] = useState(false);
  // Dialog edit
  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  useEffect(() => {
    setStateAux(columns.estado);
  }, [searchResults]);

  const closeDialog = () => {
    setLoading(false);
    setDialog({ ...dialog, active: false });
  };

  const handleMarkAsRead = async (columns) => {
    getItemById(endpoints.notificationsTable.markAsRead, columns.idAgendaNotificacion).then(
      (response) => {
        // setChangeState(true);
        setUpdated(true)
        // setStateAux()
        closeDialog();
      },
    );
  };

  return (
   
      <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
        {Object.keys(columns).map((column, index) => {
          if (column === 'idAgendaNotificacion' || column === 'idServicio' || column === 'leido') {
            return null;
          }
          return (
            <TableCell
              key={`${index + 1}`}
              component="th"
              scope="row"
              className="enabled"
              style={{ cursor: 'pointer' }}
              onClick={() => {
                //open a new window with a param
                window.open(`#/servicios/editar/${columns.idServicio.idServicio}`, '_blank');
              }}
            >
              {columns[column]}
            </TableCell>
          );
        })}
        <TableCell className={loading ? 'disabled' : 'enabled'} align="center">
          {changeState === null ? (
            <MdOutlineCheckBoxOutlineBlank
              className="icon"
              onClick={() => {
                setDialog({
                  text: formatterText('alert.modal.mark.as.read.notifications'),
                  active: true,
                  funcion: () => handleMarkAsRead(columns),
                });
              }}
            />
          ) : (
            <MdOutlineCheckBox className="icon" />
          )}
        </TableCell>
        <WarningDialog dialog={dialog} setDialog={setDialog} />
      </TableRow>
  
  );
};

export default DynamicRowNotifications;
