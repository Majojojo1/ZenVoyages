import React, { useContext, useEffect, useState } from 'react';
// Import Context
// Import Hooks
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
// Import Components
import DynamicHeadNotifications from './DynamicTableNotificacion/DynamicHeadNotifications';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import services
import { ContextUse } from './ContextAlert';

const Notifications = () => {
  // hook to loading data
  const { loading, error, displayMessage, displayLoading } = useGetData();
  const { state, _SetDispatch, DeterminateTypeUser } = useContext(ContextUse);
  const [updated, setUpdated] = useState(false);

  const setCurrentPage = (page) => {
    _SetDispatch({ type: 'CURRENT_PAGE_NOTIFICATION', payload: page });
  };

  const setRowsPerPage = (rows) => {
    _SetDispatch({ type: 'ROWS_PER_PAGE', payload: rows });
  };
  const { fetchData, COOKIE_USER } = useAxios();

  const titles = [
    <FormattedMessage key={'tab.title.dates'} id="tab.title.dates" defaultMessage="Fecha / Hora" />,
    <FormattedMessage key="tab.title.ticket" id="tab.title.ticket" defaultMessage="Ticket" />,
    <FormattedMessage
      key={'tab.title.category'}
      id="tab.title.category"
      defaultMessage="Categoria"
    />,
    <FormattedMessage key={'tab.title.message'} id="tab.title.message" defaultMessage="Mensaje" />,
    <FormattedMessage
      key={'table.name.search'}
      id="table.name.search.client"
      defaultMessage="Cliente"
    />,
    <FormattedMessage key={'table.title.city'} id="table.title.city" defaultMessage="Ciudad" />,
    <FormattedMessage
      key={'tab.title.date'}
      id="tab.title.date.markasread"
      defaultMessage="Leído el"
    />,
    <FormattedMessage
      key={'tab.title.markasread'}
      id="tab.title.markasread"
      defaultMessage="Marcar como leida"
    />,
  ];

  useEffect(() => {
    DeterminateTypeUser();
  }, [updated === true]);

  return (
    <>
      {!loading ? (        
          <FormattedMessage id="table.name.search.product" defaultMessage="Categoría de producto">
            {(placeholder) => (
              <DynamicHeadNotifications
                titles={titles}
                getData={DeterminateTypeUser}
                page={state.currentPageNotification}
                rowsPerPage={state.rowsPerPage}
                setPage={setCurrentPage}
                setRowsPerPage={setRowsPerPage}
                data={state.filteredNotification}
                totalData={state.currentCountNotification}
                updated={setUpdated}
              />
            )}
          </FormattedMessage>       
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default Notifications;
