import React from "react";
// Import Hooks
import useLang from "hooks/useLang";
import { useNavigate } from "react-router-dom";
// Import Components
import { Formiz, FormizStep, useForm } from "@formiz/core";
import HandleOnError from "common/validators/HandleOnError";
import CustomAlert from "components/CustomAlert";
// Import libs
import Swal from "sweetalert2";
// // Import services
import endpoints from "services/api";
import { addItem } from "services/api/methods";
import paths from "services/paths";

const CreateExample = () => {
  // Formiz object
  const myForm = useForm();
  // Example of form data
  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();

  // This function is executed when the create button is clicked
  const handleSubmit = (values) => {
    let data = {};

    console.log(data);

    createItem(data);
  };

  // Create new service
  const createItem = (data) => {
    Swal.fire({
      title: formatterText("alert.title.general"),
      text: formatterText("alert.description.create.general"),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText("alert.button.confirm.general"),
      allowOutsideClick: false,
      cancelButtonText: formatterText("alert.button.cancel.general"),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addItem(endpoints.services.addService, data)
            .then((_) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText("alert.title.confirm.general"),
                  text: formatterText("alert.message.confirm.created.general"),
                  confirmButtonText: formatterText("alert.button.continue"),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.serviceModule),
                }),
              );
            })
            .catch((err) => {
              reject(
                HandleOnError(formatterText("alert.message.failed.general")),
              );
              console.log(err);
            });
        });
      },
    });
  };

  // Display errors

  return (
    <>
      <div className="centered-form">
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form
            noValidate
            onSubmit={myForm.submit}
            className="container-wrapForm"
            style={{ minHeight: "16rem" }}
          >
            <div className="new-container-wrapForm__tabs">
              {myForm.steps.map((step) => (
                <button
                  key={step.name}
                  className={`new-tab-option ${
                    step.name === myForm.currentStep.name ? "is-active" : ""
                  }`}
                  type="button"
                  onClick={() => myForm.goToStep(step.name)}
                >
                  {step.label}
                  {!step.isValid && step.isSubmitted && (
                    <small className="mr-2">⚠️</small>
                  )}
                </button>
              ))}
            </div>

            <div className="container-wrapForm-content">
              <FormizStep name="step1" label="HU5 Mapa"></FormizStep>
              <FormizStep
                name="step2"
                label="HU11 Agenda Librería"
              ></FormizStep>
              <FormizStep
                name="step3"
                label="HU1 Tabla Crear Reporte"
              ></FormizStep>
              <FormizStep name="step4" label="HU10 Notificaciones"></FormizStep>
              <FormizStep name="step5" label="HU6 Asignar"></FormizStep>
              <FormizStep name="step6" label="HU10 Alertas"></FormizStep>
              {/* This button is hidden, but the reference in the id helps to execute the form (you can check it below in the class called "text")*/}
              <input
                type="submit"
                id="submit-form"
                style={{ visibility: "hidden" }}
              />
            </div>
          </form>
        </Formiz>
      </div>
      <div className="demo-form__footer">
        <section className="form-responsive-container-buttons">
          <button style={{ padding: "0px" }} className="btn-primary">
            <label className="btn-wrap-add" for="submit-form" tabindex="0">
              Crear servicio
            </label>
          </button>
          <button
            className="input-cancel"
            onClick={() => navigate(paths.example)}
          >
            Cancelar
          </button>
        </section>
      </div>
    </>
  );
};

export default CreateExample;
