import useLang from 'hooks/useLang';
import React, { useEffect, useState } from 'react';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import HandlerEmail from 'common/validators/HandlerEmail';
import HandlerNumbers from 'common/validators/HandlerNumbers';
import HandlerText from 'common/validators/HandlerText';
import CustomAlert from 'components/CustomAlert';
// Import libs
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
// Import model
import CategoryService from 'models/CategoryService';
// Import de services
import SortData from 'components/utils/SortData';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import useGetData from 'hooks/useGetData';
import endpoints from 'services/api';
import { getAllClients, updateClient } from 'services/api/clients';
import { addItem } from 'services/api/methods';
import paths from 'services/paths';

const UpdateModalItem = () => {
  return (
    <SearchWrapper>
      <UpdateModalItemComponent />
    </SearchWrapper>
  );
};

function UpdateModalItemComponent({ onClose, exeFun }) {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();
  useEffect(() => {
    getDataTable();
  }, []);
  const [clients, setClients] = useState(null);
  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAllClients()
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortData(newArray, 'asc');
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
        setClients(sortedArray);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };
  //  Call hook of language
  const { formatterText } = useLang();
  // Example of form data
  const [formData, setFormData] = useState(new CategoryService());

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    onClose();
    let data = {
      ...formData,
      idGenero: {
        idGenero: formData.idGenero,
      },
      idUnidadNegocio: {
        idUnidadNegocio: formData.idUnidadNegocio,
      },

      usuarioCreacion: Cookie.get('idUsuario'),
    };
    console.log(data);
    postItem(data);
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateClient(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    let docType = `${item.idTipoDocumento.nombre} - ${item.idTipoDocumento.abreviatura}`;
    newArray.push({
      id: item.idCliente,
      nombre: item.nombreRazonSocial,
      tipo_documento: docType,
      documento: item.identificacion,
      //   estado: item.estado,
      objeto: { ...item },
    });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    HandlerNumbers(e, formData, setFormData);
  };

  // Update a email to set into the form
  const handleEmail = (e) => {
    HandlerEmail(e, formData, setFormData);
  };

  const postItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.create.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.services.createExternalUser, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general'),
                  text: formatterText('alert.message.confirm.created.general'),
                  confirmButtonText: formatterText('alert.button.continue'),
                  allowOutsideClick: false,
                  executeFunction: () => exeFun(),
                }),
              );
            })
            .catch((err) => {
              if (err.response.status === 400 || err.response.status === 420) {
                reject(HandleOnError(formatterText('alert.message.code.error.general')));
              } else {
                reject(HandleOnError(formatterText('alert.message.failed.general')));
              }
              console.log(err);
            });
        });
      },
    });
  };

  return (
    <>
      <form className="w100-container" onSubmit={(e) => handleSubmit(e)}>
        <section className="table-container">
          <section className="userOptions">
            <Search
              placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
              width="50%"
            />
            <button className="btn-add"
              onClick={(e) => {
                e.preventDefault();
                window.open(
                  `#${paths.createClient}`,
                  "_blank",
                  
                )
              }}
            >Crear Cliente</button>

          </section>
          <DynamicTable
            titles={['Nombre cliente', 'Tipo de documento', 'Identificación']}
            pageName={'Clientes'}
            getData={getDataTable}
            handleDeleteItem={handleEditStateItem}
            handleEditStateItem={handleEditStateItem}
            routeToEdit={paths.updateClient}
            canDeleted={true}
            canModify={true}
          />
        </section>
      </form>
    </>
  );
}

export default UpdateModalItem;
