import React from "react";

export default function Container1(
  formData,
  handleSubmit,
  handleText,
  handleNumber
) {
  return (
    <form className="w100-container" onSubmit={(e) => handleSubmit(e)}>
      <section className="">
        <p className="">Crear cliente</p>
        <section className="grid-container-2c">
          <section className="d-flex">
            <h3 className="text-inline">Primer nombre</h3>
            <input
              className=""
              type="text"
              name="primerNombre"
              value={formData.primerNombre}
              onChange={handleText}
              placeholder="Primer Nombre"
              maxLength="45"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Segundo nombre</h3>
            <input
              className=""
              type="text"
              name="segundoNombre"
              value={formData.segundoNombre}
              onChange={handleText}
              placeholder="Segundo Nombre"
              maxLength="45"
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Primer apellido</h3>
            <input
              className=""
              type="text"
              name="primerApellido"
              value={formData.primerApellido}
              onChange={handleText}
              placeholder="Primer Apellido"
              maxLength="45"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Segundo apellido</h3>
            <input
              className=""
              type="text"
              name="segundoApellido"
              value={formData.segundoApellido}
              onChange={handleText}
              placeholder="Segundo Apellido"
              maxLength="45"
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Género</h3>
            <select
              className=""
              name="idGenero"
              value={formData.idGenero}
              onChange={handleText}
              required
            >
              <option value="">Seleccione</option>
              <option value="1">Masculino</option>
              <option value="2">Femenino</option>
            </select>
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Unidad de negocio</h3>
            <select
              className=""
              name="idUnidadNegocio"
              value={formData.idUnidadNegocio}
              onChange={handleText}
              required
            >
              <option value="">Seleccione</option>
              <option value="5">Unidad de negocio 1</option>
            </select>
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Teléfono</h3>
            <input
              className=""
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleNumber}
              placeholder="Ingresa  un teléfono válido"
              maxLength="15"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Correo</h3>
            <input
              className=""
              type="email"
              name="correo"
              value={formData.correo}
              onChange={handleText}
              placeholder="Ingresa  un correo válido"
              maxLength="100"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Usuario especial</h3>
            <select
              className=""
              name="usuarioEspecial"
              value={formData.usuarioEspecial}
              onChange={handleText}
              required
            >
              <option value="">Seleccione</option>
              <option value="1">Si</option>
              <option value="0">No</option>
            </select>
          </section>
        </section>

        <section className="footer-grid-buttons">
          <input type="submit" className="" value="Guardar cambios" />
          <button className="" onClick={() => alert("Llama algún servicio")}>
            Cancelar
          </button>
        </section>
      </section>
    </form>
  );
}
