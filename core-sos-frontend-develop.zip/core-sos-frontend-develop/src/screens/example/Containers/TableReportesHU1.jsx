import React from "react";

export default function TableReportesHU1() {
  return (
    <div>
      <p>Hello</p>
    </div>
  );
}
