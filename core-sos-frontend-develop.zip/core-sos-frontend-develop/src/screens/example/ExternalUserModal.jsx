import useLang from "hooks/useLang";
import React, { useState } from "react";
// Import Components
import HandlerEmail from "common/validators/HandlerEmail";
import HandlerNumbers from "common/validators/HandlerNumbers";
import HandlerText from "common/validators/HandlerText";
import CustomAlert from "components/CustomAlert";
// Import libs
import Cookie from "js-cookie";
import Swal from "sweetalert2";
// Import model
import CategoryService from "models/CategoryService";
// Import de services
import endpoints from "services/api";
import { addItem } from "services/api/methods";

export default function UpdateModalItem({ onClose, exeFun }) {
  //  Call hook of language
  const { formatterText } = useLang();
  // Example of form data
  const [formData, setFormData] = useState(new CategoryService());

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    onClose();
    let data = {
      ...formData,
      idGenero: {
        idGenero: formData.idGenero,
      },
      idUnidadNegocio: {
        idUnidadNegocio: formData.idUnidadNegocio,
      },

      usuarioCreacion: Cookie.get("idUsuario"),
    };
    console.log(data);
    postItem(data);
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    HandlerNumbers(e, formData, setFormData);
  };

  // Update a email to set into the form
  const handleEmail = (e) => {
    HandlerEmail(e, formData, setFormData);
  };

  const postItem = (data) => {
    Swal.fire({
      title: formatterText("alert.title.general"),
      text: formatterText("alert.description.create.general"),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText("alert.button.confirm.general"),
      allowOutsideClick: false,
      cancelButtonText: formatterText("alert.button.cancel.general"),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.services.createExternalUser, data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText("alert.title.confirm.general"),
                  text: formatterText("alert.message.confirm.created.general"),
                  confirmButtonText: formatterText("alert.button.continue"),
                  allowOutsideClick: false,
                  executeFunction: () => exeFun(),
                }),
              );
            })
            .catch((err) => {
              if (err.response.status === 400 || err.response.status === 420) {
                reject(
                  HandleOnError(
                    formatterText("alert.message.code.error.general"),
                  ),
                );
              } else {
                reject(
                  HandleOnError(formatterText("alert.message.failed.general")),
                );
              }
              console.log(err);
            });
        });
      },
    });
  };

  return (
    <>
      <form className="w100-container" onSubmit={(e) => handleSubmit(e)}>
        <section className="">
          <p className="">Crear cliente</p>
          <section className="grid-container-2c">
            <section className="d-flex">
              <h3 className="text-inline">Primer nombre</h3>
              <input
                className=""
                type="text"
                name="primerNombre"
                value={formData.primerNombre}
                onChange={handleText}
                placeholder="Primer Nombre"
                maxLength="45"
                required
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Segundo nombre</h3>
              <input
                className=""
                type="text"
                name="segundoNombre"
                value={formData.segundoNombre}
                onChange={handleText}
                placeholder="Segundo Nombre"
                maxLength="45"
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Primer apellido</h3>
              <input
                className=""
                type="text"
                name="primerApellido"
                value={formData.primerApellido}
                onChange={handleText}
                placeholder="Primer Apellido"
                maxLength="45"
                required
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Segundo apellido</h3>
              <input
                className=""
                type="text"
                name="segundoApellido"
                value={formData.segundoApellido}
                onChange={handleText}
                placeholder="Segundo Apellido"
                maxLength="45"
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Género</h3>
              <select
                className=""
                name="idGenero"
                value={formData.idGenero}
                onChange={handleText}
                required
              >
                <option value="">Seleccione</option>
                <option value="1">Masculino</option>
                <option value="2">Femenino</option>
              </select>
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Unidad de negocio</h3>
              <select
                className=""
                name="idUnidadNegocio"
                value={formData.idUnidadNegocio}
                onChange={handleText}
                required
              >
                <option value="">Seleccione</option>
                <option value="5">Unidad de negocio 1</option>
              </select>
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Teléfono</h3>
              <input
                className=""
                type="text"
                name="telefono"
                value={formData.telefono}
                onChange={handleNumber}
                placeholder="Ingresa  un teléfono válido"
                maxLength="15"
                required
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Correo</h3>
              <input
                className=""
                type="email"
                name="correo"
                value={formData.correo}
                onChange={handleEmail}
                placeholder="Ingresa  un correo válido"
                maxLength="100"
                required
              />
            </section>
            <section className="d-flex">
              <h3 className="text-inline">Usuario especial</h3>
              <select
                className=""
                name="usuarioEspecial"
                value={formData.usuarioEspecial}
                onChange={handleText}
                required
              >
                <option value="">Seleccione</option>
                <option value="1">Si</option>
                <option value="0">No</option>
              </select>
            </section>
          </section>

          <section className="footer-grid-buttons">
            <input type="submit" className="" value="Guardar cambios" />
            <button className="" onClick={() => onClose()}>
              Cancelar
            </button>
          </section>
        </section>
      </form>
    </>
  );
}
