import React, { useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import { useLocation } from 'react-router';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
// Import libs
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import services
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

// import HU1FTableNQR from "./davvComponents/HU1FTableNQR";
// import HU10S9PSTable from "./davvComponents/HU10S9PSTable";

const ExampleTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ExampleTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function ExampleTableComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();
  // hook useLocation
  const location = useLocation();

  const [access, setAccess] = useState([]);


   // nuevo contexto
   const { permissionsAccess, crear, editar, eliminar, consultar, exportar, permissions } =
   usePermissionContext();

 const permissionsAccessExample = () => {
   permissionsAccess(1);
 };

  useEffect(() => {
    getDataTable();
  }, []);

  useEffect(() => {
    permissionsAccessExample();
  }, [permissions]);


  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.users.getAllUsers)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idUsuario,
      nombre: item.usuario,
      apellido: item.usuario,
      correo: item.correo,
      created_at: dateFormat(item.fechaRegistro, 'yyyy/mm/dd - h:MM:ss TT'),
      estados: item.estado,
      objeto: { ...item },
    });
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  // titulos de la tabla
  const titles = [
    'Tipo de reporte',
    'Descripción',
    'Usuario',
    'Fecha y hora',
    'Formulario asociado',
    'Actividad relacionada',
    'Acciones',
  ];

  return (
    <>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          padding: '0 20px',
          height: '10vh',
        }}
      >
        <Link to={paths.createExample}>
          <button className="btn-add">Ir a template de Daniel</button>
        </Link>
        <Link to={paths.createExamplejj}>
          <button className="btn-add">Ir a template de Juan José</button>
        </Link>
      </div>
      {/* Aquí edita Juan Jose */}
      {/* Aquí edita Daniel */}
      {/* Tabla NQR */}
      {/* <HU1FTableNQR /> */}
      {/* Tabla Recaudos */}
      <div className="externalElementsContainer">
        <label className="wrapForm__label">
          <h3 className="p-styles primary-green spacing-l1">+ Registrar recaudo</h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Ingresos: $1000</h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Devoluciones: $100</h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Valor total recaudado: $900</h3>
        </label>
      </div>
      {/* <section className="tdR thR table-container">
        {consultar && (
          <FormattedMessage
            id="table.name.search.users"
            defaultMessage="Recaudos"
          >
            {(placeholder) => (
              <DynamicTable
                titles={titlesR}
                pageName={placeholder}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateUser}
                canDeleted={eliminar}
                canModify={editar}
              />
            )}
          </FormattedMessage>
        )}
      </section> */}
      {/* Tabla de Productos y Servicios */}
      {/* <HU10S9PSTable /> */}

      {!loading ? (
        <section className="table-container">
          <section className="userOptions">
            {/* <Search
              placeholder={formatterText(
                "placeholder.search.multi.items",
                "Buscar por palabra",
              )}
              width="50%"
            /> */}

            <button
              className=""
              style={{
                background: 'linear-gradient(113.52deg, #ffc954 34.84%, #e9b440 122.42%)',
                boxShadow: '0px 4px 8px rgba(0, 174, 142, 0.2)',
                border: '0',
                borderRadius: '50px',
                padding: '0.2rem 0.2rem',
                fontFamily: 'inherit',
                color: 'var(--text-dark)',
                fontWeight: 'bold',
                width: 'fit-content',
                /* minWidth: "300px", */
                cursor: 'pointer',
                maxWidth: '200px',
              }}
            >
              <label style={{ paddingLeft: '0.5rem', paddingRight: '0.5rem' }}>
                Registrar reporte
              </label>
            </button>
          </section>
          {consultar && (
            <FormattedMessage id="table.name.search.users" defaultMessage="Usuarios">
              {(placeholder) => (
                <DynamicTable
                  titles={titles}
                  pageName={placeholder}
                  getData={getDataTable}
                  handleDeleteItem={handleDeleteItem}
                  handleEditStateItem={handleEditStateItem}
                  routeToEdit={paths.updateUser}
                  canDeleted={true}
                  /* canModify={editar} */
                />
              )}
            </FormattedMessage>
          )}
        </section>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
}

export default ExampleTable;
