import CustomAlert from "components/CustomAlert";
import Cookie from "js-cookie";
import Cargo from "models/Cargo";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getCargoById, updateCargo } from "services/api/cargos";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function UpdateExample() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new Cargo());
  // toggle state
  const [active, setActive] = useState(true);

  useEffect(() => {
    getDataExampleById();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getDataExampleById = () => {
    getCargoById(id)
      .then((res) => {
        setFormData(res);
        setActive(formData.estado === "1" ? true : false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
      // instance.setPosition(e.target.name, e.target.value);
    }
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    Swal.fire({
      title: "Atención, estás seguro de realizar esta acción",
      text: "Se va a crear un nuevo agregar",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: `Guardar cambios`,
      allowOutsideClick: false,
      cancelButtonText: "Cancelar",
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateCargo(data)
            .then((response) => {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: "Operación exitosa",
                text: "Se creo el sector correctamente",
                confirmButtonText: "Continuar",
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.positions),
              });
            })
            .catch((err) => {
              if (err.response.status === 412) {
                HandleOnError(err.response.data);
                console.log(err.response.data);
              } else {
                console.log("error");
                HandleOnError("Error al crear el cargo, intenta de nuevo.");
              }

              console.log(err);
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3>Nombre cargo</h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder="Nombre de la ejemplo"
            maxLength="50"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Descripción</h3>
          <input
            className="input-primary"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handleChange}
            placeholder="Descripción del ejemplo"
            maxLength="200"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3>Estado</h3>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active ? "Activo" : "No activo"}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          Guardar cambios
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.positions)}
        >
          Cancelar
        </button>
      </section>
    </form>
  );
}
