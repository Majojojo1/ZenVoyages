import React, { useEffect, useState, useContext } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import HandleOnError from 'common/validators/HandleOnError';
import HandlerEmail from 'common/validators/HandlerEmail';
import HandlerNumbers from 'common/validators/HandlerNumbers';
import HandlerText from 'common/validators/HandlerText';
import CustomAlert from 'components/CustomAlert';
// Import libs
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
// Import Services
import endpoints from 'services/api';
import { addItem, getAll } from 'services/api/methods';
import Selector from 'common/selects/Selector';
import SelectorSearch from 'common/selects/SelectorSearch';
import { FormattedMessage } from 'react-intl';
import SelectorMulti from 'common/selects/SelectorMultiCreate';
import { useNavigate } from 'react-router-dom';
import paths from 'services/paths';

export default function CreateExternalUser({setIsOpenExternalUser}) {
  const [listPrices, setListPrices] = useState({});
  const [selectorValues, setSelectorValues] = useState([]);
  const [secondaryPrices, setSecondaryPrices] = useState({});
  const [units, setUnits] = useState();
  const [selectUnits, setSelectUnits] = useState([]);
  const [selectValues, setSelectValues] = useState([]);
  const [auxData, setAuxData] = useState({
    idListaPrecios: 0,
  });

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  const handleChangeUnits = (e) => {
    // console.log(e);
    setSelectUnits(e);
  };
  //Resetea los precios secundarios si se modifica el precio principal
  useEffect(() => {
    getSecondaryPrices();
  }, [auxData.idListaPrecios]);

  const getSecondaryPrices = () => {
    //Comprueba la cantidad de precios secundarios, para resetearlos
    if (selectValues.length !== 0) {
      let sameList = selectValues.filter((item) => item === auxData.idListaPrecios);
      let exceptList = selectValues.filter((item) => item !== auxData.idListaPrecios);
      //Si se encuentra que el precio principal es igual a alguno de los secundarios, se resetea elimina este
      if (sameList.length >= 1) {
        setSecondaryPrices(exceptList);
        setSelectValues(exceptList);
      }
    }
    //Si se selecciono algun valor principal, muestra los precios secundarios disponibles
    if (auxData.idListaPrecios !== 0) {
      let filter = listPrices.filter((item) => item !== auxData.idListaPrecios);
      setSecondaryPrices(filter);
    }
  };

  // useLanguage
  const { formatterText } = useLangv2();
  // State of form
  const [formData, setFormData] = useState({
    primerNombre: '',
    segundoNombre: '',
    primerApellido: '',
    segundoApellido: '',
    correo: '',
    telefono: '',
    idGenero: '',
    usuarioEspecial: '',
  });

  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  // const [data, setData] = useState([]);

  useEffect(() => {
    getAllBusinessUnits3();
    // getAllBusinessUnits();
    getListPrices();
  }, []);

  const closeModal = _ => {
    if(setIsOpenExternalUser instanceof Function)
      setIsOpenExternalUser(false);
  }

  //Obtener los datos de internet 1 vez
  const getListPrices = () => {
    getAll(endpoints.listPrices.getAllListPrices)
      .then((res) => {
        let newArray = [];
        res.map((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idListaPreciosActividad,
              label: `${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        setListPrices(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getAllBusinessUnits3 = () => {
    setLoading(true);
    getAll(endpoints.businessUnit.getAllBusinessUnits).then((res) => {
      let newArray = [];
      res.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idUnidadNegocio,
            label: item.nombre,
          });
        }
      });
      setUnits(newArray);
      setLoading(false);
    });
  };

  // Create a new external user structure
  const handleSubmit = () => {
    if (
      formData.primerNombre === '' ||
      formData.primerApellido === '' ||
      formData.correo === '' ||
      formData.telefono === '' ||
      formData.idGenero === '' ||
      formData.usuarioEspecial === '' ||
      selectUnits.length == 0
    ) {
      Swal.fire({
        icon: 'warning',
        title: 'Error',
        text: 'Faltan campos por llenar',
      });
    } else {
      let data = {
        usuarioServicioDto: {
          ...formData,
          idGenero: {
            idGenero: parseInt(formData.idGenero),
          },
          usuarioEspecial: parseInt(formData.usuarioEspecial),
          usuarioCreacion: parseInt(Cookie.get('idUsuario')),
        },
        unidadNegocios: selectUnits.map((item) => ({
          idUnidadNegocio: item.value,
        })),
      };
      postItem(data);
    }
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, formData, setFormData);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    HandlerNumbers(e, formData, setFormData);
  };

  // Update a email to set into the form
  const handleEmail = (e) => {
    HandlerEmail(e, formData, setFormData);
  };

  // Create new external user
  const postItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.services.createExternalUser, data)
            .then((res) => {
              AssociatePrices(res.usuarioServicio.idUsuarioServicio, resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 400 || err.response.status === 420) {
                reject(
                  HandleOnError(
                    formatterText(
                      'alert.message.code.error.externalUser',
                      'El número de teléfono ya existe',
                    ),
                  ),
                );
              } else {
                reject(
                  HandleOnError(
                    formatterText(
                      'alert.message.failed.general',
                      'Error al crear el registro, por favor intente nuevamente.',
                    ),
                  ),
                );
              }
            }).finally(_ => closeModal());
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.confirm.updated.general',
              'El registro se ha actualizado correctamente',
            ),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.createService),
          });
          // associatePrices(response, values, resolve, reject);
        });
      },
    });
  };

  const AssociatePrices = (id, res, err) => {
    let body = {
      idListaPreciosActividadCliente: null,
      idListaPreciosActividad: {
        idListaPreciosActividad: auxData.idListaPrecios.value,
      },
      principal: 1,
      idUsuarioServicio: id,
      // idUsuarioServicio: id,
    };
    addItem(endpoints.listPriceClient.addListPriceClient, body)
      .then((x) => {
        associateSecondaryPrices(id, res, err);
      })
      .catch((x) => {
        err(
          HandleOnError(
            formatterText(
              'alert.message.failed.general',
              'Error al asociar la lista de precios principal.',
            ),
          ),
        );
      });
  };

  const associateSecondaryPrices = (id, resolve, reject) => {
    if (selectValues.length !== 0) {
      const promesas = selectValues.map(
        (item) =>
          new Promise((resl, rej) => {
            let data = {
              idListaPreciosActividadCliente: null,
              idListaPreciosActividad: { idListaPreciosActividad: item.value },

              idUsuarioServicio: id,
              principal: 0,

              //idUsuarioServicio: id,
            };
            addItem(endpoints.listPriceClient.addListPriceClient, data)
              .then((res) => {
                resl(res);
              })
              .catch((err) => {
                rej(err);
              });
          }),
      );
      Promise.all(promesas)
        .then(() => {
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText(
                'alert.message.confirm.created.general',
                'El registro se ha creado correctamente',
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => console.log('User created', true),
            }),
          );
        })
        .catch((err) => {
          reject(
            HandleOnError(
              formatterText(
                'alert.message.failed.general',
                'Error al crear el registro, por favor intente nuevamente.',
              ),
            ),
          );
        });
    } else {
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.created.general',
            'El registro se ha creado correctamente',
          ),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => console.log('User created', true),
        }),
      );
    }
  };

  return (
    <form className="w100-container">
      <section className="padding-all-1">
        <p className="title-modal">Crear usuarios</p>
        <section className="grid-container-2c">
          <section className="d-flex">
            <h3 className="text-inline">Primer nombre</h3>
            <input
              className="input-default custom-margin-0010"
              type="text"
              name="primerNombre"
              value={formData.primerNombre}
              onChange={handleText}
              placeholder="Primer Nombre"
              maxLength="45"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Segundo nombre</h3>
            <input
              className="input-default custom-margin-0010"
              type="text"
              name="segundoNombre"
              value={formData.segundoNombre}
              onChange={handleText}
              placeholder="Segundo Nombre"
              maxLength="45"
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Primer apellido</h3>
            <input
              className="input-default custom-margin-0010"
              type="text"
              name="primerApellido"
              value={formData.primerApellido}
              onChange={handleText}
              placeholder="Primer Apellido"
              maxLength="45"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Segundo apellido</h3>
            <input
              className="input-default custom-margin-0010"
              type="text"
              name="segundoApellido"
              value={formData.segundoApellido}
              onChange={handleText}
              placeholder="Segundo Apellido"
              maxLength="45"
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Género</h3>
            <select
              className="input-default custom-margin-0010"
              name="idGenero"
              value={formData.idGenero}
              onChange={handleText}
              required
            >
              <option value="">Seleccione una opción</option>
              <option value="1">Masculino</option>
              <option value="2">Femenino</option>
            </select>
          </section>
          {/* aqui van las unidades */}
          <section className="d-flex">
            <h3 className="text-inline">Unidades de negocio</h3>
            <SelectorMulti
              data={units}
              isLoading={loading}
              dataValue={selectUnits}
              setterFunction={handleChangeUnits}
              required="La unidad de negocio es requerida"
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Teléfono</h3>
            <input
              className="input-default custom-margin-0010"
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleNumber}
              placeholder="Ingresa  un teléfono válido"
              maxLength="15"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Correo</h3>
            <input
              className="input-default custom-margin-0010"
              type="email"
              name="correo"
              value={formData.correo}
              onChange={handleEmail}
              placeholder="Ingresa  un correo válido"
              maxLength="100"
              required
            />
          </section>
          <section className="d-flex">
            <h3 className="text-inline">Usuario especial</h3>
            <select
              className="input-default custom-margin-0010"
              name="usuarioEspecial"
              value={formData.usuarioEspecial}
              onChange={handleText}
              required
            >
              <option value="">Seleccione una opción</option>
              <option value="1">Si</option>
              <option value="0">No</option>
            </select>
          </section>

          <section className="d-flex">
            <h3 className="text-inline">Lista de precios primaria</h3>
            <SelectorSearch
              className="input-default custom-margin-0010"
              name="idListaPrecios"
              data={listPrices}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              dataValue={auxData.idListaPrecios}
              setterFunction={setAuxData}
              isLoading={loading}
              selectValue={selectorValues}
              isRequired={false}
            />
          </section>

          <section className="d-flex">
            <h3 className="text-inline">Lista de precios secundaria</h3>
            <SelectorMulti
              data={secondaryPrices}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
            />
          </section>
        </section>

        <section className="footer-grid-buttons">
          <button
            className="btn-action-primary"
            onClick={(e) => {
              e.preventDefault();
              handleSubmit();
            }}
          >
            Crear usuario
          </button>
          <button 
            type='button'
            className="btn-action-cancel"
            onClick={(e) => {
              // e.preventDefault();
              // window.close();
              closeModal();
              window.close();
            }}
          >
            Cerrar pestaña
          </button>
        </section>
      </section>

      {/* <button
        onClick={(e) => {
          e.preventDefault();
          getAllBusinessUnits3();
        }}
      >
        Llamar otra vez
      </button>
      <button
        onClick={(e) => {
          e.preventDefault();
          cancelRequest();
        }}
      >
        Cancelar
      </button>
      {loading ? (
        <p>Cargando</p>
      ) : (
        <div>
          {data && data.map((i) => <p key={i.idUnidadNegocio}>{i.nombre}</p>)}
        </div>
      )} */}
    </form>
  );
}
