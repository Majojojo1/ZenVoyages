import React, { useEffect, useState } from 'react';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import ClienteSucursal from 'common/multiTableType/ClienteSucursal';
import UnityBusiness from 'common/multiTableType/UnityBusiness';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
// Import libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import dateFormat from 'dateformat';
import Cookie from 'js-cookie';
import moment from 'moment';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { MyField } from './inputs/MyField';
// Import services
import { SearchWrapper } from 'context/SearchContext';
import endpoints from 'services/api';
import { getAllCargos } from 'services/api/cargos';
import { getAllContracts } from 'services/api/contracts';
import {
  addFamily,
  deleteFamilyByEmployee,
  getFamiltybyEmployee,
} from 'services/api/employees';
import {
  getAllGenres,
  getAllHalthEntities,
  getAllKin,
  getAllTypeAccounts,
  getAllTypeDocument,
  getAllbanks,
} from 'services/api/institutions';
import { addItem, deleteItem, getItemById, updateItemById } from 'services/api/methods';
import { getAllMunicipalities } from 'services/api/zones';
import paths from 'services/paths';
// Import styles
import { FilterActive } from 'common/validators/FilterActives';
import HandleShortDate from 'common/validators/HandleShortDate';
import Attachments from 'components/AttachedFiles/Attachments';
import { useSeachContext } from 'context/SearchContext';
import useAxios from 'hooks/useAxios';
import 'react-tabs/style/react-tabs.css';

const EditEmployee = () => (
  <SearchWrapper>
    <EditEmployeeComponent />
  </SearchWrapper>
);
const EditEmployeeComponent = () => {
  const navigate = useNavigate();
  const myForm = useForm();
  const { fetchData } = useAxios();
  const [archivos, setCurrentFiles] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showError, setShowError] = useState(false);
  const [loadingData, setLoadingData] = useState(false);
  const [currentRelative, setCurrentRelative] = useState({
    idParentesco: '',
    idGenero: '',
    edad: '',
    nombreCompleto: '',
  });
  // get url id
  const { id } = useParams();
  const [familiares, setFamiliares] = useState([]);
  const [selectData, setSelectData] = useState({});

  const [currentEmployee, setCurrentEmployee] = useState(null);
  const [currentFamiliares, setCurrentFamiliares] = useState([]);

  const { primaryMinimalTable, setPrimaryMinimalTable, secondMinimalTable, setSecondMinimalTable } =
    useSeachContext();
  const now = new Date();
  // useLanguage
  const { formatterText, noFilledContent, newItemCreated, successRemoveItem, resourceNotFound } =
    useLangv2();
  // Helps to loading data table
  const { DisplayProgress } = useProgress();

  useEffect(() => {
    getData();
    getEmployeeFromApi(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getData();
    getEmployeeFromApi(id);
  }, [id]);

  const getData = () => {
    setLoadingData(true);

    const promesas = [
      getAllKin(),
      getAllTypeDocument(),
      getAllGenres(),
      getAllHalthEntities(),
      getAllbanks(),
      getAllTypeAccounts(),
      getAllMunicipalities(),
      getAllCargos(),
      getAllContracts(),
    ];

    Promise.all(promesas).then((values) => {     
      setSelectData({
        ...selectData,
        documentTypes: values[1],
        genres: values[2],
        municipalities: values[6],
        contracts: FilterActive(values[8]),
        positions: FilterActive(values[7]),
        healthEntities: values[3],
        banks: values[4],
        typeAccount: values[5],
        kins: values[0],
      });
    })
    .finally(() => setLoadingData(false));
  };
  //get employee's data from api
  const getEmployeeFromApi = (idEmployee) => {
    getItemById(endpoints.employees.getEmployeeById, idEmployee)
      .then((res) => {
        if (res !== null) {
          getDataEmployee(res);
        } else {
          resourceNotFound();
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const getDataEmployee = (obj) => {
    getDataAttachedFiles(obj.idEmpleado);
    if (obj) {
      getItemById(endpoints.associateDataTechnical.getUserIdbyEmployee, obj.idEmpleado)
        .then((res) => {
          getAllAssociated(res.idUsuario);
          const data = {
            ...obj,
            idTipoDocumento: obj.idTipoDocumento,
            identificacion: obj.identificacion,
            idUsuario: res.idUsuario,
            salario: parseInt(obj.salario),
            rodamiento: parseInt(obj.rodamiento),
          };
          setCurrentEmployee(data);
        })
        .catch(() => {
          const data = {
            ...obj,
            idUsuario: null,
          };
          setCurrentEmployee(data);
        });
    }

    getFamiltybyEmployee(obj.idEmpleado)
      .then((res) => {
        const familiaresAll = res.map((item) => {
          return {
            edad: item.edad,
            nombreCompleto: item.nombre,
            idGenero: {
              idGenero: item.genero.idGenero,
              nombre: item.genero.nombre,
              abreviatura: item.genero.abreviatura,
            },
            idParentesco: {
              idParentesco: item.parentesco.idParentesco,
              nombre: item.parentesco.nombre,
            },
            idFamiliares: item.idFamiliares,
          };
        });

        setFamiliares(familiaresAll);
        setCurrentFamiliares(familiaresAll);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getAllFamilies = (idFam) => {
    getFamiltybyEmployee(idFam)
      .then((res) => {
        const familiaresAll = res.map((item) => {
          return {
            edad: item.edad,
            nombreCompleto: item.nombre,
            idGenero: {
              idGenero: item.genero.idGenero,
              nombre: item.genero.nombre,
              abreviatura: item.genero.abreviatura,
            },
            idParentesco: {
              idParentesco: item.parentesco.idParentesco,
              nombre: item.parentesco.nombre,
            },
            idFamiliares: item.idFamiliares,
          };
        });

        setFamiliares(familiaresAll);
        setCurrentFamiliares(familiaresAll);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleSubmit = (values) => {
    if (showError) {
      return;
    }
    const data = {
      idEmpleado: currentEmployee.idEmpleado,
      idTipoDocumento: { 
        idTipoDocumento:  typeof values.idTipoDocumento === 'object'
        ? values.idTipoDocumento.value
        : values.idTipoDocumento
      },
      primerNombre: values.primerNombre,
      segundoNombre: values.segundoNombre,
      primerApellido: values.primerApellido,
      segundoApellido: values.segundoApellido,
      identificacion: values.identificacion,
      fechaNacimiento: dateFormat(values.fechaNacimiento, 'isoDateTime'),
      idMunicipio: { idMunicipio: values.idMunicipio.value },
      direccion: values.direccion,
      telefono: values.telefono,
      correo: values.correo,
      genero: { idGenero: values.genero.value },
      fechaIngreso: dateFormat(values.fechaIngreso, 'isoDateTime'),
      fechaAfiliacionArl: dateFormat(values.fechaAfiliacionArl, 'isoDateTime'),
      observacion: values.observacion,
      cargo: { idCargo: values.cargo.value },
      tipoContrato: { idTipoContrato: values.tipoContrato.value },
      entidadSalud: { idEntidadSalud: values.entidadSalud.value },
      banco: { idBanco: values.banco.value },
      numeroCuenta: values.numeroCuenta,
      tipoCuenta: { idTipoCuenta: values.tipoCuenta.value },
      estado: 1,
      nombreFamiliar: values.nombreFamiliar,
      telefonoFamiliar: values.telefonoFamiliar,
      salario: convertToNumber(values?.salario || 0),
      rodamiento: convertToNumber(values?.rodamiento || 0),
      fechaRegistro: currentEmployee.fechaRegistro,
      fechaModificacion: null,
      usuarioCreacion: Cookie.get('idUsuario'),
      usuarioModificacion: Cookie.get('idUsuario'),
    };

    handleSaveEmployee(data);
  };

  const convertToNumber = (value) => {
    //convert a $1.234.56 to 123456
    //fix the error use consise character class syntax '\d' instead of '[0-9]'
    try {
      return parseInt(value.replace(/[^0-9]/g, ''));
    } catch (error) {
      return parseInt(value);
    }
  };

  const handleAddFamily = () => {
    if (
      currentRelative.nombreCompleto !== '' &&
      currentRelative.edad !== '' &&
      currentRelative.idParentesco !== '' &&
      currentRelative.idGenero !== ''
    ) {
      const DATA = {
        idFamiliares: null,
        genero: {
          idGenero: currentRelative.idGenero.idGenero,
        },
        empleado: {
          idEmpleado: parseInt(id),
        },
        parentesco: {
          idParentesco: currentRelative.idParentesco.idParentesco,
        },
        nombre: currentRelative.nombreCompleto,
        edad: currentRelative.edad,
      };

      addFamily(DATA)
        .then(() => {
          newItemCreated();
          getAllFamilies(parseInt(id));
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      noFilledContent();
    }
  };

  const handleChangeRelative = (e) => {
    const NAME_REGEX = /^[a-zA-ZÀ-ÿ\u00f1\u00d1 ]*$/;
    if (e.target.value.match(NAME_REGEX)) {
      setCurrentRelative({
        ...currentRelative,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handleChangeNumberRelative = (e) => {
    const NUMBERREGEX = /^[0-9]*$/;
    if (e.target.value.match(NUMBERREGEX)) {
      setCurrentRelative({
        ...currentRelative,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handleChangeSelect = (selectedOption) => {
    setCurrentRelative({
      ...currentRelative,
      [selectedOption.target.name]:
        selectedOption.target.value === ''
          ? selectedOption.target.value
          : JSON.parse(selectedOption.target.value),
    });
  };

  const handleSaveEmployee = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateItemById(endpoints.employees.updateEmployee, data.idEmpleado, data)
            .then(() => {
              handleDeleteAssociation(resolve, reject);

              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.employees),
              });
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  //Sprint 8 Asociaciones
  const handleDeleteAssociation = (resolve, reject) => {
    const dataToDelete = getDiference(primaryMinimalTable, prevPrimaryMinimalTable);
    if (dataToDelete.length > 0) {
      const promesas = dataToDelete.forEach((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteUnityBusiness, item.idAssociate)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      Promise.all(promesas)
        .then((values) => {
          deleteAssociateSucursal(resolve, reject);
        })
        .catch((err) => {
          if (err.response.status === 412) {
            reject(HandleOnError(err.response.data));
          } else {
            console.log('error');
            reject(
              HandleOnError(formatterText('alert.title.employee.edit.deleted.error')),
            );
          }
          console.log(err);
        });
    } else {
      deleteAssociateSucursal(resolve, reject);
    }
  };
  const deleteAssociateSucursal = (resolve, reject) => {
    const data = getDiference(secondMinimalTable, prevSecondMinimalTable);
    if (data.length > 0) {
      const promises = data.forEach((item) => {
        deleteItem(endpoints.associateDataTechnical.deleteSucursal, item.idAssociate)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });

      Promise.all(promises)
        .then((res) => {
          handleAddAssociation(resolve, reject);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      handleAddAssociation(resolve, reject);
    }
  };

  const handleAddAssociation = (resolve, reject) => {
    let newDataToAdd = getNewData(primaryMinimalTable, prevPrimaryMinimalTable);
    if (newDataToAdd.length > 0) {
      const promesas = newDataToAdd.forEach((item) => {
        const data = {
          idUsuario: currentEmployee.idUsuario,
          idUnidadNegocio: item.id,
        };
        addItem(endpoints.associateDataTechnical.addUnityBusiness, data)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject(err);
          });
      });
      Promise.all(promesas)
        .then(() => {
          postAssociateSucursal(resolve, reject);
        })
        .catch((err) => {
          if (err.response.status === 412) {
            reject(HandleOnError(err.response.data));           
          } else {
            console.log('error');
            reject(
              HandleOnError(formatterText('alert.title.employee.edit.deleted.error')),
            );
          }
          console.log(err);
        });
    } else {
      postAssociateSucursal(resolve, reject);
    }
  };
  const postAssociateSucursal = (resolve, reject) => {
    const data = getNewData(secondMinimalTable, prevSecondMinimalTable);
    if (data.length > 0) {
      const promises = data.map(
        (item) =>
          new Promise((resolve, reject) => {
            const data = {
              idUsuario: currentEmployee.idUsuario,
              idSucursal: item.id,
            };
            addItem(endpoints.associateDataTechnical.addSucursal, data)
              .then((res) => {
                resolve(res);
              })
              .catch((err) => {
                reject(err);
              });
          }),
      );
      Promise.all(promises)
        .then((res) => {
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText(
                'alert.message.confirm.updated.general',
                'El registro se ha actualizado correctamente',
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.employees),
            }),
          );
        })
        .catch((err) => {
          reject((err) => {
            if (err.response.status === 412) {
              HandleOnError(err.response.data);     
            } else {
              console.log('error');
              HandleOnError(
                formatterText('alert.title.technician.creation.incomplete'),
              );
            }
            console.log(err);
          });
        });
    } else {
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.updated.general',
            'El registro se ha actualizado correctamente',
          ),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.employees),
        }),
      );
    }
  };

  const [prevPrimaryMinimalTable, setPrevPrimaryMinimalTable] = useState([]);
  const [prevSecondMinimalTable, setPrevSecondMinimalTable] = useState([]);

  useEffect(() => {
    if (
      myForm?.values?.correo !== '' &&
      myForm?.values?.correo !== undefined &&
      myForm?.values?.correo !== null
    ) {
      if (!myForm.values?.correo.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i)) {
        setShowError(true);
      } else {
        setShowError(false);
      }
    }
  }, [myForm?.values?.correo]);

  // funcion que devuelva los datos que no se encuentran en un array buscando por un id
  const getDiference = (array2, array) => {
    let newArray = [];
    array.forEach((item) => {
      let found = array2.find((element) => element.id === item.id);
      if (found === undefined) {
        newArray.push(item);
      }
    });
    return newArray;
  };
  // funcion que devuelva los datos nuevos que se encuentran en un array buscando por un id y que no se encuentran en el otro array
  const getNewData = (array2, array) => {
    let newArray = [];
    array2.forEach((item) => {
      let found = array.find((element) => element.id === item.id);
      if (found === undefined) {
        newArray.push(item);
      }
    });
    return newArray;
  };

  const getAllAssociated = (idUser) => {
    if (idUser !== null) {
      getItemById(endpoints.associateDataTechnical.getUnityBusinessById, idUser).then((res) => {
        let newArray = [];
        if (res.length > 0) {
          let data = structurePrimaryMinimalTable(res, newArray);
          setPrimaryMinimalTable(data);
          setPrevPrimaryMinimalTable(data);
        }
      });
      getItemById(endpoints.associateDataTechnical.getSucursalById, idUser).then((res) => {
        let newArray = [];
        if (res.length > 0) {         
          let data = structureSecondaryMinimalTable(res, newArray);
          setSecondMinimalTable(data);
          setPrevSecondMinimalTable(data);
        }
      });
    }
  };
  const structurePrimaryMinimalTable = (data, array) => {
    data.forEach((item) => {
      array.push({
        idAssociate: item.idUsuarioUnidadNegocio,
        id: item.idUnidadNegocio,
        unityName: item.nombreUnidadNegocio,
        code: item.codigoUnidadNegocio,
        market: item.nombreMercado !== null ? item.nombreMercado : 'Sin mercado asociado',
        country: item.nombrePais !== null ? item.nombrePais : 'Sin país asociado',
      });
    });
    return array;
  };
  const structureSecondaryMinimalTable = (data, array) => {
    data.forEach((item) => {
      array.push({
        idAssociate: item.idUsuarioSucursal,
        id: item.idSucursal,
        nombreCliente: item.nombreRazonSocial,
        tipoId: {
          value: '',
          label: item.abreviaturaTipoDocumento,
        },
        numberId: item.identificacionCliente,
        citySucursal: {
          value: '',
          label: item.nombreMunicipio,
        },
        departamento: {
          value: '',
          label: item.nombreDepartamento,
        },
        pais: {
          value: '',
          label: item.nombrePais,
        },
      });
    });
    return array;
  };

  const uploadNewFile = async (file) => {
    fetchData({
      url: endpoints.UploadFiles.save,
      method: 'post',
      body: {
        idOrigen: currentEmployee.idEmpleado,
        idTipoOrigenArchivo: 5,
        archivos: [file],
      },
    }).then((response) => {
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
        text: formatterText('alert.title.confirm.add.files'),
        confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
        allowOutsideClick: false,
        executeFunction: () => {       
        },
      });
    });
  };

  const getDataAttachedFiles = async (id) => {
    fetchData({
      url: endpoints.UploadFiles.findArchivosById,
      method: 'post',
      body: {
        idOrigen: id,
        idTipoOrigenArchivo: 5,
      },
      typeConfig: 'form',
    }).then((response) => {
      let files = response.response.map((file) => {
        return {
          name: file,
          url: file,
        };
      });
      setCurrentFiles(files);
    });
  };

  return (
    <>
      {currentEmployee ? (
        <div className="centered-form">
          <Formiz onValidSubmit={handleSubmit} connect={myForm}>
            <form
              noValidate
              onSubmit={myForm.submit}
              className="container-wrapForm"
              style={{ minHeight: '16rem' }}
            >
              <div className="new-container-wrapForm__tabs">
                {myForm?.steps.map((step) => (
                  <button
                    key={step.name}
                    className={`new-tab-option ${
                      step.name === myForm?.currentStep.name ? 'is-active' : ''
                    }`}
                    type="button"
                    onClick={() => myForm.goToStep(step.name)}
                  >
                    {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                    {formatterText(step.label)}
                  </button>
                ))}
              </div>

              <div className="container-wrapForm-content">
                <FormizStep
                  name="step1"
                  label='p.general.information'
                >
                  <div className="title-section">
                    <span className="circle-form">
                      <span>1</span>
                    </span>
                    <h2>
                      <FormattedMessage
                        id="p.employee.personal.data"
                        defaultMessage="Datos personales del empleado"
                      />
                    </h2>
                  </div>

                  <section className="grid-container-3c">
                    <InputSelectorResponsive
                      type="text"
                      name="idTipoDocumento"
                      placeholder={formatterText('p.document.type', 'Tipo de documento')}
                      labelText={formatterText('p.document.type', 'Tipo de documento')}
                      required={formatterText('p.label.title.tipoDocumentoRequerido')}
                      defaultValue={{
                        label: `${currentEmployee.idTipoDocumento.nombre} - ${currentEmployee.idTipoDocumento.abreviatura}`,
                        value: currentEmployee.idTipoDocumento.idTipoDocumento,
                      }}
                      data={
                        !!selectData.documentTypes &&
                        selectData.documentTypes.map((item) => {
                          let docLabel = `${item.nombre} - ${item.abreviatura}`;
                          return {
                            label: docLabel,
                            value: item.idTipoDocumento,
                          };
                        })
                      }
                      isLoading={loadingData}
                    />
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="text.ID" defaultMessage="Identificación" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="identificacion"
                          placeholder={formatterText(
                            'input.placeholder.enter.id',
                            'Ingresa la identificación',
                          )}
                          type="text"
                          required={formatterText('p.label.title.identificacionRequerida')}
                          defaultValue={currentEmployee.identificacion}
                          validateInput="identification"
                        />
                      </section>
                    </label>
                    <InputSelectorResponsive
                      type="text"
                      name="genero"
                      labelText={formatterText('input.placeholder.genre', 'Género')}
                      placeholder={formatterText('input.placeholder.genre', 'Género')}
                      required={formatterText('p.label.title.generoRequerido')}
                      defaultValue={{
                        label: `${currentEmployee.genero.nombre} - ${currentEmployee.genero.abreviatura}`,
                        value: currentEmployee.genero.idGenero,
                      }}
                      data={
                        !!selectData.genres &&
                        selectData.genres.map((item) => ({
                          label: `${item.nombre} - ${item.abreviatura}`,
                          value: {
                            value: item.idGenero,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />

                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.first.name" defaultMessage="Primer nombre" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="primerNombre"
                          placeholder={formatterText(
                            'input.placeholder.enter.first.name',
                            'Ingresa el primer nombre',
                          )}
                          type="text"
                          required={formatterText('p.label.title.primerNombreRequerido')}
                          validateInput="text-no-digits-one-space"
                          defaultValue={currentEmployee.primerNombre}
                        />
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.second.name" defaultMessage="Segundo nombre" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="segundoNombre"
                          placeholder={formatterText(
                            'input.placeholder.enter.second.name',
                            'Ingresa el segundo nombre',
                          )}
                          type="text"
                          defaultValue={currentEmployee.segundoNombre}
                          validateInput="text-no-digits-one-space"
                        />
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.first.lastname" defaultMessage="Primer apellido" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="primerApellido"
                          placeholder={formatterText(
                            'input.placeholder.enter.first.lastname',
                            'Ingresa el primer apellido',
                          )}
                          type="text"
                          required={formatterText('p.label.title.primerApellidoRequerido')}
                          defaultValue={currentEmployee.primerApellido}
                          validateInput="text-no-digits-one-space"
                        />
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.second.lastname"
                          defaultMessage="Segundo apellido"
                        />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="segundoApellido"
                          placeholder={formatterText(
                            'input.placeholder.enter.second.lastname',
                            'Ingresa el segundo apellido',
                          )}
                          type="text"
                          defaultValue={currentEmployee.segundoApellido}
                          validateInput="text-no-digits-one-space"
                        />
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.date.birth" defaultMessage="Fecha de nacimiento" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="fechaNacimiento"
                          label="Name"
                          type="date"
                          required={formatterText('p.label.title.fechaNacimientoRequerida')}
                          defaultValue={dateFormat(currentEmployee.fechaNacimiento, 'yyyy-mm-dd')}
                          min={HandleShortDate(-130)}
                          max={HandleShortDate(-10)}
                        />
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="table.title.email"
                          defaultMessage="Correo electrónico"
                        />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="correo"
                          placeholder={formatterText(
                            'input.placeholder.enter.email',
                            'Ingresa el correo electrónico',
                          )}
                          type="email"
                          required={formatterText('p.label.title.correoRequerido')}
                          defaultValue={currentEmployee.correo}
                        />
                        {showError && (
                          <div
                            style={{
                              //position just down of the MyField
                              position: 'absolute',
                              top: '100%',
                              padding: '0 10px',
                              boxSizing: 'border-box',
                              color: 'red',
                            }}
                          >
                            <span className="error-msg">{formatterText('p.label.title.correoNoValido')}</span>
                          </div>
                        )}
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.employee.phone"
                          defaultMessage="Teléfono empleado"
                        />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="telefono"
                          placeholder={formatterText(
                            'input.placeholder.enter.phone',
                            'Ingresa el teléfono',
                          )}
                          type="text"
                          required={formatterText('p.label.title.telefonoRequerido')}
                          defaultValue={currentEmployee.telefono}
                          validateInput="number"
                        />
                      </section>
                    </label>
                  </section>

                  <div className="title-section">
                    <span className="circle-form">
                      <span>1.1</span>
                    </span>
                    <h2>
                      <FormattedMessage
                        id="p.place.residence"
                        defaultMessage="Lugar de residencia"
                      />
                    </h2>
                  </div>

                  <section
                    className="grid-container-2c"
                    style={{
                      width: '95%',
                      margin: '0 auto',
                    }}
                  >
                    <InputSelectorResponsive
                      type="text"
                      name="idMunicipio"
                      labelText={formatterText('p.city.residence', 'Ciudad de residencia')}
                      defaultValue={{
                        label: `${currentEmployee.idMunicipio.nombre} - ${currentEmployee.idMunicipio.idDepartamento.nombre} - ${currentEmployee.idMunicipio.idDepartamento.idPais.nombrePais} `,
                        value: currentEmployee.idMunicipio.idMunicipio,
                      }}
                      placeholder={formatterText('p.city.residence', 'Ciudad de residencia')}
                      required={formatterText('p.label.title.ciudadResidenciaRequerida')}
                      data={
                        !!selectData.municipalities &&
                        selectData.municipalities.map((item) => ({
                          label: `${item.nombre} - ${item.idDepartamento.nombre} - ${item.idDepartamento.idPais.nombrePais} `,
                          value: {
                            value: item.idMunicipio,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="table.title.address" defaultMessage="Dirección" />
                      </span>
                      <section className="w100-container">
                        <MyField
                          name="direccion"
                          label="direccion"
                          placeholder={formatterText(
                            'input.placeholder.enter.address',
                            'Ingresa el dirección',
                          )}
                          type="text"
                          required={formatterText('p.label.title.direccionRequerida')}
                          defaultValue={currentEmployee.direccion}
                          validateInput="address"
                        />
                      </section>
                    </label>
                  </section>
                </FormizStep>
                <FormizStep
                  name="step2"
                  label='p.labor.information'
                >
                  <div className="title-section">
                    <span className="circle-form">
                      <span>2</span>
                    </span>
                    <h2>
                      <FormattedMessage
                        id="p.employee.labor.data"
                        defaultMessage="Datos laborales del empleado"
                      />
                    </h2>
                  </div>

                  <section className="grid-container-3c">
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="table.title.entry.date"
                          defaultMessage="Fecha de ingreso"
                        />
                      </span>
                      <MyField
                        name="fechaIngreso"
                        type="date"
                        required={formatterText('p.label.title.fechaIngresoRequerida')}
                        className="input-primary-wrap"
                        defaultValue={dateFormat(
                          moment(currentEmployee.fechaIngreso.split('T')[0]),
                          'yyyy-mm-dd',
                        )}
                        min={HandleShortDate(-50)}
                        max={HandleShortDate(0)}
                      />
                    </label>
                    <InputSelectorResponsive
                      type="text"
                      name="tipoContrato"
                      labelText={formatterText('table.title.contract.type', 'Tipo de contrato')}
                      placeholder={formatterText('table.title.contract.type', 'Tipo de contrato')}
                      required={formatterText('p.label.title.tipoContratoRequerido')}
                      defaultValue={{
                        label: currentEmployee.tipoContrato.nombre,
                        value: currentEmployee.tipoContrato.idTipoContrato,
                      }}
                      data={
                        !!selectData.contracts &&
                        selectData.contracts.map((item) => ({
                          label: item.nombre,
                          value: {
                            value: item.idTipoContrato,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />
                    <InputSelectorResponsive
                      type="text"
                      name="cargo"
                      labelText={formatterText('table.title.position', 'Cargo')}
                      placeholder={formatterText('table.title.position', 'Cargo')}
                      required={formatterText('p.label.title.cargoRequerido')}
                      defaultValue={{
                        label: currentEmployee.cargo.nombre,
                        value: currentEmployee.cargo.idCargo,
                      }}
                      data={
                        !!selectData.positions &&
                        selectData.positions.map(({ nombre, idCargo }) => ({
                          label: nombre,
                          value: {
                            value: idCargo,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.employee.salary"
                          defaultMessage="Salario empleado"
                        />
                      </span>

                      <MyField
                        name="salario"
                        placeholder={formatterText(
                          'input.placeholder.enter.employee.salary',
                          'Ingresa el salario del empleado',
                        )}
                        type="text"
                        required={formatterText('p.label.title.salarioRequerido')}
                        defaultValue={currentEmployee.salario || 0}
                        validateInput="price"
                      />
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.bearing.help"
                          defaultMessage="Auxilio de rodamiento"
                        />
                      </span>

                      <MyField
                        name="rodamiento"
                        placeholder={formatterText(
                          'input.placeholder.enter.bearing.help',
                          'Ingresa el auxilio de rodamiento',
                        )}
                        type="text"
                        defaultValue={currentEmployee.rodamiento || 0}
                        validateInput="price"
                      />
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.observation" defaultMessage="Observación" />
                      </span>

                      <MyField
                        name="observacion"
                        placeholder={formatterText(
                          'input.placeholder.enter.observation',
                          'Ingresa la observación',
                        )}
                        type="text"
                        defaultValue={currentEmployee.observacion}
                        validateInput="text"
                      />
                    </label>
                  </section>

                  <div className="title-section">
                    <span className="circle-form">
                      <span>2.1</span>
                    </span>
                    <h2>
                      <FormattedMessage
                        id="p.affiliations.banking.information"
                        defaultMessage="Afiliaciones e información bancaria"
                      />
                    </h2>
                  </div>

                  <section
                    className="grid-container-2c"
                    style={{
                      width: '95%',
                      margin: '0 auto',
                    }}
                  >
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.lra.affiliation.date"
                          defaultMessage="Fecha de afiliación ARL"
                        />
                      </span>

                      <MyField
                        name="fechaAfiliacionArl"
                        type="date"
                        required={formatterText('p.label.title.fechaAfiliacionARLRequerida')}
                        defaultValue={dateFormat(currentEmployee.fechaAfiliacionArl, 'yyyy-mm-dd')}
                        min={HandleShortDate(-80)}
                        max={HandleShortDate()}
                      />
                    </label>
                    <InputSelectorResponsive
                      type="text"
                      name="entidadSalud"
                      labelText={formatterText('p.health.entity', 'Entidad de salud')}
                      placeholder={formatterText('p.health.entity', 'Entidad de salud')}
                      required={formatterText('p.label.title.entidadSaludRequerida')}
                      defaultValue={{
                        label: currentEmployee.entidadSalud.nombre,
                        value: currentEmployee.entidadSalud.idEntidadSalud,
                      }}
                      data={
                        !!selectData.healthEntities &&
                        selectData.healthEntities.map(({ idEntidadSalud, nombre }) => ({
                          label: nombre,
                          value: {
                            value: idEntidadSalud,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />
                    <InputSelectorResponsive
                      type="text"
                      name="banco"
                      labelText={formatterText('p.bank', 'Banco')}
                      placeholder={formatterText(
                        'input.placeholder.employee.bank',
                        'Banco del empleado',
                      )}
                      required={formatterText('p.label.title.bancoEmpleadoRequerido')}
                      defaultValue={{
                        label: `${currentEmployee.banco.nombre} - ${currentEmployee.banco.abreviatura}`,
                        value: currentEmployee.banco.idBanco,
                      }}
                      data={
                        !!selectData.banks &&
                        selectData.banks.map(({ idBanco, nombre, abreviatura }) => ({
                          label: `${nombre} - ${abreviatura}`,
                          value: {
                            value: idBanco,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />
                    <InputSelectorResponsive
                      type="text"
                      name="tipoCuenta"
                      labelText={formatterText('p.account.type', 'Tipo de cuenta')}
                      placeholder={formatterText('p.account.type', 'Tipo de cuenta')}
                      required={formatterText('p.label.title.tipoCuentaRequerido')}
                      defaultValue={{
                        label: `${currentEmployee.tipoCuenta.nombre} - ${currentEmployee.tipoCuenta.abreviatura}`,
                        value: currentEmployee.tipoCuenta.idTipoCuenta,
                      }}
                      data={
                        !!selectData.typeAccount &&
                        selectData.typeAccount.map(({ idTipoCuenta, nombre, abreviatura }) => ({
                          label: `${nombre} - ${abreviatura}`,
                          value: {
                            value: idTipoCuenta,
                          },
                        }))
                      }
                      isLoading={loadingData}
                    />

                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="p.account.number" defaultMessage="Número de cuenta" />
                      </span>
                      <MyField
                        name="numeroCuenta"
                        placeholder={formatterText(
                          'input.placeholder.enter.account.number',
                          'Ingresa el número de cuenta',
                        )}
                        type="text"
                        required={formatterText('p.label.title.numeroCuentaRequerido')}
                        defaultValue={currentEmployee.numeroCuenta}
                        validateInput="number"
                      />
                    </label>
                  </section>
                </FormizStep>
                <FormizStep
                  name="step3"
                  label='p.contact.information'
                >
                  <div className="title-section">
                    <span className="circle-form">
                      <span>3</span>
                    </span>
                    <h2>
                      <FormattedMessage
                        id="p.emergency.contact.data"
                        defaultMessage="Datos de contacto de emergencia"
                      />
                    </h2>
                  </div>

                  <section
                    className="grid-container-2c"
                    style={{
                      width: '95%',
                      margin: '0 auto',
                    }}
                  >
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.emergency.contact.name"
                          defaultMessage="Nombre de contacto de emergencia"
                        />
                      </span>
                      <MyField
                        name="nombreFamiliar"
                        placeholder={formatterText(
                          'input.placeholder.enter.emergency.contact.name',
                          'Ingresa el nombre del contacto de emergencia',
                        )}
                        type="text"
                        defaultValue={currentEmployee.nombreFamiliar}
                        validateInput="text"
                      />
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.emergency.contact.phone"
                          defaultMessage="Teléfono contacto de emergencia"
                        />
                      </span>
                      <MyField
                        name="telefonoFamiliar"
                        placeholder={formatterText(
                          'input.placeholder.enter.emergency.contact.phone',
                          'Ingresa el teléfono del contacto de emergencia',
                        )}
                        type="text"
                        defaultValue={currentEmployee.telefonoFamiliar}
                        validateInput="number"
                      />
                    </label>
                  </section>

                  {selectData.kins && selectData.genres && (
                    <div>
                      <div className="title-section">
                        <span className="circle-form">
                          <span>3.1</span>
                        </span>
                        <h2>
                          <FormattedMessage id="p.add.familiar" defaultMessage="Agregar familiar" />
                        </h2>
                      </div>

                      {familiares.map((familiar, index) => (
                        <section key={index} className="wrapForm" style={{ alignItems: 'center' }}>
                          <div className="relative-circle-container">
                            <div className="relative-circle" />
                            <span
                              style={{
                                fontWeight: 'bold',
                                marginBottom: '0.5rem',
                              }}
                            >
                              {formatterText('title.user.familyMember')} {index + 1}:
                            </span>
                          </div>
                          <span>{familiar.nombreCompleto}</span>
                          <span>{familiar.idParentesco.nombre}</span>
                          <span>{familiar.idGenero.abreviatura}</span>
                          <span>{familiar.edad}</span>
                          <a
                            href="_"
                            className="delete-relative"
                            onClick={(e) => {
                              e.preventDefault();
                              deleteFamilyByEmployee(familiar.idFamiliares)
                                .then(() => {
                                  successRemoveItem();
                                  getAllFamilies(parseInt(id));
                                })
                                .catch((err) => {
                                  console.log(err);
                                });
                            }}
                          >
                           {formatterText('title.user.deleteFamilyMember')}
                          </a>
                        </section>
                      ))}

                      <section
                        className="grid-container-2c"
                        style={{
                          width: '95%',
                          margin: '0 auto',
                        }}
                      >
                        <label className="d-flex">
                          <span className="text-inline">
                            <FormattedMessage id="p.relationship" defaultMessage="Parentesco" />
                          </span>
                          <select
                            name="idParentesco"
                            id="idParentesco"
                            className="input-label-style"
                            onChange={handleChangeSelect}
                          >
                            <option value="">
                              <FormattedMessage
                                id="input.placeholder.select.relationship"
                                defaultMessage="Seleccione un parentesco"
                              />
                            </option>
                            {selectData.kins.map((item) => (
                              <option
                                key={item.idParentesco}
                                value={JSON.stringify({
                                  idParentesco: item.idParentesco,
                                  nombre: item.nombre,
                                })}
                              >
                                {item.nombre}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label className="d-flex">
                          <span className="text-inline">
                            <FormattedMessage
                              id="input.placeholder.genre"
                              defaultMessage="Género"
                            />
                          </span>
                          <select
                            name="idGenero"
                            id="idGenero"
                            className="input-label-style"
                            onChange={handleChangeSelect}
                          >
                            <option value="">
                              <FormattedMessage
                                id="input.placeholder.select.genre"
                                defaultMessage="Seleccione un género"
                              />
                            </option>
                            {selectData.genres.map((item) => (
                              <option
                                key={item.idGenero}
                                value={JSON.stringify({
                                  idGenero: item.idGenero,
                                  nombre: item.nombre,
                                  abreviatura: item.abreviatura,
                                })}
                              >
                                {item.nombre} - {item.abreviatura}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label className="d-flex">
                          <span className="text-inline">
                            <FormattedMessage id="p.age" defaultMessage="Edad" />
                          </span>
                          <input
                            name="edad"
                            placeholder={formatterText(
                              'input.placeholder.enter.familiar.age',
                              'Ingrese la edad del familiar',
                            )}
                            type="text"
                            required={formatterText('p.label.title.edadFamiliarRequerida')}
                            className="input-primary-wrap"
                            onChange={handleChangeNumberRelative}
                          />
                        </label>
                        <label className="d-flex">
                          <span className="text-inline">
                            <FormattedMessage
                              id="table.title.full.name"
                              defaultMessage="Nombre completo"
                            />
                          </span>
                          <input
                            name="nombreCompleto"
                            placeholder={formatterText(
                              'input.placeholder.enter.fullname',
                              'Ingrese el nombre completo',
                            )}
                            type="text"
                            required={formatterText('p.label.title.nombreCompletoFamiliarRequerido')}
                            className="input-primary-wrap"
                            onChange={handleChangeRelative}
                          />
                        </label>
                      </section>
                      <section className="form-responsive-container-buttons">
                        <input
                          onClick={handleAddFamily}
                          type="button"
                          className="btn-primary"
                          value={formatterText('p.add.familiar', 'Agregar familiar')}
                        />
                      </section>
                    </div>
                  )}
                </FormizStep>
                {currentEmployee.idUsuario !== null && (
                  <form>
                    <FormizStep
                      name="step4"
                      label='p.associations'
                    >
                      <UnityBusiness
                        data={primaryMinimalTable}
                        setterFunction={setPrimaryMinimalTable}
                      />
                      <ClienteSucursal
                        data={secondMinimalTable}
                        setterFunction={setSecondMinimalTable}
                      />
                    </FormizStep>
                  </form>
                )}
                <FormizStep
                  name="step5"
                  label='tab.title.attached.data'
                >
                  <Attachments
                    currentFiles={archivos}
                    setCurrentFiles={setCurrentFiles}
                    isEdited={true}
                    uploadNewFile={uploadNewFile}
                    type={4}
                    showParameters={true}
                  />
                </FormizStep>

                <div className="demo-form__footer">
                  <section className="form-responsive-container-buttons">
                    <button
                      /*  disabled={
                  isLoading || (!myForm.isValid && myForm.isSubmitted)
                } */
                      type="submit"
                      className="btn-primary"
                    >
                      {isLoading
                        ? 'Loading...'
                        : formatterText('btn.edit.employee', 'Editar empleado')}
                    </button>
                    <button className="input-cancel" onClick={() => navigate(paths.employees)}>
                      <FormattedMessage
                        id="alert.button.cancel.general"
                        defaultMessage="Cancelar"
                      />
                    </button>
                  </section>
                </div>
              </div>
            </form>
          </Formiz>
        </div>
      ) : (
        <section className="custom-margin-1000 ">
          <DisplayProgress />
        </section>
      )}
    </>
  );
};

export default EditEmployee;
