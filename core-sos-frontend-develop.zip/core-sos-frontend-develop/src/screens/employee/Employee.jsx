import Search from 'common/Search';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// paths to routes
import paths from 'services/paths';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import ExportJsonFile from 'components/utils/ExportJsonFile';
// Import Libs
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
// Import Services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteEmployee } from 'services/api/employees';
import { getAll, updateItemById } from 'services/api/methods';

const Employee = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <EmployeeComponent />
      </PermissionWrapper>
    </SearchWrapper>

  );
};

function EmployeeComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de search
  const { setDataTable, searchResults = [] } = useSeachContext();

  const [employee, setEmployee] = useState(null);

  // use Hook of language v2
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.employee);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.employees.getAllEmployees)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));

        setDataTable(newArray);
        // show loading
        toggleLoading(false);
        setEmployee(newArray);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (column) => {
    return new Promise((resolve, reject) => {
      deleteEmployee(column)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });          
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateItemById(endpoints.employees.updateEmployee, body.idEmpleado, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    let completeName = `${item.primerNombre} ${item.segundoNombre} ${item.primerApellido} ${item.segundoApellido}`;
    let formatedDate = item.fechaIngreso
      ? dateFormat(item.fechaIngreso, 'yyyy-mm-dd')
      : 'No tiene un valor';
    let typeDocument = `${item.idTipoDocumento.nombre} - ${item.idTipoDocumento.abreviatura}`;

    newArray.push({
      id: item.idEmpleado || 'No tiene un valor',
      nombre: completeName || 'No tiene un valor',
      tipoDocumento: typeDocument,
      documento: item.identificacion || 'No tiene un valor',
      municipio: item.idMunicipio.nombre || 'No tiene un valor',
      estado: item.estado,
      cargo: item.cargo.nombre || 'No tiene un valor',
      tipoContrato: item.tipoContrato.nombre || 'No tiene un valor',
      fechaRegistro: formatedDate,
      objeto: { ...item },
    });
  };

  // titulos de la tabla
  const titles = [
    formatterText('table.title.full.name', 'Nombre completo'),
    formatterText('p.document.type', 'Tipo de documento'),
    formatterText('table.title.document', 'Documento'),
    formatterText('table.title.municipality', 'Municipio'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.title.position', 'Cargo'),
    formatterText('table.title.contract.type', 'Tipo de contrato'),
    formatterText('table.title.entry.date', 'Fecha de ingreso'),
    formatterText('table.actions', 'Acciones'),
  ];

  const renderMessage = () => {
    return error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();
  };
  return (
    <>
      {!loading && employee !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createEmployee}>
                <button className="btn-add">
                  <FormattedMessage
                    id="header.title.employee.create"
                    defaultMessage="Crear Empleados"
                  />
                </button>
              </Link>
            )}

            {permittedActions.exportar && (
              <ExportJsonFile
                moduleName={'Empleado'}
                userName={JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN'}
                dataTable={searchResults}
              />
            )}
          </section>
          <FormattedMessage id="table.name.search.employee" defaultMessage="Empleado">
            {(placeholder) =>
              permittedActions.consultar && (
                <DynamicTable
                  titles={titles}
                  pageName={PAGE_NAMES.Empleados}
                  getData={getDataTable}
                  handleDeleteItem={handleDeleteItem}
                  handleEditStateItem={handleEditStateItem}
                  routeToEdit={paths.updateEmployee}
                  canDeleted={permittedActions.eliminar}
                  canModify={permittedActions.editar}
                />
              )
            }
          </FormattedMessage>
        </section>
      ) : (
        renderMessage()
      )}
    </>
  );
}

export default Employee;
