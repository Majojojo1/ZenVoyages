import React, { useEffect, useState } from 'react';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import PermissionSelector from 'common/PermissionSelector';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import CustomAlert from 'components/CustomAlert';
// Import Assets
import './rol.css';
// Import libs
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
// Import services
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { getAll, getItemById } from 'services/api/methods';
import { addPermisoModulo, updateRole } from 'services/api/roles';
import paths from 'services/paths';

export default function Edit() {
  return (
    <SearchWrapper>
      <EditComponet />
    </SearchWrapper>
  );
}

function EditComponet() {
  const idUsuario = Cookie.get('idUsuario');
  const { setDataTable } = useSeachContext();
  const navigate = useNavigate();
  const [active, setActive] = useState(false);
  const [nameRoleInput, setNameRoleInput] = useState('');
  // permisosModulos state
  const [permisosModulos, setPermisosModulos] = useState([]);
  const [toggleSelector, setToggleSelector] = useState(false);
  const [selectedPermisosModulos, setSelectedPermisosModulos] = useState([]);
  const [allPermisos, setAllPermisos] = useState([]);

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const { id } = useParams();

  const handleChange = (e) => {
    // regex para que no permita caracteres especiales
    const regex = /^[a-zA-Z0-9]*(?: [a-zA-Z0-9]*)*$/;
    if (regex.test(e.target.value)) {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const [formData, setFormData] = useState({
    idRol: '',
    nombre: '',
    descripcion: '',
    estado: '',
    fechaCreacion: '',
    fechaModificacion: '',
    usuarioCreacion: '',
    usuarioModificacion: '',
  });

  const updateRoleData = () => {
    Swal.fire({
      title: `${formatterText('question.swal.title.edit')}`,
      text: `${formatterText('question.swal.title.edit.role')}`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: `${formatterText('question.swal.title.edit.confirm')}`,
      allowOutsideClick: false,
      cancelButtonText: `${formatterText('question.swal.title.edit.cancel')}`,
      preConfirm: async () => {
        let stateValue = active ? 1 : 0;
        let descriptionValue =
          formData.descripcion.length > 0 ? formData.descripcion : 'No se añadió descripción';

        const data = JSON.stringify({
          idRol: id,
          nombre: formData.nombre.trim(),
          descripcion: descriptionValue,
          estado: stateValue,
          usuarioCreacion: formData.usuarioCreacion, //Revisar si es
          usuarioModificacion: idUsuario,
          fechaCreacion: formData.fechaCreacion,
          fechaModificacion: null,
        });

        await updateRole(data)
          .then((res) => {
            //Se actualizo el rol
            asociatePermissionModule();
          })
          .catch((err) => {
            HandleOnError(err.response.data.message);
            console.log(err);
          });
      },
    });
  };

  const getAsociatedPermissionModule = (value) => {
    getItemById(endpoints.roles.getAllRolPermisosModulosByRol, value)
      .then((res) => {
        getAll(endpoints.roles.getAllPermisosModulos)
          .then((allPermisosModulos) => {
            const formatedPermisosModulos = res.map((element) => ({
              idRolPermisoModulo: element.idRolPermisoModulo,
              idPermiso: {
                nombre: element.nombrePermiso,
                idpermiso: element.idPermiso,
              },
              idModulo: {
                nombre: element.nombreModulo,
                idModulo: element.idModulo,
              },
            }));

            // console.log(allPermisosModulos.data, res.data);
            sortData(formatedPermisosModulos);
            setSelectedPermisosModulos(formatedPermisosModulos);

            const valueInfo = allPermisosModulos.filter(
              (permiso) =>
                !res.find(
                  (element) =>
                    element.idPermiso === permiso.idPermiso.idpermiso &&
                    element.idModulo === permiso.idModulo.idModulo,
                ),
            );

            setPermisosModulos(valueInfo);
            setDataTable(valueInfo);
            setAllPermisos(allPermisosModulos);
          })
          .catch((err) => {
            console.log(err);
          });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const asociatePermissionModule = () => {
    const valueInfo = allPermisos.filter((permiso) =>
      selectedPermisosModulos.find(
        (element) =>
          element.idPermiso.idpermiso === permiso.idPermiso.idpermiso &&
          element.idModulo.idModulo === permiso.idModulo.idModulo,
      ),
    );

    const promesas = valueInfo.map((permissionInfo) => {
      let body = {
        idRolPermisoModulo: null,
        idRol: {
          idRol: id,
        },
        idPermisoModulo: {
          idPermisoModulo: permissionInfo.idPermisoModulo,
        },
        usuarioCreacion: Cookie.get('idUsuario'),
        fechaCreacion: '2022-04-06T00:41:29.488+00:00',
        usuario_modificacion: Cookie.get('idUsuario'),
        fechaModificacion: null,
      };

      return new Promise(async (resolve, reject) => {
        await addPermisoModulo(body)
          .then((res) => {
            resolve(res);
          })
          .catch((err) => {
            reject('El permiso esta en uso');
          });
      });
    });

    Promise.all(promesas)
      .then((values) => {
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.updated.general',
            'El registro se ha actualizado correctamente',
          ),
          confirmButtonText:  formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.roles),
        });
      })
      .catch((error) => {
        HandleOnError(error);
      });
  };

  const getRole = (id) => {
    getItemById(endpoints.roles.getRoleById, id)
      .then((data) => {
        setFormData({
          idRol: data.idRol,
          nombre: data.nombre,
          descripcion: data.descripcion,
          estado: parseInt(data.estado),
          fechaCreacion: data.fechaCreacion,
          fechaModificacion: data.fechaModificacion,
          usuarioCreacion: data.usuarioCreacion,
          usuarioModificacion: Cookie.get('idUsuario'),
        });

        setNameRoleInput(data.nombre);
        setActive(data.estado === 1);
        
      })
      .catch((err) => console.log(err));
  };

  //Validaciones y llama al post
  const getAllRoles = (e) => {
    e.preventDefault();

    if (selectedPermisosModulos.length === 0) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Ops...',
        text: formatterText('alert.title.add.permissions.modules'),
        confirmButtonColor: '#FFC954',
      });
      return;
    }

    if (nameRoleInput === formData.nombre) {
      updateRoleData();
    } else {
      const regex = /^[a-zA-Z0-9 ]+$/;
      // validate the role name
      if (regex.test(formData.nombre.trim())) {
        getAll(endpoints.roles.getAllRoles)
          .then((res) => {
            let rolesNames = [];
            res.map((role) => {
              rolesNames.push(role.nombre.toLowerCase());
            });

            if (rolesNames.includes(formData.nombre.toUpperCase())) {
              CustomAlert('short_msg', {
                icon: 'warning',
                title: 'Ops...',
                text: formatterText('alert.title.role.name.exists'),
                confirmButtonColor: '#FFC954',
              });
            } else {
              CustomAlert('short_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
              });
              updateRoleData();
            }
          })
          .catch((err) => console.log(err));
      } else {
        CustomAlert('short_msg', {
          icon: 'warning',
          title: 'Ops...',
          text: formatterText('alert.title.role.name.invalid'),
          confirmButtonColor: '#FFC954',
        });
      }
    }
  };

  const handleRemoveRole = (e, permiso) => {
    e.preventDefault();
    const selected = selectedPermisosModulos.filter((currentPermisosModulo) => {
      let primero = currentPermisosModulo.idPermiso.idpermiso;
      let segundo = permiso.idPermiso.idpermiso;
      let tercero = currentPermisosModulo.idModulo.idModulo;
      let cuarto = permiso.idModulo.idModulo;

      // console.log(primero !== segundo || tercero !== cuarto);

      //compare 4 numbers to see if one of them is different from the other in another way

      return primero !== segundo || tercero !== cuarto;
    });

    setSelectedPermisosModulos(selected);
    sortData(selected);
    setPermisosModulos([...permisosModulos, permiso]);
    setDataTable([...permisosModulos, permiso]);
  };

  const handleAddRole = (permiso) => {
    const newPermisosModulos = permisosModulos.filter((currentRol) => {
      let primero = currentRol.idPermiso.idpermiso;
      let segundo = permiso.idPermiso.idpermiso;
      let tercero = currentRol.idModulo.idModulo;
      let cuarto = permiso.idModulo.idModulo;

      // console.log(primero !== segundo || tercero !== cuarto);

      //compare 4 numbers to see if one of them is different from the other in another way

      return primero !== segundo || tercero !== cuarto;
    });

    setDataTable(newPermisosModulos);
    setPermisosModulos(newPermisosModulos);
    let selected = [...selectedPermisosModulos, permiso];
    sortData(selected);
    setSelectedPermisosModulos(selected);
    setToggleSelector(!toggleSelector);
  };

  const sortData = (selected) => {
    return selected.sort((a, b) => {
      const nombreA = a.idModulo.nombre.toUpperCase();
      const nombreB = b.idModulo.nombre.toUpperCase();
      if (nombreA < nombreB) {
        return -1;
      }
      if (nombreA > nombreB) {
        return 1;
      }
      return 0;
    });
  };

  useEffect(() => {
    getRole(id);
    getAsociatedPermissionModule(id);
  }, [id]);

  return (
    <form className="form-responsive">
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.name.general" defaultMessage="Nombre" />
          </h3>
          <input
            className="input-primary"
            type="name"
            placeholder={formatterText('input.placeholder.role.name', 'Nombre del rol')}
            name="nombre"
            id="nombre"
            value={formData.nombre}
            defaultValue={formData.nombre}
            onChange={(e) => handleChange(e)}
            required
          />
        </section>

        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
          </h3>
          <textarea
            className="input-textarea-sm"
            type="description"
            name="descripcion"
            id="descripcion"
            placeholder={formatterText('input.placeholder.rol.description', 'Descripción del rol')}
            value={formData.descripcion}
            defaultValue={formData.descripcion}
            onChange={handlerTextDescription}
            maxLength="200"
          />
        </section>

        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.role" defaultMessage="Rol" />
          </h3>
          <label
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              color: '#747474',
            }}
          >
            <p
              style={{
                // color: "#747474",
                fontSize: '16px',
                fontWeight: 'bold',
                margin: '0px',
                padding: '0px',
                textDecoration: 'none',
                color: 'var(--dark-gray)',
              }}
            >
              {active
                ? formatterText('p.active', 'Activo')
                : formatterText('p.unActive', 'No activo')}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>

        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.permissions.modules" defaultMessage="Permisos y módulos" />
          </h3>
          <div
            style={{
              width: '80%',
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
              flexWrap: 'wrap',
            }}
          >
            <div
              style={{ width: '100%', display: 'flex', flexWrap: 'wrap' }}
              className="input-edit inputRole"
            >
              <button
                onClick={(e) => {
                  e.preventDefault();
                  setToggleSelector(!toggleSelector);
                }}
                className="add-role"
              >
                <FormattedMessage id="btn.add.permission" defaultMessage="Añadir permiso +" />
              </button>
              {selectedPermisosModulos.map((rol, index) => (
                <button key={index} onClick={(e) => handleRemoveRole(e, rol)} className="role-item">
                  {rol.idModulo.nombre} - {rol.idPermiso.nombre}
                  <div></div>
                </button>
              ))}
            </div>
            {toggleSelector && <PermissionSelector handleAdd={handleAddRole} />}
          </div>
        </section>
      </section>

      <div className="form-responsive-container-buttons">
        <button
          type="submit"
          className="btn-primary"
          onClick={(e) => {
            getAllRoles(e);
          }}
        >
          <FormattedMessage id="alert.button.confirm.general" defaultMessage="Guardar cambios" />
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.roles)}>
          <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
        </button>
      </div>
    </form>
  );
}
