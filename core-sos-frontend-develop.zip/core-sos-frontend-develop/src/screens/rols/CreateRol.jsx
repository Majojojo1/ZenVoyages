import React, { useEffect, useState } from 'react';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import PermissionSelector from 'common/PermissionSelector';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
// Import Assets
import './rol.css';
// Import libs
import Axios from 'axios';
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
// Import services
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { getAll } from 'services/api/methods';
import { addPermisoModulo, addRole } from 'services/api/roles';
import paths from 'services/paths';

export default function CreateRol() {
  return (
    <SearchWrapper>
      <CreateRolComponent />
    </SearchWrapper>
  );
}

function CreateRolComponent() {
  const navigate = useNavigate();
  const [active, setActive] = useState(true);
  const { setDataTable } = useSeachContext();
  // permisosModulos state
  const [permisosModulos, setPermisosModulos] = useState([]);
  const [toggleSelector, setToggleSelector] = useState(false);
  const [selectedPermisosModulos, setSelectedPermisosModulos] = useState([]);
  const [allPermisos, setAllPermisos] = useState([]);

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const { id } = useParams();
  const handleChange = (e) => {
    // regex para que no permita caracteres especiales
    const regex = /^[a-zA-Z0-9]*(?: [a-zA-Z0-9]*)*$/;
    if (regex.test(e.target.value)) {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    estado: '',
    fechaCreacion: '',
    fechaModificacion: '',
    usuarioCreacion: '',
    usuarioModificacion: '',
  });

  useEffect(() => {
    getAsociatedPermissionModule();
  }, []);

  const getAsociatedPermissionModule = () => {
    Axios.get(endpoints.roles.getAllPermisosModulos, {
      headers: {
        Authorization: sessionStorage.getItem('token'),
      },
    })
      .then((allPermisosModulos) => {
        setPermisosModulos(allPermisosModulos.data);
        setDataTable(allPermisosModulos.data);
        setAllPermisos(allPermisosModulos.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  //Validaciones y llama al post
  const postRoleData = (e) => {
    e.preventDefault();

    if (selectedPermisosModulos.length === 0) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Ops...',
        text: formatterText('alert.title.add.permissions.modules'),
        confirmButtonColor: '#FFC954',
      });
      return;
    }

    const regex = /^[a-zA-Z0-9 ]+$/;
    // validate the role name
    const nameRole = formData.nombre.trim();
    if (regex.test(nameRole)) {
      getAll(endpoints.roles.getAllRoles)
        .then((res) => {
          let rolesNames = [];
          res.map((role) => {
            if (role.nombre !== null) {
              rolesNames.push(role.nombre.toLowerCase());
            }
          });

          if (rolesNames.includes(formData.nombre.toLowerCase())) {
            CustomAlert('short_msg', {
              icon: 'warning',
              title: 'Ops...',
              text: formatterText('alert.title.role.name.exists'),
              confirmButtonColor: '#FFC954',
            });
          } else {
            CustomAlert('short_msg', {
              icon: 'success',
              title: 'Operación exitosa',
              text: formatterText(
                'alert.message.confirm.created.general',
                'El registro se ha creado correctamente',
              ),
            });
            postRole();
          }
        })
        .catch((err) => console.log(err));
    } else {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Ops...',
        text: formatterText('alert.title.role.name.invalid'),
        confirmButtonColor: '#FFC954',
      });
    }
  };

  const postRole = () => {
    const data = {
      ...formData,
      descripcion:
        formData.descripcion.length > 0 ? formData.descripcion : formatterText('alert.title.no.description.added'),
      usuarioCreacion: Cookie.get('idUsuario'),
      estado: active ? '1' : '0',
      nombre: formData.nombre.trim(),
    };

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addRole(data)
            .then((res) => {
              asociatePermissionModule(res, resolve, reject);
            })
            .catch((err) => {
              reject(HandleOnError(formatterText(
                'snackbar.error.process.failed.general',
                'Error al realizar el proceso. Intentalo en otro momento.'
              ),
              ));
              console.log(err);
            });
        });
      },
    });
  };

  const asociatePermissionModule = (res, resolve, reject) => {
    const valueInfo = allPermisos.filter((permiso) =>
      selectedPermisosModulos.find(
        (element) =>
          element.idPermiso.idpermiso === permiso.idPermiso.idpermiso &&
          element.idModulo.idModulo === permiso.idModulo.idModulo,
      ),
    );

    const promesas = valueInfo.map((permissionInfo) => {
      let body = {
        idRolPermisoModulo: null,
        idRol: {
          idRol: res.idRol,
        },
        idPermisoModulo: {
          idPermisoModulo: permissionInfo.idPermisoModulo,
        },
        usuarioCreacion: 1,
        fechaCreacion: null,
        usuarioModificacion: null,
        fechaModificacion: null,
      };

      return new Promise(async (resolve, reject) => {
        await addPermisoModulo(body)
          .then((res) => {
            resolve(res);
          })
          .catch(() => {
            reject(formatterText('alert.title.permission.in.use'));
          });
      });
    });

    Promise.all(promesas)
      .then(() => {
        resolve(
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.confirm.created.general',
              'El registro se ha creado correctamente',
            ),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.roles),
          }),
        );
      })
      .catch((error) => {
        reject(HandleOnError(error));
      });
  };

  const handleRemoveRole = (e, permiso) => {
    e.preventDefault();
    const selected = selectedPermisosModulos.filter((currentPermisosModulo) => {
      let primero = currentPermisosModulo.idPermiso.idpermiso;
      let segundo = permiso.idPermiso.idpermiso;
      let tercero = currentPermisosModulo.idModulo.idModulo;
      let cuarto = permiso.idModulo.idModulo;

      console.log(primero !== segundo || tercero !== cuarto);

      //compare 4 numbers to see if one of them is different from the other in another way

      return primero !== segundo || tercero !== cuarto;
    });
    sortData(selected);
    setSelectedPermisosModulos(selected);
    setPermisosModulos([...permisosModulos, permiso]);
    setDataTable([...permisosModulos, permiso]);
  };

  const handleAddRole = (permiso) => {
    const newPermisosModulos = permisosModulos.filter((currentRol) => {
      let primero = currentRol.idPermiso.idpermiso;
      let segundo = permiso.idPermiso.idpermiso;
      let tercero = currentRol.idModulo.idModulo;
      let cuarto = permiso.idModulo.idModulo;

      // console.log(primero !== segundo || tercero !== cuarto);

      //compare 4 numbers to see if one of them is different from the other in another way

      return primero !== segundo || tercero !== cuarto;
    });

    setDataTable(newPermisosModulos);
    setPermisosModulos(newPermisosModulos);
    let selected = [...selectedPermisosModulos, permiso];
    sortData(selected);
    setSelectedPermisosModulos(selected);
    setToggleSelector(!toggleSelector);
  };

  const sortData = (selected) => {
    return selected.sort((a, b) => {
      const nombreA = a.idModulo.nombre.toUpperCase();
      const nombreB = b.idModulo.nombre.toUpperCase();
      if (nombreA < nombreB) {
        return -1;
      }
      if (nombreA > nombreB) {
        return 1;
      }
      return 0;
    });
  };

  return (
    <form className="form-responsive" onSubmit={postRoleData}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.name.general" defaultMessage="Nombre" />
          </h3>
          <input
            className="input-primary"
            type="name"
            name="nombre"
            id="nombre"
            onChange={(e) => handleChange(e)}
            value={formData.nombre}
            placeholder={formatterText('input.placeholder.role.name', 'Nombre del rol')}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
          </h3>
          <textarea
            className="input-textarea-sm"
            type="description"
            name="descripcion"
            id="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText('input.placeholder.rol.description', 'Descripción del rol')}
            maxLength="200"
          />
        </section>
        <section
          className="form-responsive-information__option"
          style={{
            display: 'none',
          }}
        >
          <h3 className="p-styles">
            <FormattedMessage id="table.title.role" defaultMessage="Rol" />
          </h3>
          <label
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              color: '#747474',
            }}
          >
            <p
              style={{
                // color: "#747474",
                fontSize: '16px',
                fontWeight: 'bold',
                margin: '0px',
                padding: '0px',
                textDecoration: 'none',
                color: 'var(--dark-gray)',
              }}
            >
              {active
                ? formatterText('p.active', 'Activo')
                : formatterText('p.unActive', 'No activo')}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>

        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="p.permissions.modules" defaultMessage="Permisos y mósdsdulos" />
          </h3>
          <div
            style={{
              width: '80%',
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
              flexWrap: 'wrap',
            }}
          >
            <div
              style={{ width: '100%', display: 'flex', flexWrap: 'wrap' }}
              className="input-edit-fix inputRole"
              required
            >
              <button
                onClick={(e) => {
                  e.preventDefault();
                  setToggleSelector(!toggleSelector);
                }}
                className="add-role"
              >
                <FormattedMessage id="btn.add.permission" defaultMessage="Añadir permiso +" />
              </button>
              {selectedPermisosModulos.map((rol, index) => (
                <button key={index} onClick={(e) => handleRemoveRole(e, rol)} className="role-item">
                  {rol.idModulo.nombre} - {rol.idPermiso.nombre}
                  <div></div>
                </button>
              ))}
            </div>
            {toggleSelector && <PermissionSelector handleAdd={handleAddRole} />}
          </div>
        </section>
      </section>

      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="alert.button.confirm.general" defaultMessage="Guardar cambios" />
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.roles)}>
          <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
