import React, { useEffect } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
// Import libs
import SortData from 'components/utils/SortData';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

let usersJson = {};

export default (props = {}) => (
  <SearchWrapper>
    <PermissionWrapper>
      <RolsTableComponent {...props} />
    </PermissionWrapper>
  </SearchWrapper>
);

function RolsTableComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { searchResults = [], setSearchResults, setDataTable } = useSeachContext();
  // use Hook of language v2
  const { formatterText } = useLangv2();

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.rol);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    return getAll(endpoints.users.getAllUsers)
      .then((res) => {
        usersJson = res;
        getAll(endpoints.roles.getAllRoles)
          .then((data) => {
            let newArray = [];
            data.forEach((item) => {
              if (item.nombre) {
                handleStructureItems(newArray, item);
              }
            });
            const sortedArray = SortData(newArray, 'asc');
            setDataTable(sortedArray);
            // show loading
            toggleLoading(false);
          })
          .catch((err) => {
            // mostrar error
            toggleError(!error);
            handleClick();
          });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.roles.deleteRole, rowId)
        .then(async () => {
          await getDataTable();
          setSearchResults([]);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    const arrayCreated = usersJson.find((user) => {
      return user.idUsuario === item.usuarioCreacion;
    });

    const arrayUpdated = usersJson.find((user) => {
      return user.idUsuario === item.usuarioModificacion;
    });

    let created_by = '';
    let updated_by = '';

    if (arrayCreated) {
      created_by = arrayCreated.usuario;
    } else {
      created_by = 'No esta asociado a ningún usuario';
    }

    if (arrayUpdated) {
      updated_by = arrayUpdated.usuario;
    } else {
      updated_by = 'No esta asociado a ningún usuario';
    }

    let created_at = dateFormat(item.fechaCreacion, 'yyyy/mm/dd - h:MM:ss TT');
    let updated_at = dateFormat(item.fechaModificacion, 'yyyy/mm/dd - h:MM:ss TT');

    newArray.push({
      id: item.idRol,
      nombre: item.nombre || 'No tiene nombre',
      descripcion: item.descripcion,
      created_at,
      updated_at,
      updated_by,
      created_by,
      estado: item.estado,
      objeto: item,
    });
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.roles.updateRole, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  // titulos de la tabla
  const titles = [
    formatterText('table.title.role', 'Rol'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.date.creation', 'Fecha de creación'),
    formatterText('table.title.date.modification', 'Fecha de modificación'),
    formatterText('table.title.modified.by', 'Modificado por'),
    formatterText('table.title.created.by', 'Creado por'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading ? (
        <section className="table-container">
          <section className="userOptions">
            <Search
              placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
              width="50%"
            />
            {permittedActions.crear && (
              <Link to={paths.createRol}>
                <button className="btn-add">
                  <FormattedMessage id="btn.create.role" defaultMessage="Crear Rol" />
                </button>
              </Link>
            )}

            {permittedActions.exportar && (
              <ExportJsonFile
                moduleName={'Rol'}
                userName={
                  JSON.parse(localStorage.getItem('userData')).usuario
                    ? JSON.parse(localStorage.getItem('userData')).usuario
                    : 'ADMIN'
                }
                dataTable={searchResults}
              />
            )}
          </section>
          {permittedActions.consultar && (
            <FormattedMessage id="table.name.search.rols" defaultMessage="Roles">
              {(placeholder) => (
                <div className="tab-container">
                  <DynamicTable
                    titles={titles}
                    pageName={PAGE_NAMES.Roles}
                    data={getDataTable}
                    handleDeleteItem={handleDeleteItem}
                    handleEditStateItem={handleEditStateItem}
                    routeToEdit={paths.updateRol}
                    canDeleted={permittedActions.eliminar}
                    canModify={permittedActions.editar}
                  />
                </div>
              )}
            </FormattedMessage>
          )}
        </section>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
}
