import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
// paths to routes
import paths from 'services/paths';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
// hook para cargar los datos
import useGetData from 'hooks/useGetData';
// Import Services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import endpoints from 'services/api';
import { deleteBillingType, updateBillingType } from 'services/api/billingType';
import { getAll } from 'services/api/methods';

const BillingTypesTable = ({permisos}) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  const [parameters, setParameters] = useState(null);

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  // función para cargar datos
  const getDataTable = () => {  

    getAll(endpoints.billingTypes.getAllBillingTypes).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item));
      setParameters(newArray);
      setDataTable(newArray);

    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteBillingType(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setParameters(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateBillingType(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idTipoFacturacion,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const { formatterText } = useLangv2();

  const titles = [
    formatterText('table.title.billing.type', 'Nombre tipo facturación'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && parameters !== null ? (
        <FormattedMessage id="table.name.search.billingType" defaultMessage="Tipos de facturación">
          {(placeholder) => (
            <DynamicTable
              titles={titles}
              pageName={PAGE_NAMES.Facturacion}
              data={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateBillingType}
              canDeleted={permisos.eliminar}
              canModify={permisos.editar}
            />
          )}
        </FormattedMessage>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default BillingTypesTable;
