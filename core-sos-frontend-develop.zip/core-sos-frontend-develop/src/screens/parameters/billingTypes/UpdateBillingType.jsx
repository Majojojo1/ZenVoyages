import React, { useEffect, useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import Cookie from "js-cookie";
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import BillingType from "models/BillingType";
// Import Services
import { validateDuplicateCodeAsync } from "common/validators/ValidateDuplicates";
import endpoints from "services/api";
import { getBillingById, updateBillingType } from "services/api/billingType";
import { getAll } from "services/api/methods";
import paths from "services/paths";

export default function UpdateMarket() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new BillingType());
  const [currentCode, setCurrentCode] = useState('');
  const { id } = useParams();
  // toggle state
  const [active, setActive] = useState(true);
  const { resourceNotFound } = useLangv2();

  useEffect(() => {
    getDataBillingType();
   
  }, []);

  useEffect(() => {    
    getDataToUpdate(id);
  }, [id]);

  const setBillForm = (data) => {
    setFormData({
      idTipoFacturacion: data.idUnidadNegocio,
      nombre: data.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: data.descripcion,
      codigo: data.codigo,      
      estado: data.estado,
      fechaRegistro: data.fechaRegistro,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion,
    });
  };

  const getDataBillingType = () => {
    const billingType = JSON.parse(localStorage.getItem("dataUpdate"));
    if (billingType) {
      setCurrentCode(billingType.codigo);
      setBillForm(billingType);
      setActive(billingType.estado);
    }
  };

  const getDataToUpdate = (id) => {
    getBillingById(id)
    .then((res) =>{
      if(res === null){
        resourceNotFound();
      }else{
      setCurrentCode(res.codigo);
      setBillForm(res);
      setActive(res.estado);
      }
    }).catch((err)=>{
      console.error(err);
    });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, CODEREGEX, formData, setFormData, true);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = async (e) => {
    e.preventDefault();
    let errorMsg = formatterText('p.label.title.errorCrearTipoClienteExistenciaCodigo');
    const isDuplicateCode = await validateDuplicateCodeAsync(
      formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
      errorMsg,
      getAll(endpoints.billingTypes.getAllBillingTypes),
      true,
      currentCode
    );
    if (!isDuplicateCode) {
      const data = {
        ...formData,
        idTipoFacturacion: id,
        nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
        estado: active ? "1" : "0",
        codigo: formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
        usuarioModificacion: Cookie.get("idUsuario"),
      };
      updateBillingTypeData(data);
    }
  };

  const updateBillingTypeData = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText:  formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateBillingType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              console.log(err);
              reject(
                HandleOnError(
                  formatterText('alert.message.failed.associations.general', 
                  'Error al crear una de las asociaciones, es posible que el código ya exista'),
                ),
              );
            });
        });
      },
    });
  };

  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.billing.type"
              defaultMessage="Nombre tipo facturación"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.billing.type",
              "Nombre tipo facturación",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder={formatterText(
              "input.placeholder.max.45.chars",
              "Ingrese hasta 45 caracteres",
            )}
            maxLength="45"
            required
          />
        </section>

        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={!!active}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
        <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancel" />
        </button>
      </section>
    </form>
  );
}
