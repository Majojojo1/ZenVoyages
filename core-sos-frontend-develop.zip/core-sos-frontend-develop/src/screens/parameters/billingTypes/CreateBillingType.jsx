import React, { useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import BillingType from "models/BillingType";
// Import Services
import { validateDuplicateCode } from "common/validators/ValidateDuplicates";
import endpoints from "services/api";
import { addBillingType } from "services/api/billingType";
import { getAll } from "services/api/methods";
import paths from "services/paths";

export default function CreateBillingType() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new BillingType());

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData, true);
  };
  
  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, TEXTREGEX, formData, setFormData, true);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = async (e) => {
    e.preventDefault();
    let errorMsg = formatterText('p.label.title.errorCrearTipoClienteExistenciaCodigo');

    if (
      validateDuplicateCode(
        formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
        errorMsg,
        () => getAll(endpoints.billingTypes.getAllBillingTypes),
      )
    ) {
      createItem({
        ...formData,
        nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
        descripcion: formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
        codigo: formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
      });
    }
  };

  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addBillingType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              console.log(err);
              reject(
                HandleOnError(
                  formatterText('alert.message.failed.associations.general', 
                  'Error al crear una de las asociaciones, es posible que el código ya exista'),
                ),
              );
            });
        });
      },
    });
  };

  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.billing.type"
              defaultMessage="Nombre tipo facturación"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.billing.type",
              "Nombre tipo facturación",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder={formatterText(
              "input.placeholder.max.45.chars",
              "Ingrese hasta 45 caracteres",
            )}
            maxLength="45"
            required
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="header.title.client.parameter.client.billing.type.create"
            defaultMessage="Crear tipo de facturación"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
