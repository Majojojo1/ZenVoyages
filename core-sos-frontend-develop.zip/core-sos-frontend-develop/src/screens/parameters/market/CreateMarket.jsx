import React, { useEffect, useState } from "react";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import { useNavigate } from "react-router-dom";
// Import Components
import SelectorMulti from "common/SelectorMulti";
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, STRINGREGEX, TEXTREGEXMIN, SPACING} from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";

// Import Libs
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import Market from "models/Market";
// Import Services
import { addMarket, addMarketCountry } from "services/api/markets";
import { getAllCountries } from "services/api/zones";
import paths from "services/paths";

export default function CreateMarket() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new Market());
  // Llena todo el multiselect con los paises
  const [selectedSearchCountries, setSearchSelectedCountries] = useState([]);
  // Setea los valores del multiselect de los paises
  const [selectValues, setSelectValues] = useState([]);
  // espera a que cargue los valores del multiselect
  const { loading, toggleLoading } = useGetData();
  const [idMarket, setIdMarket] = useState(null);
  // use Hook of language v2
  const { formatterText } = useLangv2();

  useEffect(() => {
    getDataCountries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getDataCountries = () => {
    toggleLoading(true);
    getAllCountries()
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idPais,
              label: item.nombrePais,
              isFixed: true,
            });
          }
        });
        setSearchSelectedCountries(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };


  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    if (e.target.name.toLowerCase() === "prefijo") {
      HandleInput(e, PREFIXREGEX, formData, setFormData);
    } else {
      HandleInput(e, CODEREGEX, formData, setFormData);
    }
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    createMarket({
      ...formData,
      nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  const createMarket = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addMarket(data)
            .then((res) => {
              setIdMarket(res.idMercado);
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: "Continuar",
                  allowOutsideClick: false,
                  executeFunction: () => associateCountryMarket(res.idMercado),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  const associateCountryMarket = (idM) => {
    // realizar un if si seleccionaron paises
    if (selectValues.length > 0) {
      let data = {
        mercado: {
          idMercado: idM,
        },
        pais: [],
      };
      selectValues.map((item) => data.pais.push({ idPais: item.value }));
      addMarketCountry(data)
        .then((res) => {
          console.log(res);
          CustomAlert("confirm_msg", {
            icon: "success",
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText('alert.message.associations.general', 'Las asociaciones se crearon correctamente'),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.parameters),
          });
        })
        .catch((err) => {
          if (err.response?.data?.message) {
            HandleOnError(err.response?.data?.message);
          } else {
            HandleOnError(formatterText(
              'snackbar.error.process.failed.general',
              'Error al realizar el proceso. Intentalo en otro momento.',
            ),);
          }
        });
    } else {
      navigate(paths.parameters);
    }
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="grid-container-1c zero-gap">
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.market.name"
              defaultMessage="Nombre mercado"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleText}
              placeholder={formatterText(
                "table.title.market.name",
                "Nombre mercado",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Desripción"
            />
          </span>
          <section className="w100-container">
            <textarea
              className="input-textarea"
              type="text"
              name="descripcion"
              value={formData.descripcion}
              onChange={handlerTextDescription}
              placeholder={formatterText(
                "table.title.description",
                "Descripción",
              )}
              maxLength="200"
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="codigo"
              value={formData.codigo}
              onChange={handlerTextCode}
              placeholder={formatterText(
                "input.placeholder.enter.up.characters",
                "Ingresa hasta 45 caracteres",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.countryPrefix"
              defaultMessage="Prefijo"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="prefijo"
              value={formData.prefijo}
              onChange={handleChange}
              placeholder={formatterText(
                "table.title.countryPrefix",
                "Prefijo",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="p.associated.countries"
              defaultMessage="Países asociados"
            />
          </span>
          <section className="w100-container">
            <SelectorMulti
              data={selectedSearchCountries}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
              isRequired={true}
            />
          </section>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.create.market"
            defaultMessage="crear mercado"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage
            id="alert.button.cancel.general"
            defaultMessage="Cancelar"
          />
        </button>
      </section>
    </form>
  );
}
