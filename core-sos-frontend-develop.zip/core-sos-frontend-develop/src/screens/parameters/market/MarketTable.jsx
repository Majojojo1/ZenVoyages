import React, { useEffect, useState } from 'react';
// Import Context
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
// Import libs
import { FormattedMessage } from 'react-intl';
// Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api'; //importar endpoints
import { deleteMarket, updateMarket } from 'services/api/markets';
import { getAll } from 'services/api/methods';
import paths from 'services/paths';

const MarketTable = ({ permisos }) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  const [parameters, setParameters] = useState(null);

  // use Hook of language v2
  const { formatterText } = useLangv2();

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false); //Agregar el loading
  }, [permisos]);



  // función para cargar datos
  const getDataTable = () => {
    
    getAll(endpoints.markets.getAllMarkets).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item)); //poner el response
      setParameters(newArray);
      setDataTable(newArray);  
     
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteMarket(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setParameters(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateMarket(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    const paises =
      item.paises === null
        ? 'No hay paises'
        : item.paises.map((pais, index) =>
            index === item.paises.length - 1 ? pais.nombrePais + ' ' : pais.nombrePais + ', ',
          );

    newArray.push({
      id: item.idMercado,
      nombre: item.nombre,
      descripcion: item.descripcion,
      paises: paises,
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const titles = [
    formatterText('table.title.market.name', 'Nombre mercado'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('tab.title.countries', 'Países'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && parameters !== null ? (
        <FormattedMessage id="table.name.search.market" defaultMessage="Mercados">
          {(placeholder) => (
            <DynamicTable
              titles={titles}
              pageName={PAGE_NAMES.Mercados}
              data={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateMarket}
              canDeleted={permisos.eliminar}
              canModify={permisos.editar}
            />
          )}
        </FormattedMessage>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default MarketTable;
