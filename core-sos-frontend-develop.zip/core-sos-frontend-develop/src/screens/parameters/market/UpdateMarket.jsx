import React, { useEffect, useState } from "react";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import SelectorMulti from "common/SelectorMulti";
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, PREFIXREGEX, TEXTREGEX, TEXTREGEXMIN } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import Cookie from "js-cookie";
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import Market from "models/Market";
// Import Services
import {
  addMarketCountry,
  deleteMarketFromCountry,
  getMarketAssociateByCountry,
  getMercadoByIdMercado,
  updateMarket
} from "services/api/markets";
import { getAllCountries } from "services/api/zones";
import paths from "services/paths";

export default function UpdateMarket() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState(new Market());
  const [selectedSearchCountries, setSearchSelectedCountries] = useState([]);
  const [selectValues, setSelectValues] = useState([]);
  const { loading, toggleLoading } = useGetData();
  const [idMarket, setIdMarket] = useState(null);
  const [active, setActive] = useState(true);
  const [selectedMarketAssociate, setSelectedMarketAssociate] = useState([]);
  const { formatterText, resourceNotFound } = useLangv2();
  const { id } = useParams();

  useEffect(() => {
    getDataCountries();
    getMarketsAssociated(id);
    getDataMarket();
  }, []);

  useEffect(() => {
    getDataToUpdate(id)
    getDataCountries();
    getMarketsAssociated(id);

  }, [id]);

  const setMaketForm = (data) => {
    setFormData({
      idMercado: data.idUnidadNegocio,
      nombre: data.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: data.descripcion,
      codigo: data.codigo,
      prefijo: data.prefijo,
      estado: data.estado,
      fechaRegistro: data.fechaRegistro,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion,
    });
  };

  const getDataMarket = () => {
    const market = JSON.parse(localStorage.getItem("dataUpdate"));

    if (market) {
      setMaketForm(market);
      setActive(market.estado);
      getMarketsAssociated(id);
    } else {
      navigate(paths.parameters);
    }
  };

  const getDataToUpdate = (id) => {
    getMercadoByIdMercado(id)
      .then((res) => {
        if (res === null) {
          resourceNotFound();
        } else {
          setMaketForm(res);
          setActive(res.estado);
        }
      }).catch((err) => {
        console.log(err);
      });
  };

  const getDataCountries = () => {
    toggleLoading(true);
    getAllCountries()
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idPais,
              label: item.nombrePais,
              isFixed: true,
            });
          }
        });
        setSearchSelectedCountries(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  const getMarketsAssociated = (id) => {
    console.log(id);
    getMarketAssociateByCountry(id)
      .then((res) => {
        console.log('getMarketAssociated', res);
        let newArray = [];
        res.forEach((item) => {
          newArray.push({
            value: item.idPais,
            label: item.nombrePais,
            associateId: item.idMercadoPais,
            isFixed: true,
          });
        });
        setSelectValues(newArray);
        setSelectedMarketAssociate(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match("^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$") != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    switch (e.target.name) {
      case "prefijo":
        HandleInput(e, PREFIXREGEX, formData, setFormData);
        break;
      case "codigo":
        HandleInput(e, CODEREGEX, formData, setFormData);
        break;

      default:
        HandleInput(e, TEXTREGEX, formData, setFormData);
        break;
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      idMercado: id,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
    updateMarketData(data);
  };

  const updateMarketData = (data) => {
    Swal.fire({
      title: formatterText(
        "alert.title.general",
        "Atención, estás seguro de realizar esta acción",
      ),
      text: formatterText(
        "alert.description.create.general",
        "Se va a crear un nuevo registro",
      ),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText(
        "alert.button.confirm.general",
        "Guardar cambios",
      ),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          updateMarket(data)
            .then((res) => {
              setIdMarket(res.idMercado);
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText(
                    "alert.title.confirm.general",
                    "Operación exitosa",
                  ),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () =>
                    deleteAssociateCountryMarket(res.idMercado),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  const associateCountryMarket = (idM) => {
    // realizar un if si seleccionaron paises
    if (selectValues.length > 0) {
      let data = {
        mercado: {
          idMercado: idM,
        },
        pais: [],
      };
      selectValues.map((item) => data.pais.push({ idPais: item.value }));
      selectValues.forEach((item) => {
        data.pais.push({
          idPais: item.value,
        });
      });

      addMarketCountry(data)
        .then((res) => {
          CustomAlert("confirm_msg", {
            icon: "success",
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText('alert.message.associations.general', 'Las asociaciones se crearon correctamente'),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.parameters),
          });
        })
        .catch((err) => {
          if (err.response?.data?.message) {
            HandleOnError(err.response?.data?.message);
          } else {
            HandleOnError(formatterText(
              'snackbar.error.process.failed.general',
              'Error al realizar el proceso. Intentalo en otro momento.',
            ),);
          }
        });
    } else {
      navigate(paths.parameters);
    }
  };

  const deleteAssociateCountryMarket = (idM) => {
    let newArray = [];
    selectedMarketAssociate.map((item) => newArray.push(item.associateId));
    let newArray2 = [];
    selectValues.map((item) => newArray2.push(item.associateId));
    console.log(selectValues);
    let newArray3 = newArray.filter((item) => !newArray2.includes(item));
    const promisesArray = newArray3.map((item) =>
      deleteMarketFromCountry(item)
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        }),
    );
    Promise.all(promisesArray)
      .then(() => associateCountryMarket(idM))
      .catch((err) => {
        console.log(err);
      });
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  function handleLanguage(nameLang, defaultName) {
    return <FormattedMessage id={nameLang} defaultMessage={defaultName} />;
  }

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="grid-container-1c zero-gap">
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.market.name"
              defaultMessage="Nombre mercado"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleText}
              placeholder={formatterText(
                "table.title.market.name",
                "Nombre mercado",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Desripción"
            />
          </span>
          <section className="w100-container">
            <textarea
              className="input-textarea"
              type="text"
              name="descripcion"
              value={formData.descripcion}
              onChange={handlerTextDescription}
              placeholder={formatterText(
                "table.title.description",
                "Descripción",
              )}
              maxLength="200"
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="codigo"
              value={formData.codigo}
              onChange={handlerTextCode}
              placeholder={formatterText(
                "input.placeholder.enter.up.characters",
                "Ingresa hasta 45 caracteres",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.countryPrefix"
              defaultMessage="Prefijo"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="prefijo"
              value={formData.prefijo}
              onChange={handleChange}
              placeholder={formatterText(
                "table.title.countryPrefix",
                "Prefijo",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="p.associated.countries"
              defaultMessage="Países asociados"
            />
          </span>
          <section className="w100-container">
            <SelectorMulti
              data={selectedSearchCountries}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
              der={selectedMarketAssociate}
              isRequired={true}
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <section className="w100-container">
            <label className="container-toggle-label">
              <p className="form-responsive-toggle">
                {active
                  ? formatterText("p.active", "Activo")
                  : formatterText("p.unActive", "No activo")}
              </p>
              <label className="switch">
                <input
                  checked={active ? true : false}
                  onChange={() => {
                    setActive(!active);
                  }}
                  type="checkbox"
                />
                <span className="slider round"></span>
              </label>
            </label>
          </section>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.save" defaultMessage="Guardar" />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage
            id="alert.button.cancel.general"
            defaultMessage="Cancelar"
          />
        </button>
      </section>
    </form>
  );
}
