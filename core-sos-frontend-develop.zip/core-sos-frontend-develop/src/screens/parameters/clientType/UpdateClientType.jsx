import React, { useEffect, useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import Cookie from "js-cookie";
import Swal from "sweetalert2";
// Import Models
import BillingType from "models/BillingType";
import { FormattedMessage } from "react-intl";
// Import Services
import { validateDuplicateCode } from "common/validators/ValidateDuplicates";
import { getAllClientTypes, updateClientType } from "services/api/clientType";

import endpoints from "services/api";
import { getItemById } from "services/api/methods";
import paths from "services/paths";

export default function UpdateMarket() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new BillingType());
  const [currentCode, setCurrentCode] = useState('');
  // use Hook of language v2
  const { formatterText, resourceNotFound } = useLangv2();
  // toggle state
  const [active, setActive] = useState(true);
  const { id } = useParams();

  useEffect(() => {
    getDataClientType();
  }, []);

  useEffect(() => {
    getDataToUpdate(id);
  }, [id]);

  const setClientTypeForm = (data) => {
    setFormData({
      idTipoCliente: data.idTipoCliente,
      nombre: data.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      fechaCreacion: data.fechaCreacion,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion,
    });
  }

  const getDataClientType = () => {
    const clientType = JSON.parse(localStorage.getItem("dataUpdate"));
    if (clientType) {
      setCurrentCode(clientType.codigo);
      setClientTypeForm(clientType);
      setActive(clientType.estado);
    }
  };

  const getDataToUpdate = (id) => {
    getItemById(endpoints.clientTypes.getClientTypeById, id)
      .then((res) => {
        if (res !== null) {
          const clientType = res;
          setCurrentCode(clientType.codigo);
          setClientTypeForm(clientType);
        } else {
          resourceNotFound();
        }
      }).catch((err) => {
        console.error(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData, true);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // update the form number
  const handleCode = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, TEXTREGEX, formData, setFormData, true);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    let errorMsg = formatterText('p.label.title.errorCrearTipoClienteExistenciaCodigo');
    const data = {
      ...formData,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
    if (validateDuplicateCode(
      formData.codigo,
      errorMsg,
      () => getAllClientTypes(),
      true,
      currentCode
    )) {
      updateBillingTypeData(data);
    }
  };

  const updateBillingTypeData = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateClientType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              console.log(err);
              reject(
                HandleOnError(
                  formatterText('alert.message.failed.associations.general', 
                  'Error al crear una de las asociaciones, es posible que el código ya exista'),
                ),
              );
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.client.type"
              defaultMessage="Nombre tipo cliente"
            />
          </span>
          <input
            className={(formData.nombre ? '' : 'input-error ') + 'input-primary'}
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.client.type",
              "Nombre tipo cliente",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className={(formData.codigo ? '' : 'input-error ') + 'input-primary'}
            //pattern="^\S+(?: \S+)*$"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleCode}
            placeholder={formatterText(
              "input.placeholder.max.45.chars",
              "Ingrese hasta 45 caracteres",
            )}
            maxLength="45"
            required
          />
        </section>

        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={!!active}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
