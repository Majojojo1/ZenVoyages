import React, { useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { SPACING, TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import ProviderType from "models/ProviderType";
// Import Services
import { addProviderType } from "services/api/providerType";
import paths from "services/paths";

export default function CreateProviderType() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new ProviderType());
  // use Hook of language v2
  const { formatterText } = useLangv2();

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, SPACING, formData, setFormData, true);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, TEXTREGEX, formData, setFormData, true);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    createProviderType({
      ...formData,
      nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  // create the provider type
  const createProviderType = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addProviderType(data)
            .then(() => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.provider.type.name"
              defaultMessage="Nombre tipo proveedor"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "table.title.provider.type.name",
              "Nombre tipo proveedor",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Desripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "table.title.description",
              "Descripción",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className={(formData.codigo ? '' : 'input-error ') + 'input-primary'}
            type="text"
            name="codigo"
            value={formData.codigo}
            // pattern="^\S+(?: \S+)*$"
            onChange={handleChange}
            placeholder={formatterText(
              "input.placeholder.enter.up.characters",
              "Ingresa hasta 45 caracteres",
            )}
            maxLength="45"
            required
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.create.provider.type"
            defaultMessage="Crear tipo de proveedor"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage
            id="alert.button.cancel.general"
            defaultMessage="Cancelar"
          />
        </button>
      </section>
    </form>
  );
}
