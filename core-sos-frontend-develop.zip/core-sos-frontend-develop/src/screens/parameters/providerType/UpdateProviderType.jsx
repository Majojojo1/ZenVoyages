import React, { useEffect, useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import Cookie from "js-cookie";
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import ProviderType from "models/ProviderType";
// Import Services
import { getProviderById, updateProviderType } from "services/api/providerType";
import paths from "services/paths";

export default function UpdateProviderType() {
  const navigate = useNavigate();
  // form data
  const [formData, setFormData] = useState(new ProviderType());
  // Toggle state
  const [active, setActive] = useState(true);
  const { formatterText, resourceNotFound } = useLangv2();
  const { id } = useParams();

  useEffect(() => {
    getDataProviderType();
  }, []);

  useEffect(() => {
    getDataToUpdate(id);
  }, [id]);

  const setProviderForm = (data) => {
    setFormData({
      idTipoProveedor: data.idUnidadNegocio,
      nombre: data.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      fechaRegistro: data.fechaRegistro,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion,
    });
  };

  const getDataProviderType = () => {
    const providerType = JSON.parse(localStorage.getItem("dataUpdate"));

    if (providerType) {
      setProviderForm(providerType);
      setActive(providerType.estado);
    } else {
      navigate(paths.parameters);
    }
  };

  const getDataToUpdate = (id) => {
    getProviderById(id)
      .then((res) => {
        if (res === null) {
          resourceNotFound();
        } else {
          setProviderForm(res);
          setActive(res.estado);
        }
      }).catch((err) => {
        console.log(err);
      });
  }

  // uodate the string to set into the form
  const handleText = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData, true);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  const handleChange = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, TEXTREGEX, formData, setFormData, true);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      idTipoProveedor: id,
      nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: formData.descripcion,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
    putProviderType(data);
  };

  // update the provider type
  const putProviderType = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateProviderType(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.parameters),
                }),
              );
            })
            .catch((err) => {              
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else if (err.response.status === 400) {
                  HandleOnError(formatterText(
                    'alert.message.code.error.general',
                    'El código ya existe, por favor ingrese uno distinto',
                  ),
                  );
                } else {
                  HandleOnError(formatterText(
                    'snackbar.error.process.failed.general',
                    'Error al realizar el proceso. Intentalo en otro momento.',
                  ),
                  );
                }
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="waprFom">
        <label className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="table.title.provider.type.name"
              defaultMessage="Nombre tipo proveedor"
            />
          </span>
          <input
            className={(formData.nombre ? '' : 'input-error ') + 'input-primary'}
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder="Nombre tipo proveedor"
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder="Descripción"
            maxLength="200"
          />
        </label>
        <label className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className={(formData.codigo ? '' : 'input-error ') + 'input-primary'}
            type="text"
            //pattern="^\S+(?: \S+)*$"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            placeholder="Ingresa hasta 45 caracteres"
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={!!active}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </label>
      </section>
      <section className="form-responsive-container-buttons">
        <button
          type="submit"
          className="btn-primary"
        >
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancel" />
        </button>
      </section>
    </form>
  );
}
