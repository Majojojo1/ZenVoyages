import React, { useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Search from 'common/Search';
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
// Import libs
import { Link } from 'react-router-dom';
// Import services
import paths from 'services/paths';
// Import Screens
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import BillingTypesTable from 'screens/parameters/billingTypes/BillingTypesTable';
import BusinessUnitsTable from 'screens/parameters/businessUnits/BusinessUnitsTable';
import ClientTypeTable from 'screens/parameters/clientType/ClientTypeTable';
import MarketTable from 'screens/parameters/market/MarketTable';
import ProviderTypeTable from 'screens/parameters/providerType/ProviderTypeTable';
import Parameters from 'screens/parameters/thirdType/Parameters';

const ClientParametersTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ClientParametersTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const ClientParametersTableComponent = () => {
  // use Hook of language v2
  const { formatterText } = useLangv2();

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.clientParameters.principal);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  const tabs = [
    {
      nombre: formatterText('table.name.search.market', 'Mercados'),
      route: paths.createMarket,
      nombreLink: formatterText('btn.create.market', 'Crear mercado'),
      componente: <MarketTable permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.market,
    },
    {
      nombre: formatterText('table.name.search.businessUnits', 'Unidades de negocio'),
      route: paths.createBusinessUnit,
      nombreLink: formatterText('btn.create.business.unit', 'Crear unidad de negocio'),
      componente: <BusinessUnitsTable permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.unitBusiness,
    },
    {
      nombre: formatterText('p.provider.type', 'Tipo de proveedor'),
      route: paths.createProviderType,
      nombreLink: formatterText('btn.create.provider.type', 'Crear tipo de proveedor'),
      componente: <ProviderTypeTable permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.providerType,
    },
    {
      nombre: formatterText('table.name.search.clientType', 'Tipos de clientes'),
      route: paths.createClientType,
      nombreLink: formatterText('btn.create.cliente.type', 'Crear tipo de cliente'),
      componente: <ClientTypeTable permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.clientType,
    },
    {
      nombre: formatterText('table.name.search.billingType', 'Tipos de facturación'),
      route: paths.createBillingType,
      nombreLink: formatterText('btn.create.billingType', 'Crear tipo de facturacion'),
      componente: <BillingTypesTable permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.invoiceType,
    },
    {
      nombre: formatterText('tab.title.third.types', 'Tipos de terceros'),
      route: paths.createParameter,
      nombreLink: formatterText('btn.create.thirdType', 'Crear tipo de tercero'),
      componente: <Parameters permisos={permittedActions} />,
      idPermiso: MODULES_NAME.clientParameters.thirdPartiesType,
    },
  ];

  const { setSearch } = useSeachContext();

  // Select tab
  const [selectedTab, setSelectedTab] = useState(tabs[0]);

  // Index Tab
  const [indexTabClient, setIndexTabClient] = useState(Number(localStorage.getItem('ClientParametersTable')) || 0);

  useEffect(() => {
    setSearch('');
    localStorage.setItem('ParametersServicesTable', 0);
    const index = Number(localStorage.getItem('ClientParametersTable'));
    setIndexTabClient(index);
  }, []);

  return (
    <section className="table-container">
      <section className="userOptions">
       {permittedActions.consultar && ( <Search
          placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
          width="50%"
        />)}
        {permittedActions.crear && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.route}>
            <button className="btn-add">{selectedTab.nombreLink}</button>
          </Link>
        )}
      </section>
      {<Tabs defaultIndex={indexTabClient} onSelect={index => localStorage.setItem('ClientParametersTable', index)} selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                localStorage.setItem('indexTabClient', index.toString());
                permissionsAccess(tab.idPermiso);
              }}
              key={index}
              className="tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {(permittedActions.consultar) && (tabs.map((tab, index) => (
          <TabPanel key={index}>{tab.componente}</TabPanel>
        )))}
      </Tabs>}
    </section>
  );
};

export default ClientParametersTable;
