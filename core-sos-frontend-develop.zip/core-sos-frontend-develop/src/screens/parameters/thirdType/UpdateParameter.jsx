import React, { useEffect, useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEX, TEXTREGEXMIN } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import Cookie from "js-cookie";
import { FormattedMessage } from "react-intl";
// Import Models
import Parameter from "models/Parameters/Parameter";
// Import Services
import { getAllThirdTypes, updateThirdType } from "services/api/parameters";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function UpdateParameter() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new Parameter());
  // toggle state
  const [active, setActive] = useState(false);

  useEffect(() => {
    getThirdType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const getThirdType = () => {
    getAllThirdTypes()
      .then((data) => {
        const tercero = data.find(
          (third) => third.idTipoTercero.toString() === id,
        );
        setFormData(tercero);
        setActive(tercero.estado.toString() === "1");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData, true);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: formData.descripcion ? formData.descripcion.replaceAll(/\s{2,}/gi, ' ') : "",
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateThirdType(data)
            .then((response) => {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.parameters),
              });
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else if (err.response.status === 500) {
                HandleOnError(formatterText(
                  'alert.message.code.error.general',
                  'El código ya existe, por favor ingrese uno distinto',
                ),
                );
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.'
                ),
                );
              }
            });
        });
      },
    });
  };

  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="p.third.type.name"
              defaultMessage="Nombre tipo de tercero"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "p.third.type.name",
              "Nombre tipo de tercero",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "input.placeholder.type.third.desc",
              "Descripción del tipo de tercero",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className={(formData.codigo ? '' : 'input-error ') + ' input-primary'}
            type="text"
            name="codigo"
            value={formData.codigo}
            pattern="^\S+(?: \S+)*$"
            onChange={handlerTextCode}
            placeholder={formatterText(
              "input.placeholder.type.third.code",
              "Código del tipo de tercero",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={!!active}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancel" />
        </button>
      </section>
    </form>
  );
}
