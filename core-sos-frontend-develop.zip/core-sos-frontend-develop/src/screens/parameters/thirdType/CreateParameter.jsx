import React, { useState } from "react";
// Import Hooks
import useLangv2 from "hooks/useLangv2";
import { useNavigate } from "react-router-dom";
// Import Components
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEX, TEXTREGEXMIN } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import Parameter from "models/Parameters/Parameter";
// Import Services
import { addThirdType } from "services/api/parameters";
import paths from "services/paths";

export default function CreatePosition() {
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new Parameter());

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData, true);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return addThirdType({
          nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
          descripcion: formData.descripcion,
          codigo: formData.codigo,
          estado: 1,
        })
          .then(() => {
            CustomAlert("confirm_msg", {
              icon: "success",
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText(
                'alert.message.confirm.created.general',
                'El registro se ha creado correctamente',
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.parameters),
            });
          })
          .catch((err) => {
            if (err.response?.data?.message) {
              HandleOnError(formatterText(err.response?.data?.message));
            } else {
              HandleOnError(formatterText(
                'snackbar.error.process.failed.general',
                'Error al realizar el proceso. Intentalo en otro momento.',
              ),);
            }
          });
      },
    });
  };

  const { formatterText } = useLangv2();

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <span className="warpForm-text">
            <FormattedMessage
              id="p.third.type.name"
              defaultMessage="Nombre tipo de tercero"
            />
          </span>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "p.third.type.name",
              "Nombre tipo de tercero",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </span>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "input.placeholder.type.third.desc",
              "Descripción del tipo de tercero",
            )}
            maxLength="200"
          />
        </section>
        <section className="form-responsive-information__option">
          <span className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <input
            className={(formData.codigo ? '' : 'input-error ') + 'input-primary'}
            type="text"
            name="codigo"
            //pattern="^\S+(?: \S+)*$"
            value={formData.codigo}
            onChange={handlerTextCode}
            placeholder={formatterText(
              "input.placeholder.type.third.code",
              "Código del tipo de tercero",
            )}
            maxLength="45"
            required
          />
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancel" />
        </button>
      </section>
    </form>
  );
}
