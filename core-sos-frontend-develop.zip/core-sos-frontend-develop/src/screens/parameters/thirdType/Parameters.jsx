import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
// paths to routes
import { deleteThirdType, updateThirdType } from 'services/api/parameters';
import paths from 'services/paths';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
// hook para cargar los datos
import useGetData from 'hooks/useGetData';
// Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import useLangv2 from 'hooks/useLangv2';
import endpoints from 'services/api';
import { getAll } from 'services/api/methods';

const Parameters = ({permisos}) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();

  const [parameters, setParameters] = useState(null);

  useEffect(() => {
    toggleLoading(true);
    getDataTable();
    toggleLoading(false);
  }, []);

  // función para cargar datos
  const getDataTable = () => {   

    getAll(endpoints.parameters.getAllThirdTypes).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item));
      setParameters(newArray);
      setDataTable(newArray);     
     
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteThirdType(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setParameters(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateThirdType(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idTipoTercero,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const { formatterText } = useLangv2();

  const titles = [
    formatterText('table.title.third.name', 'Nombre tercero'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && parameters !== null ? (
        <FormattedMessage id="table.name.search.parameter" defaultMessage="Parámetros">
          {(placeholder) => (
            <DynamicTable
              titles={titles}
              pageName={PAGE_NAMES.Terceros}
              data={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateParameter}
              canDeleted={permisos.eliminar}
              canModify={permisos.editar}
            />
          )}
        </FormattedMessage>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default Parameters;
