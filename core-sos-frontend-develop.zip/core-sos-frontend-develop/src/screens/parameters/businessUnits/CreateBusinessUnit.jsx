import React, { useEffect, useState } from "react";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import { useNavigate } from "react-router-dom";
// Import Components
import SelectorMulti from "common/SelectorMulti";
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEXMIN, SPACING } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
// Import Libs
import { validateDuplicateCode } from "common/validators/ValidateDuplicates";
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
// Import Models
import BusinessUnit from "models/BusinessUnit";
// Import Services
import endpoints from "services/api";
import {
  addBusinessUnit,
  addMarketCountryToUnit,
  getAllMarketCountry,
} from "services/api/businessUnit";
import { getAll } from "services/api/methods";
import paths from "services/paths";

export default function CreateBusinessUnit() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new BusinessUnit());
  const [selectedSearchCountries, setSearchSelectedCountries] = useState([]);
  // Setea los valores del multiselect de los paises
  const [selectValues, setSelectValues] = useState([]);
  // espera a que cargue los valores del multiselect
  const { loading, toggleLoading } = useGetData();
  // use Hook of language v2
  const { formatterText } = useLangv2();

  useEffect(() => {
    getDataMarkets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getDataMarkets = () => {
    toggleLoading(true);
    getAllMarketCountry()
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.mercado.estado === 1) {
            newArray.push({
              value: item.idMercadoPais,
              label: `${item.mercado.nombre} - ${item.pais.nombrePais}`,
              isFixed: true,
            });
          }
        });
        setSearchSelectedCountries(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };

  
  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  const handleCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      validateDuplicateCode(
        formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
        formatterText('alert.message.code.error.general'),
        () => getAll(endpoints.businessUnit.getAllBusinessUnits),
      )
    ) {
      createBusinessUnit({
        ...formData,
        nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
        descripcion: formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
      });
    }
  };

  const createBusinessUnit = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addBusinessUnit(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () =>
                    associateCountryMarketBusinessUnit(res.idUnidadNegocio),
                }),
              );
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(err.response?.data?.message);
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            });
        });
      },
    });
  };

  const associateCountryMarketBusinessUnit = (idM) => {
    // realizar un if si seleccionaron paisemercadUnidad
    if (selectValues.length > 0) {
      selectValues.forEach((item) => {
        let data = {
          idMercadoPaisUnidadNegocio: null,
          idMercadoPais: {
            idMercadoPais: item.value,
          },
          idUnidadNegocio: {
            idUnidadNegocio: idM,
          },
        };
        console.log(data);
        addMarketCountryToUnit(data)
          .then((res) => {
            console.log(res);
            CustomAlert("confirm_msg", {
              icon: "success",
              title:formatterText(
                "alert.title.confirm.general",
                "Operación exitosa",
              ),
              text: formatterText(
                "alert.message.associations.general",
                "Las asociaciones se crearon correctamente",
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.parameters),
            });
          })
          .catch((err) => {
            console.log(err);
            HandleOnError("Ocurrio un error al asociar");
          });
      });
    } else {
      navigate(paths.parameters);
    }
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="grid-container-1c zero-gap">
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.business.unit.name"
              defaultMessage="Nombre unidad de negocio"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleText}
              placeholder={formatterText(
                "input.placeholder.unit.name",
                "Nombre unidad",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Desripción"
            />
          </span>
          <section className="w100-container">
            <textarea
              className="input-textarea"
              type="text"
              name="descripcion"
              value={formData.descripcion}
              onChange={handlerTextDescription}
              placeholder={formatterText(
                "table.title.description",
                "Descripción",
              )}
              maxLength="200"
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="codigo"
              value={formData.codigo}
              onChange={handleCode}
              placeholder={formatterText(
                "input.placeholder.enter.up.characters",
                "Ingresa hasta 45 caracteres",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="p.country.market"
              defaultMessage="Mercado país"
            />
          </span>
          <section className="w100-container">
            <SelectorMulti
              data={selectedSearchCountries}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
              // isRequired={true}
            />
          </section>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.create.unit"
            defaultMessage="Crear unidad"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage
            id="alert.button.cancel.general"
            defaultMessage="Cancelar"
          />
        </button>
      </section>
    </form>
  );
}
