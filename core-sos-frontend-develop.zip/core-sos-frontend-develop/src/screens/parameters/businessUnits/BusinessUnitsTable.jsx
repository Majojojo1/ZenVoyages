// EXAMPLE USE AXIOS
import React, { useEffect, useState } from 'react';
// import Hooks
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';
// paths to routes
import paths from 'services/paths';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
// hook para cargar los datos
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import useGetData from 'hooks/useGetData';
import endpoints from 'services/api';
import { deleteBusinessUnit, updateBusinessUnit } from 'services/api/businessUnit';
import { getAll } from 'services/api/methods';

const BusinessUnitsTable = ({ permisos }) => {
  // hook to loading data
  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();

  const { setDataTable } = useSeachContext();

  const [parameters, setParameters] = useState(null);

  // use Hook of language v2
  const { formatterText } = useLangv2();

  useEffect(() => {
    // show loading
    toggleLoading(true);
    getDataTable();
    // show loading
    toggleLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // función para cargar datos
  const getDataTable = () => {


    getAll(endpoints.businessUnit.getAllBusinessUnits).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item));
      setParameters(newArray);
      setDataTable(newArray);

    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteBusinessUnit(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setParameters(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateBusinessUnit(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idUnidadNegocio || '' || '',
      nombre: item.nombre || '',
      descripcion: item.descripcion || '',
      codigo: item.codigo || '',
      // mercados: item.idMercado.nombre || "",
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const titles = [
    formatterText('table.title.business.unit.name', 'Nombre unidad de negocio'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    // "Mercados",
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  return (
    <>
      {!loading && parameters !== null ? (

        <FormattedMessage
          id="table.name.search.businessUnits"
          defaultMessage="Unidades de negocio"
        >            
        {(placeholder) => (
          <DynamicTable
            titles={titles}
            pageName={PAGE_NAMES.UnidadNegocio}
            data={getDataTable}
            handleDeleteItem={handleDeleteItem}
            handleEditStateItem={handleEditStateItem}
            routeToEdit={paths.updateBusinessUnit}
            canDeleted={permisos.eliminar}
            canModify={permisos.editar}
          />
        )}
        </FormattedMessage>

      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default BusinessUnitsTable;
