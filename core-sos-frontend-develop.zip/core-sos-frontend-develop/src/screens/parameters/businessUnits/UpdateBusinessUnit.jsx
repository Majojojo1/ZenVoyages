import React, { useEffect, useState } from "react";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Components
import SelectorMulti from "common/SelectorMulti";
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX, TEXTREGEXMIN, SPACING } from "common/validators/Regex";
import { validateDuplicateCodeAsync } from "common/validators/ValidateDuplicates";
import CustomAlert from "components/CustomAlert";
import { getAll } from "services/api/methods";
// Import Libs
import dateFormat from "dateformat";
import Cookie from "js-cookie";
import { FormattedMessage } from "react-intl";
import endpoints from "services/api";
import Swal from "sweetalert2";
// Import Models
import BusinessUnit from "models/BusinessUnit";
// Import Services
import {
  addMarketCountryToUnit,
  deleteMarketCountryFromUnit,
  getAllMarketCountry,
  getMarketCountryByUnit,
  updateBusinessUnit,
  updateMarketCountryToUnit,
} from "services/api/businessUnit";
import paths from "services/paths";

export default function UpdateBusinessUnit() {
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new BusinessUnit());
  const [selectedSearchCountries, setSearchSelectedCountries] = useState([]);
  // Setea los valores del multiselect de los paises
  const [selectValues, setSelectValues] = useState([]);
  // espera a que cargue los valores del multiselect
  const { loading, toggleLoading } = useGetData();
  // toggle state
  const [active, setActive] = useState(true);
  // use Hook of language v2
  const { formatterText, resourceNotFound } = useLangv2();
  const { id } = useParams();
  const [currentCode, setCurrentCode] = useState('');

  // Select current market associate
  const [selectedMarketUnitAssociate, setSelectedMarketUnitAssociate] =
    useState([]);

  useEffect(() => {
    getDataMarkets();   
    getDataToUpdate(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    getDataMarkets();
    getDataBusinessUnit();   
    getDataToUpdate(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const getDataMarkets = () => {
    toggleLoading(true);
    getAllMarketCountry()
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          if (item.mercado.estado === 1) {
            newArray.push({
              value: item.idMercadoPais,
              label: `${item.mercado.nombre} - ${item.pais.nombrePais}`,
              isFixed: true,
            });
          }
        });
        setSearchSelectedCountries(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  const getDataBusinessUnit = () => {
    const businessUnit = JSON.parse(localStorage.getItem("dataUpdate"));

    if (businessUnit) {
      setCurrentCode(businessUnit.codigo);
      setFormData({
        idUnidadNegocio: businessUnit.idUnidadNegocio,
        nombre: businessUnit?.nombre.replaceAll(/\s{2,}/gi, ' '),
        descripcion: businessUnit.descripcion,
        codigo: businessUnit.codigo,
        estado: businessUnit.estado,
        fechaRegistro: businessUnit.fechaRegistro,
        fechaModificacion: businessUnit.fechaModificacion,
        usuarioCreacion: businessUnit.usuarioCreacion,
        usuarioModificacion: businessUnit.usuarioModificacion,
      });
      setActive(Boolean(businessUnit.estado));
      getSelectCurrentValues(businessUnit.idUnidadNegocio);
    } else {
      navigate(paths.parameters);
    }
  };

  const getDataToUpdate = (id) => {
    getMarketCountryByUnit(id)
      .then((res) => {
        if(res.length === null || res === null || res === undefined){
          resourceNotFound();
          navigate(paths.parameters);
        }
        let countries = [];
        res.forEach((item) => {
          setFormData({
            idUnidadNegocio: item.idUnidadNegocio.idUnidadNegocio,
            nombre: item.idUnidadNegocio.nombre,
            descripcion: item.idUnidadNegocio.descripcion,
            codigo: item.idUnidadNegocio.codigo,
            estado: item.idUnidadNegocio.estado,
            fechaRegistro: item.idUnidadNegocio.fechaRegistro,
            fechaModificacion: item.idUnidadNegocio.fechaModificacion,
            usuarioCreacion: item.idUnidadNegocio.usuarioCreacion,
            usuarioModificacion: item.idUnidadNegocio.usuarioModificacion,
          });
          countries.push({
            value: item.idMercadoPais.idMercadoPais,
            label: `${item.idMercadoPais.mercado.nombre} - ${item.idMercadoPais.pais.nombrePais}`,
            associateId: item.idMercadoPaisUnidadNegocio,
            isFixed: true,
          });
        });
        setSelectValues(countries);
        setSelectedMarketUnitAssociate(countries);
      }).catch((err)=>{
        console.log(err);
      });
  };
 

  const getSelectCurrentValues = (id) => {
    getMarketCountryByUnit(id)
      .then((res) => {
        let newArray = [];
        res.forEach((item) => {
          newArray.push({
            value: item.idMercadoPais.idMercadoPais,
            label: `${item.idMercadoPais.mercado.nombre} - ${item.idMercadoPais.pais.nombrePais}`,
            associateId: item.idMercadoPaisUnidadNegocio,
            isFixed: true,
          });
        });
        setSelectValues(newArray);
        setSelectedMarketUnitAssociate(newArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, SPACING, formData, setFormData);
  };


  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    if (e.target.value.match(CODEREGEX)) {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handlerTextCode = (e) => {
    HandleInput(e, TEXTREGEXMIN, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      nombre: formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };
    const isDuplicateCode = await validateDuplicateCodeAsync(
      formData.codigo.replaceAll(/\s{2,}/gi, ' ').toLowerCase(),
      formatterText('alert.message.code.error.general'),
      getAll(endpoints.businessUnit.getAllBusinessUnits),
      true,
      currentCode
    );

    if(!isDuplicateCode)
      putBusinessUnit(data);
  };

  const putBusinessUnit = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateBusinessUnit(data)
            .then((res) => {
              resolve(
                CustomAlert("confirm_msg", {
                  icon: "success",
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    checkAssociateCountryMarketUnit(res.idUnidadNegocio);
                  },
                }),
              );
            })
            .catch((err) => {              
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else if (err.response.status === 412) {
                  HandleOnError(formatterText(
                    'alert.message.code.error.general',
                    'El código ya existe, por favor ingrese uno distinto',
                  ),
                  );
                } else {
                  HandleOnError(formatterText(
                    'snackbar.error.process.failed.general',
                    'Error al realizar el proceso. Intentalo en otro momento.',
                  ),
                  );
                }
            });
        });
      },
    });
  };

  const checkAssociateCountryMarketUnit = (idBU) => {
    let newArray = [];
    selectedMarketUnitAssociate.forEach((item) => {
      newArray.push(item.associateId);
    });
    let newArray2 = [];
    selectValues.forEach((item) => {
      newArray2.push(item.associateId);
    });
    let newArray3 = newArray.filter((item) => !newArray2.includes(item));

    let newArray4 = [];
    selectValues.forEach((item) => {
      if (!selectedMarketUnitAssociate.includes(item)) {
        newArray4.push(item);
      }
    });

    let lengthAssociate = selectedMarketUnitAssociate.length;
    let lengthCurrentSelect = selectValues.length;

    // if para determinar si se eliminaron los valores seleccionados
    if (lengthAssociate > lengthCurrentSelect) {
      newArray3.forEach((item) => {
        console.log("elimnino:", item);
        deleteAssociateCountryMarketUnit(item);
      });
      // if para determinar si se agregaron valores seleccionados
      if (newArray4.length > 0) {
        newArray4.forEach((item) => {
          console.log("agregando:", item);
          associateCountryMarketBusinessUnit(item.value, idBU);
        });
      }
      // if para determinar si se actualizaron los valores seleccionados
    } else if (lengthAssociate === lengthCurrentSelect) {
      if (newArray3.length === 0) {
        navigate(paths.parameters);
      } else {
        newArray3.forEach((item, i) => {
          console.log("editando:", item);
          updateAssociateCountryMarketUnit(item, idBU, newArray4[i].value);
        });
      }

      // if para determinar si se agregaron valores seleccionados
    } else if (lengthAssociate < lengthCurrentSelect) {
      newArray4.forEach((item) => {
        console.log("agregando:", item);
        associateCountryMarketBusinessUnit(item.value, idBU);
      });
      console.log("ir a la tabla principal");
    } else {
      console.log("ir a la tabla");
    }
  };

  const updateAssociateCountryMarketUnit = (idAssociate, idBU, idMP) => {
    console.log("actualizando:", idAssociate);
    console.log("actualizando:", idBU);

    let data = {
      idMercadoPaisUnidadNegocio: parseInt(idAssociate),
      idMercadoPais: {
        idMercadoPais: parseInt(idMP),
      },
      idUnidadNegocio: {
        idUnidadNegocio: parseInt(idBU),
      },
      estado: 1,
      fechaCreacion: dateFormat(new Date(), "isoDateTime"),
      fechaModificacion: dateFormat(new Date(), "isoDateTime"),
      usuarioCreacion: parseInt(Cookie.get("idUsuario")),
      usuarioModificacion: parseInt(Cookie.get("idUsuario")),
    };

    updateMarketCountryToUnit(data)
      .then((res) => {
        console.log(res);
        CustomAlert("confirm_msg", {
          icon: "success",
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText('alert.title.confirm.updates', 'Se actualizaron los registros'),
          confirmButtonText:  formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.parameters),
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const deleteAssociateCountryMarketUnit = (idBU) => {
    deleteMarketCountryFromUnit(idBU)
      .then((res) => {
        console.log(res);
        CustomAlert("confirm_msg", {
          icon: "success",
          title: formatterText(
            "alert.title.confirm.general",
            "Operación exitosa",
          ),
          text: formatterText('alert.title.confirm.deleted', 'Se eliminaron los registros'),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.parameters),
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const associateCountryMarketBusinessUnit = (idAssociate, idBU) => {
    let data = {
      idMercadoPaisUnidadNegocio: null,
      idMercadoPais: {
        idMercadoPais: idAssociate,
      },
      idUnidadNegocio: {
        idUnidadNegocio: idBU,
      },
    };
    addMarketCountryToUnit(data)
      .then((res) => {
        console.log(res);
        CustomAlert("confirm_msg", {
          icon: "success",
          title: formatterText(
            "alert.title.confirm.general",
            "Operación exitosa",
          ),
          text: formatterText(
            "alert.title.confirm.add",
            "Se agregaron nuevos registros",
          ),
          confirmButtonText:  formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.parameters),
        });
      })
      .catch((err) => {
        console.log(err);
        HandleOnError("Ocurrio un error al asociar");
      });
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="grid-container-1c zero-gap">
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.business.unit.name"
              defaultMessage="Nombre unidad de negocio"
            />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleText}
              placeholder={formatterText(
                "input.placeholder.unit.name",
                "Nombre unidad",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Desripción"
            />
          </span>
          <section className="w100-container">
            <textarea
              className="input-textarea"
              type="text"
              name="descripcion"
              value={formData.descripcion}
              onChange={handlerTextDescription}
              placeholder={formatterText(
                "table.title.description",
                "Descripción",
              )}
              maxLength="200"
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </span>
          <section className="w100-container">
            <input
              className="input-default-3c"
              type="text"
              name="codigo"
              value={formData.codigo}
              onChange={handlerTextCode}
              placeholder={formatterText(
                "input.placeholder.enter.up.characters",
                "Ingresa hasta 45 caracteres",
              )}
              maxLength="45"
              required
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage
              id="p.country.market"
              defaultMessage="Mercado país"
            />
          </span>
          <section className="w100-container">
            <SelectorMulti
              data={selectedSearchCountries}
              isLoading={loading}
              dataValue={selectValues}
              setterFunction={handleChangeMulti}
            // isRequired={true}
            />
          </section>
        </section>
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </span>
          <section className="w100-container">
            <label className="container-toggle-label">
              <p className="form-responsive-toggle">
                {active
                  ? formatterText("p.active", "Activo")
                  : formatterText("p.unActive", "No activo")}
              </p>
              <label className="switch">
                <input
                  checked={active}
                  onChange={_ => setActive(!active)}
                  type="checkbox"
                />
                <span className="slider round"></span>
              </label>
            </label>
          </section>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.parameters)}
        >
          <FormattedMessage
            id="alert.button.cancel.general"
            defaultMessage="Cancelar"
          />
        </button>
      </section>
    </form>
  );
}
