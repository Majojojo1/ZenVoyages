import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import React, { useEffect, useState } from 'react';
//Import hooks
import useLangv2 from 'hooks/useLangv2';
import { useNavigate } from 'react-router-dom';
import { getMailById, getsMails, updateMail } from 'services/api/mail';
//Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { FormattedMessage } from 'react-intl';
import paths from 'services/paths';
import 'styles/editProfile.css';
import SendMail from './SendMail';

const style = {
  position: 'absolute',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

const CreateMail = () => (
  <PermissionWrapper>
    <CreateMailComponent />
  </PermissionWrapper>
);

/* este es update mail no crear */
function CreateMailComponent() {
  const navigate = useNavigate();
  const [activeSS, setActiveSS] = useState(true);
  const [activeSA, setActiveSA] = useState(true);

  // use Hook of language v2
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  /* solo se hará un put */
  const [formData, setFormData] = useState({
    idCorreoUsuario: 1,
    host: 'cargando...',
    smtpAuth: activeSA.toString(),
    usuario: 'cargando...',
    clave: 'cargando...',
    smtpSecure: activeSS.toString(),
    puerto: 'cargando...',
    avatarUrl: 'cargando...',
    area: 'Gestión de usuarios y configuración',
  });

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.mailManagement); //permiso categorias servicio
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  const handleChangeSelect = (e) => {
    const AREA_IDS = {
      'Gestión de usuarios y configuración': 1,
      'Gestión de Compras': 2,
      'Gestión de Servicios': 3,
      'Notificaciones y Alertas': 4,
    };

    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
    });

    getEmailData(AREA_IDS[e.target.value.replaceAll(/\s{2,}/gi, ' ')]);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const AREA_IDS = {
      'Gestión de usuarios y configuración': 1,
      'Gestión de Compras': 2,
      'Gestión de Servicios': 3,
      'Notificaciones y Alertas': 4,
    };

    setFormData({
      ...formData,
      idCorreoUsuario: AREA_IDS[formData.area],
    });

    getEmail();
  };

  const getEmail = async () => {
    getsMails()
      .then((response) => {
        let areaAux = [];
        response.map((user) => {
          areaAux.push(user.area);
        });

        areaAux.includes(formData.area)
          ? putEmail()
          : HandleOnError('El nombre no existe, solo se pueden crear con las 4 áreas asignadas');
      })
      .catch((error) => {
        console.log(error);
      });
  };

  /* Crea un nuevo correo */
  const putEmail = () => {
    updateMail(formData)
      .then((response) => {
        console.log(response);
        onSucess('Se actualizó el correo.');
      })
      .catch((error) => {
        console.log(error);
        HandleOnError(formatterText('catch.error.text'));
      });
  };

  const onError = (error) => {
    CustomAlert('short_msg', {
      icon: 'error',
      title: 'Ops... ha ocurrido un error',
      text: error,
    });
  };

  const onSucess = (sucess) => {
    CustomAlert('short_msg', {
      icon: 'success',
      title: 'Acción realizada correctamente',
      text: sucess,
    });
  };

  useEffect(() => {
    getEmailData(1);
  }, []);

  const getEmailData = async (id) => {
    setFormData({
      host: 'cargando...',
      smtpAuth: 'cargando...',
      usuario: 'cargando...',
      puerto: 'cargando...',
    });

    getMailById(id)
      .then((res) => {
        setFormData({
          idCorreoUsuario: res.idCorreoUsuario,
          host: res.host,
          smtpAuth: res.smtpAuth,
          usuario: res.usuario,
          clave: res.clave,
          smtpSecure: res.smtpSecure,
          puerto: res.puerto,
          avatarUrl: res.avatarUrl,
          area: res.area,
        });

        setActiveSS(res.smtpSecure === 'true' ? true : false);
        setActiveSA(res.smtpAuth === 'true' ? true : false);
      })
      .catch((err) => {
        setFormData({
          host: '',
          smtpAuth: '',
          usuario: '',
          puerto: '',
          clave: '',
        });
      });
  };

  return (
    permittedActions.consultar && (
      <>
        <form className="edit-profile" onSubmit={handleSubmit}>
          <section className="edit-profile-container-information">
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.area" defaultMessage="Área" />
              </h3>
              <select className="input-label-style" name="area" onChange={handleChangeSelect}>
                <option value="Gestión de usuarios y configuración">
                  <FormattedMessage
                    id="select.placeholder.configuration.users.management"
                    defaultMessage="Gestión de usuarios y configuración"
                  />
                </option>
                <option value="Gestión de Compras">
                  <FormattedMessage
                    id="select.placeholder.purchases.management"
                    defaultMessage="Gestión de Compras"
                  />
                </option>
                <option value="Gestión de Servicios">
                  <FormattedMessage
                    id="select.placeholder.services.management"
                    defaultMessage="Gestión de Servicios"
                  />
                </option>
                <option value="Notificaciones y Alertas">
                  <FormattedMessage
                    id="select.placeholder.alerts.notifications"
                    defaultMessage="Notificaciones y Alertas"
                  />
                </option>
              </select>
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">Host</h3>
              <input
                className="input-primary"
                type="text"
                name="host"
                value={formData.host}
                onChange={handleChange}
                placeholder={formatterText('input.placeholder.host', 'Host del servicio')}
                maxLength={50}
                required
              />
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.associate.email" defaultMessage="Correo asociado" />
              </h3>
              <input
                className="input-primary"
                type="email"
                name="usuario"
                value={formData.usuario}
                onChange={handleChange}
                placeholder={formatterText('input.placeholder.mail.associated', 'Correo asociado')}
                autoComplete="off"
                maxLength={40}
                required
              />
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.key" defaultMessage="Clave" />
              </h3>
              <input
                className="input-primary"
                type="password"
                name="clave"
                value={formData.clave}
                onChange={handleChange}
                autoComplete="off"
                placeholder={formatterText('input.placeholder.key', 'Clave')}
                maxLength={40}
                required
              />
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.port" defaultMessage="Puerto" />
              </h3>
              <input
                className="input-primary"
                type="text"
                name="puerto"
                value={formData.puerto}
                onChange={handleChange}
                placeholder={formatterText('input.port.service', 'Puerto del servicio')}
                maxLength={6}
                required
              />
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.smtp.secure" defaultMessage="Seguridad SMTP" />
              </h3>
              <label
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  color: '#747474',
                }}
              >
                <p
                  style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    margin: '0px',
                    padding: '0px',
                    textDecoration: 'none',
                    color: 'var(--dark-gray)',
                  }}
                >
                  {activeSS
                    ? formatterText('p.active', 'Activo')
                    : formatterText('p.unActive', 'No activo')}
                </p>
                <label className="switch">
                  <input
                    checked={activeSS ? true : false}
                    onChange={() => {
                      setActiveSS(!activeSS);
                      setFormData({
                        ...formData,
                        smtpSecure: !activeSS,
                      });
                    }}
                    type="checkbox"
                    name="smtpSecure"
                  />
                  <span className="slider round"></span>
                </label>
              </label>
            </section>
            <section className="edit-profile-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.smtp.auth" defaultMessage="Autenticación SMTP" />
              </h3>
              <label
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  color: '#747474',
                }}
              >
                <p
                  style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    margin: '0px',
                    padding: '0px',
                    textDecoration: 'none',
                    color: 'var(--dark-gray)',
                  }}
                >
                  {activeSA
                    ? formatterText('p.active', 'Activo')
                    : formatterText('p.unActive', 'No activo')}
                </p>
                <label className="switch">
                  <input
                    checked={activeSA ? true : false}
                    onChange={() => {
                      setActiveSA(!activeSA);
                      setFormData({
                        ...formData,
                        smtpAuth: !activeSA,
                      });
                    }}
                    name="smtpAuth"
                    type="checkbox"
                  />
                  <span className="slider round"></span>
                </label>
              </label>
            </section>
          </section>
          <section className="edit-profile-container-buttons">
            {(permittedActions.editar || permittedActions.crear) && (
              <button type="submit" className="btn-primary">
                <FormattedMessage id="btn.save.changes" defaultMessage="Guardar cambios" />
              </button>
            )}

            <button className="input-cancel" onClick={() => navigate(paths.home)}>
              <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
            </button>
          </section>
        </form>

        {permittedActions.consultar && (
          <section className="edit-profile-container-buttons">
            <button className="btn-primary" onClick={handleOpen}>
              <FormattedMessage id="btn.test.emails" defaultMessage="Probar correos" />
            </button>
          </section>
        )}

        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="parent-modal-title"
          aria-describedby="parent-modal-description"
        >
          <Box sx={{ ...style, width: '90%' }}>
            <SendMail onClose={handleClose} />
          </Box>
        </Modal>
      </>
    )
  );
}

export default CreateMail;
