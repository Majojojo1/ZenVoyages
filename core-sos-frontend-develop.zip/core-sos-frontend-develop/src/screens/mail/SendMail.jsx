//Import hooks
import useGetData from "hooks/useGetData";
import React, { useState } from "react";
//Import services
import { formatterText } from "hooks/useLangv2";
import { FormattedMessage } from "react-intl";
import { sendMail } from "services/api/mail";
import "styles/editProfile.css";

export default function SendMail({ onClose }) {
  const [formData, setFormData] = useState({
    area: 1,
    destinatario: "",
  });
  const [textBtn, setTextBtn] = useState(`${formatterText('btn.send.test.email')}`);
  const {
    loading,
    error,
    success,
    toggleLoading,
    toggleError,
    toggleSuccess,
    handleClick,
    displayMessage,
  } = useGetData();

  // use Hook of language v2

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    verifyModule();
  };

  const verifyModule = async () => {
    sendEmailTest();
  };

  const sendEmailTest = async () => {
    setTextBtn("Enviando...");
    toggleLoading(true);

    let FIX_formData = {
      area: parseInt(formData.area),
      destinatario: formData.destinatario,
    };

    sendMail(FIX_formData)
      .then((response) => {
        console.log(response);
        setTextBtn("Enviar correo de prueba");
        toggleLoading(false);
        toggleSuccess(true);
        handleClick();
      })
      .catch((error) => {
        console.log(error);
        setTextBtn("Enviar correo de prueba");
        toggleLoading(false);
        toggleError(true);
        handleClick();
      });
  };

  return (
    <>
      <form className="edit-profile" onSubmit={handleSubmit}>
        <section className="edit-profile-container-information">
          <section className="edit-profile-information__option">
            <h3>
              <FormattedMessage id="p.area" defaultMessage="Área" />
            </h3>
            <select
              className="input-label-style"
              name="area"
              onChange={handleChange}
            >
              <option value="1">
                <FormattedMessage
                  id="select.placeholder.configuration.users.management"
                  defaultMessage="Gestión de usuarios y configuración"
                />
              </option>
              <option value="2">
                <FormattedMessage
                  id="select.placeholder.purchases.management"
                  defaultMessage="Gestión de Compras"
                />
              </option>
              <option value="3">
                <FormattedMessage
                  id="select.placeholder.services.management"
                  defaultMessage="Gestión de Servicios"
                />
              </option>
              <option value="4">
                <FormattedMessage
                  id="select.placeholder.alerts.notifications"
                  defaultMessage="Notificaciones y Alertas"
                />
              </option>
            </select>
          </section>

          <section className="edit-profile-information__option">
            <h3>
              <FormattedMessage id="p.subject" defaultMessage="Asunto" />
            </h3>
            <input
              className="input-primary disabled"
              type="text"
              name="asunto"
              value={formData.asunto}
              onChange={handleChange}
              placeholder={formatterText(
                "input.placeholder.email.subject",
                "Asunto del correo",
              )}
              maxLength={50}
              disabled
            />
          </section>
          <section className="edit-profile-information__option">
            <h3>
              <FormattedMessage
                id="p.recipient"
                defaultMessage="Destinatario"
              />
            </h3>
            <input
              className="input-primary"
              type="email"
              name="destinatario"
              value={formData.destinatario}
              onChange={handleChange}
              placeholder={formatterText("p.email", "Correo electrónico")}
              required
            />
          </section>
          <section className="edit-profile-information__option">
            <h3>
              <FormattedMessage id="p.content" defaultMessage="Contenido" />
            </h3>
            <input
              className="input-primary disabled"
              type="text"
              name="contenido"
              value={formData.contenido}
              onChange={handleChange}
              placeholder={formatterText(
                "input.placeholder.email.content",
                "Contenido del correo",
              )}
              maxLength={50}
              disabled
            />
          </section>
        </section>
        <section className="edit-profile-container-buttons">
          <button type="submit" className="btn-primary" disabled>
            <FormattedMessage
              id="btn.send.email"
              defaultMessage="Enviar correo"
            />
          </button>
          <button type="submit" className="btn-primary" disabled={loading}>
            {textBtn}
          </button>
          <button className="input-cancel" onClick={onClose}>
            <FormattedMessage id="btn.discard" defaultMessage="Descartar" />
          </button>
        </section>
      </form>
      {success &&
        displayMessage("success", "Correo enviado.", "toast.email.success")}
      {error &&
        displayMessage(
          "error",
          "Ha ocurrido un error, intentalo más tarde.",
          "toast.error.general",
        )}
    </>
  );
}
