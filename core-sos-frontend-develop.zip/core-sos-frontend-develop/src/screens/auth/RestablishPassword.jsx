import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import paths from "services/paths";
import { restablishPasswordWithSecret } from "services/api/auth";
import CustomAlert from "components/CustomAlert";
import SimpleHeader from "common/SimpleHeader";
import { IoMdEye, IoMdEyeOff } from "react-icons/io";
import "styles/loginRecover.css";
import { FormattedMessage } from "react-intl";

export default function RestablishPassword() {
  const navigate = useNavigate();
  const { secret } = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirm, setNewPasswordConfirm] = useState("");
  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };

  const restablishPassword = (e) => {
    e.preventDefault();
    setErrorMessage(false);

    if (newPassword === newPasswordConfirm) {
      //  create an expression to validate if the password have at least 1 number, at least 1 letter uppercase and at special character
      const regex =
        /^(?=.*\d)(?=.*[A-Z])(?=.*[!\"#$%&\/\(\)=?¡¿+\{\}\[\]\-_:\.;,\|*\^~])(?=.*[a-zA-Z]).{8,}$/;

      if (regex.test(newPassword)) {
        console.log("password correct");

        let jsonData = {
          secrect: secret,
          password: newPassword,
        };
        setIsLoading(true);

        restablishPasswordWithSecret(jsonData)
          .then((res) => {
            setIsLoading(false);
            if (res) {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: "Contraseña cambiada",
                text: "Su contraseña ha sido cambiada con éxito, vuelva a iniciar sesión.",
                confirmButtonText: "Iniciar sesión",
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.login),
              });
            }
          })
          .catch((err) => {
            setIsLoading(false);
            CustomAlert("short_msg", {
              icon: "error",
              title: `Error`,
              text: "Verifique el enlace de restablecer de contraseña.",
            });
          });
        setErrorMessage(false);
      } else {
        setErrorMessage(true);
      }
    } else {
      CustomAlert("short_msg", {
        icon: "error",
        title: `Error`,
        text: "Las contraseñas no coinciden",
      });
      setIsLoading(false);
    }
  };

  return (
    <>
      <SimpleHeader />
      <section className="recover-password">
        <form
          className="recover-password-container"
          onSubmit={restablishPassword}
          autoComplete="off"
        >
          <h4 className="recover-password-title"><FormattedMessage id="menu.recover" defaultMessage="Recupera tu contraseña" /></h4>

          <div className="pass-wrapper">
            <input
              className="input-other-pswd"
              type={passwordShown ? "text" : "password"}
              placeholder="Contraseña nueva"
              name="newPassword"
              onChange={(e) => setNewPassword(e.target.value)}
              maxLength="25"
              required
            />
            {passwordShown ? (
              <IoMdEye
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            ) : (
              <IoMdEyeOff
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            )}
          </div>

          <div className="pass-wrapper">
            <input
              className="input-other-pswd"
              type={passwordShown ? "text" : "password"}
              placeholder="Confirmar contraseña nueva"
              name="newPasswordConfirm"
              onChange={(e) => setNewPasswordConfirm(e.target.value)}
              maxLength="25"
              required
            />
            {passwordShown ? (
              <IoMdEye
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            ) : (
              <IoMdEyeOff
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            )}
          </div>
          <button
            type="submit"
            className="btn-primary spacing"
            disabled={isLoading}
          >
            {isLoading ? "Cargando..." : "Cambiar contraseña"}
          </button>
          {errorMessage && (
            <ul className="error-message">
              <li>La contraseña debe tener:</li>
              <li>*Mínimo 8 caracteres.</li>
              <li>*Mínimo un número.</li>
              <li>*Mínimo una mayúscula.</li>
              <li>*Mínimo un carácter especial.</li>
            </ul>
          )}
          <p className="back" onClick={() => navigate(paths.login)}>
            <FormattedMessage id="menu.goback" defaultMessage="Regresar al inicio de sesion" />
          </p>
        </form>
      </section>
    </>
  );
}
