import React, { useState } from "react";
// Impport Hooks
import { useNavigate, useParams } from "react-router-dom";
// Impport Components
import SimpleHeader from "common/SimpleHeader";
import CustomAlert from "components/CustomAlert";
// Impport Libs
import { IoMdEye, IoMdEyeOff } from "react-icons/io";
import { validateEmail } from "services/api/auth";
// Impport Services
import paths from "services/paths";
// Impport Styles
import { formatterText } from "hooks/useLangv2";
import { FormattedMessage } from "react-intl";
import "styles/loginRecover.css";

export default function ChangeFirstPassword() {
  const navigate = useNavigate();
  const { secret } = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirm, setNewPasswordConfirm] = useState("");

  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };

  const restablishPassword = (e) => {
    e.preventDefault();
    setErrorMessage(false);

    if (newPassword === newPasswordConfirm) {
      //  create an expression to validate if the password have at least 1 number, at least 1 letter uppercase
      // at special character like !"#$%&/()=?¡¿+{-_-:.;,|*
      const regex =
        /^(?=.*\d)(?=.*[A-Z])(?=.*[!\"#$%&\/\(\)=?¡¿+\{\}\[\]\-_:\.;,\|*\^~])(?=.*[a-zA-Z]).{8,}$/;

      if (regex.test(newPassword)) {
        console.log("password correct");

        let jsonData = {
          secrect: secret,
          password: newPassword,
        };
        setIsLoading(true);

        validateEmail(jsonData)
          .then((res) => {
            setIsLoading(false);
            if (res) {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: formatterText('title.user.passwordChanged.success'),
                text: formatterText('title.user.passwordChanged'),
                confirmButtonText: formatterText('title.user.passwordstMatch.log.in'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.login),
              });
            }
          })
          .catch((err) => {
            setIsLoading(false);
            CustomAlert("short_msg", {
              icon: "error",
              title: `Error`,
              text: formatterText('title.user.verifyPasswordChangeLink'),
            });
          });
        setErrorMessage(false);
      } else {
        setErrorMessage(true);
      }
    } else {
      CustomAlert("short_msg", {
        icon: "error",
        title: `Error`,
        text: formatterText('title.user.passwordsDoNotMatch'),
      });
      setIsLoading(false);
    }
  };

  return (
    <>
      <SimpleHeader />
      <section className="recover-password">
        <form
          className="recover-password-container"
          onSubmit={restablishPassword}
          autoComplete="off"
        >
          <h4 className="recover-password-title"><FormattedMessage id="ChangeFirstPassword.text1" defaultMessage="Cambia tu contraseña"/></h4>

          <div className="pass-wrapper">
            <input
              className="input-passwords"
              type={passwordShown ? "text" : "password"}
              placeholder={formatterText('title.user.newPassword')}
              name="newPassword"
              id="Password"
              onChange={(e) => setNewPassword(e.target.value)}
              maxLength="45"
              required
            />
            {passwordShown ? (
              <IoMdEye
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            ) : (
              <IoMdEyeOff
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            )}
          </div>

          <div className="pass-wrapper">
            <input
              className="input-passwords"
              type={passwordShown ? "text" : "password"}
              placeholder={formatterText('title.user.confirmNewPassword')}
              name="newPasswordConfirm"
              onChange={(e) => setNewPasswordConfirm(e.target.value)}
              maxLength="45"
              required
            />
            {passwordShown ? (
              <IoMdEye
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            ) : (
              <IoMdEyeOff
                size={30}
                className="eye-icon"
                onClick={togglePasswordVisiblity}
              />
            )}
          </div>

          <button
            type="submit"
            className="btn-primary spacing"
            disabled={isLoading}
          >
            {isLoading ? `${formatterText('title.user.loading')}` : `${formatterText('title.user.changePassword')}`}
          </button>
          {errorMessage && (
            <ul className="error-message">
            <li>{formatterText('title.user.passwordRequirements')}</li>
            <li>{formatterText('title.user.passwordRequirement1')}</li>
            <li>{formatterText('title.user.passwordRequirement2')}</li>
            <li>{formatterText('title.user.passwordRequirement3')}</li>
            <li>{formatterText('title.user.passwordRequirement4')}</li>
            </ul>
          )}
        </form>
      </section>
    </>
  );
}
