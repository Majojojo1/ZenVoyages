import React, { useContext, useState } from "react";
// Import Context
// Import Hooks
import { useAuth } from "hooks/useAuth";
import { useNavigate } from "react-router-dom";
// Import Components
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import CustomAlert from "components/CustomAlert";
import Footer from "components/layout/Footer";
// Import Libs
import Cookie from "js-cookie";
import { IoMdEye, IoMdEyeOff } from "react-icons/io";
import { FormattedMessage } from "react-intl";
// Import Services
import endpoints from "services/api";
import { confirmEmail, confirmSession } from "services/api/auth";
import { getAll } from "services/api/methods";
import { getUserInfo } from "services/api/users";
import paths from "services/paths";
// Import Assets
import logo from "assets/logo.png";
import { langContext } from 'context/langContext';
import "styles/login.css";

const style = {
  position: "absolute",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

function Login() {  
  const auth = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [textBtn, setTextBtn] = useState("Iniciar sesión");
  const [loginAttempts, setLoginAttempts] = useState(1);
  const idioma = useContext(langContext);

  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => setPasswordShown(!passwordShown);

  const [formData, setFormData] = useState({
    Username: "",
    Password: "",
    Step: "step1",
    TokenCelular: null,
    TipoAcceso: null,
    Code: "",
  });

  const [formData2, setFormData2] = useState({
    Username: "Joshe",
    Password: "qp2lmy2I",
    TokenCelular: null,
    Step: "step2",
    Code: "",
  });

  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const fetchAndStoreData = () => { 
      
      getAll(endpoints.services.getAllHours)
        .then((res) => {          
          localStorage.setItem("hours", JSON.stringify(res));
        }).catch((err) => {
          console.error(err);
        })      
  }; 

  const handleSubmit = (e) => {
    e.preventDefault();
    setTextBtn("Enviando...");
    setIsLoading(true);

    verifyStepOne();
  };

  const verifyStepOne = () => {
    confirmEmail(formData)
      .then((res) => {
        if (res.message === 'Error_Step_0_UsuarioBloqueado') {
          CustomAlert("short_msg", {
            icon: "error",
            title: "Error en el login",
            text: "Usuario bloqueado",
          });
          setIsLoading(false);
          setTextBtn("Iniciar sesión");
          return
        }
        if (res.message === "Ok_Step_1") {
          handleOpen();
          setTextBtn("Iniciar sesión");
          setIsLoading(false);
        } else {
          CustomAlert("short_msg", {
            icon: "error",
            title: "Ops... ha ocurrido un error",
            text: "El nombre de usuario o la contraseña es incorrecta.",
          });
          setTextBtn("Iniciar sesión");
          setIsLoading(false);
          setLoginAttempts(loginAttempts + 1);
          if (loginAttempts >= 3) {
            handleAttempts();
          } else {
            CustomAlert("short_msg", {
              icon: "error",
              title: "Ops... ha ocurrido un error",
              text: "El nombre de usuario o la contraseña es incorrecta.",
            });
          }
        }
      })
      .catch(() => {
        setTextBtn("Iniciar sesión");
        setIsLoading(false);
        CustomAlert("short_msg", {
          icon: "error",
          title: "Ops... ha ocurrido un error",
          text: "Error al solicitar la información, vuelve a intentarlo.",
        });
      });
  };

  const verifyStepTwo = (e) => {
    e.preventDefault();
    handleClose();
    fetchAndStoreData();
    confirmSession(formData2)
      .then((res) => {
        if (res.message === "Ok_Step2_code") {
          const token = res?.token
          sessionStorage.setItem("token", token);
          // Get user id info
          getUserInfoById(res.userid, res, res.lenguage);
        } else {
          setLoginAttempts(loginAttempts + 1);
          CustomAlert("short_msg", {
            icon: "error",
            title: "Ops...",
            text: "Código de confirmación ya expiró.",
            confirmButtonColor: "#FFC954",
          });
        }
      })
      .catch(() => {
        CustomAlert("short_msg", {
          icon: "error",
          title: "Ops...",
          text: "Hubo un error en la válidación",
          confirmButtonColor: "#FFC954",
        });
      });
  };

  /* Esta función trae los datos del usuario para guardarlos en localstorage */
  const getUserInfoById = (idUser, responseData, lang) => {
    getUserInfo(idUser)
      .then((res) => {
        if (res.estado === 2) {
          CustomAlert("short_msg", {
            icon: "warning",
            title: "Atención",
            text: "El usuario debe cambiar la contraseña por primera vez",
            confirmButtonColor: "#FFC954",
          });
          setTextBtn("Iniciar sesión");
          setIsLoading(false);
        } else {

          Cookie.set("idUsuario", responseData.userid, {
            sameSite: 'None',
            secure: true,
          });
          auth.login();
          if(lang?.toLowerCase() == "es"){
            localStorage.setItem('lang', 'en-ES');
          }else if (lang?.toLowerCase() == "en"){
            localStorage.setItem('lang', 'en-US');
          }
          idioma.establecerLenguaje(localStorage.getItem('lang'));
          CustomAlert("confirm_msg", {
            icon: "success",
            title: "Inicio de sesión exitoso",
            text: "Haz click en el botón para continuar",
            confirmButtonText: "Aceptar",
            allowOutsideClick: false,
            executeFunction: () => {
              navigate(paths.panelNotifications);
              window.location.reload();         
          },
          });
          const USER_DATA = {
            ...res,
            clave: null,
          };
          localStorage.setItem("userData", JSON.stringify(USER_DATA));
          Cookie.set("rolSize", res.roles.length, {
            sameSite: 'None',
            secure: true,
          });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      TokenCelular: null,
      TipoAcceso: 1,
      [e.target.name]: e.target.value,
    });
    setFormData2({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleChange2 = (e) => {
    setFormData2({
      ...formData2,
      TokenCelular: null,
      [e.target.name]: e.target.value,
      Step: "step2",
    });
  };

  const handleAttempts = () => {
    CustomAlert("short_msg", {
      icon: "error",
      title: "Ops...",
      text: "Cuenta bloqueada temporalmente, por favor contacte con un administrador",
      confirmButtonColor: "#FFC954",
    });
    // Agregar servicio de bloqueo de usuario
  };

  return (
    <>
      <main className="o-container-login">
        <section className="o-enter-logo">
          <img src={logo} alt="Logo coral" />
        </section>
        <section className="o-enter-user">
          <section className="o-card-login">
            <form className="o-login-form" onSubmit={handleSubmit}>
              <h3>
                <FormattedMessage id="menu.home" defaultMessage="Bienvenido" />
              </h3>
              <p><FormattedMessage id="menu.text" defaultMessage="Ingresa tu nombre de usuario y contraseña para continuar" /></p>
              <input
                type="username"
                className="input-primary spacing"
                placeholder="Nombre de usuario"
                name="Username"
                id="Username"
                onChange={(e) => handleChange(e)}
                autoComplete="username"
                maxLength={25}
                required
              />
              <div className="pass-wrapper">
                <input
                  type={passwordShown ? "text" : "password"}
                  className="input-passwords"
                  placeholder="Contraseña"
                  name="Password"
                  id="Password"
                  onChange={(e) => handleChange(e)}
                  autoComplete="off"
                  maxLength={25}
                  required
                />
                {passwordShown ? (
                  <IoMdEye
                    size={30}
                    className="eye-icon"
                    onClick={togglePasswordVisiblity}
                  />
                ) : (
                  <IoMdEyeOff
                    size={30}
                    className="eye-icon"
                    onClick={togglePasswordVisiblity}
                  />
                )}
              </div>

              <p
                className="o-forget-password"
                onClick={() => navigate(paths.recover)}
              >
                <FormattedMessage id="menu.forgotpassword" defaultMessage="¿Olvidaste tu contraseña?" />
              </p>
              <button
                type="submit"
                className="btn-primary"
                disabled={isLoading}
              >
                {textBtn}
              </button>
            </form>
          </section>
        </section>
        <Modal
          open={open}
          aria-labelledby="parent-modal-title"
          aria-describedby="parent-modal-description"
        >
          <Box sx={{ ...style, width: "70vw" }}>
            <h2 id="parent-modal-title"><FormattedMessage id="menu.textcode" defaultMessage="Ingresa el código" /></h2>
            <p id="parent-modal-description">
              <FormattedMessage id="menu.textcode2" defaultMessage="Ingresa el código que te enviamos a tu correo para continuar." />
            </p>
            <input
              className="input-edit"
              type="type"
              placeholder="Código"
              name="Code"
              id="Code"
              maxLength="8"
              onChange={(e) => handleChange2(e)}
              required
            />
            <button
              type="submit"
              className="btn-primary"
              onClick={verifyStepTwo}
            >
              <FormattedMessage id="menu.verify" defaultMessage="Verificar código" />
            </button>
            <button
              type="submit"
              className="input-cancel spacing-1"
              onClick={() => setOpen(false)}
            >
              <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
            </button>
          </Box>
        </Modal>
      </main>
      <Footer />
    </>
  );
}

export default Login;
