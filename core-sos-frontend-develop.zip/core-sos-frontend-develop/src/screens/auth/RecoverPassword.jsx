import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import paths from "services/paths";
import { sendEmailRecoveryPassword } from "services/api/auth";
import CustomAlert from "components/CustomAlert";
import SimpleHeader from "common/SimpleHeader";
import "styles/loginRecover.css";
import { FormattedMessage } from "react-intl";

export default function RecuperarPassword() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [username, setUsername] = useState("");

  const sendRecoverPassword = (e) => {
    e.preventDefault();
    setIsLoading(true);
    sendEmailRecoveryPassword(username)
      .then((res) => {
        if (res) {
          CustomAlert("confirm_msg", {
            icon: "success",
            title: "Usuario verificado",
            text:
              "Se ha enviado un correo electrónico al correo asociado al nombre de usuario, sigue los pasos e inicia sesión.",
            confirmButtonText: "Iniciar sesión",
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.login),
          });
        }
      })
      .catch((err) => {
        CustomAlert("short_msg", {
          icon: "error",
          title: `Error`,
          text: `No existe un usuario con el nombre de usuario ${username}, no se encuentra activo o no han trascurrido 15 minutos desde la última vez que se ha solicitado un cambio de contraseña.`,
        });
      });
    setIsLoading(false);
  };

  return (
    <>
      <SimpleHeader />
      <section className="recover-password">
        <form
          className="recover-password-container"
          onSubmit={sendRecoverPassword}
        >
          <h4 className="recover-password-title"><FormattedMessage id="menu.recover" defaultMessage="Recupera tu contraseña"/></h4>
          <input
            className="input-edit"
            type="text"
            placeholder="Nombre de usuario"
            name="username"
            id="username"
            onChange={(e) => setUsername(e.target.value)}
            maxLength="25"
            autoComplete="off"
            required
          />
          <button type="submit" className="btn-primary" disabled={isLoading}>
            <FormattedMessage id="menu.validate" defaultMessage="validar"/>
          </button>
          <p className="back" onClick={() => navigate(paths.login)}>
           <FormattedMessage  id="menu.goback" defaultMessage="Regresar al inicio de sesión"/>
          </p>
        </form>
      </section>
    </>
  );
}
