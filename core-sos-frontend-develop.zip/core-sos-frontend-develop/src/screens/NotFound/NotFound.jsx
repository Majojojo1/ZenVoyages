import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import "./NotFound.css";

export default class NotFound extends Component {
  render() {
    return (
      <section className="container__error">
        <section className="container__error--details">
          <h2>No tienes acceso</h2>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? "active" : "notActive")}
          >
            <p>Ir a la sección principal</p>
          </NavLink>
          {/* <p>Página no encontrada</p> */}
        </section>
      </section>
    );
  }
}
