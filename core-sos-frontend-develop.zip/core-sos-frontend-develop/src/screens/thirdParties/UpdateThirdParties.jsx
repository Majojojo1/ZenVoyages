import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import Cookie from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getAllMunicipalities } from 'services/api/zones';
import paths from 'services/paths';
import Swal from 'sweetalert2';
// hook para cargar los datos
import { Formiz, FormizStep, useForm } from '@formiz/core';
import { isEmail, isPattern } from '@formiz/validations';
import { URLREGEX } from 'common/validators/Regex';
import Attachments from 'components/AttachedFiles/Attachments';
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { getAllTypeDocument } from 'services/api/institutions';
import { getItemById } from 'services/api/methods';
import { getAllThirdTypes } from 'services/api/parameters';
import { updateThirdParty } from 'services/api/thirdParties';

export default function UpdateThirdParties() {
  // hook to loading data
  const { loading, toggleLoading } = useGetData();
  const { fetchData } = useAxios();
  const navigate = useNavigate();
  const [searchResults, setSearchResults] = useState([]);
  const [archivos, setCurrentFiles] = useState([]);
  const [typeThirdParties, setTypeThirdParties] = useState([]);
  const [typeDocument, setTypeDocument] = useState([]);
  const [currentThird, setCurrentThird] = useState(null);
  const regimen = [
    {
      label: 'Simplificado',
      value: 'simplificado',
    },
    {
      label: 'Común',
      value: 'comun',
    },
  ];

  // get url id
  const { id } = useParams();
  // use Hook of language v2
  const { formatterText, resourceNotFound } = useLangv2();

  useEffect(() => {
    getAllTypeThirdParties();
    getAllMunicipios();
    getAllTypeDocuments();
    getThirdById(id);
  }, []);

  const getAllTypeThirdParties = () => {
    toggleLoading(true);
    getAllThirdTypes()
      .then((response) => {
        let ArrayMunicipios = [];
        response.map((item) => {
          if (item.estado === 1) {
            ArrayMunicipios.push({
              label: item.nombre,
              value: {
                value: item.idTipoTercero,
              },
            });
          }
        });
        setTypeThirdParties(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        toggleLoading(false);
      });
  };

  const getAllMunicipios = () => {
    toggleLoading(true);
    getAllMunicipalities()
      .then((response) => {
        let ArrayMunicipios = [];
        response.forEach((municipio) => {
          if (municipio.estado === 1) {
            ArrayMunicipios.push({
              label: `${municipio.nombre} - ${municipio.idDepartamento.nombre} - ${municipio.idDepartamento.idPais.nombrePais}`,
              value: municipio.idMunicipio,
            });
          }
        });
        setSearchResults(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        toggleLoading(false);
      });
  };

  const getAllTypeDocuments = () => {
    toggleLoading(true);
    getAllTypeDocument()
      .then((response) => {
        let ArrayMunicipios = [];
        response.map((item) => {
          ArrayMunicipios.push({
            label: `${item.nombre} - ${item.abreviatura}`,
            value: {
              value: item.idTipoDocumento,
            },
          });
        });
        setTypeDocument(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        toggleLoading(false);
      });
  };
  //get data from api
  const getThirdById = (id) => {
    getItemById(endpoints.thirdParties.getThirdPartyById, id).then((res) => {
      if (res !== null) {
        setCurrentThird(res);
        getDataAttachedFiles(res.idTercero);
      } else {
        resourceNotFound();
      }
    });
  };

  const myForm = useForm();

  const handleSubmit = (values) => { 
    console.log(values);  
    let data = {
      idTercero: currentThird.idTercero,
      nombre: values.nombre,
      idTipoDocumento: {
        idTipoDocumento: values.tipoDocumento.value,
      },
      regimen: values.regimen.label? values.regimen.label : values.regimen,
      identificacion: values.identificacion,
      idMunicipio: {
        idMunicipio: values.idMunicipio.label? values.idMunicipio.value : values.idMunicipio,
      },
      direccion: values.direccion,
      telefono: values.telefono,
      telefonoAlterno: values.telefonoAlterno,
      sitioWeb: values.sitioWeb,
      correo: values.correo,
      idTipoTercero: {
        idTipoTercero: values.idTipoTercero.value,
      },
      estado: 1,
      fechaRegistro: currentThird.fechaRegistro,
      fechaModificacion: null,
      usuarioCreacion: Cookie.get('idUsuario'),
      usuarioModificacion: Cookie.get('idUsuario'),
    };    

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return updateThirdParty(data)
          .then((response) => {
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText(
                'alert.message.confirm.updated.general',
                'El registro se ha actualizado correctamente',
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.thirdParties),
            });
          })
          .catch((err) => {
            if (err.response.status === 412) {
              HandleOnError(formatterText('p.document.already.exists'));
            } else {
              HandleOnError(formatterText('alert.message.failed.general'));
            }
          });
      },
    });
  };

  const uploadNewFile = async (file) => {
    fetchData({
      url: endpoints.UploadFiles.save,
      method: 'post',
      body: {
        idOrigen: currentThird.idTercero,
        idTipoOrigenArchivo: 8, // 8 = tercero
        archivos: [file],
      },
    }).then((response) => {
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: 'Operación exitosa',
        text: 'Se agregó el adjunto correctamente',
        confirmButtonText: 'Continuar',
        allowOutsideClick: false,
        executeFunction: () => console.log(),
      });
    });
  };

  const getDataAttachedFiles = async (id) => {
    fetchData({
      url: endpoints.UploadFiles.findArchivosById,
      method: 'post',
      body: {
        idOrigen: id,
        idTipoOrigenArchivo: 8,
      },
      typeConfig: 'form',
    }).then((response) => {
      let files = response.response.map((file) => {
        return {
          name: file,
          url: file,
        };
      });
      setCurrentFiles(files);
    });
  };

  return (
    <div className="centered-form">
      {currentThird ? (
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form noValidate onSubmit={myForm.submit} className="container-wrapForm">
            <div className="new-container-wrapForm__tabs">
              {myForm.steps.map((step) => (
                <button
                  key={step.name}
                  className={`new-tab-option ${
                    step.name === myForm.currentStep.name ? 'is-active' : ''
                  }`}
                  type="button"
                  onClick={() => myForm.goToStep(step.name)}
                >
                  {!step.isValid && step.isSubmitted && (
                    <small className="mr-2" aria-label="warning">
                      ⚠️
                    </small>
                  )}
                  {formatterText(step.label)}
                </button>
              ))}
            </div>
            <div className="container-wrapForm-content">
              <FormizStep
                name="step1"
                label='p.general.information'
              >
                <div className="title-section">
                  <span className="circle-form">
                    <span>1</span>
                  </span>
                  <h2>
                    <FormattedMessage
                      id="p.general.information"
                      defaultMessage="Información general"
                    />
                  </h2>
                </div>

                <section className="grid-container-3c">
                  <InputSelectorResponsive
                    type="text"
                    name="tipoDocumento"
                    labelText={formatterText('p.document.type', 'Tipo de documento')}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    required="El tipo de documento es requerido"
                    defaultValue={{
                      label: currentThird.idTipoDocumento.abreviatura,
                      value: currentThird.idTipoDocumento.idTipoDocumento,
                    }}
                    data={typeDocument}
                    isLoading={loading}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="identificacion"
                    labelText={formatterText('text.ID', 'Identificación')}
                    placeholder={formatterText('text.ID', 'Identificación')}
                    validateInput="integer"
                    required="La identificación es requerida"
                    defaultValue={currentThird.identificacion}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="nombre"
                    labelText={formatterText('p.name.compName', 'Nombre o razón social')}
                    placeholder={formatterText('p.name.compName', 'Nombre o razón social')}
                    validateInput="text"
                    required="Nombre o razón social es requerido"
                    defaultValue={currentThird.nombre}
                  />
                  <InputSelectorResponsive
                    type="text"
                    name="regimen"
                    labelText={formatterText('p.regime', 'Régimen')}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    required="El régimen es requerido"
                    data={regimen}
                    defaultValue={{
                      label: currentThird.regimen,
                      value: currentThird.regimen,
                    }}
                    isLoading={loading}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="telefono"
                    labelText={formatterText('table.title.phone', 'Teléfono')}
                    placeholder={formatterText('table.title.phone', 'Teléfono')}
                    validateInput="integer"
                    required="El número de teléfono es requerido"
                    defaultValue={currentThird.telefono}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="telefonoAlterno"
                    labelText={formatterText('p.alt.phone', 'Teléfono alterno')}
                    placeholder={formatterText('p.alt.phone', 'Teléfono alterno')}
                    validateInput="integer"
                    required="El número de alterno es requerido"
                    defaultValue={currentThird.telefonoAlterno}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="sitioWeb"
                    labelText={formatterText('table.title.website', 'Sitio web')}
                    placeholder={formatterText('table.title.website', 'Sitio web')}
                    validateInput="web"
                    required="El sitio web es requerido"
                    defaultValue={currentThird.sitioWeb}
                    validations={[
                      {
                        rule: isPattern(URLREGEX),
                        message: 'La url no es válida',
                      },
                    ]}
                  />
                  <InputFieldResponsive
                    type="email"
                    name="correo"
                    labelText={formatterText('table.title.email', 'Correo electrónico')}
                    placeholder={formatterText('table.title.email', 'Correo electrónico')}
                    required="El Correo electrónico es requerido"
                    defaultValue={currentThird.correo}
                    validations={[
                      {
                        rule: isEmail(),
                        message: 'El correo no es válido',
                      },
                    ]}
                  />
                  <InputSelectorResponsive
                    type="text"
                    name="idTipoTercero"
                    labelText={formatterText('p.third.type', 'Tipo de tercero')}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    defaultValue={{
                      label: currentThird.idTipoTercero.nombre,
                      value: currentThird.idTipoTercero.idTipoTercero,
                    }}
                    required="El Tipo de tercero es requerido"
                    data={typeThirdParties}
                    isLoading={loading}
                  />
                </section>
                <div className="title-section">
                  <span className="circle-form">
                    <span>1.1</span>
                  </span>
                  <h2>
                    <FormattedMessage id="p.place.residence" defaultMessage="Lugar de residencia" />
                  </h2>
                </div>
                <section
                  className="grid-container-2c"
                  style={{
                    width: '100%',
                  }}
                >
                  <InputSelectorResponsive
                    type="text"
                    name="idMunicipio"
                    labelText={formatterText('p.city.residence', 'Ciudad de residencia')}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    defaultValue={{
                      label: currentThird.idMunicipio.nombre,
                      value: currentThird.idMunicipio.idMunicipio,
                    }}
                    selectedOption={currentThird.idMunicipio}
                    required="La ciudad de residencia es requerida"
                    data={searchResults}
                    isLoading={loading}
                  />
                  <InputFieldResponsive
                    type="text"
                    name="direccion"
                    labelText={formatterText('table.title.address', 'Dirección')}
                    placeholder={formatterText('table.title.address', 'Dirección')}
                    required="La dirreción electrónico es requerida"
                    defaultValue={currentThird.direccion}
                    validateInput="address"
                  />
                </section>
              </FormizStep>

              <FormizStep
                name="step2"
                label='p.load.attachment.files'
              >
                <Attachments
                  currentFiles={archivos}
                  setCurrentFiles={setCurrentFiles}
                  isEdited={true}
                  uploadNewFile={uploadNewFile}
                  type={2}
                  showParameters={true}
                />
              </FormizStep>
              <section className="form-responsive-container-buttons">
                <button type="submit" className="btn-primary">
                  <FormattedMessage
                    id="alert.button.confirm.general"
                    defaultMessage="Guardar cambios"
                  />
                </button>
                <button className="input-cancel" onClick={() => navigate(paths.thirdParties)}>
                  <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
                </button>
              </section>
            </div>
          </form>
        </Formiz>
      ) : (
        <div>Cargando...</div>
      )}
    </div>
  );
}
