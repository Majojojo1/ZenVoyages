import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import Cookie from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllMunicipalities } from 'services/api/zones';
import paths from 'services/paths';
import Swal from 'sweetalert2';
// hook para cargar los datos
import { Formiz, FormizStep, useForm } from '@formiz/core';
import { isEmail } from '@formiz/validations';
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { getAllTypeDocument } from 'services/api/institutions';
import { getAllThirdTypes } from 'services/api/parameters';
import { addThirdParty } from 'services/api/thirdParties';
import Attachments from '../../components/AttachedFiles/Attachments';

export default function CreateThirdParties() {
  // hook to loading data
  const { loading, toggleLoading } = useGetData();
  const { fetchData } = useAxios();
  const navigate = useNavigate();
  const [searchResults, setSearchResults] = useState([]);
  const [archivos, setCurrentFiles] = useState([]);
  const [typeThirdParties, setTypeThirdParties] = useState([]);
  const [typeDocument, setTypeDocument] = useState([]);
  const { formatterText } = useLangv2();

  const regimen = [
    {
      label: 'Simplificado',
      value: '1',
    },
    {
      label: 'Común',
      value: '2',
    },
  ];

  useEffect(() => {
    getAllTypeThirdParties();
    getAllMunicipios();
    getAllTypeDocuments();
  }, []);

  const getAllTypeThirdParties = () => {
    toggleLoading(true);
    getAllThirdTypes()
      .then((response) => {
        let ArrayMunicipios = [];
        response.map((item) => {
          if (item.estado === 1) {
            ArrayMunicipios.push({
              label: item.nombre,
              value: item.idTipoTercero,
            });
          }
        });
        setTypeThirdParties(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const getAllMunicipios = () => {
    toggleLoading(true);
    getAllMunicipalities()
      .then((response) => {
        let ArrayMunicipios = [];
        console.log(response);

        response.forEach((municipio) => {
          if (municipio.estado === 1) {
            ArrayMunicipios.push({
              label: `${municipio.nombre} - ${municipio.idDepartamento.nombre} - ${municipio.idDepartamento.idPais.nombrePais}`,
              value: municipio.idMunicipio,
            });
          }
        });

        setSearchResults(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const getAllTypeDocuments = () => {
    toggleLoading(true);
    getAllTypeDocument()
      .then((response) => {
        let ArrayMunicipios = [];
        response.map((item) =>
          ArrayMunicipios.push({
            label: `${item.nombre} - ${item.abreviatura}`,
            value: item.idTipoDocumento,
          }),
        );
        setTypeDocument(ArrayMunicipios);
        toggleLoading(false);
      })
      .catch((error) => {
        console.log(error);
        toggleLoading(false);
      });
  };

  const myForm = useForm();

  const handleSubmit = (values) => {
    const data = {
      idTercero: null,
      nombre: values.nombre,
      idTipoDocumento: {
        idTipoDocumento: values.tipoDocumento,
      },
      regimen: values.regimen,
      identificacion: values.identificacion,
      idMunicipio: {
        idMunicipio: values.idMunicipio,
      },
      direccion: values.direccion,
      telefono: values.telefono,
      telefonoAlterno: values.telefonoAlterno,
      sitioWeb: values.sitioWeb,
      correo: values.correo,
      idTipoTercero: {
        idTipoTercero: values.idTipoTercero,
      },
      estado: 1,
      fechaRegistro: null,
      fechaModificacion: null,
      usuarioCreacion: Cookie.get('idUsuario'),
      usuarioModificacion: null,
    };

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text:  formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return addThirdParty(data)
          .then((response) => {
            uploadFiles(response.idTercero);
          })
          .catch((err) => {
            if (err.response?.data?.message) {
              HandleOnError((formatterText(err.response?.data?.message)));
            } else {
              HandleOnError(formatterText(
                'snackbar.error.process.failed.general',
                'Error al realizar el proceso. Intentalo en otro momento.',
              ),);
            }
          });
      },
    });
  };

  const uploadFiles = (id) => {
    return new Promise((resolve, reject) => {
      if (archivos.length > 0) {
        fetchData({
          url: endpoints.UploadFiles.save,
          method: 'post',
          body: {
            idOrigen: id,
            idTipoOrigenArchivo: 8, // 8 = Tercero
            archivos,
          },
        })
          .then((response) => {
            resolve(
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.created.general',
                  'El registro se ha creado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.thirdParties),
              }),
            );
          })
          .catch((err) => {
            reject(err);
          });
      } else {
        resolve(
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.confirm.created.general',
              'El registro se ha creado correctamente',
            ),
            confirmButtonText:  formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.thirdParties),
          }),
        );
      }
    });
  };

  return (
    <div className="centered-form">
      <Formiz onValidSubmit={handleSubmit} connect={myForm}>
        <form noValidate onSubmit={myForm.submit} className="container-wrapForm">
          <div className="new-container-wrapForm__tabs">
            {myForm.steps.map((step) => (
              <button
                key={step.name}
                className={`new-tab-option ${
                  step.name === myForm.currentStep.name ? 'is-active' : ''
                }`}
                type="button"
                onClick={() => myForm.goToStep(step.name)}
              >
                {!step.isValid && step.isSubmitted && (
                  <small className="mr-2" aria-label="warning">
                    ⚠️
                  </small>
                )}
                {formatterText(step.label)}
              </button>
            ))}
          </div>
          <div className="container-wrapForm-content">
            <FormizStep
              name="step1"
              label='p.general.information'
            >
              <div className="title-section">
                <span className="circle-form">
                  <span>1</span>
                </span>
                <h2>
                  <FormattedMessage
                    id="p.general.information"
                    defaultMessage="Información general"
                  />
                </h2>
              </div>

              <section className="grid-container-3c">
                <InputSelectorResponsive
                  type="text"
                  name="tipoDocumento"
                  labelText={formatterText('p.document.type', 'Tipo de documento')}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  required="El tipo de documento es requerido"
                  data={typeDocument}
                  isLoading={loading}
                />
                <InputFieldResponsive
                  type="text"
                  name="identificacion"
                  labelText={formatterText('text.ID', 'Identificación')}
                  placeholder={formatterText('text.ID', 'Identificación')}
                  validateInput="integer"
                  required="La identificación es requerida"
                />
                <InputFieldResponsive
                  type="text"
                  name="nombre"
                  labelText={formatterText('p.name.compName', 'Nombre o razón social')}
                  placeholder={formatterText('p.name.compName', 'Nombre o razón social')}
                  validateInput="text"
                  required="Nombre o razón social es requerido"
                />
                <InputSelectorResponsive
                  type="text"
                  name="regimen"
                  labelText={formatterText('p.regime', 'Régimen')}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  required="El régimen es requerido"
                  data={regimen}
                  isLoading={loading}
                />
                <InputFieldResponsive
                  type="text"
                  name="telefono"
                  labelText={formatterText('table.title.phone', 'Teléfono')}
                  placeholder={formatterText('table.title.phone', 'Teléfono')}
                  validateInput="integer"
                  required="El número de teléfono es requerido"
                />
                <InputFieldResponsive
                  type="text"
                  name="telefonoAlterno"
                  labelText={formatterText('p.alt.phone', 'Teléfono alterno')}
                  placeholder={formatterText('p.alt.phone', 'Teléfono alterno')}
                  validateInput="integer"
                  required="El número de alterno es requerido"
                />
                <InputFieldResponsive
                  type="text"
                  name="sitioWeb"
                  labelText={formatterText('table.title.website', 'Sitio web')}
                  placeholder={formatterText('table.title.website', 'Sitio web')}
                  validateInput="web"
                  required="El sitio web es requerido"
                  // // validations is not working with web
                  // validations={[
                  //   {
                  //     rule: isPattern(URLREGEX),
                  //     message: "La url no es válida",
                  //   },
                  // ]}
                />
                <InputFieldResponsive
                  type="email"
                  name="correo"
                  labelText={formatterText('table.title.email', 'Correo electrónico')}
                  placeholder={formatterText('table.title.email', 'Correo electrónico')}
                  required="El Correo electrónico es requerido"
                  validations={[
                    {
                      rule: isEmail(),
                      message: 'El correo no es válido',
                    },
                  ]}
                />
                <InputSelectorResponsive
                  type="text"
                  name="idTipoTercero"
                  labelText={formatterText('p.third.type', 'Tipo de tercero')}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  required="El Tipo de tercero es requerido"
                  data={typeThirdParties}
                  isLoading={loading}
                />
              </section>
              <div className="title-section">
                <span className="circle-form">
                  <span>1.1</span>
                </span>
                <h2>
                  <FormattedMessage id="p.place.residence" defaultMessage="Lugar de residencia" />
                </h2>
              </div>
              <section
                className="grid-container-2c"
                style={{
                  width: '95%',
                  margin: '0 auto',
                }}
              >
                <InputSelectorResponsive
                  type="text"
                  name="idMunicipio"
                  labelText={formatterText('p.city.residence', 'Ciudad de residencia')}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  required="La ciudad de residencia es requerida"
                  data={searchResults}
                  isLoading={loading}
                />
                <InputFieldResponsive
                  type="text"
                  name="direccion"
                  labelText={formatterText('table.title.address', 'Dirección')}
                  placeholder={formatterText('table.title.address', 'Dirección')}
                  required="La direción es requerida"
                />
              </section>
            </FormizStep>

            <FormizStep
              name="step2"
              label='p.load.attachment.files'
            >
              <Attachments
                currentFiles={archivos}
                setCurrentFiles={setCurrentFiles}
                isEdited={false}
                type={2}
                showParameters={true}
              />
            </FormizStep>
            <section className="form-responsive-container-buttons">
              <button type="submit" className="btn-primary">
                <FormattedMessage
                  id="alert.button.confirm.general"
                  defaultMessage="Guardar cambios"
                />
              </button>
              <button className="input-cancel" onClick={() => navigate(paths.thirdParties)}>
                <FormattedMessage id="alert.button.cancel.general" defaultMessage="Cancelar" />
              </button>
            </section>
          </div>
        </form>
      </Formiz>
    </div>
  );
}
