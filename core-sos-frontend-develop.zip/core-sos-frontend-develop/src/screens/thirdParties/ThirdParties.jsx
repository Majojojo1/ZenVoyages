import React, { useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { useLocation } from 'react-router';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
// Import libs
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { getAll } from 'services/api/methods';
import { deleteThirdParty, updateThirdParty } from 'services/api/thirdParties';
import paths from 'services/paths';

const ThirdParties = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ThirdPartiesComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function ThirdPartiesComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();
  // hook useLocation
  const location = useLocation();

  const [thirdParties, setThirdParties] = useState(null);

  // use Hook of language v2
  const { formatterText } = useLangv2();
  // titulos de la tabla
  const titles = [
    formatterText('table.title.full.name', 'Nombre completo'),
    formatterText('p.document.type', 'Tipo de documento'),
    formatterText('table.title.document', 'Documento'),
    formatterText('table.title.municipality', 'Municipio'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.thirdParties);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAll(endpoints.thirdParties.getAllThirdParties)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
        setThirdParties(newArray);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteThirdParty(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setThirdParties(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateThirdParty(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    let docType = `${item.idTipoDocumento.nombre} - ${item.idTipoDocumento.abreviatura}`;
    newArray.push({
      id: item.idTercero,
      nombre: item.nombre,
      tipo_documento: docType,
      documento: item.identificacion,
      municipio: item.idMunicipio.nombre,
      estado: item.estado,
      objeto: { ...item },
    });
  };  

  const renderMessage = () =>
    error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();
  return (
    <>
      {!loading && thirdParties !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createThirdParty}>
                <button className="btn-add">
                  <FormattedMessage
                    id="header.title.third.party.create"
                    defaultMessage="Crear terceros"
                  />
                </button>
              </Link>
            )}

            {permittedActions.exportar && (
              <ExportJsonFile
                moduleName={'Tercero'}
                userName={
                  JSON.parse(localStorage.getItem('userData')).usuario
                    ? JSON.parse(localStorage.getItem('userData')).usuario
                    : 'ADMIN'
                }
                dataTable={thirdParties}
              />
            )}
          </section>
          {permittedActions.consultar && (
            <FormattedMessage id="table.name.search.thirdParties" defaultMessage="Terceros">
              {(placeholder) => (
                <DynamicTable
                  titles={titles}
                  pageName={PAGE_NAMES.Terceras}
                  getData={getDataTable}
                  handleDeleteItem={handleDeleteItem}
                  handleEditStateItem={handleEditStateItem}
                  routeToEdit={paths.updateThirdParty}
                  canDeleted={permittedActions.eliminar}
                  canModify={permittedActions.editar}
                />
              )}
            </FormattedMessage>
          )}
        </section>
      ) : (
        renderMessage()
      )}
    </>
  );
}

export default ThirdParties;
