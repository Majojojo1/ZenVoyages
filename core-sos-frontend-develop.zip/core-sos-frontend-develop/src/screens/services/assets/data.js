import moment from "moment";
import { DataItemInterface } from "../interfaces/dataItem.interface";

const getRandomYear = (base = 2000) =>
  Math.floor(base + Math.random() * (base - moment().year()));

const getRandomMonth = (base = 11) =>
  Math.floor(Math.random() * base);

const getRandomDay = (base = 28) =>
  Math.floor(Math.random() * base);

const getRandomHour = (base = 24) =>
  Math.floor(Math.random() * base);

const getRandomMinutes = (base = 60) =>
  Math.floor(Math.random() * base);

const getRandomDateStart = () => {
  const year = Number(getRandomYear(2023));
  const month = Number(moment().month());
  const day = Number(moment().date());
  const hour = Number(getRandomHour());
  const minute = Number(getRandomMinutes());

  return moment(new Date(year, month, day, hour, minute)).format();
};

const getRandomDateEnd = (startDate) => {
  const date = moment(startDate);
  const year = date.year();
  const month = date.month();
  const day = date.date();
  const hour = date
    .add(Math.floor(Math.random() * 2), "hours")
    .hour();
  const minute = date
    .add(Math.floor(Math.random() * 240), "minutes")
    .minute();

  return moment(new Date(year, month, day, hour, minute)).format();
};

const getRandomTime = () => `${getRandomHour()}:${getRandomMinutes()}`;

const buildData = (count = 0) => {
  let data = [];

  for (let index = 0; index <= count; index++) {
    const dateStart = getRandomDateStart();
    const dateEnd = getRandomDateEnd(dateStart);

    data = [
      ...data,
      {
        id: index,
        technician_name: `Santiago Ruiz ${index}`,
        technician_id: index,
        technician_charge: "Técnico de electricidad",
        technician_picture: null,
        ticket: "2023080200012",
        percentage: Math.floor(Math.random() * 100),
        service_type: "Instalación de bombillo",
        service_status: "in_progress",
        service_date_start: dateStart,
        service_date_end: dateEnd,
      },
    ];
  }

  return data;
};

const data = buildData();

export  {
  data,
};
