import React, { useEffect, useState } from 'react';
// import Hooks
import { TimePicker } from '@material-ui/pickers';
import dateformat from 'dateformat';
import useAxios from 'hooks/useAxios';
import useLangv2, { formatterText } from 'hooks/useLangv2';
import { useParams } from 'react-router';
// import Services
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
// import Styles
import { getValueHour } from 'common/utils/HoursHelper';
import styles from 'screens/services/ExtraTabs/Tab.module.css';

const UpdateDatimeAlert = ({ onClose, DATA: DATOS, infoToChange, WayChange = false, getDataToUpdate, getAllTechnicalsServices, flagStatus = false, setFlagStatus, OpenSearch, idTecnico, idCitaServicioTecnico }) => {
  const { id } = useParams();
  const { fetchData } = useAxios();
  const now = new Date();
  const [eventData, setEventData] = useState({
    fechaCita: '',
    idHoraCita: '',
  });
  const [dateValidate, setDateValidate] = useState({
    idHoraCita: '',
  })
  // Stare of date picker
  const [time, setTime] = useState(new Date('0000-01-01T00:00'));
  const { noScheduleTech, updatedItem, errorProcess, customSB, handleRequestError } = useLangv2();
  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    if (WayChange === true) {
      updateService();
    } else if (!WayChange) {
      updateState();
    }
  };

  const updateService = () => {
    fetchData({ url: endpoints.services.getServiceById(id) }).then((data) => {
      const { response } = data;
      console.log(response);
      const SERVICE_FULL = prepareServiceData(response.servicio);
      if (validateServiceData(SERVICE_FULL)) {
        customSB(
          'warning',
          'snackbar.warning.validate.tech.exist.update',
          'Se está validando que el servicio cumpla con los requisitos para ser actualizado, por favor espere...',
        );
        fetchAndProcessServiceData(SERVICE_FULL);
        getAllTechnicalsServices();
      } else {
        customSB(
          'warning',
          "snackbar.warning.complete.field.date",
          'Ingresa Fecha y/o la Hora de la cita',
        );
      }
    });
  };

  const updateState = () => {
    fetchData({ url: endpoints.services.getServiceById(id) }).then((data) => {
      const { response } = data;
      const SERVICE_FULL = prepareServiceData(response.servicio);
      if (validateServiceData(SERVICE_FULL)) {
        customSB(
          'warning',
          'snackbar.warning.validate.tech.exist.update',
          'Se está validando que el servicio cumpla con los requisitos para ser actualizado, por favor espere...',
        );
        fetchAndProcessServiceDataToUpdateStatus(SERVICE_FULL);
      } else {
        customSB(
          'warning',
          "snackbar.warning.complete.field.date",
          'Ingresa Fecha y/o la Hora de la cita',
        );
      }
    });
  }
  const fetchAndProcessServiceData = (SERVICE_FULL) => {
    fetchData({
      url: endpoints.services.generateEndDate,
      method: 'post',
      body: SERVICE_FULL,
    }).then((DATA) => {
      const { response } = DATA;
      if (dateValidate.idHoraCita?.hora) {
        const dataToSend = {
          idServicio: { ...response },
          idTecnico: { idTecnico: idTecnico },
        };
        fetchData({
          url: endpoints.services.updateCitaAuxTech,
          method: 'put',
          body: dataToSend,
        }).then(() => {
          updatedItem();
          onClose();
          getDataToUpdate();
        }).catch(handleRequestError);
      }
    }).catch(() => {
      customSB(
        'error',
        'Error al obtener los datos, consulte a su administrador',
      );
    });
  };

  const fetchAndProcessServiceDataToUpdateStatus = (SERVICE_FULL) => {
    fetchData({
      url: endpoints.services.generateEndDate,
      method: 'post',
      body: SERVICE_FULL,
    }).then((DATA) => {
      const { response } = DATA;
      if (dateValidate.idHoraCita?.hora) {
        const dataToSend = {
          ...response,
          idHoraCita: {
            ...response.idHoraCita,
            hora: dateValidate.idHoraCita.hora,
            valor: dateValidate.idHoraCita.valor,
          },
        };
        fetchData({
          url: endpoints.services.validatePrincipalTech,
          method: 'post',
          body: dataToSend,
        }).then((d) => {
          const ans = d.response;
          if (ans) {
            fetchData({
              url: endpoints.services.updateDate,
              method: 'post',
              body: dataToSend,
            }).then((r) => {
              const res = r.response;
              if (res.codigo === 2) {
                customSB(
                  'error',
                  'Error, el Servicio debe estar en Curso',
                );
              } else {
                updatedItem();
                setFlagStatus(true);
                onClose();
                getDataToUpdate();
              }
            }).catch(errorProcess);
          } else {
            noScheduleTech();
          }
        }).catch(errorProcess);
      }
    }).catch(() => {
      customSB(
        'error',
        'Error al obtener los datos, consulte a su administrador',
      );
    });
  };

  const prepareServiceData = (serviceData) => {
    const SERVICE_FULL = { ...serviceData };
    delete SERVICE_FULL.fechaCita;
    delete SERVICE_FULL.idHoraCita;
    delete SERVICE_FULL.fechaCitaFin;
    delete SERVICE_FULL.idHoraCitaFin;
    SERVICE_FULL.fechaCita = eventData.fechaCita;
    SERVICE_FULL.idHoraCita = eventData.idHoraCita;
    return SERVICE_FULL;
  };

  const validateServiceData = (serviceData) => {
    return (
      serviceData.idHoraCita !== '' &&
      serviceData.idHoraCita !== null &&
      serviceData.fechaCita !== '' &&
      serviceData.fechaCita !== null
    );
  };
  
  useEffect(() => {
    if (flagStatus) {
      console.log("setFlag cambia a true");
    }
  }, [flagStatus]);

  const handleDate = (e) => {
    if (e.target) {
      setEventData({
        ...eventData,
        [e.target.name]: e.target.value,
      });
    } else {
      setTime(e);
      const HOUR_ID = searchHour(dateformat(e, 'HH:MM'));
      const NAME_VALUE = 'idHoraCita';
      const HOUR_VALUE = getValueHour(HOUR_ID);


      setEventData({
        ...eventData,
        [NAME_VALUE]: {
          idHora: HOUR_ID,

        },
      });
      setDateValidate((prevDateValidate) => {
        if (prevDateValidate.idHoraCita) {
          return {
            ...prevDateValidate,
            [NAME_VALUE]: {
              ...prevDateValidate.idHoraCita,
              hora: dateformat(e, 'HH:MM'),
              valor: HOUR_VALUE,
            },
          };
        } else {
          return {
            ...prevDateValidate,
            [NAME_VALUE]: {
              idHora: HOUR_ID,
              hora: dateformat(e, 'HH:MM'),
              valor: HOUR_VALUE,
            },
          };
        }
      });
    }
  };

  const searchHour = (hour) => {
    const HOURS = JSON.parse(localStorage.getItem('hours'));    
    const idHora = HOURS?.find((item) => item.hora === hour);
    return idHora?.idHora;
  };

  return (    
      <form className={styles['container-ps-modal-ud']}>
        <p className="title-modal">{formatterText('title.service.updateDateTime')}</p>
        <h4>{formatterText('title.service.newDateTime')}</h4>

        <label>
          <span>{formatterText('title.service.appointmentDate')}</span>
          <input
            className="input-date"
            type="date"
            name="fechaCita"
            value={eventData.fechaCita}
            onChange={handleDate}
            min={dateformat(
              new Date(now.getFullYear(), now.getMonth(), now.getDate() - 60),
              'yyyy-mm-dd',
            )}
            style={{ width: '60%', margin: '1rem 0rem' }}
          />
        </label>
        <label>
          <span>{formatterText('title.service.appointmentTime')}</span>
          <TimePicker
            name="idHoraCita"
            ampm={false}
            placeholder={
              <FormattedMessage
                id="input.placeholder.select"
                defaultMessage="Selecciona una opción"
              />
            }

            value={time}
            onChange={handleDate}
            style={{ width: '60%', margin: '1rem 0rem' }}
          />
        </label>

        <section className="footer-grid-buttons">
          <input
            type="submit"
            className="btn-action-primary"
            value={formatterText('title.service.update')}
            onClick={(e) => handleSubmit(e)}
          />
          <button
            className="btn-action-cancel"
            onClick={(e) => {
              e.preventDefault();
              onClose();
            }}
          >
           {formatterText('title.service.return')}
          </button>
        </section>
      </form>
    
  );
};

export default UpdateDatimeAlert;