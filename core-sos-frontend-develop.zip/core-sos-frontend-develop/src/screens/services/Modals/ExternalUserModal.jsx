import React, { useState } from 'react';
// Import Contexts
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import HandlerNumbers from 'common/validators/HandlerNumbers';
import HandlerText from 'common/validators/HandlerText';
import SortData from 'components/utils/SortData';
// Import libs
// import Swal from "sweetalert2";
// Import de services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import endpoints from 'services/api';
import { updateClient } from 'services/api/clients';
import { addItem } from 'services/api/methods';
import paths from 'services/paths';
import Modal from 'react-responsive-modal';
import CreateExternalUser from 'screens/externalUser/CreateExternalUser';

const ExternalUserModal = ({ onClose, exeFun }) => {
  return (
    <SearchWrapper>
      <ExternalUserModalComponent onClose={onClose} exeFun={exeFun} />
    </SearchWrapper>
  );
};

function ExternalUserModalComponent({ onClose, exeFun }) {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  const titlesSearch = [
    formatterText('title.user.name'),
    formatterText('title.user.phone'),
    formatterText('title.user.email'),
    formatterText('title.user.actions')
  ];
  // hook to loading data
  const { error, toggleLoading, toggleError, handleClick } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();
  const [ IsOpenExternalUser , setIsOpenExternalUser] = useState(false);

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateClient(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    if (item.estado === 1) {
      const nombre = `${item.primerNombre || 'None'} ${item.segundoNombre || ''} ${item.primerApellido} ${item.segundoApellido || ''}`;
      newArray.push({
        id: item.idUsuarioServicio,
        nombre,
        telefono: item.telefono,
        correo: item.correo ? item.correo : '',
        objeto: { ...item },
      });
    }
  };

  const [userExternalSearch, setUserExternalSearch] = useState({
    primerNombre: '',
    telefono: '',
  });

  const findExternalUsers = () => {
    const jsonToSend = {
      primerNombre:
        userExternalSearch.primerNombre !== ''
          ? userExternalSearch.primerNombre.replaceAll(/\s{2,}/gi, ' ')
          : null,
      telefono:
        userExternalSearch.telefono !== ''
          ? userExternalSearch.telefono.replaceAll(/\s{2,}/gi, ' ')
          : null,
    };
    addItem(endpoints.services.getAllExternalUsersByQuery, jsonToSend)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortData(newArray, 'asc');
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandlerText(e, userExternalSearch, setUserExternalSearch);
  };

  // Update a number to set into the form
  const handleNumber = (e) => {
    if (e.target.value.match(/^[0-9]*$/)) {
      HandlerNumbers(e, userExternalSearch, setUserExternalSearch);
    }
  };

  return (
    <>
      <section className="container-search-modals">
        <section className="box-40p">
          <p className="p-text-primary">{formatterText('title.user.name.table.search')}</p>
          <input
            type="text"
            name="primerNombre"
            placeholder={formatterText('title.service.enterClientName')}
            value={userExternalSearch.primerNombre}
            onChange={(e) => handleText(e)}
            className="input-default"
          />
        </section>
        <section className="box-40p">
          <p className="p-text-primary">{formatterText('title.service.phone.user')}</p>
          <input
            type="text"
            name="telefono"
            placeholder={formatterText('title.service.enterClientPhone')}
            value={userExternalSearch.telefono}
            onChange={(e) => handleNumber(e)}
            className="input-default"
          />
        </section>
        <button
          className="btn-search"
          onClick={(e) => {
            e.preventDefault();
            findExternalUsers();
          }}
        >
          {formatterText('title.service.search')}
        </button>
      </section>
      <section className="w100-container">
        <section className="table-container">
          <p className="p-text-primary">{formatterText('title.service.foundUsers')}</p>
          <section className="boxTable">
            <Search
              placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
              width="50%"
            />
            <button
              className="btn-add"
              onClick={() =>{
                console.log('createExternalUser');
                setIsOpenExternalUser(true);
                //window.open(`#${paths.createExternalUser}`, '_blank',);
              }
                
              }
            >
              {formatterText('title.service.createUser')}
            </button>
          </section>
          <DynamicTable
            titles={titlesSearch}
            pageName={PAGE_NAMES.Usuarios}
            getData={findExternalUsers}
            handleDeleteItem={handleEditStateItem}
            handleEditStateItem={handleEditStateItem}
            routeToEdit={paths.updateClient}
            canDeleted={false}
            canModify={false}
            canSelectEU={true}
            onClose={onClose}
          />
        </section>
      </section>
      <Modal
        open={IsOpenExternalUser}
        onClose={_ => setIsOpenExternalUser(false)}
      >
        <CreateExternalUser setIsOpenExternalUser={setIsOpenExternalUser}></CreateExternalUser>
      </Modal>
    </>
  );
}

export default ExternalUserModal;
