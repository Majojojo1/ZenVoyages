import React from "react";

export default function ProvidersData({ data }) {
  const { nombreRazonSocial, identificacion, telefono, correo } = data;
  return (
    <div>
      <p>Nombre / Razon Social {nombreRazonSocial}</p>
      <p>Identificacion {identificacion}</p>
      <p>Telefono {telefono}</p>
      <p>Correo {correo}</p>
    </div>
  );
}
