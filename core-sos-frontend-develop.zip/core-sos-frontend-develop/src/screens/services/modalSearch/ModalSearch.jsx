import React, { useState } from "react";
import dateFormat from "dateformat";

const NOW = new Date();

export default function ModalSearch({
  onClose,
  setterFun,
  verifyTechAvailable,
}) {
  const [formData, setFormData] = useState([]);
  const handleDate = (e) => {
    setFormData({ ...formData, [e.target.name]: new Date(e.target.value) });
  };

  const buildFormData = (formData) => {
    const hora = dateFormat(formData.fechaFin, "HH:MM");
    const fecha = dateFormat(formData.fechaFin, "yyyy-mm-dd");

    setterFun((prev) => ({ ...prev, fechaCita: fecha, horaCita: hora }));
    onClose();
    verifyTechAvailable(fecha, hora);
  };

  return (
    <>
      <label className="center-container-modal">
        <span
          style={{
            textAlign: "center",
          }}
          className="title-table"
        >
          Cambiar la fecha y hora de la cita
        </span>
        <input
          className="input-primary-wrap"
          name="fechaFin"
          label="Fecha de Servicio"
          type="dateTime-local"
          min={dateFormat(
            new Date(NOW.getFullYear() - 5, NOW.getMonth(), NOW.getDate()),
            "yyyy-mm-dd"
          )}
          onChange={handleDate}
          required
        />
      </label>
      <section className="form-responsive-container-buttons">
        <button
          className="btn-action-primary"
          onClick={() => buildFormData(formData)}
        >
          Aceptar
        </button>
        <button className="btn-action-cancel" onClick={onClose}>
          Cancelar
        </button>
      </section>
    </>
  );
}
