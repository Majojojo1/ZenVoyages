import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import SelectComboBox from 'common/selects/SelectComboBox';
import DateTimePicker from 'components/pickers/DateTimePicker';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import SortDataByDate from 'components/utils/SortDataByDate';
import { MdKeyboardArrowDown, MdKeyboardArrowRight } from 'react-icons/md';
// Import Libs
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';

// Import Models
import ServiceType from 'models/service/ServiceType';
// Import Services
import endpoints from 'services/api';
import paths from 'services/paths';
// Import Styles
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { sortBy } from 'lodash';
import { addItem, getAll, getItemById } from 'services/api/methods';
import grid from './Service.module.css';

// id Employee

function sleep(delay = 0) {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
}

const ServiceTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ServiceTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const ServiceTableComponent = () => {
  // Manage axios requests
  const [open, setOpen] = React.useState(false);
  const [options, setOptions] = React.useState([]);
  const loading2 = open && options.length === 0;
  const [selectValue, setSelectValue] = useState({
    id: null,
    label: '',
  });
  const [val, setVal] = useState({
    id: null,
    label: '',
  });

  // Estado del id de la entidad (Empleado o Tercero)
  const [filterBill, setFilterBill] = useState({
    billId: null,
    label: '',
  });

  const [allStateService, setAllStateService] = useState([]);
  React.useEffect(() => {
    let active = true;

    if (!loading2) {
      return undefined;
    }

    (async () => {
      if (active && selectValue.length >= 3) {
        const response = await getItemById(
          endpoints.services.getAllExternalUsersByNumber,
          selectValue,
        );
        await sleep(1e3); // For demo purposes.
        const users = await response;
        let newArray = [];
        Object.keys(users).forEach((key) => {
          let formatData = `${users[key].primerNombre} ${users[key].primerApellido} - ${users[key].telefono}`;
          newArray.push({ id: users[key].id, label: formatData });
        });
        setOptions(newArray);
      }
    })();

    return () => {
      active = false;
    };
  }, [loading2, selectValue]);

  React.useEffect(() => {
    if (!open) {
      setOptions([]);
    }
  }, [open]);

  // State of the labels and ids of the selectors
  const [selectValues, setSelectValues] = useState({
    nombre_cliente: {
      id: null,
      label: '',
    },
    idDepartamento: {
      id: null,
      label: '',
    },
    nombre_usuario: {
      id: null,
      label: '',
    },
    idTecnico: {
      id: null,
      label: '',
    },
    idTipoServicio: {
      id: null,
      label: '',
    },
    idEstadoServicio: {
      id: null,
      label: '',
    },
  });

  const [formData, setFormData] = useState(new ServiceType());

  const [dates, setDates] = useState({
    rangoFechaCitaInicio: null,
    rangoFechaCitaFin: null,
    rangoFechaCreacionInicial: null,
    rangoFechaCreacionFinal: null,
    rangoValorHoraInicial: null,
    rangoValorHoraFinal: null,
  });

  // hook to loading data
  const { loading, error, displayMessage } = useGetData();
  // useContext de búsqueda
  const { dataTable, setDataTable, searchResults = [] } = useSeachContext();
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  const [services, setServices] = useState(null);

  const [show, setShow] = useState(false);

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.service.principal);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  // getData from the client or exteralUser select
  const {
    setExternalUserSelected,
    setBillingUserSelected,
    setClientSelected,
    setUserSelected,
    hours,
  } = useContext(AppContext);



  const getAllStatesService = () => {
    getAll(endpoints.services.getAllStates).then((data) => {
      const resp = data.map((item) => ({
        id: item.idEstadoServicio,
        label: item.nombre,
      }));
      const sorted = sortBy(resp, 'id');
      setAllStateService(sorted);
    });
  };

  useEffect(() => {
    setClientSelected({
      nombre: 'Seleccione un cliente',
      id: null,
    });

    setExternalUserSelected({
      nombre: 'Seleccione un usuario',
      id: null,
    });

    setUserSelected({
      nombre: 'Seleccione un usuario generador',
      id: null,
      esVip: 2,
    });
    setBillingUserSelected({ nombre: 'Seleccione usuario facturacion', id: null });

    getDataTable();
    getAllStatesService();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // use Hook of language v2
  const { formatterText, fillAtLeastOne } = useLangv2();

  // titles table
  const titlesTable = [
    formatterText('table.title.service.ticket.number', '# Ticket del servicio'),
    formatterText('table.title.expedient', 'Expediente'),
    formatterText('table.title.princial.client.name', 'Nombre del cliente principal'),
    formatterText('table.title.client.id', 'Identificación'),
    formatterText('table.title.princial.client.phone', 'Telefono del cliente principal'),
    formatterText('table.title.user.name', 'Nombre de usuario'),
    formatterText('text.phone', 'Teléfono del usuario'),    
    formatterText('table.title.date.hour.meet', 'Fecha y hora de la cita'),
    formatterText('tech.assigned', 'Técnico asignado'),
    formatterText('p.activities.associated', 'Actividades asociadas'),   
    formatterText('table.title.city', 'Ciudad'),
    formatterText('table.title.address', 'Dirección'),
    formatterText('table.title.category.service', 'Categoría servicio'),
    formatterText('table.title.type.service', 'Tipo de servicio'),
    formatterText('table.title.state.service', 'Estado del servicio'),
    formatterText('table.title.special.service', 'Servicio especial'),
    formatterText('text.shedule.create.date', 'Fecha y hora de creación del servicio'),
    formatterText('table.actions', 'Acciones'),
  ];

  // get data from the table
  const getDataTable = () => {
    let idEmpleado = JSON.parse(localStorage.getItem('userData'))?.idEmpleado?.idEmpleado || '';
    let idAsesorCliente =
      JSON.parse(localStorage.getItem('userData'))?.idAsesorCliente?.idAsesor || '';
    if (idEmpleado !== '') {
      idEmpleado = parseInt(idEmpleado);
    }
    if (idAsesorCliente !== '') {
      idAsesorCliente = parseInt(idAsesorCliente);
    }
    const QUERY = `idEmpleado=${idEmpleado}&idAsesorCliente=${idAsesorCliente}`;
    setLoadingProgress(true);

    getAll(endpoints.technicalServices.getAll24Hrs(QUERY)).then((data) => {
      let newArray = [];

      data.forEach((item) => handleStructureItems(newArray, item));

      const sortedArray = SortDataByDate(newArray, 'desc');
      setDataTable(sortedArray);
      // show loading
      setLoadingProgress(false);

      setServices(sortedArray);
    });
  };

  // this function structure the items of the table
  const handleStructureItems = (newArray, item) => {   
    const timeZone = 'America/Bogota';

    const fechaCita = new Date(item.fechaCita);
    const fechaCreacion = new Date(item.fechaCreacion);

    try {
      // client phone
      let clientName = 'No asignado';
      let clientPhone = 'No asignado';
      // user phone
      let userName = 'No asignado';
      let userPhone = 'No asignado';

      let documentClient = 'No asignado';
      let documentUser = 'Usuario';

      if (item.idGeneradorCliente) {
        clientName = item.idGeneradorCliente.nombreRazonSocial;
        clientPhone = item.idGeneradorCliente.telefono;
        documentClient = item.idGeneradorCliente.identificacion;
      }

      if (item.idUsuario) {        
        userName = `${item.idUsuario.primerNombre + ' ' + item.idUsuario.primerApellido}`;
        userPhone = item.idUsuario.telefono;
        documentUser = 'No asignado';
      }

      // show technical assign
      let techAssing = 'Ninguno';

      if (item?.idTecnico !== null && item?.idTecnico !== undefined) {
        if (item.idTecnico.idTercero !== null) {
          techAssing = 'Avisar a greg codigo: ST';
        } else if (item.idTecnico.idEmpleado !== null) {
          const TECH = item.idTecnico.idEmpleado;
          techAssing = `${TECH.primerNombre} ${TECH.primerApellido} - ${TECH.identificacion}`;
        }
      }

      newArray.push({
        id: item.idServicio,
        nombre: item.ticket,
        expediente: item.expediente,
        nombreCliente: clientName,
        documentClient,
        telefonoCliente: clientPhone,
        userName,
        userPhone: userPhone.toString(),
        fechaHoraCita: dateFormat(fechaCita, 'yyyy/mm/dd ' + item.idHoraCita.hora + ':00 TT', {
          timeZone,
        }),
        techAssing,
        activities: 'N/A',
        city: item.idDireccion.idSector.idMunicipio.nombre,
        address: item.idDireccion.direccion,
        categoryService: item.idTipoServicio.idCategoriaServicio.nombre,
        typeService: item.idTipoServicio.nombre,
        stateService: item.idEstadoServicio.nombre,
        special: item.especial === 1 ? 'Si' : 'No',
        datetimeCreation: dateFormat(fechaCreacion, 'yyyy/mm/dd - HH:MM TT', { timeZone }),
        objeto: { ...item },
      });
    } catch (error) {
      console.log('Structure items: ', error);
    }
  };

  const handleChange = (e) => {
    const value = e.target.value;
    if (value.match('^[a-zA-Z0-9 ñáéíóúÁÉÍÓÚÑ]*$') != null) {
      setFormData({ ...formData, [e.target.name]: e.target.value.trim() });
      setInputValue(value);

      if (value.length >= 3) {
        setShowAutocomplete(true);
      } else {
        setShowAutocomplete(false);
      }
    }
  };
  const handleAutocompleteSelect = (option) => {
    setFormData({ ...formData, identificacion: option });
    setInputValue(option);
    setShowAutocomplete(false);
  };

  // Handle to clear the select
  const handlerClear = (e) => {
    e.preventDefault();
    setShow(!show);

    // Clear selects
    setSelectValues({
      nombre_cliente: {
        id: null,
        label: '',
      },
      idDepartamento: {
        id: null,
        label: '',
      },
      nombre_usuario: {
        id: null,
        label: '',
      },
      idTecnico: {
        id: null,
        label: '',
      },
      idTipoServicio: {
        id: null,
        label: '',
      },
      idEstadoServicio: {
        id: null,
        label: '',
      },
    });
    // clear Dates
    setDates({
      rangoFechaCitaInicio: null,
      rangoFechaCitaFin: null,
      rangoFechaCreacionInicial: null,
      rangoFechaCreacionFinal: null,
      rangoValorHoraInicial: null,
      rangoValorHoraFinal: null,
    });
    setFilterBill({
      billId: null,
      label: '',
    });

    // Clear inputs
    setFormData(new ServiceType());
    // fill the table
    getDataTable();
    // clear to suggestions selects
    setSelectValue({
      id: null,
      label: '',
    });
  };

  const handleFechaCreacionInicial = (date) => {
    setDates((prevState) => ({
      ...prevState,
      ...date,
    }));
  };

  const handleFechaCreacionFinal = (date) => {
    setDates((prevState) => ({
      ...prevState,
      ...date,
    }));
  };

  const handleFechaCitaInicioChange = (date) => {
    setDates((prevState) => ({
      ...prevState,
      ...date,
    }));
  };
  const handleFechaCitaFinChange = (date) => {
    setDates((prevState) => ({
      ...prevState,
      ...date,
    }));
  };

  // data of the table
  const [selectedSearch, setSearchSelected] = useState([
    {
      typeService: [],
      techinicals: [],
      clientsAssociate: [],
      users: [],
    },
  ]);

  useEffect(() => {
    getAllClientsToAssociate();
    getAllUsers();
    getAllTypeServices();
    getAllTechs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // get all type services to the select
  const getAllTypeServices = () => {
    getAll(endpoints.typeService.getAllTypeService).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            id: item.idTipoServicio,
            label: `${item.nombre} - ${item.codigo}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        typeService: newArray,
      }));
    });
  };

  const [listIdentification, setListIdentification] = useState([]);
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [inputValue, setInputValue] = useState('');

  // get all techs to the select
  const getAllTechs = () => {
    getAll(endpoints.services.getAllTechActives).then((data) => {
      // create new array
      const newArray = [];
      const identifications = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        newArray.push({
          id: item.idTecnico,
          label: `${item.nombre} ${item.identificacion}`,
        });
        identifications.push(item.identificacion);
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        techinicals: newArray,
      }));
      setListIdentification((prev) => ({
        ...prev,
        identification: identifications,
      }));
    });
  };

  // get all clients to the select
  const getAllClientsToAssociate = () => {
    getAll(endpoints.clients.getAllClients).then((data) => {
      // create new array
      const newArray = [
        {
          id: 0,
          label: 'Ninguno',
        },
      ];
      const identifications = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            id: item.idCliente,
            label: `${item.nombreRazonSocial}`,
          });
          identifications.push(item.identificacion);
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        clientsAssociate: newArray,
      }));
      setListIdentification((prev) => ({
        ...prev,
        identification: identifications,
      }));
    });
  };

  // get all users to the select
  const getAllUsers = () => {
    getAll(endpoints.userServices.getAll)
      .then((data) => {
        // console.log("get all users::: ", res);
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        data.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              id: item.idUsuarioServicio,
              label: `${item.primerNombre} ${item.segundoNombre} ${item.primerApellido}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          users: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // this function show if the table has data or not within the last 24 hours
  const determinateData = () => {
    if (dataTable.length > 0) {
      return (
        <FormattedMessage id="table.name.search.service" defaultMessage="Servicios">
          {(placeholder) =>
            permittedActions.consultar && (
              <DynamicTable
                titles={titlesTable}
                pageName={PAGE_NAMES.Servicios}
                getData={getDataTable}
                routeToEdit={paths.updateService}
                canModify={permittedActions.editar}
              />
            )
          }
        </FormattedMessage>
      );
    } else {
      return (
        <>
          {permittedActions.consultar && (
            <FormattedMessage
              id="text.services.no.data"
              defaultMessage="No hay servicios en las últimas 24 horas o no se encontraron coincidencias en la búsqueda."
            />
          )}
        </>
      );
    }
  };

  // show loader or error
  const determinateLoader = () => {
    if (error) {
      return displayMessage(
        'error',
        'Ha ocurrido un error, intentalo más tarde.',
        'toast.error.general',
      );
    } else {
      return <DisplayProgress />;
    }
  };

  const dateFormatWithoutSeconds = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}`;
  };

  const searchAdvance = (e) => {
    e.preventDefault();
    let idEmpleado = JSON.parse(localStorage.getItem('userData'))?.idEmpleado?.idEmpleado || '';
    let idAsesorCliente =
      JSON.parse(localStorage.getItem('userData'))?.idAsesorCliente?.idAsesor || '';
    if (idEmpleado !== '') {
      idEmpleado = parseInt(idEmpleado);
    }
    if (idAsesorCliente !== '') {
      idAsesorCliente = parseInt(idAsesorCliente);
    }
    const QUERY = `idEmpleado=${idEmpleado}&idAsesorCliente=${idAsesorCliente}`;

    let RFCF =
      dates.rangoFechaCitaInicio && dates.rangoFechaCitaInicio.rangoFechaCitaInicio instanceof Date
        ? dateFormatWithoutSeconds(dates.rangoFechaCitaInicio.rangoFechaCitaInicio)
        : null;

    let RFCI =
      dates.rangoFechaCitaFin && dates.rangoFechaCitaFin.rangoFechaCitaFin instanceof Date
        ? dateFormatWithoutSeconds(dates.rangoFechaCitaFin.rangoFechaCitaFin)
        : null;

    // If RFCF and RFCI are instances of Date, convert them to "hh:mm" format
    if (RFCF instanceof Date) {
      RFCF = dateFormat(RFCF, 'HH:MM');
    } else {
      RFCF = null;
    }

    if (RFCI instanceof Date) {
      RFCI = dateFormat(RFCI, 'HH:MM');
    } else {
      RFCI = null;
    }

    let findRangoFechaCitaFin;
    let findRangoFechaCitaInicio;
    if (RFCF && RFCI) {
      // Combine the date part ("yyyy-mm-dd") with the time part ("hh:mm")
      findRangoFechaCitaFin = `${dateFormatWithoutSeconds(
        dates.rangoFechaCitaFin.rangoFechaCitaFin,
      )} ${RFCF}`;
      findRangoFechaCitaInicio = `${dateFormatWithoutSeconds(
        dates.rangoFechaCitaInicio.rangoFechaCitaInicio,
      )} ${RFCI}`;
    }

    const HOURS = JSON.parse(localStorage.getItem('hours'));

    // find the valor of the hour with the key hora
    let findValorHoraInicial = HOURS?.find((item) => item.hora === findRangoFechaCitaInicio);

    let findValorHoraFinal = HOURS.find((item) => item.hora === findRangoFechaCitaFin);

    let rangoFechaCitaFin = dates.rangoFechaCitaFin
      ? dateFormatWithoutSeconds(dates.rangoFechaCitaFin)
      : null;
    let rangoFechaCitaInicio = dates.rangoFechaCitaInicio
      ? dateFormatWithoutSeconds(dates.rangoFechaCitaInicio)
      : null;

    let rangoFechaCreacionInicial = dates.rangoFechaCreacionInicial
      ? dateFormatWithoutSeconds(dates.rangoFechaCreacionInicial)
      : null;
    let rangoFechaCreacionFinal = dates.rangoFechaCreacionFinal
      ? dateFormatWithoutSeconds(dates.rangoFechaCreacionFinal)
      : null;

    let DATA = {
      ticket: formData.ticket === '' ? null : formData.ticket,
      expediente: formData.expediente === '' ? null : formData.expediente,
      idCliente: selectValues.nombre_cliente.id,
      identificacionCliente: formData.identificacion === '' ? null : formData.identificacion,
      // idUsuario: selectValues.nombre_usuario.id,
      idUsuario: selectValues.nombre_usuario ? selectValues.nombre_usuario.id : null,
      telefonoUsuario: formData.telefono_usuario === '' ? null : formData.telefono_usuario,
      rangoFechaCitaInicio,
      rangoFechaCitaFin,
      rangoValorHoraInicial: findValorHoraInicial ? findValorHoraInicial.valor : null,
      rangoValorHoraFinal: findValorHoraFinal ? findValorHoraFinal.valor : null,
      rangoFechaCreacionInicial: rangoFechaCreacionInicial,
      rangoFechaCreacionFinal: rangoFechaCreacionFinal,
      idTecnico: selectValues.idTecnico.id,
      idTipoServicio: selectValues.idTipoServicio.id,
      idEstadoServicio: selectValues.idEstadoServicio.id,
      facturaAsociada: filterBill.value || filterBill.value === 0 ? filterBill.value : null,
    };

    // iterate each value of the object and check if it is null
    if (Object.values(DATA).every((item) => item === null)) {
      fillAtLeastOne();
    } else {
      setLoadingProgress(true);
      DATA = {
        ...DATA,
        estado: 1,
      };

      addItem(endpoints.technicalServices.advancedSearchWithTech(QUERY), DATA).then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        setLoadingProgress(false);
      });
    }
  };

  return (
    <>
      <section className="table-container">
        <section className="userOptions">
          {permittedActions.consultar && (
            <Search
              placeholder={formatterText('input.placeholder.search.service.table')}
              width="50%"
            />
          )}

          {permittedActions.crear && (
            <Link to={paths.createService}>
              <button className="btn-add">
                <FormattedMessage id="text.create.service" defaultMessage="Crear Servicio" />
              </button>
            </Link>
          )}

          {permittedActions.exportar && (
            <ExportJsonFile
              moduleName={'Servicios'}
              userName={
                JSON.parse(localStorage.getItem('userData')).usuario
                  ? JSON.parse(localStorage.getItem('userData')).usuario
                  : 'ADMIN'
              }
              dataTable={searchResults}
            />
          )}
        </section>

        <section className="advance-search">
         {permittedActions.consultar && ( <p
            onClick={(e) => {
              e.preventDefault();
              setShow(!show);
            }}
          >
            {show ? (
              <MdKeyboardArrowDown size={22} color="gray" cursor="pointer" />
            ) : (
              <MdKeyboardArrowRight size={22} color="gray" cursor="pointer" />
            )}
            <FormattedMessage
              id="text.action.show.advanced.search"
              defaultMessage="Búsqueda avanzada"
            />
          </p>)}
        </section>
        {/* advanced Seacrh */}
        {show && permittedActions.consultar ? (
          <form style={{ marginBottom: '30px', padding: '0' }}>
            <section className={grid.grid}>
              {/* Ticket input */}
              <label>
                <input
                  style={{ marginLeft: '10px' }}
                  className="input-primary"
                  type="text"
                  name="ticket"
                  placeholder={formatterText('text.ticket', 'Ticket')}
                  maxLength="45"
                  onChange={handleChange}
                  value={formData.ticket}
                />
              </label>
              {/* Expendient input */}
              <label>
                <input
                  style={{ marginLeft: '10px' }}
                  className="input-primary"
                  type="text"
                  name="expediente"
                  placeholder={formatterText('text.expedient', 'Expediente')}
                  maxLength="45"
                  onChange={handleChange}
                  value={formData.expediente}
                />
              </label>
              {/* Phone input */}
              <label>
                <input
                  style={{ marginLeft: '10px' }}
                  className="input-primary"
                  type="text"
                  name="telefono_usuario"
                  placeholder={formatterText('text.phone', 'Teléfono del usuario')}
                  maxLength="45"
                  onChange={handleChange}
                  value={formData.telefono_usuario}
                />
              </label>
              {/* ID input */}
              <div>
                <label>
                  <input
                    style={{ marginLeft: '10px' }}
                    className="input-primary"
                    type="text"
                    name="identificacion"
                    placeholder={formatterText('table.title.client.id')}
                    maxLength="45"
                    onChange={handleChange}
                    value={formData.identificacion}
                    autocomplete="off"
                  />
                </label>
                {showAutocomplete && (
                  <div>
                    {listIdentification.identification
                      .filter((opcion) => opcion.includes(inputValue))
                      .map((opcion) => (
                        <div key={opcion} onClick={() => handleAutocompleteSelect(opcion)}>
                          {opcion}
                        </div>
                      ))}
                  </div>
                )}
              </div>

              <SelectComboBox
                name="nombre_usuario"
                selectValue={selectValues.nombre_usuario}
                setterFunction={(nombre_usuario) =>
                  setSelectValues({ ...selectValues, nombre_usuario })
                }
                val={val}
                data={selectedSearch.users}
                placeholder={formatterText('input.placeholder.user.name')}
              />
              <SelectComboBox
                name="nombre_cliente"
                selectValue={selectValues.nombre_cliente}
                setterFunction={(nombre_cliente) =>
                  setSelectValues({ ...selectValues, nombre_cliente })
                }
                val={val}
                data={selectedSearch.clientsAssociate}
                placeholder={formatterText('text.client.name')}
              />
              {/* Username technical */}

              <SelectComboBox
                name="idTecnico"
                selectValue={selectValues.idTecnico}
                setterFunction={(idTecnico) => setSelectValues({ ...selectValues, idTecnico })}
                val={val}
                data={selectedSearch.techinicals}
                placeholder={formatterText('input.placeholder.principal.tech')}
              />
              {/* Username technical */}
              <SelectComboBox
                name="idTipoServicio"
                selectValue={selectValues.idTipoServicio}
                setterFunction={(idTipoServicio) =>
                  setSelectValues({ ...selectValues, idTipoServicio })
                }
                data={selectedSearch.typeService}
                placeholder={formatterText('input.placeholder.service.type')}
              />
              {/* State service */}
              <SelectComboBox
                name="idEstadoServicio"
                selectValue={selectValues.idEstadoServicio}
                setterFunction={(idEstadoServicio) =>
                  setSelectValues({ ...selectValues, idEstadoServicio })
                }
                data={allStateService}
                placeholder={formatterText('input.placeholder.service.state')}
              />

              <span
                style={{
                  fontSize: '0.9rem',
                  color: 'var(--text-primary)',
                  fontWeight: 'bold',
                  alignSelf: 'center',
                  marginLeft: '10px',
                }}
              >
                {formatterText('label.text.appointment.date')}
              </span>
              {/* Date start input */}
              <label>
                <DateTimePicker
                  name="rangoFechaCitaInicio"
                  placeholder={formatterText('text.start')}
                  value={selectValues.rangoFechaCitaInicio}
                  onChange={(data) => handleFechaCitaInicioChange(data)}
                />
              </label>
              <label>
                <DateTimePicker
                  name="rangoFechaCitaFin"
                  placeholder={formatterText('text.end')}
                  value={selectValues.rangoFechaCitaFin}
                  onChange={(data) => handleFechaCitaFinChange(data)}
                />
              </label>
              <span
                style={{
                  fontSize: '0.9rem',
                  color: 'var(--text-primary)',
                  fontWeight: 'bold',
                  alignSelf: 'center',
                  marginLeft: '10px',
                }}
              >
                {formatterText('label.text.appointment.creation')}
              </span>
              {/* Date start input */}
              <label>
                <DateTimePicker
                  name="rangoFechaCreacionInicial"
                  placeholder={formatterText('text.start')}
                  value={selectValues?.rangoFechaCreacionInicial ?? ''}
                  onChange={(data) => handleFechaCreacionInicial(data)}
                />
              </label>
              <label>
                <DateTimePicker
                  name="rangoFechaCreacionFinal"
                  placeholder={formatterText('text.end')}
                  value={selectValues?.rangoFechaCreacionFinal ?? ''}
                  onChange={(data) => handleFechaCreacionFinal(data)}
                />
              </label>
              <span
                style={{
                  fontSize: '0.9rem',
                  color: 'var(--text-primary)',
                  fontWeight: 'bold',
                  alignSelf: 'center',
                  marginLeft: '10px',
                }}
              >
                {formatterText('label.text.billing.type')}
              </span>
              <label
                style={{
                  marginTop: '10px',
                }}
              >
                <SelectComboBox
                  name="billId"
                  data={[
                    {
                      label: formatterText('input.placeholder.all.bill'),
                      value: 0,
                    },
                    {
                      label: formatterText('input.placeholder.with.bill'),
                      value: 1,
                    },
                    {
                      label: formatterText('input.placeholder.without.bill'),
                      value: 2,
                    },
                  ]}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  dataValue={filterBill}
                  setterFunction={setFilterBill}
                  isRequired={false}
                />
              </label>
            </section>
            <section className={grid['display-btn-advanced-search']}>
              <button
                className="btn-search"
                onClick={(e) => searchAdvance(e)}
                disabled={loadingProgress}
              >
                {loadingProgress ? (
                  <FormattedMessage id="btn.loading" defaultMessage="Cargando..." />
                ) : (
                  <FormattedMessage id="btn.search" defaultMessage="Buscar" />
                )}
              </button>
              <button className="btn-clear-form" onClick={(e) => handlerClear(e)}>
                <FormattedMessage id="btn.clean" defaultMessage="Limpiar" />
              </button>
            </section>
          </form>
        ) : null}

        {!loading && services !== null ? determinateData() : determinateLoader()}
      </section>
    </>
  );
};

export default ServiceTable;
