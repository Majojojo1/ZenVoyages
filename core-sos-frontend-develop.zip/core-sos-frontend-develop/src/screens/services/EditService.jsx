import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useLangv2 from 'hooks/useLangv2';
import useProgress from 'hooks/useProgress';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import SelectorGrid from 'common/selects/SelectorGrid';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import CustomAlert from 'components/CustomAlert';
import {
  MdOutlineAddCircleOutline,
  MdOutlineFileCopy,
  MdOutlineRemoveCircleOutline,
} from 'react-icons/md';
import { Modal } from 'react-responsive-modal';
// Import Tabs
import { TableMinimalContext } from 'context/TableMinimalContext';
import NQR from './ExtraTabs/NQR';
import Precautions from './ExtraTabs/Precautions';
import Reports from './ExtraTabs/Reports';
import ProductServices from './ExtraTabs/TabFourth/ProductServices';
import TechnicalAssign from './ExtraTabs/TabOne/TechnicalAssign';
import Activities from './ExtraTabs/TabTwo/Activities';
import Trazabilidad from './ExtraTabs/Trazabilidad';
// Import Modals
import ExternalUserModal from './Modals/ExternalUserModal';
import ClientModal from './Modals/ModalClientSearch';
import ModalSearch from './Modals/ModalSearch';
import Quotation from './Modals/Quotation';
// Import libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import hours from './hours';
import hoursWithValue from './hoursWithValue';
// // Import services
import endpoints from 'services/api';
import { addItem, deleteItem, getAll, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';
// Import Styles
import { TimePicker } from '@material-ui/pickers';
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { ACTIVITIES } from 'constants/lang/services/services/activities';
import { COLLECTIONS } from 'constants/lang/services/services/collections';
import { REPORTS } from 'constants/lang/services/services/reports';
import { usePermissionContext } from 'context/PermissionContext';
import usePermission from 'hooks/usePermission';
import { isNull, sortBy } from 'lodash';
import moment from 'moment';
import 'react-responsive-modal/styles.css';
import 'styles/services.css';
import InvoiceTable from './ExtraTabs/invoiceTable';
import ModalBillingUser from './Modals/ModalBillingUser';
import styles from './Service.module.css';
import { valueSetter } from './utils/string';

const EditService = () => {
  const hashCanAnulate = {
    1: true,
    2: true,
    3: true,
    4: true,
    5: true,
    6: true,
    7: false,
  };

  const hashReopenService = {
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    7: false,
    8: true,
    9: true,
  };

  // use Hook of language v2
  const {
    formatterText,
    errorProcess,
    showSB,
    showPermissionDenied,
    customSB,
    handleRequestError,  
    updatedItem,
    successRemoveItem,
  } = useLangv2();
  // Helps to loading data table
  const { loadingProgress, setLoadingProgress, DisplayProgress } = useProgress();
  // Address Data
  const [addressData, setAddressData] = useState('Loading...');
  // Formiz object
  const myForm = useForm();
  // get id from the url
  const { id } = useParams();
  // getData from the client or exteralUser select
  const {
    clientSelected,
    listActivities,
    externalUserSelected,
    userSelected,
    billingUserSelected,
    setBillingUserSelected,
    setExternalUserSelected,
    setClientSelected,
    setUserSelected,
    setServiceCloneData,
    idEstadoServicio,
    setIdEstadoServicio,
    serviceCloneData,
  } = useContext(AppContext);
  const navigate = useNavigate();
  // Manage axios requests
  const { fetchData, COOKIE_USER, TOKEN } = useAxios();
  const [idBillingService, setIdBillingService] = useState(0);

  // auxService data
  const [auxService, setAuxService] = useState([]);

  // permissions
  const [searchAutomatic, setSearchAutomatic] = useState(false);
  const [manualSearch, setManualSearch] = useState(false);
  const { permissions, permissionPerModule } = usePermission();

  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      // news
      clients: [],
      address: [],
      users: [],
      typeService: [],
      communicationMedia: [],
      timeMeeting: [],
      communicationChannel: [],
      typeServiceByTech: [],
    },
  ]);

  const [ppTech, setPpTech] = useState({
    idtech: -1,
    label: '',
  });

  // Helps to save the ids and labels of the selects data
  const [selectIds, setSelectIds] = useState({
    idGeneradorCliente: {
      value: 0,
      label: '',
    },
    idUsuario: {
      value: 0,
      label: '',
    },
    idDireccion: {
      value: 0,
      label: '',
    },
    idTipoServicio: {
      value: 0,
      label: '',
    },
    idMedioComunicacion: {
      value: 0,
      label: '',
    },
    idHoraCita: {
      value: 0,
      label: '',
    },
    idCanalComunicacion: {
      value: 0,
      label: '',
    },
  });

  // Stare of date picker
  const [time, setTime] = useState(new Date());

  const [archivos, setCurrentFiles] = useState([]);

  const { setSelectedTable } = useContext(TableMinimalContext);

  // checkouts states
  const [checkoutValidations, setCheckoutValidations] = useState({
    equalsExp: false,
    specialService: false,
  });
  // permissions access
  const { access, setAccess, permittedActions } = usePermissionContext();
  const [NQRAccess, setNQRAccess] = useState([]);
  // permissions
  const [activityProgress, setActivityProgress] = useState(false);
  const [changeState, setChangeState] = useState(false);
  const [activityStart, setActivityStart] = useState(false);
  const [serviceChangeTS, setServiceChangeTS] = useState(false);
  const [changeStatusNQR, setChangeStatusNQR] = useState(false);
  const [canDeleteNQR, setCanDeleteNQR] = useState(false);
  const [canDeleteAnsNQR, setCanDeleteAnsNQR] = useState(false);
  const [activityNoTechEnd, setActivityNoTechEnd] = useState(false);
  const [canReopen, setCanReopen] = useState(false);
  const [openBillingUser, setOpenBillingUser] = useState(false);

  // Modal config
  const [openClient, setOpenClient] = useState(false);
  const [openExternalUser, setOpenExternalUser] = useState(false);
  const [quotation, setQuotation] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);

  const onToggleBillingUser = () => setOpenBillingUser(!openBillingUser);

  const [isGenClient, setIsGenClient] = useState(true);

  const [eventData, setEventData] = useState({
    fechaCita: '',
    idHoraCita: '',
  });

  // State loader
  const [loadingValidation, setLoadingValidation] = useState(false);

  const [originalData, setOriginalData] = useState({
    idTipoServicio: {
      value: '',
      id: -1,
    },
  });

  const onCloseClient = () => setOpenClient(false);
  const onCloseExternalUser = () => setOpenExternalUser(false);
  const onOpenSearch = () => setOpenSearch(true);
  const onCloseSearch = () => setOpenSearch(false);
  const onOpenQuotation = () => setQuotation(true);
  const onCloseQuotation = () => setQuotation(false);
  const [allStateService, setAllStateService] = useState([]);
  const [expedient, setExpedient] = useState('');
  const [ticket, setTicket] = useState('');
  const [showInvoice, setShowInvoice] = useState(false);
  const now = new Date();

  const getAllStatesService = () => {
    getAll(endpoints.services.getAllStates).then((data) => {
      const resp = data.map((item) => ({
        id: item.idEstadoServicio,
        label: item.nombre,
      }));
      const sorted = sortBy(resp, 'id');
      setAllStateService(sorted);
    });
  };

  const permissionsAccess = () => {
    const filterNQR = permissionPerModule(MODULES_NAME.service.nqr);
    const filterAccess = permissionPerModule(MODULES_NAME.service.principal);
    setNQRAccess(filterNQR);
    setAccess([...filterAccess]);
  };

  const validationData = () => {
    access.forEach((element) => {
      switch (element.nombrePermiso) {
        case 'CAMBIAR_TIPO_SERVICIO':
          setServiceChangeTS(true);
          break;
        case 'CAMBIAR_ESTADO':
          setChangeState(true);
          break;
        case 'REABRIR':
          setCanReopen(true);
          break;
        case 'BUSQUEDA_MANUAL':
          setManualSearch(true);
          break;
        case 'BUSQUEDA_AUTOMATICA':
          setSearchAutomatic(true);
          break;
        default:
          break;
      }
    });
    validationNQR();
  };

  const validationNQR = () => {
    NQRAccess.forEach((element) => {
      switch (element.nombrePermiso) {
        case 'CAMBIAR_ESTADO':
          setChangeStatusNQR(true);
          break;
        case 'ELIMINAR':
          setCanDeleteNQR(true);
          break;
        case 'ELIMINAR_RESPUESTA':
          setCanDeleteAnsNQR(true);
          break;
        default:
          break;
      }
    });
  };

  // obtiene los datos de facturacion
  const getBillingData = () => {
    getItemById(endpoints.services.getBillingUserByService, id)
      .then((res) => {
        res.forEach((item) => {
          if (item) {
            const billingClient = item.idCliente;
            setIdBillingService(item.idServicioFacturacion);
            const name = billingClient
              ? `${billingClient.nombreRazonSocial}-${billingClient.identificacion}-${billingClient.correo}`
              : formatterText(
                  'placeholder.user.was.not.selected',
                  'No fue seleccionado ningún usuario',
                );
            setBillingUserSelected({
              nombre: name,
              id: billingClient?.idCliente || null,
            });
          }
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const dataFact = (dataJson) => {
    setExpedient(dataJson.expediente);
    setTicket(dataJson.ticket);
  };
  // get data from the localStorage
  const getDataToUpdate = () => {
    console.log('PERMISOS', permittedActions);
    getItemById(endpoints.services.getServiceById, id)
      .then((res) => {
        setAuxService(res);

        let dataJson = res.servicio;
        setIdService(id);
        setIdEstadoServicio(dataJson.idEstadoServicio.idEstadoServicio);

        setActivityProgress(dataJson.idEstadoServicio.idEstadoServicio === 6);

        let dataClient = '';
        let dataUser = '';
        let dataSystemUser = '';
        let dataUserId = null;
        let dataClientId = null;
        let dataGenUserId = null;

        let controlGenerator = true;

        if (dataJson.idGeneradorCliente !== null) {
          dataClient = `${dataJson.idGeneradorCliente.nombreRazonSocial} - ${dataJson.idGeneradorCliente.identificacion}`;
          dataClientId = dataJson.idGeneradorCliente.idCliente;
          if (dataJson.idUsuario) {
            dataUser = `${dataJson.idUsuario.primerNombre} ${dataJson.idUsuario.primerApellido} - ${dataJson.idUsuario.telefono} `;
            dataUserId = dataJson.idUsuario.idUsuarioServicio;
          } else {
            dataUser = formatterText(
              'placeholder.user.was.not.selected',
              'No fue seleccionado ningún usuario',
            );
          }
        } else {
          // this the data of the system user
          dataSystemUser = `${dataJson.idGeneradorUsuario.primerNombre} ${dataJson.idGeneradorUsuario.primerApellido} - ${dataJson.idGeneradorUsuario.telefono}`;
          dataGenUserId = dataJson.idGeneradorUsuario.idUsuarioServicio;
          if (dataJson.idUsuario) {
            dataUser = `${dataJson.idUsuario.primerNombre} ${dataJson.idUsuario.primerApellido} - ${dataJson.idUsuario.telefono} `;
            dataUserId = dataJson.idUsuario.idUsuarioServicio;
          } else {
            dataUser = formatterText(
              'placeholder.user.was.not.selected',
              'No fue seleccionado ningún usuario',
            );
          }
          controlGenerator = false;
        }

        // set Address
        setAddressData(
          `${dataJson.idDireccion.direccion} - ${dataJson.idDireccion.datosAdicionales}`,
        );

        dataFact(dataJson);

        // set form
        setFormItem({
          ...dataJson,
          descripcion: dataJson.descripcion,
          expediente: dataJson.expediente,
          idGeneradorCliente: dataClient,
          idDireccion: dataJson.idDireccion.direccion,
          idTipoServicio: `${dataJson.idTipoServicio.nombre} - ${dataJson.idTipoServicio.idCategoriaServicio.nombre}`,
          idHoraCita: dataJson.idHoraCita.hora,
          idUsuario: dataUser,
        });
        setTime(moment(dataJson.idHoraCita.hora, 'HH:mm').toDate());
        const padre = res.servicioPadre === null ? [] : [res.servicioPadre];
        const hijos = res.servicioHijo === null ? [] : res.servicioHijo;
        // set clone info
        setFormParent(padre);
        setFormChildrens(hijos);

        // If is special service
        let specialService = dataJson.especial === 1;

        if (controlGenerator) {
          setIsGenClient(controlGenerator);
          setClientSelected({
            nombre: dataClient,
            id: dataClientId,
            esVip: specialService ? 1 : 2,
          });
        } else {
          setIsGenClient(controlGenerator);
          setUserSelected({
            nombre: dataSystemUser,
            id: dataGenUserId,
            esVip: specialService ? 1 : 2,
          });
        }

        // set external user
        setExternalUserSelected({
          nombre: dataUser,
          id: dataUserId,
        });

        // set meet date
        setEventData({
          fechaCita: dataJson.fechaCita.split('T')[0],
        });

        // Checks sect
        setCheckoutValidations((prev) => {
          return {
            ...prev,
            specialService: specialService,
          };
        });

        let equalsExp = dataJson.expediente === dataJson.ticket;
        setCheckoutValidations((prev) => {
          return {
            ...prev,
            equalsExp: equalsExp,
          };
        });

        setOriginalData({
          ...originalData,
          idTipoServicio: {
            value: dataJson.idTipoServicio.idTipoServicio,
            id: dataJson.idTipoServicio.idTipoServicio,
          },
        });

        setSelectIds({
          ...selectIds,
          idDireccion: dataJson.idDireccion.idDireccion,
          idTipoServicio: {
            // value: dataJson.idTipoServicio.idTipoServicio,
            // label: dataJson.idTipoServicio.idTipoServicio,
            value: `${dataJson.idTipoServicio.idTipoServicio}-${dataJson.idTipoServicio.idCategoriaServicio.idCategoriaServicio}`,
            label: `${dataJson.idTipoServicio.nombre} - ${dataJson.idTipoServicio.idCategoriaServicio.nombre}`,
          },
          idHoraCita: {
            value: dataJson.idHoraCita.idHora,
            id: dataJson.idHoraCita.idHora,
          },
          idMedioComunicacion: {
            value: `${dataJson.idMedioComunicacion.nombre} - ${dataJson.idMedioComunicacion.codigo}`,
            id: dataJson.idMedioComunicacion.idMedioComunicacion,
          },
          idCanalComunicacion: {
            value: `${dataJson.idCanalComunicacion.nombre} - ${dataJson.idCanalComunicacion.codigo}`,
            id: dataJson.idCanalComunicacion.idCanalComunicacion,
          },
        });

        setLoadingProgress(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // validate if the activities started
  const getActivitiesActive = () => {
    getItemById(endpoints.services.getActivitiesActiveByService, id).then((data) => {
      setActivityStart(data);
    });
  };

  const activitiesNoTechsEndeds = () => {
    getItemById(endpoints.services.getActivitiesNoTechsByService, id).then((data) => {
      setActivityNoTechEnd(data);
    });
  };

  const searchHour = (hour) => {
    // search in hours array the idHora that matches with the hour
    const idHora = hours.find((item) => item.hora === hour);
    return idHora.idHora;
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (values) => {
    const dateService = new Date(auxService.servicio.fechaCita).toISOString().split('T')[0];
    let especial = 0;
    if (clientSelected.esVip === 1) {
      especial = clientSelected.esVip === 1 ? 1 : 0;
    } else if (userSelected.esVip === 1) {
      especial = userSelected.esVip === 1 ? 1 : 0;
    }
    const { idTipoServicio: serviceType = {} } = selectIds;

    const serviceTypeId = Number(serviceType.value.split('-')[0] || '0');

    let data = {
      idServicio: parseInt(id),
      idDireccion: {
        idDireccion: selectIds.idDireccion,
      },
      idTipoServicio: {
        idTipoServicio: serviceTypeId,
      },
      descripcion: formItem.descripcion ? formItem.descripcion : '',
      idMedioComunicacion: {
        idMedioComunicacion: serviceCloneData.idMedioComunicacion.idMedioComunicacion,
      },
      idCanalComunicacion: {
        idCanalComunicacion: serviceCloneData.idCanalComunicacion.idCanalComunicacion,
      },
      fechaCita: eventData.fechaCita ? eventData.fechaCita : formItem.expediente,
      idHoraCita: {
        idHora: selectIds.idHoraCita.value,
      },
      fechaCitaFin: formItem.fechaCitaFin,
      idHoraCitaFin: {
        idHora: formItem.idHoraCitaFin.idHora,
      },
      expediente: checkoutValidations.equalsExp ? null : formItem.expediente,
      especial,
      idEstadoServicio: {
        idEstadoServicio: idEstadoServicio,
      },
      usuarioCreacion: formItem.usuarioCreacion,
      usuarioModificacion: COOKIE_USER,
      idServicioPadre: formItem.idServicioPadre,
      estado: formItem.estado,
      fechaCreacion: formItem.fechaCreacion,
      fechaModificacion: null,
      ticket: formItem.ticket,
    };

    // OPTION 1: GUSER where idGeneradorCliente are null
    if (userSelected.id !== null) {
      // OPTION 2:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select genUser and Externarl User
        data = {
          ...data,
          idGeneradorCliente: null,
          idGeneradorUsuario: {
            idUsuarioServicio: parseInt(userSelected.id),
          },
          idUsuario: {
            idUsuarioServicio: parseInt(externalUserSelected.id),
          },
        };
      } else {
        // Only select gen system user Option 1 only
        data = {
          ...data,
          idGeneradorCliente: null,
          idGeneradorUsuario: {
            idUsuarioServicio: parseInt(userSelected.id),
          },
          idUsuario: null,
        };
      }
    }
    // OPTION 3: GCLIENT + GUSER where idGeneradorUsuario is null
    else if (clientSelected.id !== null) {
      // OPTION 4:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select geClient and Externarl User
        data = {
          ...data,
          idGeneradorCliente: {
            idCliente: parseInt(clientSelected.id),
          },
          idGeneradorUsuario: null,
          idUsuario: {
            idUsuarioServicio: parseInt(externalUserSelected.id),
          },
        };
      } else {
        // Option 3: Only GenClient
        data = {
          ...data,
          idGeneradorCliente: {
            idCliente: clientSelected.id,
          },
          idGeneradorUsuario: null,
          idUsuario: null,
        };
      }
    } else {
      alert('Error to update service: notify admin');
    }
    //Only change type of service serviceTypeId
    if (idEstadoServicio != 1) {
      if (idEstadoServicio != 3) {
        if (
          originalData.idTipoServicio.id !== serviceTypeId &&
          (selectIds.idCanalComunicacion.id ===
            auxService.servicio.idCanalComunicacion.idCanalComunicacion ||
            selectIds.idMedioComunicacion.id ===
              auxService.servicio.idMedioComunicacion.idMedioComunicacion ||
            dateService === eventData?.fechaCita ||
            selectIds.idHoraCita.value === auxService.servicio.idHoraCita.idHora)
        ) {
          if (!activityStart) {
            customSB(
              'warning',
              'snackbar.warning.update.state.service',
              "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
            );
          } else {
            generateDateEnd(data);
          }
        }

        if (
          originalData.idTipoServicio.id !== serviceTypeId &&
          selectIds.idCanalComunicacion.id !==
            auxService.servicio.idCanalComunicacion.idCanalComunicacion &&
          selectIds.idMedioComunicacion.id !==
            auxService.servicio.idMedioComunicacion.idMedioComunicacion &&
          dateService !== eventData?.fechaCita &&
          selectIds.idHoraCita.value !== auxService.servicio.idHoraCita.idHora
        ) {
          if (!activityStart) {
            customSB(
              'warning',
              'snackbar.warning.update.state.service',
              "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
            );
          } else {
            generateDateEnd(data);
          }
        }

        if (
          dateService !== eventData?.fechaCita &&
          originalData.idTipoServicio.id === serviceTypeId &&
          (selectIds.idHoraCita.value !== auxService.servicio.idHoraCita.idHora ||
            selectIds.idCanalComunicacion.id !==
              auxService.servicio.idCanalComunicacion.idCanalComunicacion ||
            selectIds.idMedioComunicacion.id !==
              auxService.servicio.idMedioComunicacion.idMedioComunicacion)
        ) {
          if (!activityStart) {
            customSB(
              'warning',
              'snackbar.warning.update.state.service',
              "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
            );
          } else {
            generateDateEndByCalendar(data);
          }
        }

        if (
          (selectIds.idCanalComunicacion.id !==
            auxService.servicio.idCanalComunicacion.idCanalComunicacion ||
            selectIds.idMedioComunicacion.id !==
              auxService.servicio.idMedioComunicacion.idMedioComunicacion) &&
          dateService === eventData?.fechaCita &&
          selectIds.idHoraCita.value === auxService.servicio.idHoraCita.idHora &&
          originalData.idTipoServicio.id === serviceTypeId
        ) {
          putItem(data);
        }

        if (
          dateService !== eventData?.fechaCita &&
          originalData.idTipoServicio.id === serviceTypeId &&
          selectIds.idCanalComunicacion.id ===
            auxService.servicio.idCanalComunicacion.idCanalComunicacion &&
          selectIds.idMedioComunicacion.id ===
            auxService.servicio.idMedioComunicacion.idMedioComunicacion &&
          selectIds.idHoraCita.value === auxService.servicio.idHoraCita.idHora
        ) {
          if (!activityStart) {
            customSB(
              'warning',
              'snackbar.warning.update.state.service',
              "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
            );
          } else {
            generateDateEndByCalendar(data);
          }
        }

        if (
          selectIds.idHoraCita.value !== auxService.servicio.idHoraCita.idHora &&
          originalData.idTipoServicio.id === serviceTypeId &&
          selectIds.idCanalComunicacion.id ===
            auxService.servicio.idCanalComunicacion.idCanalComunicacion &&
          selectIds.idMedioComunicacion.id ===
            auxService.servicio.idMedioComunicacion.idMedioComunicacion &&
          dateService === eventData?.fechaCita
        ) {
          if (!activityStart) {
            customSB(
              'warning',
              'snackbar.warning.update.state.service',
              "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
            );
          } else {
            generateDateEndByCalendar(data);
          }
        }
        if (selectIds.idHoraCita.value !== auxService.servicio.idHoraCita.idHora) {
          generateDateEndByCalendar(data);
        }
      } else {
        customSB(
          'warning',
          'snackbar.warning.update.state.service.on.displacement',
          'No se puede actualizar el estado del servicio, debido a que se encuentra en desplazamiento',
        );
      }
    }

    if (billingUserSelected.id) {
      saveBillingUser();
    }

    if (idEstadoServicio == 1) {
      if (
        (selectIds.idCanalComunicacion.id !==
          auxService.servicio.idCanalComunicacion.idCanalComunicacion ||
          originalData.idTipoServicio.id !== serviceTypeId ||
          selectIds.idMedioComunicacion.id !==
            auxService.servicio.idMedioComunicacion.idMedioComunicacion) &&
        dateService === eventData?.fechaCita &&
        selectIds.idHoraCita.value === auxService.servicio.idHoraCita.idHora
      ) {
        putItem(data);
      }

      if (
        dateService !== eventData?.fechaCita ||
        selectIds.idHoraCita.value !== auxService.servicio.idHoraCita.idHora
      ) {
        generateDateEndByCalendar(data);
      }
    }
  };

  const generateDateEnd = (data) => {
    setLoadingValidation(true);
    customSB(
      'warning',
      'snackbar.warning.validate.risk.exist',
      'Calculando riesgos de imcumplimiento asociados, por favor espere...',
    );
    addItem(endpoints.services.generateEndDate, data)
      .then((response) => {
        const { idDireccion: direction = '', idTipoServicio: serviceType = {} } = selectIds;
        const [serviceTypeId = '', serviceTypeCategory = ''] = (serviceType?.value || '').split(
          '-',
        );
        const ADDRESS = auxService.servicio.idDireccion.idDireccion;
        const SECTOR = auxService.servicio.idDireccion.idSector.idSector;
        const MUNICIPALITY = auxService.servicio.idDireccion.idSector.idMunicipio.idMunicipio;
        const TYPE_SERVICE = parseInt(serviceTypeId);
        const CATEGORY_SERVICE = parseInt(serviceTypeCategory);

        const idHora = hoursWithValue.find((item) => item.idHora === formItem.idHoraCitaFin.idHora);
        const DATA_ORIGINAL = data;

        const DATA_VALIDATED = {
          ...data,
          idDireccion: {
            idDireccion: ADDRESS,
            idSector: {
              idSector: SECTOR,
              idMunicipio: {
                idMunicipio: MUNICIPALITY,
              },
            },
          },
          idTipoServicio: {
            idTipoServicio: TYPE_SERVICE,
            idCategoriaServicio: {
              idCategoriaServicio: CATEGORY_SERVICE,
            },
          },
          idHoraCita: {
            // idHora: formItem.idHoraCitaFin.idHora,
            // valor: dateformat(formItem.idHoraCitaFin.idHora, 'HH:MM').split(':').map(Number).reduce((horas, minutos) => horas + minutos / 60, 0),
            idHora: formItem.idHoraCitaFin.idHora,
            valor: idHora.valor,
          },
          fechaCitaFin: response.fechaCitaFin.split('T')[0],
          idHoraCitaFin: {
            idHora: response.idHoraCitaFin.idHora,
            valor: response.idHoraCitaFin.valor,
          },
        };
        validateServiceRiskEvent(DATA_VALIDATED, DATA_ORIGINAL);
      })
      .catch(() => {
        errorProcess();
        setLoadingValidation(false);
      });
  };

  // Calculate service's risks
  const validateServiceRiskEvent = (DATA, DATA_ORIGINAL) => {
    addItem(endpoints.services.calculateServiceRisk, DATA)
      .then((response) => {
        if (response) {
          setLoadingValidation(false);

          const START_AVAILABILITY_TIME = (response.tiempoDisponibilidadInicio = -1
            ? formatterText('info.swal.previous.services', 'No hay servicio previo')
            : response.tiempoDisponibilidadInicio);
          const END_AVAILABILITY_TIME = (response.tiempoDisponibilidadFin = -1
            ? formatterText('info.swal.post.services', 'No hay servicio posterior')
            : response.tiempoDisponibilidadFin);
          const low = formatterText('info.swal.low.risk', 'BAJO');
          const medium = formatterText('info.swal.medium.risk', 'MEDIO');
          const hight = formatterText('info.swal.hight.risk', 'ALTO');
          const PREVIOUS_BREACH_RISK = (response.riesgoIncumplimientoAnterior = 1
            ? `<span style="color: #0aa48a; font-weight: bold;">${low}</span>`
            : (response.riesgoIncumplimientoAnterior = 2
                ? `<span style="color: #f4bf4a; font-weight: bold;">${medium}</span>`
                : `<span style="color: #e21e26; font-weight: bold;">${hight}</span>`));

          const FOLLOWING_BREACH_RISK = (response.riesgoIncumplimientoSiguiente = 1
            ? `<span style="color: #0aa48a; font-weight: bold;">${low}</span>`
            : (response.riesgoIncumplimientoSiguiente = 2
                ? `<span style="color: #f4bf4a; font-weight: bold;">${medium}</span>`
                : `<span style="color: #e21e26; font-weight: bold;">${hight}</span>`));

          const alertText = `
          <ul style="padding: 0 3rem; text-align: start; font-size: 0.9rem">
            <li>${formatterText(
              'info.swal.start.availability.time',
              'Tiempo disponible al inicio',
            )}: ${START_AVAILABILITY_TIME}</li>
            <li>${formatterText(
              'info.swal.end.availability.time',
              'Tiempo disponible al final',
            )}: ${END_AVAILABILITY_TIME}</li>
            <li>${formatterText(
              'info.swal.risk.prior.default',
              'Riesgo de incumplimiento previo',
            )}: ${PREVIOUS_BREACH_RISK}</li>
            <li>${formatterText(
              'info.swal.risk.next.default',
              'Riesgo de incumplimiento siguiente',
            )}: ${FOLLOWING_BREACH_RISK}</li>
          </ul>
          `;
          const textLowRisk = `      
            <p style="padding: 0 3rem; text-align: justify-content; font-size: 0.9rem"> 
            ${formatterText(
              'info.swal.title.no.previous.service',
              'No hay servicios previos y/o posteriores que puedan verse afectados con este cambio.',
            )}</p><br/>
            <ul style="padding: 0 3rem; text-align: start; font-size: 0.9rem">
              <li>${formatterText(
                'info.swal.start.availability.time',
                'Tiempo disponible al inicio',
              )}: ${START_AVAILABILITY_TIME}</li>
              <li>${formatterText(
                'info.swal.end.availability.time',
                'Tiempo disponible al final',
              )}: ${END_AVAILABILITY_TIME}</li>
              <li>${formatterText(
                'info.swal.risk.prior.default',
                'Riesgo de incumplimiento servicio previo',
              )}: ${PREVIOUS_BREACH_RISK}</li>
              <li>${formatterText(
                'info.swal.risk.next.default',
                'Riesgo de incumplimiento servicio siguiente',
              )}: ${FOLLOWING_BREACH_RISK}</li>
            </ul>
          `;

          const titleTextWarn = `${formatterText(
            'info.swal.title.risk.medium.hight',
            'Riesgo Medio - Alto',
          )} <br/> <p style="font-size: 1rem"> ${formatterText(
            'info.swal.title.previous.service',
            'Antes de continuar, verifica riesgos asociados al cumplimiento de tus servicios previos y/o posteriores',
          )}</p>`;
          const titlelOWrISK = `${formatterText('info.swal.title.risk.low', 'Riesgo Bajo')} <br/>`;

          Swal.fire({
            icon: PREVIOUS_BREACH_RISK > 1 || FOLLOWING_BREACH_RISK > 1 ? 'error' : 'success',
            title:
              PREVIOUS_BREACH_RISK > 1 || FOLLOWING_BREACH_RISK > 1 ? titleTextWarn : titlelOWrISK,
            html: PREVIOUS_BREACH_RISK > 1 || FOLLOWING_BREACH_RISK > 1 ? alertText : textLowRisk,
            confirmButtonColor: '#09a288',
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            showCancelButton: true,
            allowOutsideClick: true,
            cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
          }).then((result) => {
            if (result.isConfirmed) {
              putItem(DATA_ORIGINAL);
            }
          });
        } else {
          setLoadingValidation(false);
          customSB(
            'error',
            'snackbar.error.validate.tech.exist',
            'No se encontró un técnico disponible para este servicio, seleccione otro horario o fecha.',
          );
        }
      })
      .catch((error) => {
        if ((error = 500)) {
          customSB(
            'warning',
            'snackbar.error.validate.service.address.date.hour',
            'Debe seleccionar una dirección, una fecha y una hora para poder crear el servicio.',
          );
          setLoadingValidation(false);
        } else {
          errorProcess();
          setLoadingValidation(false);
        }
      });
  };

  const generateDateEndByCalendar = (data) => {
    return new Promise((resolve, reject) => {
      setLoadingValidation(true);
      customSB(
        'warning',
        'snackbar.warning.validate.tech.exist.update',
        'Se esta validando que el servicio cumpla con los requisitos para ser actualizado, por favor espere...',
      );
      addItem(endpoints.services.generateEndDate, data)
        .then((response) => {
          const { idDireccion: direction = '', idTipoServicio: serviceType = {} } = selectIds;
          const [serviceTypeId = '', serviceTypeCategory = ''] = (serviceType?.value || '').split(
            '-',
          );
          const ADDRESS = auxService.servicio.idDireccion.idDireccion;
          const SECTOR = auxService.servicio.idDireccion.idSector.idSector;
          const MUNICIPALITY = auxService.servicio.idDireccion.idSector.idMunicipio.idMunicipio;
          const TYPE_SERVICE = parseInt(serviceTypeId);
          const CATEGORY_SERVICE = parseInt(serviceTypeCategory);

          const idHora = hoursWithValue.find(
            (item) => item.idHora === formItem.idHoraCitaFin.idHora,
          );
          const DATA_ORIGINAL = data;

          const DATA_VALIDATED = {
            ...data,
            idDireccion: {
              idDireccion: ADDRESS,
              idSector: {
                idSector: SECTOR,
                idMunicipio: {
                  idMunicipio: MUNICIPALITY,
                },
              },
            },
            idTipoServicio: {
              idTipoServicio: TYPE_SERVICE,
              idCategoriaServicio: {
                idCategoriaServicio: CATEGORY_SERVICE,
              },
            },
            idHoraCita: {
              // idHora: formItem.idHoraCitaFin.idHora,
              // valor: dateformat(formItem.idHoraCitaFin.idHora, 'HH:MM').split(':').map(Number).reduce((horas, minutos) => horas + minutos / 60, 0),
              idHora: eventData.idHoraCita,
              valor: idHora.valor,
            },
            fechaCitaFin: response.fechaCitaFin.split('T')[0],
            idHoraCitaFin: {
              idHora: response.idHoraCitaFin.idHora,
              valor: response.idHoraCitaFin.valor,
            },
          };
          validateServiceAgendaEvent(DATA_VALIDATED, DATA_ORIGINAL);
          setLoadingValidation(false);
          resolve(true); // Resuelve con `true` si todo va bien
        })
        .catch((error) => {
          errorProcess();
          setLoadingValidation(false);
          reject(error);
        });
    });
  };

  // Validate if the agenda have horary available
  const validateServiceAgendaEvent = (DATA, DATA_ORIGINAL) => {
    addItem(endpoints.services.validateCreateService, DATA)
      .then((response) => {
        if (response) {
          putItemWhitTech(DATA_ORIGINAL);
          setLoadingValidation(false);
          customSB(
            'success',
            'snackbar.success.validate.tech.exist',
            'Se encontró al menos un técnico disponible para este servicio, puede continuar con el proceso.',
          );
        } else {
          setLoadingValidation(false);
          customSB(
            'error',
            'snackbar.error.validate.tech.exist',
            'No se encontró un técnico disponible para este servicio, seleccione otro horario o fecha.',
          );
        }
      })
      .catch((error) => {
        errorProcess();
        setLoadingValidation(false);
        console.error(error);
      });
  };

  // Update service
  const putItemWhitTech = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          updateItem(endpoints.services.updateService, data)
            .then((_) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    onOpenSearch();
                  },
                }),
              );
            })
            .catch((err) => {
              handleRequestError(err);
            });
        });
      },
    });
  };

  // Update service
  const putItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          updateItem(endpoints.services.updateService, data)
            .then((_) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => navigate(paths.serviceModule),
                }),
              );
            })
            .catch((err) => {
              handleRequestError(err);
            });
        });
      },
    });
  };

  // Get the clients for the selector
  const getAllClientsServices = () => {
    getAll(endpoints.clients.getAllClients)
      .then((res) => {
        // create new array
        const newArray = [
          {
            value: -1,
            label: 'Ninguno',
          },
        ];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCliente,
              label: `${item.nombreRazonSocial} - ${item.identificacion}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          clients: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the users for the selector
  const getAllUsersServices = () => {
    getAll(endpoints.services.getAllExternalUsers)
      .then((res) => {
        // create new array
        const newArray = [
          {
            value: -1,
            label: 'Ninguno',
          },
        ];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idUsuarioServicio,
              label: `${item.primerNombre} ${item.primerApellido} - ${item.telefono}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          users: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the typeServices for the SelectorGrid
  const getAllTypeServicesServices = () => {
    getAll(endpoints.typeService.getAllTypeService).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: `${item.idTipoServicio}-${item.idCategoriaServicio.idCategoriaServicio}`,
            label: `${item.nombre} - ${item.idCategoriaServicio.nombre}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        typeService: newArray,
      }));
    });
  };

  // Get the typeServices for the selector
  const getAllTypeServicesByTech = (idTech) => {
    // Set idTech to 0 if it is null
    getItemById(endpoints.typeService.getAllTypeServiceByTech, idTech)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: `${item.idTipoServicio}-${item.idCategoriaServicio.idCategoriaServicio}`,
              label: `${item.nombre} - ${item.idCategoriaServicio.nombre}`,
            });
          }
        });

        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          typeServiceByTech: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the communicationMediaServices for the selector
  const getAllCommunicationMediaServices = () => {
    getAll(endpoints.services.getAllMedia)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.codigo,
              label: `${item.nombre} ${item.codigo}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          communicationMedia: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Get the communicationChannel for the selector
  const getAllCommunicationChannelServices = () => {
    getAll(endpoints.services.getAllChannels)
      .then((res) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.codigo,
              label: `${item.nombre} - ${item.codigo}`,
            });
          }
        });
        // set the values of the select
        setSearchSelected((prev) => ({
          ...prev,
          communicationChannel: newArray,
        }));
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const saveBillingUser = () => {
    if (!isNull(billingUserSelected.id)) {
      let data = {
        idServicio: {
          idServicio: id,
        },
        idCliente: {
          idCliente: billingUserSelected.id,
        },
        usuarioCreacion: COOKIE_USER,
      };
      addItem(endpoints.services.saveBillingUser, data)
        .then((resp) => {
          setIdBillingService(resp.idServicioFacturacion);
          updatedItem();
        })
        .catch(console.log);
    }
  };

  const deleteBillingUser = () => {
    if (idBillingService) {
      deleteItem(endpoints.services.deleteBillingUserByService, idBillingService)
        .then((resp) => successRemoveItem())
        .catch(console.log);
    }
  };
  // Get the timeMeeting for the selector
  const getAllTimeMeetingServices = () => {
    // create new array
    const newArray = [];
    // iterate response and get only the values that are active
    hours.forEach((item) => {
      newArray.push({
        value: item.idHora,
        label: item.hora,
      });
    });
    // set the values of the select
    setSearchSelected((prev) => ({
      ...prev,
      timeMeeting: newArray,
    }));
  };

  const handleDate = (e) => {
    if (e.target) {
      setEventData({
        ...eventData,
        [e.target.name]: e.target.value,
      });
    } else {
      setTime(e);
      const HOUR_ID = searchHour(dateFormat(e, 'HH:MM'));
      setEventData({
        ...eventData,
        idHoraCita: HOUR_ID,
      });
    }
  };

  const [formItem, setFormItem] = useState([
    {
      descripcion: '',
    },
  ]);

  const [formParent, setFormParent] = useState([]);
  const [formChildrens, setFormChildrens] = useState([]);

  const [idService, setIdService] = useState(0);

  const [showServiceData, setShowServiceData] = useState(true);

  const [statusTypeService, setStatusTypeService] = useState(false);

  const cloneService = () => {
    const STATE_SERVICE_BAN = {
      5: true,
      7: true,
      8: true,
    };

    const RES = STATE_SERVICE_BAN[parseInt(idEstadoServicio)] || false;

    if (RES) {
      // alert that the service can not be cloned
      customSB(
        'warning',
        'snackbar.warning.clone.state.service',
        'No se puede clonar con el estado servicio actual.',
      );
    } else {
      let newService = {
        ...auxService.servicio,
        idServicioPadre: auxService.servicio.idServicio,
        idServicio: null,
        fechaCreacion: null,
        fechaModificacion: null,
        usuarioCreacion: null,
        usuarioModificacion: null,
      };

      // set the data in the context
      setServiceCloneData(newService);
      navigate(paths.duplicateService);
    }
  };

  const setEstadoServicio = (idES, idServicio) => {
    if (idEstadoServicio === 6 && !activityStart) {
      customSB(
        'warning',
        'snackbar.warning.update.state.service',
        "No se puede actualizar el estado del servicio, debido a que el estado 'En Curso' tiene actividades iniciadas.",
      );
    } else {
      if (changeState) {
        const prevEstado = idES;

        const NEW_SERVICE = {
          id_servicio: parseInt(idServicio),
          id_estado_servicio: idES,
        };

        updateItem(endpoints.services.updateServiceState, NEW_SERVICE)
          .then((data) => {
            if (data.estado === false) {
              showSB('error', formatterText(data.mensaje));
            } else {
              // success data
              customSB(
                'success',
                'snackbar.success.update.state.service',
                'Estado del servicio actualizado correctamente',
              );
              setIdEstadoServicio(idES);
            }
          })
          .catch((error) => {
            handleRequestError(error);
          });
      } else {
        showPermissionDenied();
      }
    }
  };

  const handleDownload = () => {
    getItemById(endpoints.services.downloadResume, id)
      .then((res) => {
        const extensionArchivo = 'pdf';
        const MimeType = 'pdf';
        const decoded = decodeBase64(res);
        functionToDownload(decoded, `Resume.${extensionArchivo}`, MimeType);
      })
      .catch((error) => errorProcess());
  };

  const decodeBase64 = (base64) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return byteArray;
  };

  const functionToDownload = (decoded, fileName, ext) => {
    const blob = new Blob([decoded], { type: `aplication/${ext}` });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  };

  const reOpenService = () => {
    const hashDesition = {
      8: 9,
      9: 6,
    };
    setEstadoServicio(hashDesition[parseInt(idEstadoServicio)], idService);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formItem, setFormItem);
  };

  // upload files
  const uploadNewFile = (file) => {
    fetchData({
      url: endpoints.UploadFiles.save,
      method: 'post',
      body: {
        idOrigen: id,
        idTipoOrigenArchivo: 13, //cambiar a parámetro servicio
        archivos: [file],
      },
    }).then(() => {
      getDataAttachedFiles();
      updatedItem();
    });
  };

  const getDataAttachedFiles = async () => {
    const body = {
      url: endpoints.UploadFiles.findArchivosById,
      method: 'post',
      body: {
        idOrigen: id,
        idTipoOrigenArchivo: 13,
      },
      typeConfig: 'form',
    };

    const response = await fetchData(body);

    let files = response.response.map((file) => {
      return {
        name: file,
        url: file,
      };
    });
    setCurrentFiles(files);
  };

  // Call services to fill in the selects
  useEffect(() => {
    (async () => {
      getAllStatesService();
      getBillingData();
      // news
      setLoadingProgress(true);
      await getDataToUpdate();
      getAllClientsServices();
      getAllUsersServices();
      getAllTypeServicesServices();
      getAllTypeServicesByTech(0);
      getAllCommunicationMediaServices();
      getAllCommunicationChannelServices();
      getAllTimeMeetingServices();
      await getDataAttachedFiles();
    })();
  }, []);

  useEffect(() => {
    let techIdToSend = ppTech.idtech;
    // If ppTech.idtech is null, undefined, or -1, set techIdToSend to 0
    if (ppTech.idtech === null || ppTech.idtech === -1 || ppTech.idtech === undefined) {
      techIdToSend = 0;
    }
    (async () => {
      await getAllTypeServicesByTech(techIdToSend);
    })();
  }, [ppTech.idtech]);

  useEffect(() => {
    getActivitiesActive();
    activitiesNoTechsEndeds();
  }, [listActivities]);

  useEffect(() => {
    permissionsAccess();
  }, [permissions]);

  useEffect(() => {
    validationData();
  }, [access]);

  useEffect(() => {
    if (serviceChangeTS && activityStart && activityProgress) {
      setStatusTypeService(true);
    } else {
      setStatusTypeService(false);
    }
  }, [activityStart, activityProgress, serviceChangeTS]);

  useEffect(() => {
    setShowInvoice(true);
  }, [ticket, expedient]);
  return (
    <>
      <div className="centered-form">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
          className="container-wrapForm"
          style={{ minHeight: '16rem' }}
        >
          <div className="new-container-wrapForm__tabs">
            <div className="new-tab-option is-active">
              <p
                onClick={(e) => {
                  e.preventDefault();

                  setShowServiceData(!showServiceData);
                }}
              >
                {formatterText(
                  'header.title.panel.service',
                  'Información del servicio - Número Ticket',
                )}{' '}
                {formItem.expediente}
              </p>
              <button
                className="p-show-services"
                onClick={(e) => {
                  e.preventDefault();

                  setShowServiceData(!showServiceData);
                }}
              >
                {showServiceData
                  ? formatterText('id.service.hide detail', 'Ocultar Detalle')
                  : formatterText('id.service.view.detail', 'Ver detalle')}
              </button>
            </div>
          </div>
          <div className="container-wrapForm-content">
            {loadingProgress ? (
              <DisplayProgress />
            ) : (
              showServiceData && (
                <>
                  <section className="w100-container">
                    <section
                      style={{
                        display: 'flex',
                        width: '100%',
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                      }}
                    >
                      <p
                        className="p-clone-action"
                        style={{
                          padding: '1rem',
                        }}
                        onClick={(e) => {
                          e.preventDefault();
                          cloneService();
                        }}
                      >
                        {formatterText('p.title.clone.service', 'Clonar servicio')}
                      </p>
                      <MdOutlineFileCopy
                        size={25}
                        color="gray"
                        cursor="pointer"
                        onClick={() => cloneService()}
                      />
                    </section>
                    <section className="padding-all-1">
                      {/* gen, user and direction */}
                      <section className="grid-container-2c">
                        <label className="d-flex">
                          <section className="box-text-container">
                            {isGenClient ? (
                              <p className="text-inline">
                                <FormattedMessage
                                  id="p.generate.Client"
                                  defaultMessage="Generado / Cliente"
                                />
                              </p>
                            ) : (
                              <p className="text-inline">Generado / Usuario</p>
                            )}
                          </section>
                          <div className="wrap-input">
                            <div className="input-label-icon">
                              {isGenClient ? (
                                <input
                                  type="text"
                                  name="idGeneradorCliente"
                                  className="input-label-style"
                                  value={clientSelected.nombre}
                                  disabled
                                />
                              ) : (
                                <input
                                  type="text"
                                  name="idGeneradorCliente"
                                  className="input-label-style"
                                  value={userSelected.nombre}
                                  disabled
                                />
                              )}
                              <div className="btn-action-style">
                                <MdOutlineRemoveCircleOutline size={25} color="gray" />
                              </div>
                            </div>
                          </div>
                        </label>

                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="text-inline">
                              {formatterText('p.generate.user', 'Usuario')}
                            </p>
                          </section>

                          <div className="wrap-input">
                            <div className="input-label-icon">
                              <input
                                type="text"
                                name="idUsuario"
                                className="input-label-style"
                                value={externalUserSelected.nombre}
                                required
                                disabled
                              />
                              <div className="btn-action-style">
                                <MdOutlineRemoveCircleOutline size={25} color="gray" />
                              </div>
                            </div>
                          </div>
                        </label>

                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="spacing-r1 p-styles margin-bottom-1">
                              {formatterText('p.label.direction')}
                            </p>
                          </section>
                          <input
                            type="text"
                            name="idDireccion"
                            className="input-label-style"
                            value={addressData}
                            disabled
                          />
                        </label>

                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="spacing-r1 p-styles margin-bottom-1">
                              {' '}
                              {formatterText('p.status.service', 'Estado servicio')}
                            </p>
                          </section>
                          <select
                            name="idEstadoServicio"
                            disabled
                            selectedSearch
                            className="input-label-style"
                            defaultValue={idEstadoServicio}
                            value={idEstadoServicio}
                            onChange={(e) => {
                              if (e.target.value === '0') {
                                console.log('nada');
                              } else {
                                setEstadoServicio(parseInt(e.target.value), idService);
                              }
                            }}
                          >
                            <option value="0">Estados de servicios</option>
                            {allStateService.map((item) => (
                              <option value={item.id}>{item.label}</option>
                            ))}
                          </select>
                          {hashReopenService[parseInt(idEstadoServicio)] && canReopen && (
                            <p
                              className="btn-primary"
                              style={{
                                minWidth: '5%',
                                minHeight: '2rem',
                                padding: '0.5rem',
                                margin: '0.5rem',
                                cursor: 'pointer',
                                textAlign: 'center',
                              }}
                              onClick={reOpenService}
                            >
                              {formatterText('p.button.reopen.service', 'Reabrir servicio')}
                            </p>
                          )}
                        </label>
                        {/* make a button to reopen service */}
                      </section>

                      {/* exped num and type service */}
                      <section className="grid-container-2c">
                        <label className="d-flex custom-margin-0100-s">
                          <p className="text-inline margin-bottom-1">NoExpediente</p>
                          <section className="w100-container">
                            <input
                              className={
                                checkoutValidations.equalsExp
                                  ? 'input-default input-default-disable'
                                  : 'input-default'
                              }
                              type="text"
                              name="expediente"
                              value={formItem.expediente}
                              onChange={(e) => {
                                setFormItem({
                                  ...formItem,
                                  [e.target.name]: e.target.value,
                                });
                              }}
                              placeholder="NoExpediente"
                              disabled={checkoutValidations.equalsExp}
                            />
                            <label
                              className="label-position"
                              style={{
                                display: 'ruby-text-container',
                              }}
                            >
                              <input
                                type="checkbox"
                                name="equalsExp"
                                className=""
                                onChange={(e) => {
                                  setCheckoutValidations((prev) => {
                                    if (e.target.checked) {
                                      setFormItem({
                                        ...formItem,
                                        expediente: '',
                                      });
                                    }

                                    return {
                                      ...prev,
                                      [e.target.name]: e.target.checked,
                                    };
                                  });
                                }}
                                checked={checkoutValidations.equalsExp}
                              />
                              <p
                                className="text-checkout"
                                style={{
                                  width: 'fit-content',
                                  display: 'block',
                                }}
                              >
                                {formatterText('p.label.no.record', 'Usar mismo No. Ticket')}
                              </p>
                            </label>
                          </section>
                        </label>

                        <label className="d-flex">
                          <p className="text-inline margin-bottom-1">
                            {formatterText('id.day.event.service.type', 'Tipo de servicio:')}
                          </p>
                          <section className="w100-container">
                            <SelectorGrid
                              disabled={
                                !hashCanAnulate[parseInt(idEstadoServicio)] && activityStart
                              }
                              name="idTipoServicio"
                              data={selectedSearch.typeServiceByTech}
                              placeholder={formItem.idTipoServicio}
                              dataValue={selectIds.idTipoServicio}
                              setterFunction={setSelectIds}
                              permission={permittedActions.cambiar_tipo_servicio}
                              managePermission={true}
                            />
                            <label className="label-position">
                              {clientSelected.esVip === 1 && (
                                <>
                                  <input
                                    type="checkbox"
                                    name="specialService"
                                    className=""
                                    onChange={(e) => {
                                      setCheckoutValidations((prev) => {
                                        return {
                                          ...prev,
                                          specialService: true,
                                        };
                                      });
                                    }}
                                    checked={true}
                                  />
                                  <p className="text-checkout">
                                    {formatterText(
                                      'id.day.check.service.isspecial',
                                      'Es un servicio especial',
                                    )}
                                  </p>
                                </>
                              )}
                            </label>
                          </section>
                        </label>
                      </section>
                      {/* description */}
                      <section
                        className=""
                        style={{
                          display: 'flex',
                          flexDirection: 'row',
                          flexWrap: 'wrap',
                          fontFamily: 'inherit',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          width: '100%',
                        }}
                      >
                        <section className="container-description">
                          <p
                            className="p-styles"
                            style={{
                              textDecoration: 'none',
                              fontSize: '1rem',
                              fontWeight: 600,
                              color: 'var(--dark-gray)',
                            }}
                          >
                            {formatterText('table.title.description', 'Descripción')}
                          </p>
                          <textarea
                            className="input-default-textarea"
                            name="descripcion"
                            value={formItem.descripcion}
                            onChange={handlerTextDescription}
                            placeholder={formatterText('table.title.description', 'Descripción')}
                            maxLength="200"
                          />
                        </section>
                      </section>

                      <section className="grid-container-2c">
                        <label className="d-flex">
                          <p className="text-inline">
                            {' '}
                            {formatterText('p.label.comunication.media', 'Medio de comunicación')}
                          </p>
                          <SelectorGrid
                            name="idMedioComunicacion"
                            data={selectedSearch.communicationMedia}
                            placeholder={selectIds.idMedioComunicacion.value}
                            dataValue={selectIds.idMedioComunicacion.value}
                            setterFunction={setSelectIds}
                          />
                        </label>

                        <label className="d-flex">
                          <p className="text-inline">
                            {formatterText('p.label.comunication.channel', 'Canal de comunicación')}
                          </p>
                          <SelectorGrid
                            name="idCanalComunicacion"
                            data={selectedSearch.communicationChannel}
                            placeholder={selectIds.idCanalComunicacion.value}
                            dataValue={selectIds.idCanalComunicacion.value}
                            setterFunction={setSelectIds}
                          />
                        </label>

                        <label className="d-flex">
                          <p className="text-inline">
                            {formatterText('p.label.date.appointment', 'Fecha de la cita')}
                          </p>
                          <input
                            className="input-date"
                            type="date"
                            name="fechaCita"
                            value={eventData.fechaCita}
                            onChange={handleDate}
                            min={dateFormat(
                              new Date(now.getFullYear(), now.getMonth(), now.getDate() - 60),
                              'yyyy-mm-dd',
                            )}
                          />
                        </label>

                        <label className="d-flex">
                          <p className="text-inline">
                            {formatterText('p.label.hour.appointment', 'Hora de la cita')}
                          </p>

                          <TimePicker
                            name="idHoraCita"
                            ampm={false}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecciona una opción"
                              />
                            }
                            value={time}
                            onChange={handleDate}
                          />
                        </label>
                      </section>
                      <section className="grid-container-2c">
                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="text-inline">
                              {formatterText('p.label.billing.user', 'Usuario facturación')}
                            </p>
                          </section>

                          <div className="wrap-input">
                            <div className="input-label-icon">
                              <input
                                type="text"
                                name="idUsuarioFactura"
                                className="input-label-style"
                                value={valueSetter(billingUserSelected.nombre)}
                                required
                                disabled
                              />
                              <div className="btn-action-style">
                                {billingUserSelected.id ? (
                                  <MdOutlineRemoveCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        deleteBillingUser();
                                        setBillingUserSelected({
                                          nombre: 'Seleccione usuario facturación(Optional)',
                                          id: null,
                                        });
                                      });
                                    }}
                                  />
                                ) : (
                                  <MdOutlineAddCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        onToggleBillingUser();
                                      });
                                    }}
                                  />
                                )}
                              </div>
                            </div>
                          </div>
                        </label>
                      </section>
                    </section>
                    {formParent.length !== 0 && (
                      <section>
                        <h3 className={styles['text-association']}>
                          {formatterText('label.text.parent.service', 'Servicio padre')}
                        </h3>
                        <div style={{ marginLeft: '50px', marginRight: '50px' }}>
                          <table
                            style={{
                              width: '100%',
                              textAlign: 'center',
                              border: '1px solid transparent !important',
                              // borderCollapse: 'revert-layer'
                            }}
                          >
                            <thead style={{ border: 'none' }}>
                              <tr style={{ border: 'none' }}>
                                <th style={{ border: 'none' }}>
                                  {' '}
                                  <label className="text-inline">
                                    {formatterText('table.title.expedient', 'Expediente')}
                                  </label>
                                </th>
                                <th style={{ border: 'none' }}>
                                  <label className="text-inline">
                                    {formatterText('text.ticket', 'Ticket')}
                                  </label>
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {formParent.map((item) => (
                                <tr key={item.idServicio} style={{ border: 'none' }}>
                                  <td>{item.expediente}</td>
                                  <td>{item.ticket}</td>
                                  <td>
                                    <button
                                      style={{
                                        borderRadius: '20px',
                                        backgroundColor: '#0aa48a',
                                        padding: '0px 1rem',
                                        fontSize: 'bold',
                                        color: '#fff',
                                        border: 'none',
                                      }}
                                      onClick={(e) => {
                                        e.preventDefault();
                                        window.open(
                                          `#/servicios/editar/${item.idServicio}`,
                                          '_blank',
                                        );
                                      }}
                                    >
                                      {formatterText('view.details', 'Ver detalle')}
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </section>
                    )}
                    {formChildrens.length !== 0 && (
                      <section>
                        <h3 className={styles['text-association']}>
                          {formatterText('label.text.child.service', 'Servicios hijos')}
                        </h3>
                        <div style={{ marginLeft: '50px', marginRight: '50px' }}>
                          <table
                            style={{
                              width: '100%',
                              textAlign: 'center',
                              border: '1px solid transparent !important',
                              // borderCollapse: 'revert-layer'
                            }}
                          >
                            <thead style={{ border: 'none' }}>
                              <tr style={{ border: 'none' }}>
                                <th style={{ border: 'none' }}>
                                  {' '}
                                  <label className="text-inline">
                                    {formatterText('table.title.expedient', 'Expediente')}
                                  </label>
                                </th>
                                <th style={{ border: 'none' }}>
                                  <label className="text-inline">
                                    {formatterText('text.ticket', 'Ticket')}
                                  </label>
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {formChildrens.map((item) => (
                                <tr key={item.idServicio} style={{ border: 'none' }}>
                                  <td>{item.expediente}</td>
                                  <td>{item.ticket}</td>
                                  <td>
                                    <button
                                      style={{
                                        borderRadius: '20px',
                                        backgroundColor: '#0aa48a',
                                        padding: '0px 1rem',
                                        fontSize: 'bold',
                                        color: '#fff',
                                        border: 'none',
                                      }}
                                      onClick={(e) => {
                                        e.preventDefault();
                                        window.open(
                                          `#/servicios/editar/${item.idServicio}`,
                                          '_blank',
                                        );
                                      }}
                                    >
                                      {formatterText('view.details', 'Ver detalle')}
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </section>
                    )}
                  </section>
                  <input type="submit" id="submit-form" style={{ visibility: 'hidden' }} />
                </>
              )
            )}
            <div
              style={{
                //center the button
                display: 'flex',
                justifyContent: 'space-evenly',
                alignItems: 'center',
                marginBottom: '2rem',
              }}
            >
              {hashCanAnulate[parseInt(idEstadoServicio)] && activityStart && (
                <button
                  style={{ padding: '0px', marginHorizontal: '2rem' }}
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    setEstadoServicio(7, idService);
                  }}
                >
                  <label className="btn-wrap-add">
                    {formatterText('p.service.cancel.button', 'Anular servicio')}
                  </label>
                </button>
              )}
              <button
                style={{ padding: '0px', marginHorizontal: '2rem' }}
                className="btn-primary"
                onClick={(e) => {
                  e.preventDefault();
                  handleDownload();
                }}
              >
                <label className="btn-wrap-add">
                  {formatterText(
                    'p.service.resume.download.button',
                    'Descargar resumen del servicio',
                  )}
                </label>
              </button>
              {idEstadoServicio === 9 && activityNoTechEnd && (
                <button
                  style={{ padding: '0px' }}
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    setEstadoServicio(8, idService);
                  }}
                >
                  <label className="btn-wrap-add">
                    {formatterText('p.service.end.button', 'Finalizar Servicio')}
                  </label>
                </button>
              )}
            </div>
            <div className="demo-form__footer">
              <section className="form-responsive-container-buttons">
                <button
                  style={{ padding: '0px' }}
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    handleSubmit();
                  }}
                >
                  <label className="btn-wrap-add" htmlFor="submit-form" tabIndex="0">
                    {formatterText('btn.save.changes', 'Guardar cambios')}
                  </label>
                </button>
                <button
                  style={{ padding: '0px' }}
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();

                    const STATE_SERVICE_BAN = {
                      5: true,
                      7: true,
                      8: true,
                      9: true,
                    };

                    if (STATE_SERVICE_BAN[idEstadoServicio]) {
                      customSB(
                        'warning',
                        'snackbar.warning.state.service.no.valid',
                        'Solo se puede descargar cotizaciones en estados: En Coordinación, Asignado, En Desplazamiento, En Sitio, En Curso.',
                      );
                    } else {
                      onOpenQuotation();
                    }
                  }}
                >
                  <label className="btn-wrap-add">
                    {formatterText('btn.download.quotation', 'Descargar cotización')}
                  </label>
                </button>
                <button className="input-cancel" onClick={() => navigate(paths.serviceModule)}>
                  {formatterText('btn.cancel', 'Cancelar')}
                </button>
              </section>
            </div>

            <Formiz onValidSubmit={handleSubmit} connect={myForm}>
              <form noValidate onSubmit={myForm.submit} className="container-options-tables">
                <div
                  className="new-container-wrapForm__tabs"
                  style={{
                    overflow: 'auto',
                  }}
                >
                  {myForm.steps.map((step) => (
                    <button
                      key={step.name}
                      className={`tab-options-tables ${
                        step.name === myForm.currentStep.name ? 'is-active' : ''
                      }`}
                      type="button"
                      onClick={() => myForm.goToStep(step.name)}
                    >
                      {formatterText(step.label)}
                      {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                    </button>
                  ))}
                </div>

                <div className="container-table-content">
                  <FormizStep
                    style={{
                      overflow: 'auto',
                      marginTop: '1rem',
                    }}
                    name="step1"
                    label="id.technicians.assigned"
                  >
                    <TechnicalAssign
                      serviceState={parseInt(idEstadoServicio)}
                      ppTech={ppTech}
                      idService={idService}
                      searchAutomatic= {searchAutomatic}
                      manualSearch= {manualSearch}
                      setPpTech={setPpTech}
                      getDataToUpdate={getDataToUpdate}
                      onOpenSearch={onOpenSearch}
                    />
                  </FormizStep>
                  {/*    // asdasd */}

                  <FormizStep name="step2" label={ACTIVITIES.title}>
                    <Activities
                      getActivitiesActive={getActivitiesActive}
                      statusActivity={parseInt(idEstadoServicio)}
                      getDataToUpdate={getDataToUpdate}
                    />
                  </FormizStep>

                  <FormizStep name="step3" label={COLLECTIONS.title}>
                    <Precautions />
                  </FormizStep>

                  <FormizStep
                    isEnabled={idEstadoServicio === 6}
                    name="step4"
                    label="id.step.products"
                  >
                    <ProductServices />
                  </FormizStep>

                  <FormizStep
                    name="step5"
                    label={REPORTS.title}
                    style={{
                      marginTop: '1rem',
                    }}
                  >
                    <Reports />
                  </FormizStep>
                  <FormizStep name="step6" label="NQR">
                    <NQR
                      changeStatusNQR={changeStatusNQR}
                      canDeleteNQR={canDeleteNQR}
                      canDeleteAnsNQR={canDeleteAnsNQR}
                    />
                  </FormizStep>
                  <FormizStep name="step7" label="id.step.traceability">
                    <Trazabilidad />
                  </FormizStep>
                  <FormizStep name="step8" label="label.text.billing.type">
                    {showInvoice && <InvoiceTable ticket={ticket} expedient={expedient} />}
                  </FormizStep>
                  {/* This button is hidden, but the reference in the id helps to execute the form (you can check it below in the class called "text")*/}
                  <input type="submit" id="submit-form" style={{ visibility: 'hidden' }} />
                </div>
              </form>
            </Formiz>
          </div>
        </form>
      </div>
      {/* Client system modal */}
      <Modal
        Modal
        open={openClient}
        onClose={onCloseClient}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ClientModal onClose={onCloseClient} exeFun={getAllUsersServices} />
      </Modal>

      {/* Billing user modal */}
      <Modal
        open={openBillingUser}
        onClose={onToggleBillingUser}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalBillingUser onClose={onToggleBillingUser} exeFun={getAllUsersServices} />
      </Modal>
      {/* External user modal */}
      <Modal
        Modal
        open={openExternalUser}
        onClose={onCloseExternalUser}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ExternalUserModal onClose={onCloseExternalUser} exeFun={getAllUsersServices} />
      </Modal>
      {/* Search data modal */}
      <Modal
        Modal
        open={openSearch}
        onClose={onCloseSearch}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalSearch
          onClose={onCloseSearch}
          exeFun={getAllUsersServices}
          serviceId={idService}
          permissions={{
            automatic: searchAutomatic,
            manual: manualSearch,
          }}
        />
      </Modal>
      {/* Cotización data modal */}
      <Modal
        Modal
        open={quotation}
        onClose={onCloseQuotation}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <Quotation onClose={onCloseQuotation} />
      </Modal>
    </>
  );
};

export default EditService;
