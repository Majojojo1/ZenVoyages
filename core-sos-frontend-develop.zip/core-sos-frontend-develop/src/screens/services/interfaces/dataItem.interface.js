export const DataItemInterface = {
  id: 0,
  technician_name: '',
  technician_id: 0,
  technician_charge: '',
  technician_picture: null,
  ticket: '',
  percentage: 0,
  service_type: '',
  service_status: '',
  service_date_start: '',
  service_date_end: ''
};
