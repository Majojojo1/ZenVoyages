import DataItemInterface from "./dataItem.interface";

export const DayEventPropsInterface = {
  service: DataItemInterface,
  height: undefined
};
