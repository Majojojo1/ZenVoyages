import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Day } from './GanttDiagram/Calendar';
import { Week } from './GanttDiagram/Calendar/Week';
// Import Hooks
import useAxios from 'hooks/useAxios';
import { useStorage } from "hooks/useStorage";
import { FormattedMessage } from 'react-intl';
//Import Services
import { isEmpty, isString } from 'lodash';
import endpoints from 'services/api';
// Import Libs
import moment from 'moment';
//Import Utils
import styles from './CalendarService.module.css';
//Import Components
import SelectComboBox from 'common/selects/SelectComboBox';
import DatePicker from "components/pickers/DatePicker";
import useLangv2 from "hooks/useLangv2";
import { MdAutorenew } from "react-icons/md";

const GanttService = () => {

  const [isLoading, setIsLoading] = useState(true);
  const [calendarServices, setCalendarServices] = useState([]);
  const [tecnicos, setTecnicos] = useState(null);
  const { getItem } = useStorage();
  const userData = getItem('userData');
  const [filters, setFilters] = useState({
    technicianName: null,
    cargo: null,
  });

  const [hasFiltered, setHasFiltered] = useState(false);
  const [technicianName, setTechnicianName] = useState(null);
  const [rangoFechaServicioInicial, setRangoFechaCitaInicio] = useState(new Date(''));
  const [rangoFechaServicioFinal, setRangoFechaServicioFinal] = useState(new Date(''));
  const [cargos, setCargos] = useState(null);
  const [filteredServices, setFilteredServices] = useState([]);
  const [week, setWeek] = useState([]);
  const { formatterText } = useLangv2();

  // Manage axios requests
  const { fetchData } = useAxios();

  const clientId = useMemo(
    () =>
      !userData || !userData?.idAsesorCliente || !userData?.idAsesorCliente?.idAsesor
        ? null
        : userData.idAsesorCliente.idAsesor,
    [userData],
  );

  const employeeId = useMemo(
    () =>
      !userData || !userData?.idEmpleado || !userData?.idEmpleado?.idEmpleado
        ? null
        : userData.idEmpleado.idEmpleado,
    [userData],
  );

  const startDate = useMemo(
    () =>
      rangoFechaServicioInicial === ''
        ? moment()
        : moment(rangoFechaServicioInicial.rangoFechaServicioInicial),
    [rangoFechaServicioInicial],
  );

  const endDate = useMemo(
    () =>
      rangoFechaServicioFinal === '' || rangoFechaServicioFinal === null || rangoFechaServicioFinal === undefined
        ? null
        : moment(rangoFechaServicioFinal.rangoFechaServicioFinal),
    [rangoFechaServicioFinal],
  );

  const jobId = useMemo(
    () => (!filters || !filters?.cargo || !filters?.cargo?.id ? null : filters.cargo.id),
    [filters],
  );

  const serviceRequestBody = useMemo(
    () => ({
      idAsesorCliente: clientId,
      idEmpleado: employeeId,
      fechaInicio: !startDate ? new Date() : startDate.format('YYYY-MM-DD'),
      fechaFin: !endDate ? startDate.format('YYYY-MM-DD') : endDate.format('YYYY-MM-DD'),
      nombreTecnico: technicianName?.label.split(" ").slice(0, -1).join(" ").trim(),
      idCargo: jobId,
    }),
    [clientId, employeeId, startDate, endDate, technicianName, jobId],
  );

  const serviceRequestBodyToWeek = useMemo(
    () => ({
      idAsesorCliente: clientId,
      idEmpleado: employeeId,
      fechaInicio: !startDate ? new Date() : startDate.format('YYYY-MM-DD'),
      fechaFin: null,
      nombreTecnico: technicianName?.label.split(" ").slice(0, -1).join(" ").trim(),
      idCargo: jobId,
    }),
    [clientId, employeeId, startDate, endDate, technicianName, jobId],
  );


  const handleButtonRefresh = async () => {

    serviceRequestBody.fechaInicio = moment(new Date()).format('YYYY-MM-DD');
    serviceRequestBody.fechaFin = moment(new Date()).format('YYYY-MM-DD');
    serviceRequestBody.nombreTecnico = null;
    setTechnicianName(null);
    serviceRequestBody.idCargo = null;
    setRangoFechaServicioFinal('');
    setRangoFechaCitaInicio('');
    setFilters({
      technicianName: null,
      cargo: null,
    })
    await Promise.all([getServices()]);
    setHasFiltered(false);

  };

  const handleButtonFilter = async () => {
    await Promise.all([loadData()]);
    setHasFiltered(true);
  };


  const getJobs = useCallback(async () => {
    setIsLoading(true);
    const jobs = await fetchData({ url: endpoints.cargos.getAllCargos });
    const formattedJobs = jobs.response.map(({ idCargo, nombre }) => ({
      id: idCargo,
      label: nombre,
    }));

    setCargos(formattedJobs);
    setIsLoading(false);
  }, []);

  const formatServiceData = (services) => {
    return services.flatMap(({ idTecnico, nombre, cargo, servicios }) => {
      return servicios.map((servicio) => {
        const formattedService = {
          id: idTecnico,
          technician_name: `${nombre}`,
          technician_id: idTecnico,
          technician_charge: cargo,
          technician_picture: null,
          ticket: servicio.ticket,
          percentage: 50, // Math.floor(Math.random() * 100),
          serviceId: servicio.idServicio,
          notifications: servicio.notificaciones,
          service_type: servicio.tipoServicio,
          service_status: servicio.estadoServicio,
          service_date_start: moment(servicio.fechaInicio, 'YYYY-MM-DD h:mm'),
          service_date_end: moment(servicio.fechaFin, 'YYYY-MM-DD h:mm'),
          service_time: servicio.horaInicio,
          service_duration: moment(servicio.fechaFin).diff(moment(servicio.fechaInicio), 'minutes'),
        };

        return formattedService;
      });
    });
  };

  const loadData = async () => {
    try {
      const reqBody = serviceRequestBody;
      const calendarServicePromise = await fetchData({
        url: endpoints.services.getCalendarServices,
        method: 'post',
        body: reqBody,
      });
      const techs = calendarServicePromise.response.map(({ idTecnico, nombre }) => ({
        id: idTecnico,
        label: `${nombre}`,
      }));
      setTecnicos(techs);

      const Formattedtechn = formatServiceData(calendarServicePromise.response);
      setCalendarServices(Formattedtechn);

      const cargosPromise = await fetchData({
        url: endpoints.cargos.getAllCargos,
        method: 'get',
      });

      setCargos(
        cargosPromise.response.map((cargo) => ({
          id: cargo.idCargo,
          label: cargo.nombre,
        })),
      );
      setWeek(Formattedtechn);
      setIsLoading(false);
    } catch (error) {
      console.log("Error: ", error);
    }
  };

  const getServices = useCallback(async () => {
    setIsLoading(true);

    const services = await fetchData({
      url: endpoints.services.getFirstCalendarServices,
      method: 'post',
      body: serviceRequestBody,
    });

    if (isString(services.response)) {
      setCalendarServices([]);
    } else {
      setCalendarServices(services.response);
    }

    const techs = services.response.map(({ idTecnico, nombre, cargo }) => ({
      id: idTecnico,
      label: `${nombre}`,

    }));
    setTecnicos(techs);

    const Formattedtechn = formatServiceData(services.response);

    setCalendarServices(Formattedtechn);
    setIsLoading(false);
  }, [serviceRequestBody]);

  const getServicesWeek = async () => {
    setIsLoading(true);

    const services = await fetchData({
      url: endpoints.services.getFirstCalendarServices,
      method: 'post',
      body: serviceRequestBodyToWeek,
    });

    const Formattedtechn = formatServiceData(services.response);
    setWeek(Formattedtechn);
  };

  useEffect(() => {

    (async () => {
      await getServices();
      await getJobs();
      await getServicesWeek();
    })();

  }, []);

  const getDayPropStart = () => startDate.toDate();
  const getDayPropEnd = () => (endDate ? endDate.toDate() : startDate.toDate());


  useEffect(() => {
    const filteredResults = calendarServices.filter(({ technician_name, technician_charge, servicios }) => {
      let matches = true;

      if (!isEmpty(filters.technicianName)) {
        matches = matches && new RegExp(filters.technicianName.label, 'gi').test(technician_name);
      }
      if (!isEmpty(filters.cargo) && !isEmpty(filters.cargo.label)) {
        matches = matches && new RegExp(filters.cargo.label, 'gi').test(technician_charge);
      }

      if (!isEmpty(rangoFechaServicioInicial) && !isEmpty(rangoFechaServicioInicial.rangoFechaServicioInicial)) {
        const compareFrom = moment(rangoFechaServicioInicial);
        matches = matches && servicios.some((servicio) => {
          const compareFrom = moment(rangoFechaServicioInicial);

          results = results.filter(({ servicios }) =>
            servicios.some((servicio) => {
              const [hours = 0, minutes = 0, , seconds = 0] = (servicio?.horaInicio || '')
                .split(':')
                .map(Number);

              const compareTo = moment(servicio.fechaInicio).set({
                hours,
                minutes,
                seconds,
              });
              return compareFrom.isSame(compareTo);
            }),
          );

        });
      }

      if (!isEmpty(rangoFechaServicioFinal) && !isEmpty(rangoFechaServicioFinal.rangoFechaServicioFinal)) {
        const compareFrom = moment(rangoFechaServicioFinal.rangoFechaServicioFinal);
        matches = matches && servicios.some((servicio) => {
          const compareFrom = moment(rangoFechaServicioFinal.rangoFechaServicioFinal);

          results = results.filter(({ servicios }) =>
            servicios.some((servicio) => {
              const [hours = 0, minutes = 0, , seconds = 0] = (servicio?.horaFin || '')
                .split(':')
                .map(Number);

              const compareTo = moment(servicio.fechaFin).set({
                hours,
                minutes,
                seconds,
              });
              return compareFrom.isSame(compareTo);
            }),
          );

        });
      }
      return matches;
    });

    setFilteredServices(filteredResults);
  }, [calendarServices, filters, rangoFechaServicioFinal, rangoFechaServicioInicial]);

  useEffect(() => {
    let intervalId;
  
    if (!hasFiltered) {      
      intervalId = setInterval(getServices, 120000);
    } else {      
      intervalId = setInterval(loadData, 120000);
    }
  
    return () => {     
      clearInterval(intervalId);
    }
  }, [hasFiltered]);
  

  
  return (
    <>
      {tecnicos !== null ? (
        <div className="spacing-1">
          <section className={styles.filtersContainer}>
            <div className="grid-container-1c-2g">
              <h3 style={{
                color: '#31D7B9',
                fontWeight: 'bold'

              }}>
                <FormattedMessage id="text.filter.date" defaultMessage="Filtrar por fecha" />
              </h3>
              <div>
                <DatePicker
                  id="rangoFechaServicioInicial"
                  name="rangoFechaServicioInicial"
                  placeholder={formatterText('input.placeholder.start.date', 'Rango de fecha Inicial')}
                  selectValue={rangoFechaServicioInicial}
                  setterFunction={setRangoFechaCitaInicio}
                  showMdRemove={false}
                  noIcon={true}
                  refresh={true}
                />
              </div>
              <div>
                <DatePicker
                  id="rangoFechaServicioFinal"
                  name="rangoFechaServicioFinal"
                  placeholder={formatterText('input.placeholder.end.date', 'Rango de fecha Final')}
                  selectValue={rangoFechaServicioFinal}
                  setterFunction={setRangoFechaServicioFinal}
                />
              </div>
            </div>
            <div className="grid-container-1c-2g">
              <h3
                style={{
                  color: '#31D7B9',
                  fontWeight: 'bold'

                }}>
                <FormattedMessage
                  id="text.filter.nameOrJobTitle"
                  defaultMessage="Filtrar por nombre o cargo"
                />
              </h3>
              <SelectComboBox
                id="technicianName"
                selectValue={filters.technicianName}
                setterFunction={(selectedTechnician) => {
                  setFilters({
                    ...filters,
                    technicianName: selectedTechnician
                  })
                  setTechnicianName(selectedTechnician);
                }
                }
                data={tecnicos}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.technicianName"
                    defaultMessage="Nombre del técnico"
                  />
                }
              />
              <SelectComboBox
                name="cargo"
                selectValue={filters.cargo}
                setterFunction={(cargo) => setFilters({ ...filters, cargo })}
                data={cargos}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.agenda.select.position"
                    defaultMessage="Filtrar por cargo"
                  />
                }
              />
            </div>
          </section>
          <section className={styles.btnFiltersContainer}>
            <button onClick={handleButtonFilter} className="btn-add" style={{
              boxShadow: "100px",
            }} >
              <FormattedMessage id="btn.filter" defaultMessage="Filtrar" />
            </button>
            <button onClick={handleButtonRefresh} className="btn-action-primary custom-margin-0001" style={{
              fontSize: "13px",
              color: "#ffff",
              fontWeight: "600",
              boxShadow: "10px",
              background: "#F9B233"
            }} >
              <MdAutorenew className="icon-refresh" />
            </button>
          </section>
          <div style={{ display: "flex", marginTop: 50, gap: 20 }}>
            <Day
              data={filteredServices}
              today={new Date()}
              day={new Date(getDayPropStart())}
              dateEnd={new Date(getDayPropEnd())}
            />
          </div>
          <Week
            firstDateOfWeek={new Date(getDayPropStart())}
            today={new Date()}
            data={week}
          />
        </div>
      ) : ("...No data available")}
    </>
  );
}
export default GanttService;
