import React, { DetailedHTMLProps, ButtonHTMLAttributes, ReactNode } from "react";
import styles from "./styles.module.css";

const IconButton = ({ icon, ...props }) => {
  return (
    <button
      className={`${styles.button__icon} ${styles.button__ripple} ${props.className}`}
      {...props}
    >
      {icon}
    </button>
  );
};
export default IconButton;

