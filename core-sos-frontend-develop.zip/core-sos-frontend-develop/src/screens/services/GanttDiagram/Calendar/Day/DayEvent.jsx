import useLangv2 from "hooks/useLangv2";
import moment from "moment";
import React, { useMemo } from "react";
import { BsFillBellFill } from "react-icons/bs";
import { NavLink } from "react-router-dom";
import { addOpacityToHSL, getRandomColor } from "screens/services/utils/string";
import paths from 'services/paths';
import styles from "./styles.module.css";




const DayEvent = ({ service, height = 100 }) => {
  const { formatterText } = useLangv2();


  const startDate = useMemo(
    () => moment(new Date(service.service_date_start)),
    [service]
  );

  const startDateMinutes = useMemo(() => startDate.minutes, [startDate]);

  const endDate = useMemo(
    () => moment(new Date(service.service_date_end)),
    [service]
  );

  const duration = useMemo(() => {
    return startDate.diff(endDate, "minutes");
  }, [startDate, endDate]);

  const width = useMemo(() => {
    const result = (duration * 100) / 60;

    if (result < 0) return result * -1;

    return result;
  }, [duration]);

  const color = useMemo(() => {
    return getRandomColor();
  }, []);

  const isLate = useMemo(
    () =>
      endDate <= moment() &&
      (service.service_status === "Asignado"),

    [endDate]);

  const handleAuxClick = (e, pathToGo) => {
    if (e.button === 1) {
      e.preventDefault();
      window.open(`#${pathToGo}`, '_blank');
    } else if (e.button === 0) {
      return;
    }
  };

  return (

    <div
      style={{
        width: `${width}%`,
        background: isLate
          ? "rgba(255, 63, 63, 1.0)"
          : `${addOpacityToHSL(color)}`,
        minHeight: `${height}%`,
        left: `${service.service_time.slice(3)}%`,
      }}
      className={styles.day__event_container}
    >

      <div
        className={styles.day__event_progress}
        style={{
          width: `${isLate ? 100 : service.percentage}%`,
          background: isLate ? "rgba(0, 0, 0, 0.0)" : color,
          height: "100%",
        }}
      >
        <span className={styles.day__event_progress_alert}>
          {service.notifications ? <BsFillBellFill /> : ''}
        </span>
      </div>
      <div className={styles.day__tooltip}>
        <div
          className={styles.day__event_progress}
          style={{
            width: `${service.percentage}%`,
            background: color,
            height: "5px",
            borderRadius: 6,
          }}
        />
        <ul>
          <NavLink
            to={paths.updateService.replace(':id', parseInt(service.serviceId))}
            onAuxClick={(e) => handleAuxClick(e, paths.updateService.replace(':id', parseInt(service.serviceId)))}
            onScrollCapture={(e) => e.preventDefault()}


          >
            <li>
              {formatterText('id.day.event.service.id')} <span>{service.serviceId}</span>
            </li>
          </NavLink>
          <li>
            Ticket: <span>{service.ticket}</span>
          </li>
          <li>
            {formatterText('id.day.event.service.type')} <span>{service.service_type}</span>
          </li>
          <li>
            {formatterText('id.day.event.service.state')} <span>{service.service_status}</span>
          </li>
          {service.notifications !== 0 && (
            <NavLink
              to={paths.panelNotifications}
              onAuxClick={(e) => handleAuxClick(e, paths.panelNotifications)}
              onScrollCapture={(e) => e.preventDefault()}>
              <li>
                {formatterText('id.day.event.service.notifications')} <span>{service.notifications}</span>
              </li>
            </NavLink>
          )}
        </ul>
      </div>
    </div >
  );
};
export default DayEvent;
