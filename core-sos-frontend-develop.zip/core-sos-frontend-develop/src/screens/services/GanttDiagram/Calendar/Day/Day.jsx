import useLangv2 from 'hooks/useLangv2';
import { nanoid } from 'nanoid';
import React, { Fragment, useMemo, useRef, useState } from "react";
import { diffInHours, formatDate, formatDateString, getDatesOfWeek, getHoursOfDay } from "screens/services/utils/date";
import DayEvent from "./DayEvent";
import styles from "./styles.module.css";


const Day = ({ day, dateEnd, data, today }) => {

  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [startY, setStartY] = useState(0);
  const [startScrollLeft, setStartScrollLeft] = useState(0);
  const [startScrollTop, setStartScrollTop] = useState(0);
  const containerRef = useRef(null);

  // const handleMouseDown = (e) => {
  //   if (!isDragging) {
  //     setIsDragging(true);
  //     setStartX(e.pageX);
  //     setStartY(e.pageY);
  //     setStartScrollLeft(containerRef.current.scrollLeft);
  //     setStartScrollTop(containerRef.current.scrollTop);
  //   }
  // };

  // const handleMouseMove = (e) => {
  //   if (isDragging) {
  //     const x = e.pageX;
  //     const y = e.pageY;
  //     const distanceX = x - startX;
  //     const distanceY = y - startY;
  //     containerRef.current.scrollLeft = startScrollLeft - distanceX;
  //     containerRef.current.scrollTop = startScrollTop - distanceY;
  //   }
  // };

  // const handleMouseUp = () => {
  //   if (isDragging) {
  //     setIsDragging(false);
  //   }
  // };


  const { formatterText } = useLangv2();

  const getDataOfToday = (today, tech_id) => {
    const hoy = new Date(today);
    const nextHour = new Date(today);
    nextHour.setHours(nextHour.getHours() + 1);

    return data.filter((service) => {
      const dateService = new Date(service.service_date_start);
      const endService = new Date(service.service_date_end);

      return (
        dateService.getTime() >= hoy.getTime() &&
        dateService.getTime() < nextHour.getTime() &&
        dateService.getTime() < endService &&
        service.technician_id === tech_id
      );
    });
  };

  const getDataOfDay = (day, tech_id) => {
    const nextHour = new Date(day);
    nextHour.setHours(nextHour.getHours() + 1);

    return data.filter((service) => {
      const dateService = new Date(service.service_date_start);
      const endService = new Date(service.service_date_end);

      return (
        dateService.getTime() >= day.getTime() &&
        dateService.getTime() < nextHour.getTime() &&
        dateService.getTime() < endService &&
        service.technician_id === tech_id
      );
    });
  }

  const isHour = (date) => {
    const now = new Date();
    const nextHour = new Date(now);
    nextHour.setHours(now.getHours() + 1);
    const diff = diffInHours(now, date);
    return (
      now.getTime() >= date.getTime() &&
      date.getTime() < nextHour.getTime() &&
      diff === 0
    );
  };

  const technicians = useMemo(() => {
    const techs = data?.map((service) => ({
      technician_name: service.technician_name,
      technician_id: service.technician_id,
      technician_charge: service.technician_charge,
      technician_picture: service.technician_picture,
      serviceId: service.serviceId,
      notifications: service.notifications,
    }));

    return techs?.filter(
      (tech, idx) =>
        idx === techs.findIndex((t) => t.technician_id === tech.technician_id)
    );
  }, [data]);

  const hours = useMemo(() => {
    return getHoursOfDay();
  }, [day, dateEnd, today]);

  const dates = useMemo(() => {

    const initialRange = day || today;
    const endRange = dateEnd || day;
    return getDatesOfWeek(initialRange, endRange);

  }, [day, dateEnd, today]);

  return (
    <div className={styles.gantt__container}
    // ref={containerRef}
    // onMouseDown={handleMouseDown}
    // onMouseMove={handleMouseMove}
    // onMouseUp={handleMouseUp}
    >

      {dates.map((date) => (
        <div
          key={date.getTime()}
          className={styles.day__container}

        >
          {/* HEADER DATES */}
          <div className={styles.day__header}>
            {/* {dates[0] === date && ( */}
            <div className={styles.day__technician_header}>
              <span
                className={styles.tech__header_text}>
                {formatterText('nav.parent.2.child.option.5', 'Técnicos')}
              </span>
            </div>
            {/* )} */}

            <div
              key={date.getTime()}
              className={styles.day__date_cell}
            >
              <span className={styles.date__header}>
                {`${formatDateString(date, "monthString")}`}
                
              </span>
              {/* HEADER HOURS */}
              <div className={styles.day__header}>
                {hours.map((hour) => {
                  const todayHour = isHour(new Date(`${formatDate(day)} ${hour}`));

                  return (
                    <div
                      key={hour}
                      className={`${styles.hour} ${todayHour ? styles.today : ""}`}
                    >
                      <span className={styles.day__header_text}>{hour}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          {/* Content */}
          <div className={styles.day__content}>
            {technicians?.map((tech) => {
              return (
                <Fragment key={`${tech.idServicio}-${nanoid()}`}>
                  {/* {dates[0] === date && ( */}
                  <div className={styles.day__technician_content}>
                    <img
                      src="https://www.vhv.rs/dpng/d/276-2761771_transparent-avatar-png-vector-avatar-icon-png-png.png"
                      alt="Avatar img"
                    />
                    <div className={styles.name__techs}>
                      <span className={styles.day__tech_name}>
                        {tech.technician_name}
                      </span>         
                      <span className={styles.day__tech_charge}>
                        {tech.technician_charge}
                      </span>
                    </div>
                  </div>
                  {/* )} */}
                  {hours.map((hour) => {
                    const dataOfHour = getDataOfDay(
                      new Date(`${formatDate(date)} ${hour}`),
                      tech.technician_id
                    );
                    const dataOfHourToday = getDataOfToday(
                      new Date(`${formatDate(today)} ${hour}`),
                      tech.technician_id
                    );
                    return (
                      <div key={hour} className={styles.day__container_card} >
                        {date !== null && hour !== null ? (
                          dataOfHour.map((service) => (
                            <DayEvent
                              key={service.id}
                              service={service}
                              height={100 / dataOfHour.length}
                            />
                          ))
                        ) : (
                          dataOfHourToday.map((service) => (
                            <DayEvent
                              key={service.id}
                              service={service}
                              height={100 / dataOfHourToday.length}
                            />
                          ))
                        )}
                      </div>
                    );
                  })}
                </Fragment>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};
export default Day;