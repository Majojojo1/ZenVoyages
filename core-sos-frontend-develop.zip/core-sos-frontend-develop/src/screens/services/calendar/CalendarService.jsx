import { useCallback, useEffect, useMemo, useState } from 'react';
// Import Hooks
import { useStorage } from 'hooks/useStorage';
import useGetData from 'hooks/useGetData';
import useAxios from 'hooks/useAxios';
//Import Components
import { styled } from '@mui/material/styles';
import DateTimePicker from 'components/pickers/DateTimePicker';
// import SelectorGrid from "common/selects/SelectorGrid";
import TextField from '@mui/material/TextField';
import { Link } from 'react-router-dom';
import SelectComboBox from 'common/selects/SelectComboBox';
import { FormattedMessage } from 'react-intl';
//Import Utils
import styles from './CalendarService.module.css';
// Import Services
import endpoints from 'services/api';
// import { getAllCargos } from "services/api/cargos";
import paths from 'services/paths';
import { nanoid } from 'nanoid';
import { isEmpty, isString } from 'lodash';
import moment from 'moment';
import { Gantt, parseGanttSourceID } from './gantt';

const serviceStatuses = {
  inProgress: 'Asignado',
  doneTechnician: 'Finalizado Técnico',
  done: 'Finalizado',
};

// const getFormattedDate = (date) => {
//   const offset = date.getTimezoneOffset();
//   const compensatedDate = new Date(date.getTime() - offset * 60 * 1000);
//   return compensatedDate.toISOString().split('T')[0];
// };

// const buildDateObject = (stringDate) => {
//   const parts = stringDate.split('/');
//   return new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
// };

const getCardColor = (status) => {
  if (status === serviceStatuses.doneTechnician) {
    return {
      primary: '#fd6d6d',
      secondary: '#FFE3E1',
    };
  }

  if (status === serviceStatuses.inProgress) {
    return {
      primary: '#3ec3ca',
      secondary: '#CBF1F5',
    };
  }

  return {
    primary: '#e2bb45',
    secondary: '#FFF6BF',
  };
};

const CargoTextField = styled(TextField)({
  '& .MuiOutlinedInput-root': {
    '& .MuiInputBase-input': {
      padding: '7px 14px',
    },
  },
});

const TechnicianCard = ({ fullName = '', job = '' }) => {
  return (
    <div className={styles.techniciaCard}>
      <p>{fullName}</p>
      <p>{job}</p>
    </div>
  );
};

const TechnicianService = ({
  id,
  ticketNumber,
  serviceType,
  serviceStatus,
  startDate,
  endDate,
  startHour,
  endHour,
}) => {
  const colors = getCardColor(serviceStatus);

  return (
    <Link to={paths.updateService.replace(':id', parseInt(id))} target="_blank">
      <div
        className={styles.technicianServiceCard}
        style={{
          backgroundColor: colors.secondary,
          border: `2px solid ${colors.primary}`,
        }}
      >
        <div className={styles.headerContainer}>
          <div className={styles.TickerNumberType}>
            <p style={{ margin: 0 }}>#{ticketNumber}</p>
            <p>{serviceType}</p>
          </div>

          <div className={styles.serviceStatus}>
            <p className={styles.boldText} style={{ backgroundColor: colors.primary }}>
              {serviceStatus}
            </p>
          </div>
        </div>

        <div className={styles.serviceCardDateTimeContainer}>
          <div className={styles.serviceCardDateTimeRow}>
            <p>
              <FormattedMessage id="text.start" defaultMessage="Inicio" />
            </p>
            <p>{startDate}</p>
            <p>{startHour}</p>
          </div>
          <div className={styles.serviceCardDateTimeRow}>
            <p>
              <FormattedMessage id="text.end" defaultMessage="Fin" />
            </p>
            <p>{endDate}</p>
            <p>{endHour}</p>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default function CalendarService() {
  // Manage axios requests
  const { fetchData } = useAxios();
  const { displayLoading } = useGetData();
  const [isLoading, setIsLoading] = useState(true);
  const [cargos, setCargos] = useState(null);
  const [tecnicos, setTecnicos] = useState(null);
  const { getItem } = useStorage();
  const userData = getItem('userData');
  const [filters, setFilters] = useState({
    technicianName: null,
    cargo: null,    
  });
  const [calendarServices, setCalendarServices] = useState([]);
  const [rangoFechaServicioInicial, setRangoFechaCitaInicio] = useState('');
  const [rangoFechaServicioFinal, setRangoFechaServicioFinal] = useState('');
  const [technicianName, setTechnicianName] = useState('');

  const calendarServicesFiltered = useMemo(() => {
    let results = [...calendarServices];

    if (!isEmpty(filters.technicianName)) {
      results = results.filter(({ nombre }) =>
        new RegExp(filters.technicianName.label, 'gi').test(nombre),
      );
    }
    if (!isEmpty(filters.cargo) && !isEmpty(filters.cargo.label)) {
      results = results.filter(({ cargo }) => new RegExp(cargo, 'gi').test(filters.cargo.label));
    }

    if (
      !isEmpty(rangoFechaServicioInicial) &&
      !isEmpty(rangoFechaServicioInicial.rangoFechaServicioInicial)
    ) {
      const compareFrom = moment(rangoFechaServicioInicial.rangoFechaServicioInicial);

      results = results.filter(({ servicios }) =>
        servicios.some((servicio) => {
          const [hours = 0, minutes = 0, , seconds = 0] = (servicio?.horaInicio || '')
            .split(':')
            .map(Number);

          const compareTo = moment(servicio.fechaInicio).set({
            hours,
            minutes,
            seconds,
          });

          return compareFrom.isSame(compareTo);
        }),
      );
    }

    if (
      !isEmpty(rangoFechaServicioFinal) &&
      !isEmpty(rangoFechaServicioFinal.rangoFechaServicioFinal)
    ) {
      const compareFrom = moment(rangoFechaServicioFinal.rangoFechaServicioFinal);

      results = results.filter(({ servicios }) =>
        servicios.some((servicio) => {
          const [hours = 0, minutes = 0, , seconds = 0] = (servicio?.horaFin || '')
            .split(':')
            .map(Number);

          const compareTo = moment(servicio.fechaFin).set({
            hours,
            minutes,
            seconds,
          });

          return compareFrom.isSame(compareTo);
        }),
      );
    }

    return results;
  }, [calendarServices, filters, rangoFechaServicioFinal, rangoFechaServicioInicial]);

  const ganttRows = useMemo(
    () => [
      {
        id: '1',
        customId: ({ row, vido }) => {
          const id = parseGanttSourceID(row.id);
          return vido.html`<div class="your-class" @click="${() => onClick({ row, vido })}">
            Row id = ${id}
          </div>`;
        },
      },
      {
        id: '2',
        customId: ({ row, vido }) => {
          const id = parseGanttSourceID(row.id);
          return vido.html`<div class="your-class" @click="${() => onClick({ row, vido })}">
            Row id = ${id}
          </div>`;
        },
      },
      {
        id: '3',
        customId: ({ row, vido }) => {
          const id = parseGanttSourceID(row.id);
          return vido.html`<div class="your-class" @click="${() => onClick({ row, vido })}">
            Row id = ${id}
          </div>`;
        },
      },
    ],
    [calendarServicesFiltered],
  );

  const ganttColumns = useMemo(
    () => [
      {
        id: 'id',
        width: 100,
        data: 'customId',
        header: { content: 'ID' },
      },
      {
        id: 'name',
        width: 250,
        expander: true,
        data: 'customName',
        header: {
          content: ({ column, vido }) =>
            vido.html`<div class="my-row" @click="${() => onClick(column)}">
            Name ${parseGanttSourceID(column.id)}
          </div>`,
        },
      },
    ],
    [calendarServicesFiltered],
  );

  const ganttItems = useMemo(
    () => [
      {
        id: '1',
        label: () => `<div>${'Michell'}</div>`,
        rowId: '1',
        isHTML: true,
        time: {
          start: moment(`2023-01-01`).valueOf(),
          end: moment('2023-01-02').valueOf(),
        },
      },
      {
        id: '2',
        label: () => `<div>${'Rafael'}</div>`,
        rowId: '2',
        linkedWith: ['1'],
        isHTML: true,
        time: {
          start: moment(`2023-01-02`).valueOf(),
          end: moment('2023-01-03').valueOf(),
        },
      },
      {
        id: '3',
        label: () => `<div>${'Charles'}</div>`,
        rowId: '2',
        linkedWith: ['1'],
        isHTML: true,
        time: {
          start: moment(`2023-01-04`).valueOf(),
          end: moment('2023-01-05').valueOf(),
        },
      },
      {
        id: '3',
        label: () => `<div>${'Juan'}</div>`,
        rowId: '2',
        linkedWith: ['1'],
        isHTML: true,
        time: {
          start: moment(`2023-01-04`).valueOf(),
          end: moment('2023-01-05').valueOf(),
        },
      },
      // {
      //   id: '2',
      //   label: 'Item 2',
      //   rowId: '1',
      //   isHTML: true,
      //   time: {
      //     start: moment('2020-02-01').valueOf(),
      //     end: moment('2020-02-02').valueOf(),
      //   },
      // },
      // {
      //   id: '3',
      //   label: 'Item 3',
      //   rowId: '2',
      //   isHTML: true,
      //   time: {
      //     start: moment('2020-01-15').valueOf(),
      //     end: moment('2020-01-20').valueOf(),
      //   },
      // },
    ],
    [calendarServicesFiltered],
  );

  const startDate = useMemo(
    () =>
      !rangoFechaServicioInicial || !rangoFechaServicioInicial.current
        ? moment()
        : moment(rangoFechaServicioInicial),
    [rangoFechaServicioInicial],
  );

  const endDate = useMemo(
    () =>
      !rangoFechaServicioFinal || !rangoFechaServicioFinal?.current
        ? null
        : moment(rangoFechaServicioFinal?.current?.value),
    [rangoFechaServicioFinal],
  );

  const jobId = useMemo(
    () => (!filters || !filters?.cargo || !filters?.cargo?.id ? null : filters.cargo.id),
    [filters],
  );

  const clientId = useMemo(
    () =>
      !userData || !userData?.idAsesorCliente || !userData?.idAsesorCliente?.idAsesor
        ? null
        : userData.idAsesorCliente.idAsesor,
    [userData],
  );

  const employeeId = useMemo(
    () =>
      !userData || !userData?.idEmpleado || !userData?.idEmpleado?.idEmpleado
        ? null
        : userData.idEmpleado.idEmpleado,
    [userData],
  );

  const serviceRequestBody = useMemo(
    () => ({
      idAsesorCliente: clientId,
      idEmpleado: employeeId,
      fechaInicio: startDate.format('YYYY-MM-DD'),
      fechaFin: !endDate ? null : endDate.format('YYYY-MM-DD'),
      nombreTecnico: technicianName,
      idCargo: jobId,
    }),
    [clientId, employeeId, startDate, endDate, technicianName, jobId],
  );

  const getJobs = useCallback(async () => {
    setIsLoading(true);
    const jobs = await fetchData({ url: endpoints.cargos.getAllCargos });
    const formattedJobs = jobs.response.map(({ idCargo, nombre }) => ({
      id: idCargo,
      label: nombre,
    }));

    setCargos(formattedJobs);
    setIsLoading(false);
  }, []);

  const getServices = useCallback(async () => {
    setIsLoading(true);
    const services = await fetchData({
      url: endpoints.services.getFirstCalendarServices,
      method: 'post',
      body: serviceRequestBody,
    });
    if (isString(services.response)) setCalendarServices([]);
    else setCalendarServices(services.response);
    
    const Formattedtechn = services.response.map(({ idTecnico, nombre }) => ({
      id: idTecnico,
      label: nombre,

    }));
    setTecnicos(Formattedtechn);
    setIsLoading(false);
  }, [serviceRequestBody]);

  const reload = useCallback(async () => {
    await getJobs();
    await getServices();
   
  }, [getJobs, getServices]);

  function onClick({ row, vido }) {
    alert(`Row ${parseGanttSourceID(row.id)} clicked!`);
  }

  useEffect(() => {
    const defaultRefreshTime = 1000 * 60;
    const timeoutId = setInterval(() => getServices(), defaultRefreshTime);
    (async () => {
      await reload();
    })();
    return () => {
      clearTimeout(timeoutId);
    };
  }, []);

  const loadData = async () => {
    try {
      const reqBody = serviceRequestBody;

      const calendarServicePromise = await fetchData({
        url: endpoints.services.getCalendarServices,
        method: 'post',
        body: reqBody,

      });
      const cargosPromise = await fetchData({
        url: endpoints.cargos.getAllCargos,
        method: 'get',
      });

      setCalendarServices(calendarServicePromise.response);
      setCargos(
        cargosPromise.response.map((cargo) => ({
          id: cargo.idCargo,
          label: cargo.nombre,
        })),
      );

      setIsLoading(false);
    } catch (error) {
      console.log("Error: ", error);
    }
  };

  if (isLoading) return displayLoading();



  return (
    <div className="spacing-1">
      <section className={styles.filtersContainer}>
        <div className="grid-container-1c-2g">
          <h3>
            <FormattedMessage id="text.filter.date" defaultMessage="Filtrar por fecha" />
          </h3>
          <div>
            <DateTimePicker
              name="rangoFechaServicioInicial"
              value={rangoFechaServicioInicial}
              onChange={setRangoFechaCitaInicio}
            />
          </div>
          <div>
            <DateTimePicker
              name="rangoFechaServicioFinal"
              value={rangoFechaServicioFinal}
              onChange={setRangoFechaServicioFinal}
            />
          </div>
        </div>
        <div className="grid-container-1c-2g">
          <h3>
            <FormattedMessage
              id="text.filter.nameOrJobTitle"
              defaultMessage="Filtrar por nombre o cargo"
            />
          </h3>
          <SelectComboBox
            id="technicianName"            
            selectValue={filters.technicianName}
            setterFunction={(selectedTechnician) => {
              setFilters({ 
                ...filters, 
                technicianName: selectedTechnician 
              })
              setTechnicianName(selectedTechnician);
            }
            }
            data={tecnicos}
            placeholder={
              <FormattedMessage
                id="input.placeholder.technicianName"
                defaultMessage="Nombre del técnico"
              />
            }
          />
          <SelectComboBox
            name="cargo"
            selectValue={filters.cargo}
            setterFunction={(cargo) => setFilters({ ...filters, cargo })}
            data={cargos}
            placeholder={
              <FormattedMessage
                id="input.placeholder.agenda.select.position"
                defaultMessage="Filtrar por cargo"
              />
            }
          />
        </div>
      </section>
      <section className={styles.btnFiltersContainer}>
        <button onClick={async () => loadData()} className="btn-add">
          <FormattedMessage id="btn.filter" defaultMessage="Filtrar" />
        </button>
      </section>

      <div className={styles.calendarContainer}>
        <table>
          <tbody>
            {calendarServicesFiltered.map((technician) => {
              return (
                <tr key={`${technician.idServicio}-${nanoid()}`}>
                  <td>
                    <TechnicianCard fullName={technician.nombre} job={technician.cargo} />
                  </td>
                  <td>
                    <div className={styles.servicesContainer}>
                      {technician.servicios.map((service) => {
                        const startDate = moment(service.fechaInicio).format('DD/MM/YYYY');
                        const endDate = moment(service.fechaFin).format('DD/MM/YYYY');

                        return (
                          <TechnicianService
                            key={`${service.idServicio}-${nanoid()}`}
                            id={service.idServicio}
                            ticketNumber={service.ticket}
                            serviceType={service.tipoServicio}
                            serviceStatus={service.estadoServicio}
                            startDate={startDate}
                            endDate={endDate}
                            startHour={service.horaInicio}
                            endHour={service.horaFin}
                          />
                        );
                      })}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Gantt rows={ganttRows} items={ganttItems} columns={ganttColumns} />
    </div>
  );
}
