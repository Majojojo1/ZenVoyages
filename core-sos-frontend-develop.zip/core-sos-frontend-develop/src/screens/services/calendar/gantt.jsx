import { useEffect, useState } from 'react';
import GSTC from 'gantt-schedule-timeline-calendar/dist/gstc.wasm.esm.min';
import 'gantt-schedule-timeline-calendar/dist/style.css';
import PropTypes from 'prop-types';

import './gantt.scss';

export const parseGanttSourceID = GSTC.api.GSTCID;

/**
 * Convert data from array into GSTC object
 */
const ganttParseFromArray = (array = []) => {
  const resultObj = {};

  for (const item of array) {
    item.id = parseGanttSourceID(item.id);

    if ('rowId' in item) item.rowId = parseGanttSourceID(item.rowId);
    if ('parentId' in item) item.parentId = parseGanttSourceID(item.parentId);
    if (Array.isArray(item.linkedWith)) {
      item.linkedWith = item.linkedWith.map((linkId) => parseGanttSourceID(linkId));
    }

    resultObj[item.id] = item;
  }

  return resultObj;
};

export const Gantt = ({ rows, items, columns }) => {
  let gantRef = null;
  const [state, setState] = useState(null);
  const [gantt, setGantt] = useState(null);
  const [config, setConfig] = useState(null);
  const [isMounted, setIsMounted] = useState(false);
  const [isGanttMounted, setIsGanttMounted] = useState(false);

  const render = (element) => {
    gantRef = element;
    if (isMounted) {
      const isReady = localStorage.getItem('is_ready') === 'true';

      if (!isReady && !!element && !isGanttMounted) {
        const $config = {
          licenseKey: process.env.REACT_APP_GANTT_SCHEDULE_TIMELINE_CALENDAR_LICENCE,
          list: {
            columns: {
              data: ganttParseFromArray(columns),
            },
            rows: ganttParseFromArray(rows),
          },
          chart: {
            items: ganttParseFromArray(items),
          },
        };

        const $state = GSTC.api.stateFromConfig($config);
        const $gantt = GSTC({ element, state: $state });

        localStorage.setItem('is_ready', 'true');
        setGantt($gantt);
        setState($state);
        setConfig($config);
        setIsGanttMounted(true);
      }
    }
  };

  useEffect(() => {
    localStorage.removeItem('is_ready');
    setIsMounted(true);

    return () => {
      localStorage.removeItem('is_ready');

      if (!!gantRef && !!gantRef) {
        if (!!gantt) gantt.destroy();
      }
    };
  }, []);

  useEffect(() => {
    if (!!gantt && !!gantRef) {
      gantt.reload();
    }
  });

  const padding = 30;
  const rowHeight = 75;

  /// Height: debe ser un Number, si o si
  return (
    <div
      className="gantt-root"
      ref={render}
      style={{
        height: rows.length * rowHeight + padding,
      }}
    />
  );
};

Gantt.propTypes = {
  rows: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    }),
  ).isRequired,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
      rowId: PropTypes.string.isRequired,
      time: PropTypes.shape({
        start: PropTypes.number.isRequired,
        end: PropTypes.number.isRequired,
      }).isRequired,
    }),
  ).isRequired,
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      data: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
      sortable: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
      isHTML: PropTypes.bool,
      width: PropTypes.number,
      header: PropTypes.shape({
        content: PropTypes.node,
      }),
    }),
  ).isRequired,
};
