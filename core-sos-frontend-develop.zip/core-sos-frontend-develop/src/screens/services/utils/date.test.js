import {
    formatHour,
    getDatesOfWeek,
    getDaysOfWeek,
    getHoursOfDay,
    getHoursOfDayB,
    getHoursOfDayForNDays,
    getHoursOfRange,
    isToday
} from './date';

describe('getHoursOfDay', () => {
    test('returns an array with 24 formatted hours', () => {
        const result = getHoursOfDay();
        expect(result).toHaveLength(24);
    })
});

describe('getHoursOfRange', () => {
    test('returns an array with hours of the given range', () => {
        const date = new Date('2023-01-01T12:00:00Z');
        const endDate = new Date('2023-01-03T12:00:00Z');
        const result = getHoursOfRange(date, endDate);
        expect(result).toHaveLength(72);
    });
});

describe('getHoursOfDayForNDays', () => {
    test('returns an array with days of the given range', () => {

        const date = new Date('2023-01-01T12:00:00Z');
        const endDate = new Date('2023-01-03T12:00:00Z');
        const result = getHoursOfDayForNDays(date, endDate);
        expect(result).toHaveLength(3);

    });
});

it('should return an array with 24 elements', () => {
    const result = getHoursOfDayB();
    expect(result).toHaveLength(24);
});


it('should return an array with elements representing different hours of the day', () => {
    const result = getHoursOfDayB();
    result.forEach((date, idx) => {
        const hour = new Date(date).getHours();
        expect(hour).toBe(idx);
    });
});


it('should not use any parameters', () => {
    const result = getHoursOfDayB();
    expect(result).toBeDefined();
});


it('should have the first element representing the date with hour 0', () => {
    const result = getHoursOfDayB();
    const firstDate = new Date(result[0]);
    expect(firstDate.getHours()).toBe(0);
});

it('should return an array with one element when endDate is not provided', () => {
    const date = new Date();
    const result = getDatesOfWeek(date);
    expect(result).toHaveLength(1);
    expect(result[0]).toEqual(date);
});


it('should return an array with all dates between date and endDate', () => {
    const date = new Date(2022, 0, 1);
    const endDate = new Date(2022, 0, 5);
    const result = getDatesOfWeek(date, endDate);
    expect(result).toHaveLength(5);
    expect(result[0]).toEqual(date);
    expect(result[4]).toEqual(endDate);
});

it('should return a formatted time string in 12-hour format when given a valid date and "12hours" format string', () => {
    const date = new Date(2022, 0, 1, 14, 30);
    const format = "12hours";
    const result = formatHour(date, format);
    expect(result).toBe("2:30 pm");
});


it('should return an array of 7 dates when given a valid date string', () => {
    const result = getDaysOfWeek('2022-01-01');
    expect(result).toHaveLength(7);
    expect(result[0]).toBeInstanceOf(Date);
    expect(result[1]).toBeInstanceOf(Date);
    expect(result[2]).toBeInstanceOf(Date);
    expect(result[3]).toBeInstanceOf(Date);
    expect(result[4]).toBeInstanceOf(Date);
    expect(result[5]).toBeInstanceOf(Date);
    expect(result[6]).toBeInstanceOf(Date);
});

it('should return true when given date is today', () => {
    const date = new Date();
    expect(isToday(date)).toBe(true);
});

it('should return false when given date is in the future', () => {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    expect(isToday(date)).toBe(false);
});


it('should return an array with a single date when given an invalid date object', () => {
    const invalidDate = new Date('invalid');
    const result = getDaysOfWeek(invalidDate);
    expect(result[0]).toBeInstanceOf(Date);
});

















