import {
    addOpacityToHSL,
    getRandomColor,
    uppercaseFirstLetter,
    valueSetter,
} from './string';


it('should return a string with the first letter capitalized', () => {
    const result = uppercaseFirstLetter('hello');
    expect(result).toBe('Hello');
});

it('should return a string with three values separated by commas', () => {
    const result = getRandomColor();
    const values = result.split(',');
    expect(values.length).toBe(3);
});


it('should invoke the getRandomColor function', () => {
    const spy = jest.spyOn(global.Math, 'random');
    getRandomColor();
    expect(spy).toHaveBeenCalled();
    spy.mockRestore();
});

it('should add opacity value of .5 to a valid HSL string', () => {
    const input = 'hsl(180, 50%, 50%)';
    const expected = 'hsl(180, 50%, 50%, .5)';
    const result = addOpacityToHSL(input);
    expect(result).toEqual(expected);
});


it('should return the input text when it does not contain placeholder', () => {
    const inputText = 'This is a test';
    const result = valueSetter(inputText);
    expect(result).toBe(inputText);
});