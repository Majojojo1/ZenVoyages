import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useLangv2 from 'hooks/useLangv2';
import usePermission from 'hooks/usePermission';
import { useParams } from 'react-router';
import { useNavigate } from 'react-router-dom';
// Import Components
// Mui Cell row style
import TableRow from '@mui/material/TableRow';
import {
  MdCheckBox,
  MdDelete,
  MdDownload,
  MdEdit,
  MdEmail,
  MdLoyalty,
  MdRemoveRedEye,
} from 'react-icons/md';
// Icons for cell
import TableCell from '@mui/material/TableCell';
// Import Libs
import { Modal } from 'react-responsive-modal';
// import Screens
import UpdateDatimeAlert from 'screens/services/Modals/UpdateDatimeAlert';
// import Services
import endpoints from 'services/api';
import { addItem, getItemById, updateItem } from 'services/api/methods';
// import Styles
import WarningDialog from 'components/tableOptions/WarningDialog';
import { useSeachContext } from 'context/SearchContext';
import styles from 'screens/services/ExtraTabs/Tab.module.css';

const DynamicRowServices = ({
  titles,
  columns,
  getData,
  handleDownloadItem,
  handleDeleteItem,
  handleEditStateItem,
  noHandleEditStateItem,
  routeToEdit,
  canDeleted,
  canDownload,
  canViewDetails,
  canChangeData,
  canModify,
  canSelectEU,
  canSelectSC,
  onClose,
  statusActivity,
  sendMail,
  setSendMail,
  getDataToUpdate,
  setCounterActivities,
}) => {
  // Modal config
  const [changeDateTime, setChangeDateTime] = useState(false);
  const onOpenChangeDateTime = () => setChangeDateTime(true);
  const onCloseChangeDateTime = () => setChangeDateTime(false);
  // Manage axios requests
  const { fetchData, COOKIE_USER } = useAxios();
  const { permissions } = usePermission();
  // use Hook of language v2
  const {
    updatedItem,
    successRemoveItem,
    noFilledContent,
    errorProcess,
    errorRestriction,
    errorRelation,
    errorUsed,
    showPermissionDenied,
    customSB,
    handleRequestError,
    formatterText,
  } = useLangv2();
  // eslint-disable-next-line no-unused-vars
  const { dataTable, searchResults = [], setDataTable } = useSeachContext();
  const navigate = useNavigate();
  // Set the data of the externalUserSelected and ClientSelected
  const { setExternalUserSelected, setClientSelected, idEstadoServicio, listActivities } =
    useContext(AppContext);

  const [stateAux, setStateAux] = useState(columns.estado);
  const [loadingAux, setLoadingAux] = useState(false);
  // eslint-disable-next-line no-unused-vars
  const [dateAux, setDateAux] = useState(columns.fechaModificacion);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({});
  // Modal config
  const [openDetails, setOpenDetails] = useState(false);
  const [openChangeData, setOpenChangeData] = useState(false);
  const onCloseDetails = () => setOpenDetails(false);
  const onOpenDetails = () => setOpenDetails(true);
  const onCloseChangeData = () => setOpenChangeData(false);
  const onOpenChangeData = () => setOpenChangeData(true);

  const [loadingModal, setLoadingModal] = useState(false);
  const [flagStatus, setFlagStatus] = useState(false);
  // const [sendMail, setSendMail] = useState(false);
  const [mailProv, setMailProv] = useState('');

  // get the id of the services
  const { id } = useParams();
  // Dialog edit
  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  //
  const [dataProvider, setDataProvider] = useState([
    {
      nombreRazonSocial: '',
      identificacion: '',
      telefono: '',
      correo: '',
    },
  ]);

  useEffect(() => {
    setStateAux(columns.estado);
    // setDateAux(columns.fechaModificacion);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchResults]);

  const handleEdit = (id) => {
    localStorage.setItem(
      'dataUpdate',
      JSON.stringify({
        ...columns.objeto,
        estado: stateAux,
      }),
    );
    navigate(routeToEdit.replace(':id', parseInt(id)));
  };

  const handleChangeSendMail = () => setSendMail(!sendMail);
  const handleDelete = (columns) => {
    handleDeleteItem(columns)
      .then((res) => {
        if (res) {
          successRemoveItem();
          closeDialog();
        }
      })
      .catch((err) => {
        if (err.response.status === 500) {
          errorRelation();
        } else {
          errorRestriction();
        }
        closeDialog();
      });
  };

  // Permite el cambio de estado de un registro
  const handleToggle = () => {
    const estado = stateAux === 1 ? 0 : 1;
    closeDialog();
    const newData = {
      ...columns.objeto,
      estado: estado,
      usuarioModificacion: COOKIE_USER,
    };
    // execute update function
    handleEditStateItem(newData)
      .then((res) => {
        successRemoveItem();
        // set the values of the state of the item of currentDataRow
        setStateAux(estado);
      })
      .catch((err) => {
        handleRequestError(err);
      });
  };

  const closeDialog = () => {
    setLoading(false);
    setDialog({ ...dialog, active: false });
  };

  const displayColor = (date) => {
    const date1 = new Date(date);
    const date2 = new Date();
    const timeDiff = date1.getTime() - date2.getTime();
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    if (diffDays >= 90 && diffDays > 30) {
      return '#FFC954';
    } else if (diffDays <= 30 && diffDays > 0) {
      return '#F4A64A';
    } else if (diffDays <= 0) {
      return '#DD3333';
    } else {
      return 'gray';
    }
  };

  // Sprint 8 Download Form
  const handleDownload = (id) => {
    handleDownloadItem(id);
  };

  // Sprint 9 View Details HU10
  const handleDetails = (value) => {
    getItemById(
      endpoints.serviceProduct.getAlllProviderByIdServiceProduct,
      value.idServicioProducto,
    )
      .then((res) => {
        setLoadingAux(true);
        setDataProvider(res);
        onOpenDetails();
      })
      .catch((err) => {
        console.log('err ', err);
      });
  };

  // Update data of a product service S9 HU10
  const handleUpdatePCO = (obj) => {
    //  check if the fields are empty
    if (
      formData.cantidadSolicitada === '' ||
      formData.cantidadAprobada === '' ||
      formData.observacion === ''
    ) {
      noFilledContent();
    } else {
      setLoadingModal(true);
      const data = {
        idServicioProducto: obj.idServicioProducto,
        idProducto: obj.idProducto,
        idServicio: parseInt(id),
        idProveedor: obj.idProveedor,
        idTipoEntrega: obj.idTipoEntrega,
        idUnidadMedida: obj.idUnidadmedida,
        gestionado: obj.gestionado,
        cantidadSolicitada: parseInt(formData.cantidadSolicitada),
        cantidadAprobada: parseInt(formData.cantidadAprobada),
        costo: formData.costo,
        observacion: formData.observacion,
        fechaRegistro: obj.fechaRegistro,
        fechaModificacion: null,
        usuarioCreacion: obj.usuarioCreacion,
        usuarioModificacion: COOKIE_USER,
        nombreProducto: obj.nombreProducto,
        idCategoriaProducto: obj.idCategoriaProducto,
        sku: obj.sku,
        nombreCategoriaProducto: obj.nombreCategoriaProducto,
        iva: 19,
        idMoneda: {
          idMoneda: 1,
        },
      };
      updateItem(endpoints.serviceProduct.updateServiceProduct, data)
        .then((res) => {
          if (res) {
            updatedItem();
            getData();
            onCloseChangeData();
          }
          setLoadingModal(false);
        })
        .catch((err) => {
          console.log(err);
          handleRequestError(err);
          closeDialog();
          setLoadingModal(false);
        });
    }
  };

  // Sprint 8 Select obj Externaluser
  const handleSelectEU = (obj) => {
    new Promise((resolve) => {
      setExternalUserSelected({
        nombre: `${obj.primerNombre} ${obj.primerApellido} - ${obj.telefono} - ${obj.correo}`,
        id: obj.idUsuarioServicio,
      });
      resolve();
    }).then(() => {
      onClose();
    });
  };

  // Sprint 8 Select obj System Client
  const handleSelectSC = (obj) => {
    new Promise((resolve) => {
      setClientSelected({
        nombre: `${obj.nombreRazonSocial} - ${obj.identificacion} - ${obj.telefono} - ${obj.correo}`,
        id: obj.idCliente,
      });
      resolve();
    }).then(() => {
      onClose();
    });
  };

  // Update the state of the delivery
  const updateDeliveryState = (value, obj) => {
    if (value !== '') {
      let data = {
        idServicioProducto: obj.idServicioProducto,
        idProducto: obj.idProducto,
        idServicio: parseInt(id),
        idProveedor: obj.idProveedor,
        idTipoEntrega: parseInt(value),
        idUnidadMedida: obj.idUnidadmedida,
        gestionado: obj.gestionado,
        cantidadSolicitada: obj.cantidadSolicitada,
        cantidadAprobada: obj.cantidadSolicitada,
        costo: obj.costo,
        observacion: obj.observacion,
        fechaRegistro: obj.fechaRegistro,
        fechaModificacion: null,
        usuarioCreacion: obj.usuarioCreacion,
        usuarioModificacion: COOKIE_USER,
        iva: 19,
        idMoneda: {
          idMoneda: 1,
        },
      };

      updateItem(endpoints.serviceProduct.updateServiceProduct, data)
        .then((res) => {
          if (res) {
            updatedItem();
            closeDialog();
          }
        })
        .catch((err) => {
          console.log(err);
          handleRequestError(err);
          closeDialog();
        });
    }
  };

  // Update the state of the activity service state
  const updateActivityServiceState = (value, obj) => {
    // iterate the list of activities to extract the index, then verify if the values above have the
    // idEstadoActividad !== 1, if so, the activity is not updated showing a message to the user
    const VALUE_I = listActivities.findIndex((item) => item.id === obj.idServicioActividad);

    // aux variable to verify if the activity can be updated
    let canUpdate = true;

    // iterate the list of activities to verify if the activity can be updated
    for (let index = 0; index <= VALUE_I - 1; index++) {
      const element = listActivities[index];

      if (element.EstadoActividad === 1) {
        canUpdate = false;
        customSB(
          'warning',
          'snackbar.warning.activity.service.pending',
          'Hay actividades pendientes sin iniciar, por favor actualice el estado de las anteriores actividades.',
        );
        break;
      }
    }

    if (canUpdate) {
      if (value !== '') {
        const DATA = {
          idServicioActividad: obj.idServicioActividad,
          idEstadoActividad: { idEstadoActividad: parseInt(value) },
          idServicio: { idServicio: obj.idServicio.idServicio },
          fechaCreacion: new Date().toISOString(),
          usuarioCreacion: COOKIE_USER,
          usuarioModificacion: COOKIE_USER,
        };
        if (parseInt(value) === 4) {
          onOpenChangeDateTime();
          if (flagStatus) {
            updateItem(endpoints.services.updateStateActivityService, DATA)
              .then((res) => {
                if (res) {
                  updatedItem();
                  setCounterActivities(0);
                  getData();
                }
              })
              .catch((err) => {
                handleRequestError(err);
                setCounterActivities(0);
                getData();
              });
            setFlagStatus(false);
          }
          setFlagStatus(false);
        } else {
          updateItem(endpoints.services.updateStateActivityService, DATA)
            .then((res) => {
              if (res) {
                updatedItem();
                setCounterActivities(0);
                getData();
              }
            })
            .catch((err) => {
              handleRequestError(err);
              setCounterActivities(0);
              getData();
            });
        }
      }
    }
  };

  const changeStateOfProduct = (state, columns) => {
    // manage the state of the product S9 HU10 C6
    const access = permissions.filter(
      (item) => item.idModulo === 22 && item.nombrePermiso === 'CAMBIAR_ESTADO',
    );
    if (state === 1) {
      if (access.length > 0) {
        handlerChangeStateOfProduct(state, columns);
      } else {
        showPermissionDenied();
      }
    } else {
      if (idEstadoServicio === 6) {
        if (access.length > 0) {
          handlerChangeStateOfProduct(state, columns);
        } else {
          showPermissionDenied();
        }
      } else {
        customSB(
          'warning',
          'snackbar.warning.update.state.product.progress',
          "No se puede actualizar el estado del producto, debido a que el servicio no esta en estado 'En Curso'.",
        );
      }
    }
  };

  const handlerChangeStateOfProduct = (state, columns) => {
    closeDialog();
    const newData = {
      idServicioProducto: columns.objeto.idServicioProducto,
      idProducto: columns.objeto.idProducto,
      idServicio: parseInt(id),
      idProveedor: columns.objeto.idProveedor,
      idTipoEntrega: columns.objeto.idTipoEntrega,
      idUnidadMedida: columns.objeto.idUnidadmedida,
      gestionado: state,
      cantidadSolicitada: columns.objeto.cantidadSolicitada,
      cantidadAprobada: columns.objeto.cantidadAprobada,
      costo: columns.objeto.costo,
      observacion: columns.objeto.observacion,
      fechaRegistro: columns.objeto.fechaRegistro,
      fechaModificacion: null,
      usuarioCreacion: columns.objeto.usuarioCreacion,
      usuarioModificacion: COOKIE_USER,
      nombreProducto: columns.objeto.nombreProducto,
      idCategoriaProducto: columns.objeto.idCategoriaProducto,
      sku: columns.objeto.sku,
      nombreCategoriaProducto: columns.objeto.nombreCategoriaProducto,
    };

    handleEditStateItem(newData)
      .then((res) => {
        getData();
        updatedItem();
        setStateAux(state);
      })
      .catch((err) => {
        handleRequestError(err);
      });
  };

  // const handleDownloadForm = (id) => {

  //   if (columns.EstadoActividad != 3) {
  //     return "PENDIND";
  //   }

  // }

  const handleSendMail = (columns) => {
    let body = {
      idServicioProducto: columns.objeto.idServicioProducto,
    };
    addItem(endpoints.serviceProduct.sendMail, body)
      .then((data) => {
        customSB('success', 'toast.email.success', data.message);
        closeDialog();

      })
      .catch((err) => {
        customSB('error', 'toast.email.error', 'El correo no pudo ser enviado.');
        closeDialog();

      });
  };
  const selectProvider = (providerData, serviceProduct) => {
    const newUpdate = {
      idServicioProducto: serviceProduct.idServicioProducto,
      idProducto: serviceProduct.idProducto,
      idServicio: parseInt(id),
      idProveedor: providerData.idproveedor,
      costo: providerData.costo,
      idTipoEntrega: serviceProduct.idTipoEntrega,
      idUnidadMedida: serviceProduct.idUnidadmedida,
      gestionado: serviceProduct.gestionado,
      cantidadSolicitada: parseInt(serviceProduct.cantidadSolicitada),
      cantidadAprobada: parseInt(serviceProduct.cantidadAprobada),
      observacion: serviceProduct.observacion,
      fechaRegistro: serviceProduct.fechaRegistro,
      fechaModificacion: serviceProduct.fechaModificacion,
      usuarioCreacion: serviceProduct.usuarioCreacion,
      usuarioModificacion: COOKIE_USER,
      nombreProducto: serviceProduct.nombreProducto,
      idCategoriaProducto: serviceProduct.idCategoriaProducto,
      sku: serviceProduct.sku,
      nombreCategoriaProducto: serviceProduct.nombreCategoriaProducto,
      iva: 19,
      idMoneda: {
        idMoneda: 1,
      },
    };

    fetchData({
      url: endpoints.serviceProduct.updateServiceProduct,
      method: 'put',
      body: newUpdate,
    }).then((data) => {
      const { error } = data;
      if (error === '200') {
        updatedItem();
        getData();
        handleChangeSendMail();
        onCloseDetails();
      }
    }).catch((err) => {
      console.log(err);
      handleRequestError(err);
    });
  };

  return (
    <>
      <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
        {Object.keys(columns).map((column, index) => {
          if (
            column === 'id' ||
            column === 'objeto' ||
            column === 'usuarioCreacion' ||
            column === 'fc' ||
            column === 'uc'
          ) {
            return null;
          }
          if (column === 'estado') {
            return (
              <TableCell className={loading ? 'disabled' : 'enabled'} align="center" key={index}>
                {stateAux === 1 ? (
                  <button
                    className="btn-state"
                    disabled={loading}
                    onClick={() => {
                      if (!noHandleEditStateItem) {
                        setDialog({
                          text: `dialog.title.delete.mid.first ${columns.nombre} dialog.title.delete.mid.end.inactive`,
                          active: true,
                          funcion: () => handleToggle(),
                        });
                      }
                    }}
                  >
                    {formatterText('title.service.status.active')}
                  </button>
                ) : stateAux === 0 ? (
                  <button
                    className="btn-inactive_state"
                    disabled={loading}
                    onClick={() => {
                      if (!noHandleEditStateItem) {
                        setDialog({
                          text: `dialog.title.delete.mid.first ${columns.nombre} dialog.title.delete.mid.end.active`,
                          active: true,
                          action: 'active',
                          funcion: () => handleToggle(),
                        });
                      }
                    }}
                  >
                    {formatterText('title.service.status.inactive')}
                  </button>
                ) : stateAux === 2 ? (
                  <button className="btn-disabled_state">{formatterText('title.service.status.disabled')}</button>
                ) : (
                  <h5> </h5>
                )}
              </TableCell>
            );
          }
          if (column === 'productState') {
            return (
              <TableCell align="center" key={index}>
                {columns[column] === 0 ? (
                  /*  <button
                    className="btn-action-ps"
                    onClick={(e) => e.preventDefault()}
                  >
                    Sin gestionar
                  </button> */

                  <button
                    className="btn-action-ps"
                    disabled={loading}
                    onClick={(e) => {
                      e.preventDefault();
                      if (!noHandleEditStateItem) {
                        setDialog({
                          text: `${formatterText('title.service.confirm.changeStatusTo')} ${columns.nombre} ${formatterText('title.service.status.managed')}`,
                          active: true,
                          action: 'active',
                          funcion: (e) => {
                            changeStateOfProduct(1, columns);
                            handleChangeSendMail();
                          },
                        });
                      }
                    }}
                  >
                    {formatterText('title.service.status.managed')}

                  </button>
                ) : columns[column] === 1 ? (
                  <button
                    className="btn-action-ps"
                    disabled={loading}
                    onClick={(e) => {
                      e.preventDefault();
                      if (!noHandleEditStateItem) {
                        setDialog({
                          text: `${formatterText('title.service.confirm.changeStatusTo')} ${columns.nombre} ${formatterText('title.service.status.unmanaged')}`,
                          active: true,
                          action: 'active',
                          funcion: (e) => {
                            changeStateOfProduct(0, columns);
                            handleChangeSendMail();
                          },
                        });
                      }
                    }}
                  >
                    {formatterText('title.service.status.unmanaged')}

                  </button>
                ) : columns[column] === 2 ? (
                  <button className="btn-disabled_state">{formatterText('title.service.status.otherManagementType')}</button>
                ) : (
                  <h5>{formatterText('title.service.error.idIncorrect')}</h5>
                )}
              </TableCell>
            );
          }
          if (column === 'deliveryType') {
            return (
              <TableCell align="center" key={index}>
                <select
                  className="select-type"
                  defaultValue={columns[column]}
                  onChange={(e) => {
                    e.preventDefault();
                    updateDeliveryState(e.target.value, columns.objeto);
                  }}
                >
                  <option value="">{formatterText('title.service.select.option')}</option>
                  <option value="1">{formatterText('title.service.search.store')}</option>
                  <option value="2">{formatterText('title.service.awaiting.product')}</option>
                </select>
              </TableCell>
            );
          }
          if (column === 'EstadoActividad') {
            return (
              <TableCell align="center" key={index}>
                <select
                  className="select-type"
                  defaultValue={columns[column].toString()}
                  value={columns[column].toString()}
                  disabled={
                    statusActivity === 9
                      ? columns['actividadTecnica'] === 'Si'
                        ? true
                        : false
                      : false
                  }
                  onChange={(e) => {
                    e.preventDefault();
                    updateActivityServiceState(e.target.value, columns.objeto);
                  }}
                >
                  <option value="">{formatterText('title.service.select.option')}</option>
                  <option value="1">{formatterText('title.service.status.notStarted')}</option>
                  <option value="2">{formatterText('title.service.status.inProgress')}</option>
                  <option value="3">{formatterText('title.service.status.completed')}</option>
                  <option value="4">{formatterText('title.service.status.paused')}</option>
                </select>
              </TableCell>
            );
          }
          if (column === 'fechaModificacion') {
            return (
              <TableCell align="left" key={index}>
                {dateAux}
              </TableCell>
            );
          }
          if (column === 'vencimientoSoat') {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: 'none',
                    color: 'white',
                    borderRadius: '15px',
                    fontWeight: '700',
                    padding: '0.7rem',
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          if (column === 'vencimientoTecnicoMecanico') {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: 'none',
                    color: 'white',
                    borderRadius: '15px',
                    fontWeight: '700',
                    padding: '0.7rem',
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          if (column === 'vencimientoRunt') {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: displayColor(columns[column]),
                    border: 'none',
                    color: 'white',
                    borderRadius: '15px',
                    fontWeight: '700',
                    padding: '0.7rem',
                  }}
                >
                  {columns[column]}
                </button>
              </TableCell>
            );
          }
          if (column === 'color') {
            return (
              <TableCell align="center" key={index}>
                <button
                  style={{
                    backgroundColor: columns[column],
                    border: 'none',
                    color: 'white',
                    borderRadius: '15px',
                    fontWeight: '700',
                    padding: '0.7rem',
                  }}
                ></button>
              </TableCell>
            );
          }
          return (
            <TableCell key={index} component="th" scope="row" className="enabled">
              {columns[column]}
            </TableCell>
          );
        })}

        {titles.includes(formatterText('title.service.create.product.actions')) && (
          <TableCell className={loading ? 'disabled' : 'enabled'} align="center" width="120px">
            {canSelectEU && (
              <MdCheckBox
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => handleSelectEU(columns.objeto)}
              />
            )}
            {canSelectSC && (
              <MdCheckBox
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => handleSelectSC(columns.objeto)}
              />
            )}
            {canDownload && (
              <MdDownload
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => handleDownload(columns.id)}
              />
            )}
            {canViewDetails && (
              <MdRemoveRedEye
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => handleDetails(columns.objeto)}
              />
            )}
            {canChangeData && (
              <MdLoyalty
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => {
                  // set the data in the fields and then open the modal
                  setFormData({
                    cantidadSolicitada: columns.objeto.cantidadSolicitada,
                    cantidadAprobada: columns.objeto.cantidadAprobada,
                    observacion: columns.objeto.observacion,
                    costo: columns.objeto.costo,
                  });

                  onOpenChangeData();
                }}
              />
            )}
            {canModify && (
              <MdEdit
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() => handleEdit(columns.id)}
              />
            )}

            {canDeleted && (
              <MdDelete
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() =>
                  setDialog({
                    text: `${formatterText('title.service.confirm.delete')} ${columns.nombre}`,
                    active: true,
                    action: 'delete',
                    funcion: () => handleDelete(columns.id),
                  })
                }
              />
            )}
            {sendMail && (
              <MdEmail
                size={25}
                color="gray"
                cursor="pointer"
                disabled={loading}
                onClick={() =>
                  setDialog({
                    text: `${formatterText('title.service.confirm.sendPurchaseOrderTo')}  ${columns.proveeAProb}`,
                    active: true,
                    funcion: () => handleSendMail(columns),
                  })
                }
              />
            )}
          </TableCell>
        )}
        {titles.includes('Eliminar') && (
          <TableCell className={loading ? 'disabled' : 'enabled'} align="center">
            <MdDelete
              size={25}
              color="gray"
              cursor="pointer"
              onClick={() =>
                setDialog({
                  text: `Vas a eliminar ${columns.nombre}`,
                  active: true,
                  action: 'delete',
                  funcion: () => handleDelete(columns),
                })
              }
              disabled={loading}
            />
          </TableCell>
        )}
        {titles.includes('Acciones.') && (
          <TableCell className={loading ? 'disabled' : 'enabled'} align="center">
            <MdDelete
              size={25}
              color="gray"
              cursor="pointer"
              onClick={() =>
                setDialog({
                  text: `Vas a eliminar ${columns.nombre}`,
                  active: true,
                  action: 'delete',
                  funcion: () => handleDelete(columns),
                })
              }
              disabled={loading}
            />
          </TableCell>
        )}
        <WarningDialog dialog={dialog} setDialog={setDialog} />
      </TableRow>
      <Modal
        open={openDetails}
        onClose={onCloseDetails}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        {loadingAux &&
          dataProvider.map((data, index) => (
            <div key={`${index}+${data.nombreRazonSocial}`}>
              <h3>{formatterText('title.service.create.supplier')}: {index + 1} </h3>
              <p>{formatterText('title.service.create.nameOrLegalEntity')}: {data.nombreRazonSocial}</p>
              <p>{formatterText('title.service.create.identification')}: {data.identificacion}</p>
              <p>{formatterText('title.service.create.city')}: {data.nombreMunicipio}</p>
              <p>{formatterText('title.service.create.address')}: {data.direccion}</p>
              <p>{formatterText('title.service.create.phone')}: {data.telefono}</p>
              <p>{formatterText('title.service.create.email')}: {data.correo}</p>
              <p>
                {formatterText('title.service.create.cost')}: {data.costo} ({formatterText('title.service.create.unitOfMeasure')}: {data.nombreUnidadMedida})
              </p>
              <button
                className="btn-primary"
                onClick={(e) => {
                  e.preventDefault();
                  selectProvider(data, columns.objeto);
                }}
              >
                {formatterText('title.service.create.select')}
              </button>
            </div>
          ))}
      </Modal>
      <Modal
        open={openChangeData}
        onClose={onCloseChangeData}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal-90',
        }}
      >
        <section className={styles['container-ps-modal-ud']}>
          <h3 className="title-modal">{formatterText('title.service.create.updateData')}</h3>
          <label>
            <span>{formatterText('title.service.create.approvedQuantity')}</span>
            <input
              type="text"
              className="input-default"
              name="cantidadSolicitada"
              placeholder="Cantidad Solicitada"
              value={formData.cantidadSolicitada}
              onChange={(e) => setFormData({ ...formData, cantidadSolicitada: e.target.value })}
            />
          </label>
          <label>
            <span>{formatterText('title.service.create.approvedQuantity2')}</span>
            <input
              type="text"
              className="input-default"
              name="cantidadAprobada"
              placeholder="Cantidad Aprobada"
              value={formData.cantidadAprobada}
              onChange={(e) => setFormData({ ...formData, cantidadAprobada: e.target.value })}
            />
          </label>
          <label>
            <span>{formatterText('title.service.create.comments')}</span>
            <input
              type="text"
              className="input-default"
              name="observacion"
              placeholder={formatterText('title.service.create.comments')}
              value={formData.observacion}
              onChange={(e) => setFormData({ ...formData, observacion: e.target.value })}
            />
          </label>
          {formData.costo !== null && (
            <label>
              <span>{formatterText('title.service.create.cost2')}</span>
              <input
                type="text"
                className="input-default"
                name="costo"
                placeholder={formatterText('title.service.create.cost2')}
                value={formData.costo}
                onChange={(e) => setFormData({ ...formData, costo: e.target.value })}
              />
            </label>
          )}

          <button
            className="btn-primary"
            onClick={() => {
              if (formData.costo != null) {
                const access = permissions.filter(
                  (item) => item.idModulo === 22 && item.nombrePermiso === 'EDITAR',
                );

                if (access.length > 0) {
                  handleUpdatePCO(columns.objeto);
                } else {
                  showPermissionDenied();
                }
              } else {
                handleUpdatePCO(columns.objeto);
              }
            }}
            disabled={loadingModal}
          >
            {loadingModal ? 'Cargando...' : formatterText('title.service.create.update')}
          </button>
        </section>
      </Modal>
      {/* Activity change dateTime */}
      <Modal
        open={changeDateTime}
        onClose={onCloseChangeDateTime}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <section>
          <UpdateDatimeAlert
            onClose={onCloseChangeDateTime}
            flagStatus={flagStatus}
            setFlagStatus={setFlagStatus}
            getDataToUpdate={getDataToUpdate}
          />
        </section>
      </Modal>
    </>
  );
};

export default DynamicRowServices;
