import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { AppContext } from 'context/AppContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import { useNavigate } from 'react-router-dom';
import useLangv2 from '../../hooks/useLangv2';
// Import Components
import SelectorGrid from 'common/selects/SelectorGrid';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
import { TableMinimalContext } from 'context/TableMinimalContext';
import {
  MdDelete,
  MdKeyboardArrowDown,
  MdKeyboardArrowRight,
  MdOutlineAddCircleOutline,
  MdOutlineRemoveCircleOutline,
} from 'react-icons/md';
import { Modal } from 'react-responsive-modal';
import AddressModal from './Modals/AddressModal';
import ExternalUserModal from './Modals/ExternalUserModal';
import ClientModal from './Modals/ModalClientSearch';
import ModalSearch from './Modals/ModalSearch';
import ModalUserSystemSearch from './Modals/ModalUserSystemSearch';
// Import libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import dateFormat from 'dateformat';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import hours from './hours';
import hoursWithValue from './hoursWithValue';
// Import services
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import endpoints from 'services/api';
import { addItem, getAll, getItemById } from 'services/api/methods';
import paths from 'services/paths';
// Import Styles
import { TimePicker } from '@material-ui/pickers';
import usePermission from 'hooks/usePermission';
import { isNull } from 'lodash';
import 'react-responsive-modal/styles.css';
import ModalBillingUser from './Modals/ModalBillingUser';
import { valueSetter } from './utils/string';

const CreateService = () => {
  // Manage axios requests
  const { fetchData, COOKIE_USER } = useAxios();

  const navigate = useNavigate();
  // getData from the client or exteralUser select
  const {
    clientSelected,
    userSelected,
    externalUserSelected,
    setExternalUserSelected,
    billingUserSelected,
    setBillingUserSelected,
    setClientSelected,
    setUserSelected,
  } = useContext(AppContext);
  // useLanguage
  const { formatterText, errorProcess, customSB } = useLangv2();
  // Value that select use
  const [selectedSearch, setSearchSelected] = useState([
    {
      clients: [],
      users: [],
      typeService: [],
      communicationMedia: [],
      timeMeeting: [],
      communicationChannel: [],
    },
  ]);

  const [addressAux, setAddressAux] = useState([
    {
      value: 0,
      label: 'Nonthing',
    },
  ]);

  const [listPriceAux, setListAux] = useState([
    {
      value: 0,
      label: 'Nonthing',
    },
  ]);

  const myForm = useForm();

  // checkouts states
  const [checkoutValidations, setCheckoutValidations] = useState({
    equalsExp: false,
    specialService: false,
  });

  // Stare of date picker
  const [time, setTime] = useState(new Date());

  // State loader
  const [loadingValidation, setLoadingValidation] = useState(false);

  // Modal config
  const [openClient, setOpenClient] = useState(false);
  const [openExternalUser, setOpenExternalUser] = useState(false);
  const [openAddress, setOpenAddress] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);
  const [openSystemUser, setOpenSystemUser] = useState(false);
  const [openBillingUser, setOpenBillingUser] = useState(false);

  const [show, setShow] = useState(false);
  const fileInput = React.useRef(null);
  const reader = new FileReader();
  const [typeGenerate, setTypeGenerate] = useState(true);
  const [filesOnCreate, setFilesOnCreate] = useState([]);

  const onOpenClient = () => setOpenClient(true);
  const onCloseClient = () => setOpenClient(false);

  const onOpenExternalUser = () => setOpenExternalUser(true);
  const onCloseExternalUser = () => setOpenExternalUser(false);
  const onOpenSystemUser = () => setOpenSystemUser(true);
  const onCloseSystemUser = () => setOpenSystemUser(false);

  const onOpenAddress = () => setOpenAddress(true);
  const onCloseAddress = () => setOpenAddress(false);
  const onToggleBillingUser = () => setOpenBillingUser(!openBillingUser);

  const onOpenSearch = () => setOpenSearch(true);
  const onCloseSearch = () => setOpenSearch(false);

  const [access, setAccess] = useState([]);
  const [searchAutomatic, setSearchAutomatic] = useState(false);
  const [manualSearch, setManualSearch] = useState(false);
  const { setSelectedTable } = useContext(TableMinimalContext);
  const { permissionPerModule, permissions } = usePermission();

  useEffect(() => {
    validationData();
  }, [access]);

  useEffect(() => {
    permissionsAccess();
  }, [permissions]);

  const permissionsAccess = () => {
    const flterAcces = permissionPerModule(17);
    setAccess(flterAcces);
  };

  const validationData = () => {
    access.forEach((element) => {
      switch (element.nombrePermiso) {
        case 'BUSQUEDA_MANUAL':
          setManualSearch(true);
          break;
        case 'BUSQUEDA_AUTOMATICA':
          setSearchAutomatic(true);
          break;
        default:
          break;
      }
    });
  };

  const now = new Date();
  // Helps to save the ids and labels of the selects data
  const [selectIds, setSelectIds] = useState({
    idGeneradorCliente: {
      value: 0,
      label: '',
    },
    idUsuario: {
      value: 0,
      label: '',
    },
    idDireccion: '',
    idListaPrecios: '',
    idTipoServicio: {
      value: 0,
      label: '',
    },
    idMedioComunicacion: {
      value: 0,
      label: '',
    },
    idHoraCita: {
      value: 0,
      label: '',
    },
    idCanalComunicacion: {
      value: 0,
      label: '',
    },
  });

  // Call services to fill in the selects
  useEffect(() => {
    // news
    getAllClientsServices();
    getAllUsersServices();
    getAllTypeServicesServices();
    getAllCommunicationMediaServices();
    getAllCommunicationChannelServices();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    // display the address of the client, gen user or external user
    showAddress();
    getListPrice();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientSelected.id, externalUserSelected.id, userSelected.id]);

  const showAddress = (addressCreated = null) => {
    // OPTION 1: GUSER where idGeneradorCliente are null
    if (userSelected.id !== null) {
      // OPTION 2:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select genUser and Externarl User
        getAddressExternalUser(addressCreated);
      } else {
        // Only select gen system user Option 1 only
        getAddressSystemUser(addressCreated);
      }
    }
    // OPTION 3: GCLIENT + GUSER where idGeneradorUsuario is null
    else if (clientSelected.id !== null) {
      // OPTION 4:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select geClient and Externarl User
        getAddressExternalUser(addressCreated);
      } else {
        // Option 3: Only GenClient
        getAddressesClient(addressCreated);
      }
    } else {
      setAddressAux([]);
    }
  };

  const getListPrice = () => {
    // OPTION 1: GUSER where idGeneradorCliente are null
    if (userSelected.id !== null) {
      // OPTION 2:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select genUser and Externarl User
        getListPriceExternalUser();
      } else {
        // Only select gen system user Option 1 only
        getListPriceSystemUser();
      }
    }
    // OPTION 3: GCLIENT + GUSER where idGeneradorUsuario is null
    else if (clientSelected.id !== null) {
      // OPTION 4:HAVE USER SYSTEM Too
      if (externalUserSelected.id !== null) {
        // Select geClient and Externarl User
        getListPriceExternalUser();
      } else {
        // Option 3: Only GenClient

        getListPriceClient();
      }
    } else {
      setListAux([]);
    }
  };

  const getListPriceExternalUser = () => {
    getItemById(
      endpoints.listPriceClient.getListPriceByIdUsuarioServicio,
      externalUserSelected.id,
    ).then((data) => {
      // create new array
      const newArray = [];
      let principalId = '';
      // iterate response and get only the values that are active
      data.forEach((item) => {
        newArray.push({
          value: item.idListaPreciosActividad.idListaPreciosActividad, //idListaPreciosActividad
          label: item.idListaPreciosActividad.nombre,
        });
        //if item.principal === 1 save the id
        if (item.principal === 1) {
          principalId = item.idListaPreciosActividad.idListaPreciosActividad;
        }
      });
      setListAux(newArray);
      setSelectIds({
        ...selectIds,
        idListaPrecios: principalId,
      });
    });
  };

  const getListPriceSystemUser = () => {
    getItemById(endpoints.listPriceClient.getListPriceByIdUsuarioServicio, userSelected.id).then(
      (data) => {
        // create new array
        const newArray = [];
        let principalId = '';
        // iterate response and get only the values that are active
        data.forEach((item) => {
          newArray.push({
            value: item.idListaPreciosActividad.idListaPreciosActividad, //idListaPreciosActividad
            label: item.idListaPreciosActividad.nombre,
          });
          //if item.principal === 1 save the id
          if (item.principal === 1) {
            principalId = item.idListaPreciosActividad.idListaPreciosActividad;
          }
        });
        setListAux(newArray);
        setSelectIds({
          ...selectIds,
          idListaPrecios: principalId,
        });
      },
    );
  };

  const getListPriceClient = () => {
    getItemById(endpoints.listPriceClient.getListPriceById, clientSelected.id).then((data) => {
      // create new array
      const newArray = [];
      let principalId = '';
      // iterate response and get only the values that are active
      data.forEach((item) => {
        newArray.push({
          value: item.idListaPreciosActividad.idListaPreciosActividad, //idListaPreciosActividad
          label: item.idListaPreciosActividad.nombre,
        });
        //if item.principal === 1 save the id
        if (item.principal === 1) {
          principalId = item.idListaPreciosActividad.idListaPreciosActividad;
        }
      });
      setListAux(newArray);
      setSelectIds({
        ...selectIds,
        idListaPrecios: principalId,
      });
    });
  };

  // getAllExternalUser
  const getAddressExternalUser = (address = null) => {
    getItemById(endpoints.services.getAllAddressExternalUsersById, externalUserSelected.id).then(
      (data) => {
        // create new array
        const newArray = [];
        // iterate response and get only the values that are active
        data.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: `${item.idDireccion.idDireccion}-${item.idDireccion.idSector.idSector}-${item.idDireccion.idSector.idMunicipio}`,
              label: `${item.idDireccion.direccion} - ${item.idDireccion.datosAdicionales}`,
            });
          }
        });
        setAddressAux(newArray);
        // set the values of the select
        if (address !== null) {
          setSelectIds({
            ...selectIds,
            idDireccion: `${address.idDireccion.idDireccion}-${address.idDireccion.idSector.idSector}-${address.idDireccion.idSector.idMunicipio}`,
          });
        }
      },
    );
  };

  // get All Address System User
  const getAddressSystemUser = (address = null) => {
    getItemById(endpoints.services.getAllAddressExternalUsersById, userSelected.id).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: `${item.idDireccion.idDireccion}-${item.idDireccion.idSector.idSector}-${item.idDireccion.idSector.idMunicipio}`,
            label: `${item.idDireccion.direccion} - ${item.idDireccion.datosAdicionales}`,
          });
        }
      });
      setAddressAux(newArray);
      // set the values of the select
      if (address !== null) {
        setSelectIds({
          ...selectIds,
          idDireccion: `${address.idDireccion.idDireccion}-${address.idDireccion.idSector.idSector}-${address.idDireccion.idSector.idMunicipio}`,
        });
      }
    });
  };

  const validateFields = () => {
    if (selectIds.idTipoServicio.value == 0) {
      return customSB('warning', 'snackbar.error.validate.serviceType');
    }
    if (selectIds.idDireccion === '') {
      return customSB('warning', 'snackbar.error.validate.address');
    }
    if (selectIds.idCanalComunicacion.value === 0) {
      return customSB('warning', 'snackbar.error.validate.channel');
    }
    if (selectIds.idMedioComunicacion.value === 0) {
      return customSB('warning', 'snackbar.error.validate.media');
    }
    return true;
  };

  // Get the address for the SelectorGrid
  const getAddressesClient = (address = null) => {
    getItemById(endpoints.branchOffices.getSucursalClientById, clientSelected.id).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: `${item.idDireccion.idDireccion}-${item.idDireccion.idSector.idSector}-${item.idDireccion.idSector.idMunicipio.idMunicipio}`,
            label: `${item.idDireccion.direccion} - ${item.idDireccion.datosAdicionales}`,
          });
        }
      });
      // set the values of the select
      setAddressAux(newArray);
      if (address !== null) {
        setSelectIds({
          ...selectIds,
          idDireccion: `${address.idDireccion.idDireccion}-${address.idDireccion.idSector.idSector}-${address.idDireccion.idSector.idMunicipio}`,
        });
      }
    });
  };

  const handleSubmit = () => {
    const valid = validateFields();
    if (valid) {
      let especial = 0;

      if (clientSelected.esVip === 1) {
        especial = clientSelected.esVip === 1 ? 1 : 0;
      } else if (userSelected.esVip === 1) {
        especial = userSelected.esVip === 1 ? 1 : 0;
      }

      const { idDireccion: direction = '', idTipoServicio: serviceType = {} } = selectIds;
      const [directionId = ''] = direction.split('-');
      const serviceTypeId = Number(serviceType.value.split('-')[0] || '0');

      let data = {
        idServicio: null,
        idDireccion: {
          idDireccion: Number(directionId),
        },

        idTipoServicio: {
          idTipoServicio: serviceTypeId,
        },
        descripcion: formItem.descripcion ? formItem.descripcion : '',
        idMedioComunicacion: {
          idMedioComunicacion: selectIds.idMedioComunicacion.value,
        },
        idCanalComunicacion: {
          idCanalComunicacion: selectIds.idCanalComunicacion.value,
        },
        fechaCita: `${eventData.fechaCita}T10:00:00.000Z`,
        idHoraCita: {
          idHora: eventData.idHoraCita,
        },
        expediente: checkoutValidations.equalsExp ? null : formItem.expediente,
        especial,
        idEstadoServicio: {
          idEstadoServicio: 1,
        },
        usuarioCreacion: COOKIE_USER,
        idServicioPadre: null,
      };

      // OPTION 1: GUSER where idGeneradorCliente are null
      if (userSelected.id !== null) {
        // OPTION 2:HAVE USER SYSTEM Too
        if (externalUserSelected.id !== null) {
          // Select genUser and Externarl User
          data = {
            ...data,
            idGeneradorCliente: null,
            idGeneradorUsuario: {
              idUsuarioServicio: Number(userSelected.id),
            },
            idUsuario: {
              idUsuarioServicio: parseInt(externalUserSelected.id),
            },
          };
        } else {
          // Only select gen system user Option 1 only
          data = {
            ...data,
            idGeneradorCliente: null,
            idGeneradorUsuario: {
              idUsuarioServicio: parseInt(userSelected.id),
            },
            idUsuario: null,
          };
        }
      }
      // OPTION 3: GCLIENT + GUSER where idGeneradorUsuario is null
      else if (clientSelected.id !== null) {
        // OPTION 4:HAVE USER SYSTEM Too
        if (externalUserSelected.id !== null) {
          // Select geClient and Externarl User
          data = {
            ...data,
            idGeneradorCliente: {
              idCliente: parseInt(clientSelected.id),
            },
            idGeneradorUsuario: null,
            idUsuario: {
              idUsuarioServicio: parseInt(externalUserSelected.id),
            },
          };
        } else {
          // Option 3: Only GenClient
          data = {
            ...data,
            idGeneradorCliente: {
              idCliente: clientSelected.id,
            },
            idGeneradorUsuario: null,
            idUsuario: null,
          };
        }
      } else {
        alert('Error to create service: notify admin');
      }
      generateDateEnd(data);
    }
  };

  // generate the end date of the service for validate the agenda
  const generateDateEnd = (data) => {
    setLoadingValidation(true);
    customSB(
      'warning',
      'snackbar.warning.validate.tech.exist',
      'Se esta validando que el servicio cumpla con los requisitos para ser creado, por favor espere...',
    );
    addItem(endpoints.services.generateEndDate, data)
      .then((response) => {
        const { idDireccion: direction = '', idTipoServicio: serviceType = {} } = selectIds;
        const [address = '', sector = '', town = ''] = direction.split('-');
        const [serviceTypeId = '', serviceTypeCategory = ''] = (serviceType?.value || '').split(
          '-',
        );

        const ADDRESS = parseInt(address);
        const SECTOR = parseInt(sector);
        const MUNICIPALITY = parseInt(town);
        const TYPE_SERVICE = parseInt(serviceTypeId);
        const CATEGORY_SERVICE = parseInt(serviceTypeCategory);

        const idHora = hoursWithValue.find((item) => item.idHora === eventData.idHoraCita);

        const DATA_ORIGINAL = data;

        const DATA_VALIDATED = {
          ...data,
          idDireccion: {
            idDireccion: ADDRESS,
            idSector: {
              idSector: SECTOR,
              idMunicipio: {
                idMunicipio: MUNICIPALITY,
              },
            },
          },
          idTipoServicio: {
            idTipoServicio: TYPE_SERVICE,
            idCategoriaServicio: {
              idCategoriaServicio: CATEGORY_SERVICE,
            },
          },
          idHoraCita: {
            idHora: eventData.idHoraCita,
            valor: idHora.valor,
          },
          fechaCitaFin: response.fechaCitaFin.split('T')[0],
          idHoraCitaFin: {
            idHora: response.idHoraCitaFin.idHora,
            valor: response.idHoraCitaFin.valor,
          },
        };

        validateServiceAgendaEvent(DATA_VALIDATED, DATA_ORIGINAL);
      })
      .catch((error) => {
        errorProcess();
        setLoadingValidation(false);
        console.error(error);
      });
  };

  // Validate if the agenda have horary available
  const validateServiceAgendaEvent = (DATA, DATA_ORIGINAL) => {
    addItem(endpoints.services.validateCreateService, DATA)
      .then((response) => {
        if (response) {
          createItem(DATA_ORIGINAL);
          setLoadingValidation(false);
          customSB(
            'success',
            'snackbar.success.validate.tech.exist',
            'Se encontró al menos un técnico disponible para este servicio, puede continuar con el proceso.',
          );
        } else {
          setLoadingValidation(false);
          customSB(
            'error',
            'snackbar.error.validate.tech.exist',
            'No se encontró un técnico disponible para este servicio, seleccione otro horario o fecha.',
          );
        }
      })
      .catch((error) => {
        errorProcess();
        setLoadingValidation(false);
        console.error(error);
      });
  };

  // Create new service
  const createItem = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addItem(endpoints.services.addService, {
            ...data,
            idListaPreciosActividad: parseInt(selectIds.idListaPrecios),
            idClienteFactura: null,
          })
            .then((response) => {
              uploadReports(response.idServicio);
              saveBillingUser(response.idServicio);
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.created.general',
                    'El registro se ha creado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    setIdService(response.idServicio);
                    onOpenSearch();
                    setExternalUserSelected({
                      nombre: 'Seleccione un usuario (Opcional)',
                      id: null,
                    });

                    setClientSelected({
                      nombre: formatterText('input.placeholder.select.client'),
                      id: null,
                      esVip: 2,
                    });

                    setUserSelected({
                      nombre: 'Seleccione un usuario generador',
                      id: null,
                      esVip: 2,
                    });
                  },
                }),
              );
            })
            .catch((error) => {
              console.error('Error al crear el item:', error);
              reject(
                HandleOnError(
                  formatterText(
                    'alert.message.failed.general',
                    'Error al crear el registro, por favor intente nuevamente.',
                  ),
                ),
              );
              setLoadingValidation(false);
            });
        });
      },
    });
  };

  // Get the clients for the SelectorGrid
  const getAllClientsServices = () => {
    getAll(endpoints.clients.getAllClients).then((data) => {
      // create new array
      const newArray = [
        {
          value: -1,
          label: 'Ninguno',
        },
      ];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idCliente,
            label: `${item.nombreRazonSocial} - ${item.identificacion}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        clients: newArray,
      }));
    });
  };

  // Get the users for the SelectorGrid
  const getAllUsersServices = () => {
    getAll(endpoints.services.getAllExternalUsers).then((data) => {
      // create new array
      const newArray = [
        {
          value: -1,
          label: 'Ninguno',
        },
      ];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idUsuarioServicio,
            label: `${item.primerNombre} ${item.primerApellido} - ${item.telefono}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        users: newArray,
      }));
    });
  };

  // Get the typeServices for the SelectorGrid
  const getAllTypeServicesServices = () => {
    getAll(endpoints.typeService.getAllTypeService).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: `${item.idTipoServicio}-${item.idCategoriaServicio.idCategoriaServicio}`,
            label: `${item.nombre} - ${item.idCategoriaServicio.nombre}`,
          });
        }
      });

      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        typeService: newArray,
      }));
    });
  };

  // Get the communicationMediaServices for the SelectorGrid
  const getAllCommunicationMediaServices = () => {
    getAll(endpoints.services.getAllMedia).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idMedioComunicacion,
            label: `${item.nombre} - ${item.codigo}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        communicationMedia: newArray,
      }));
    });
  };

  // Get the communicationChannel for the SelectorGrid
  const getAllCommunicationChannelServices = () => {
    getAll(endpoints.services.getAllChannels).then((data) => {
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idCanalComunicacion,
            label: `${item.nombre} - ${item.codigo}`,
          });
        }
      });
      // set the values of the select
      setSearchSelected((prev) => ({
        ...prev,
        communicationChannel: newArray,
      }));
    });
  };
  const saveBillingUser = (idServ) => {
    if (!isNull(billingUserSelected.id)) {
      let data = {
        idServicio: {
          idServicio: idServ,
        },
        idCliente: {
          idCliente: billingUserSelected.id,
        },
        usuarioCreacion: COOKIE_USER,
      };
      addItem(endpoints.services.saveBillingUser, data).then((resp) => {
        setBillingUserSelected({
          nombre: 'Seleccione un usuario (Opcional)',
          id: null,
        });
      });
    }
  };

  const handleDate = (e) => {
    if (e.target) {
      setEventData({
        ...eventData,
        [e.target.name]: e.target.value,
      });
    } else {
      setTime(e);
      const HOUR_ID = searchHour(dateFormat(e, 'HH:MM'));
      setEventData({
        ...eventData,
        idHoraCita: HOUR_ID,
      });
    }
  };

  const searchHour = (hour) => {
    // search in hours array the idHora that matches with the hour
    const idHora = hours.find((item) => item.hora === hour);
    return idHora.idHora;
  };

  const [eventData, setEventData] = useState({
    fechaCita: '',
    idHoraCita: '',
  });

  const [formItem, setFormItem] = useState([
    {
      descripcion: '',
    },
  ]);

  const [idService, setIdService] = useState(71);

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formItem, setFormItem);
  };

  const uploadFromCreate = (e) => {
    e.preventDefault();
    const selectedFile = e.target.files[0];
    if (selectedFile.size > 5000000) {
      HandleOnError(formatterText('id.error.file.large'));
      return;
    } // png, jpg, tiff
    if (
      selectedFile.type !== 'image/jpg' &&
      selectedFile.type !== 'image/png' &&
      selectedFile.type !== 'image/jpeg' &&
      selectedFile.type !== 'image/tiff' &&
      selectedFile.type !== 'video/mp4'
    ) {
      HandleOnError(formatterText('id.error.file.no.valid'));
      return;
    }

    if (filesOnCreate.length >= 3) {
      HandleOnError(formatterText('id.error.three.files'));
      return;
    }

    reader.readAsDataURL(selectedFile);
    reader.onload = () => {
      const archivo = reader.result.split('base64,')[1];
      //obtener el tipo del archivo
      const extensionArchivo =
        selectedFile.name.lastIndexOf('.') > -1
          ? selectedFile.name.substring(
              selectedFile.name.lastIndexOf('.') + 1,
              selectedFile.name.length,
            )
          : '';
      const name = selectedFile.name;
      setFilesOnCreate((filesOnCreate) => [
        ...filesOnCreate,
        { name, extensionArchivo: `.${extensionArchivo}`, archivo },
      ]);
    };
  };

  const deleteFile = (e, item) => {
    e.preventDefault();
    if (filesOnCreate.length === 1) {
      setFilesOnCreate([]);
    } else {
      const index = filesOnCreate.indexOf(item);
      filesOnCreate.splice(index, 1);
      setFilesOnCreate([...filesOnCreate]);
    }
  };

  const uploadReports = (id) => {
    if (filesOnCreate.length > 0) {
      const userData = JSON.parse(localStorage.getItem('userData'));
      const data = {
        idServicioReporte: null,
        idServicio: {
          idServicio: id,
        },
        idTipoReporte: {
          idTipoReporte: parseInt(4),
        },
        descripcion: 'Archivos Adjuntos del servicio',
        notificacionAsesor: 0,
        publico: parseInt(1),
        fechaCreacion: new Date().toISOString(),
        usuarioCreacion: userData.idAsesorCliente
          ? parseInt(COOKIE_USER)
          : parseInt(COOKIE_USER),
        urlsArchivos: null,
      };

      fetchData({ url: endpoints.reports.create, method: 'post', body: data })
        .then(async (res) => {
          await fetchData({
            url: endpoints.UploadFiles.save,
            method: 'post',
            body: {
              idOrigen: res.response.idServicioReporte,
              idTipoOrigenArchivo: 2,
              archivos: filesOnCreate,
            },
          });
        })
        .catch((error) => {
          console.error('Error en la carga de archivos:', error);
          return Promise.reject(error);
        });
    }
  };

 

  return (
    <>
      <div className="centered-form">
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form className="container-wrapForm" style={{ minHeight: '16rem' }}>
            <div className="new-container-wrapForm__tabs">
              {myForm.steps.map((step, index) => (
                <button
                  key={step.name}
                  className={`new-tab-option ${
                    step.name === myForm.currentStep.name ? 'is-active' : ''
                  }`}
                  type="button"
                  onClick={() => {
                    setSelectedTable(index);

                    myForm.goToStep(step.name);
                  }}
                >
                  {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                  {formatterText(step.label)}
                </button>
              ))}
            </div>
            <div className="container-wrapForm-content" style={{ padding: '1rem' }}>
              <FormizStep name="step1" label='p.information.service.general'>
                <section className="advance-search">
                  <p
                    onClick={(e) => {
                      e.preventDefault();
                      setShow(!show);
                    }}
                  >
                    {show ? (
                      <MdKeyboardArrowDown size={22} color="gray" cursor="pointer" />
                    ) : (
                      <MdKeyboardArrowRight size={22} color="gray" cursor="pointer" />
                    )}
                    <FormattedMessage
                      id="text.action.show.service.generating.ask"
                      defaultMessage="¿Quién genera el servicio?"
                    />
                  </p>
                </section>
                {/* advanced Seacrh */}
                {show && (
                  <section className="form-responsive-container-buttons">
                    <button
                      className="btn-primary"
                      type="button"
                      onClick={() => {
                        setTypeGenerate(true);
                        setClientSelected({
                          nombre: formatterText('input.placeholder.select.client'),
                          id: null,
                          esVip: 2,
                        });

                        setUserSelected({
                          nombre: 'Seleccione un usuario generador',
                          id: null,
                          esVip: 2,
                        });
                      }}
                    >
                      {formatterText('table.name.search.client')}
                    </button>
                    <button
                      className="btn-primary"
                      type="button"
                      onClick={() => {
                        setTypeGenerate(false);
                        setClientSelected({
                          nombre: formatterText('input.placeholder.select.client'),
                          id: null,
                          esVip: 2,
                        });

                        setUserSelected({
                          nombre: 'Seleccione un usuario generador',
                          id: null,
                          esVip: 2,
                        });
                      }}
                    >
                      {formatterText('table.title.user')}
                    </button>
                  </section>
                )}
                <section className="w100-container">
                  <section className="padding-all-1">
                    {/* gen, user and direction */}
                    <section className="grid-container-2c">
                      {typeGenerate ? (
                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="text-inline">
                              <FormattedMessage
                                id="p.generate.Client"
                                defaultMessage="Generado / Cliente"
                              />
                            </p>
                            {/* open modal of external user */}
                            <p
                              onClick={(e) => {
                                e.preventDefault();
                                onOpenClient();
                              }}
                              className="p-review"
                            >
                              {formatterText('text.details.view.more')}
                            </p>
                          </section>
                          <div className="wrap-input">
                            <div className="input-label-icon">
                              <input
                                type="text"
                                name="idGeneradorCliente"
                                className="input-label-style"
                                value={valueSetter(clientSelected.nombre)}
                                disabled
                              />
                              <div className="btn-action-style">
                                {clientSelected.id ? (
                                  <MdOutlineRemoveCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        setClientSelected({
                                          nombre: `${formatterText(
                                            'input.placeholder.select.client',
                                          )}`,
                                          id: null,
                                          esVip: 2,
                                        });
                                      });
                                    }}
                                  />
                                ) : (
                                  <MdOutlineAddCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        onOpenClient();
                                      });
                                    }}
                                  />
                                )}
                              </div>
                            </div>
                            <label
                              style={{
                                position: 'relative',
                                top: ' 0.5rem',
                              }}
                            ></label>
                          </div>
                        </label>
                      ) : (
                        <label className="d-flex">
                          <section className="box-text-container">
                            <p className="text-inline">
                              {formatterText('p.generate.user', 'Usuario')}
                            </p>
                            {/* open modal of generater user */}
                            <p
                              onClick={(e) => {
                                e.preventDefault();
                                onOpenSystemUser();
                              }}
                              className="p-review"
                            >
                              {formatterText('text.details.view.more')}
                            </p>
                          </section>
                          <div className="wrap-input">
                            <div className="input-label-icon">
                              <input
                                type="text"
                                name="idUsuario"
                                className="input-label-style"
                                value={valueSetter(userSelected.nombre)}
                                required
                                disabled
                              />
                              <div className="btn-action-style">
                                {userSelected.id ? (
                                  <MdOutlineRemoveCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        setUserSelected({
                                          nombre: 'Seleccione un usuario generador',
                                          id: null,
                                          esVip: 2,
                                        });
                                      });
                                    }}
                                  />
                                ) : (
                                  <MdOutlineAddCircleOutline
                                    size={25}
                                    color="gray"
                                    cursor="pointer"
                                    onClick={(e) => {
                                      new Promise((resolve, reject) => {
                                        e.preventDefault();
                                        resolve();
                                      }).then(() => {
                                        onOpenSystemUser();
                                      });
                                    }}
                                  />
                                )}
                              </div>
                            </div>
                          </div>
                        </label>
                      )}

                      <label className="d-flex">
                        <section className="box-text-container">
                          <p className="text-inline">
                            {formatterText('p.generate.user', 'Usuario')}
                          </p>
                          {/* open modal of external user */}
                          <p
                            onClick={(e) => {
                              e.preventDefault();
                              onOpenExternalUser();
                            }}
                            className="p-review"
                          >
                            {formatterText('text.details.view.more')}
                          </p>
                        </section>

                        <div className="wrap-input">
                          <div className="input-label-icon">
                            <input
                              type="text"
                              name="idUsuario"
                              className="input-label-style"
                              value={valueSetter(externalUserSelected.nombre)}
                              required
                              disabled
                            />
                            <div className="btn-action-style">
                              {externalUserSelected.id ? (
                                <MdOutlineRemoveCircleOutline
                                  size={25}
                                  color="gray"
                                  cursor="pointer"
                                  onClick={(e) => {
                                    new Promise((resolve, reject) => {
                                      e.preventDefault();
                                      resolve();
                                    }).then(() => {
                                      setExternalUserSelected({
                                        nombre: 'Seleccione un usuario (Opcional)',
                                        id: null,
                                      });
                                    });
                                  }}
                                />
                              ) : (
                                <MdOutlineAddCircleOutline
                                  size={25}
                                  color="gray"
                                  cursor="pointer"
                                  onClick={(e) => {
                                    new Promise((resolve, reject) => {
                                      e.preventDefault();
                                      resolve();
                                    }).then(() => {
                                      onOpenExternalUser();
                                    });
                                  }}
                                />
                              )}
                            </div>
                          </div>
                        </div>
                      </label>

                      <label className="d-flex">
                        <section className="box-text-container">
                          <p className="text-inline">{formatterText('p.label.direction')}</p>
                          {/* open modal of address */}
                          <p
                            onClick={(e) => {
                              e.preventDefault();
                              onOpenAddress();
                            }}
                            className="p-review"
                          >
                            {formatterText('text.details.view.more')}
                          </p>
                        </section>
                        <select
                          name="idDireccion"
                          className="input-label-style"
                          value={selectIds.idDireccion}
                          onChange={(e) => {
                            if (e.target.value !== '') {
                              setSelectIds({
                                ...selectIds,
                                idDireccion: e.target.value,
                              });
                            }
                          }}
                        >
                          <option value="">
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecciona una opción"
                            />
                          </option>
                          {addressAux.map((item) => (
                            <option key={item.value} value={item.value}>
                              {item.label}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className="d-flex">
                        <section className="box-text-container">
                          <p className="text-inline">{formatterText('p.label.price.list')}</p>
                        </section>
                        <select
                          name="idListaPrecios"
                          className="input-label-style"
                          value={selectIds.idListaPrecios}
                          onChange={(e) => {
                            if (e.target.value !== '') {
                              setSelectIds({
                                ...selectIds,
                                idListaPrecios: e.target.value,
                              });
                            }
                          }}
                        >
                          <option value="">
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecciona una opción"
                            />
                          </option>
                          {listPriceAux.map((item) => (
                            <option key={item.value} value={item.value}>
                              {item.label}
                            </option>
                          ))}
                        </select>
                      </label>
                    </section>
                    {/* exped num and type service */}
                    <section className="grid-container-2c">
                      <label className="d-flex custom-margin-0100-s">
                        <p className="text-inline margin-bottom-1">
                          {formatterText('p.label.expedient')}
                        </p>
                        <section className="w100-container">
                          <input
                            className={
                              checkoutValidations.equalsExp
                                ? 'input-default input-default-disable'
                                : 'input-default'
                            }
                            style={{ width: '100%' }}
                            type="text"
                            name="expediente"
                            value={formItem.expediente}
                            onChange={(e) => {
                              if (e.target.value.match(/^\w*$/)) {
                                setFormItem({
                                  ...formItem,
                                  [e.target.name]: e.target.value,
                                });
                              }
                            }}
                            placeholder={formatterText('p.label.expedient')}
                            disabled={checkoutValidations.equalsExp}
                          />

                          <label className="label-position">
                            <input
                              type="checkbox"
                              name="equalsExp"
                              className=""
                              onChange={(e) => {
                                setCheckoutValidations((prev) => {
                                  if (e.target.checked) {
                                    setFormItem({
                                      ...formItem,
                                      expediente: '',
                                    });
                                  }

                                  return {
                                    ...prev,
                                    [e.target.name]: e.target.checked,
                                  };
                                });
                              }}
                            />
                            <p className="text-checkout">{formatterText('p.label.no.record')}</p>
                          </label>
                        </section>
                      </label>

                      <label className="d-flex">
                        <p className="text-inline margin-bottom-1">
                          {formatterText('table.title.type.service')}
                        </p>
                        <section className="w100-container">
                          <SelectorGrid
                            name="idTipoServicio"
                            data={selectedSearch.typeService}
                            placeholder={
                              <FormattedMessage
                                id="input.placeholder.select"
                                defaultMessage="Selecciona una opción"
                              />
                            }
                            dataValue={selectIds.idTipoServicio}
                            setterFunction={setSelectIds}
                          />
                          <label className="label-position">
                            {clientSelected.esVip === 1 && (
                              <>
                                <input
                                  type="checkbox"
                                  name="specialService"
                                  className=""
                                  onChange={(e) => {
                                    setCheckoutValidations((prev) => {
                                      return {
                                        ...prev,
                                        specialService: true,
                                      };
                                    });
                                  }}
                                  checked={true}
                                />
                                <p className="text-checkout">
                                  {formatterText('title.service.isSpecialService')}
                                </p>
                              </>
                            )}
                          </label>
                          <label className="label-position">
                            {userSelected.esVip === 1 && (
                              <>
                                <input
                                  type="checkbox"
                                  name="specialService"
                                  className=""
                                  onChange={(e) => {
                                    setCheckoutValidations((prev) => {
                                      return {
                                        ...prev,
                                        specialService: true,
                                      };
                                    });
                                  }}
                                  checked={true}
                                />
                                <p className="text-checkout">
                                  {formatterText('title.service.isSpecialService')}
                                </p>
                              </>
                            )}
                          </label>
                        </section>
                      </label>
                    </section>
                    {/* description */}
                    <section
                      className=""
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        flexWrap: 'wrap',
                        fontFamily: 'inherit',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        width: '100%',
                      }}
                    >
                      <section className="container-description">
                        <p
                          className="p-styles"
                          style={{
                            textDecoration: 'none',
                            fontSize: '1rem',
                            fontWeight: 600,
                            color: 'var(--dark-gray)',
                          }}
                        >
                          {formatterText('table.title.description')}
                        </p>
                        <textarea
                          className="input-default-textarea"
                          name="descripcion"
                          value={formItem.descripcion}
                          onChange={handlerTextDescription}
                          placeholder={formatterText('table.title.description')}
                          maxLength="200"
                          required
                        />
                      </section>
                    </section>

                    <section className="grid-container-2c">
                      <label className="d-flex">
                        <p className="text-inline">{formatterText('p.label.comunication.media')}</p>
                        <SelectorGrid
                          name="idMedioComunicacion"
                          data={selectedSearch.communicationMedia}
                          placeholder={
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecciona una opción"
                            />
                          }
                          dataValue={selectIds.idMedioComunicacion}
                          setterFunction={setSelectIds}
                          isRequired={true}
                        />
                      </label>

                      <label className="d-flex">
                        <p className="text-inline">
                          {formatterText('p.label.comunication.channel')}
                        </p>
                        <SelectorGrid
                          name="idCanalComunicacion"
                          data={selectedSearch.communicationChannel}
                          placeholder={
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecciona una opción"
                            />
                          }
                          dataValue={selectIds.idCanalComunicacion}
                          setterFunction={setSelectIds}
                          isRequired={true}
                        />
                      </label>

                      <label className="d-flex">
                        <p className="text-inline">{formatterText('p.label.date.appointment')}</p>
                        <input
                          className="input-date"
                          type="date"
                          name="fechaCita"
                          value={eventData.fechaCita}
                          onChange={handleDate}
                          min={dateFormat(
                            new Date(now.getFullYear(), now.getMonth(), now.getDate() - 60),
                            'yyyy-mm-dd',
                          )}
                        />
                      </label>
                      <label className="d-flex">
                        <p className="text-inline">{formatterText('p.label.hour.appointment')}</p>
                        <TimePicker
                          name="idHoraCita"
                          ampm={false}
                          placeholder={
                            <FormattedMessage
                              id="input.placeholder.select"
                              defaultMessage="Selecciona una opción"
                            />
                          }
                          value={time}
                          onChange={handleDate}
                        />
                      </label>
                    </section>

                    <section className="grid-container-2c">
                      <label className="d-flex">
                        <section className="box-text-container">
                          <p className="text-inline">{formatterText('p.label.billing.user')}</p>
                          {/* open modal of billing user */}
                          <p
                            onClick={(e) => {
                              e.preventDefault();
                              onToggleBillingUser();
                            }}
                            className="p-review"
                          >
                            {formatterText('text.details.view.more')}
                          </p>
                        </section>

                        <div className="wrap-input">
                          <div className="input-label-icon">
                            <input
                              type="text"
                              name="idUsuarioFactura"
                              className="input-label-style"
                              value={valueSetter(billingUserSelected.nombre)}
                              required
                              disabled
                            />
                            <div className="btn-action-style">
                              {billingUserSelected.id ? (
                                <MdOutlineRemoveCircleOutline
                                  size={25}
                                  color="gray"
                                  cursor="pointer"
                                  onClick={(e) => {
                                    new Promise((resolve, reject) => {
                                      e.preventDefault();
                                      resolve();
                                    }).then(() => {
                                      setBillingUserSelected({
                                        nombre: 'Seleccione un usuario (Opcional)',
                                        id: null,
                                      });
                                    });
                                  }}
                                />
                              ) : (
                                <MdOutlineAddCircleOutline
                                  size={25}
                                  color="gray"
                                  cursor="pointer"
                                  onClick={(e) => {
                                    new Promise((resolve, reject) => {
                                      e.preventDefault();
                                      resolve();
                                    }).then(() => {
                                      onToggleBillingUser();
                                    });
                                  }}
                                />
                              )}
                            </div>
                          </div>
                        </div>
                      </label>
                    </section>
                  </section>
                </section>
              </FormizStep>
              {/* 2: Attachment files */}
              <FormizStep name="step2" label="tab.title.attached.data">
                <div className="edit&btnAContainer"></div>
                <div>
                  <div>
                    <h3 className="p-styles spacing-l1 primary-green">
                      {formatterText('p.label.attachment.files')}{' '}
                    </h3>
                  </div>
                  <div className="btnAdjuntarContainer">
                    <label
                      style={{
                        display: 'block',
                        background: '#EFEEEE',
                        boder: '1px',
                        borderStyle: 'dashed',
                        borderColor: '#747474',
                        margin: '15px auto',
                        minHeight: '150px',
                        borderRadius: '10px',
                        maxWidth: '800px',
                      }}
                      className="custom-file-upload"
                    >
                      <input
                        id="file-input"
                        style={{ display: 'none' }}
                        accept=".png , .jpg , .tiff , .mp4"
                        type="file"
                        name="files"
                        value=""
                        onChange={uploadFromCreate}
                        ref={fileInput}
                      />
                      <div
                        style={{
                          display: 'flex',
                          flexFlow: 'row wrap',
                        }}
                      >
                        {filesOnCreate.map((item, index) => (
                          <div
                            key={`${index + 1}`}
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderRadius: '10px',
                              boder: '1px',
                              borderStyle: 'solid',
                              borderColor: '#D9D9D9',
                              padding: '5px',
                              paddingRight: '10px',
                              marginRight: '20px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                            }}
                          >
                            <p
                              style={{
                                cursor: 'pointer',
                              }}
                              onClick={(e) => {
                                e.preventDefault();
                              }}
                            >
                              {item.name}
                            </p>
                            <MdDelete
                              size={25}
                              color="red"
                              style={{
                                marginLeft: '10px',
                                zIndex: '999',
                              }}
                              cursor="pointer"
                              onClick={(e) => {
                                e.preventDefault();
                                deleteFile(e, item);
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    </label>
                  </div>
                  <div
                    style={{
                      width: '80%',
                      display: 'flex',
                      margin: '0 auto',
                      justifyContent: 'flex-end',
                      marginTop: '25px',
                      marginBottom: '25px',
                    }}
                  >
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        fileInput.current.click();
                      }}
                      style={{ width: 'fit-content' }}
                      className="btn-primary"
                    >
                      <FormattedMessage id="btn.upload.files" defaultMessage="Subir archivos" />
                    </button>
                  </div>
                </div>
              </FormizStep>
            </div>
          </form>
        </Formiz>
        <div className="demo-form__footer">
          <section className="form-responsive-container-buttons">
            <button
              style={{ padding: '0px' }}
              onClick={(e) => {
                e.preventDefault();
                handleSubmit();
              }}
              className="btn-primary"
              disabled={loadingValidation}
            >
              <label className="btn-wrap-add">
                {loadingValidation ? 'Comprobando...' : formatterText('text.create.service')}
              </label>
            </button>
            <button className="input-cancel" onClick={() => navigate(paths.serviceModule)}>
              {formatterText('btn.cancel')}
            </button>
          </section>
        </div>
      </div>
      {/* Client system modal */}
      <Modal
        Modal
        open={openClient}
        onClose={onCloseClient}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ClientModal onClose={onCloseClient} exeFun={getAllUsersServices} />
      </Modal>
      {/* External external user modal */}
      <Modal
        open={openExternalUser}
        onClose={onCloseExternalUser}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ExternalUserModal onClose={onCloseExternalUser} exeFun={getAllUsersServices} />
      </Modal>
      {/* Billing user modal */}
      <Modal
        open={openBillingUser}
        onClose={onToggleBillingUser}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalBillingUser onClose={onToggleBillingUser} exeFun={getAllUsersServices} />
      </Modal>
      {/* User system modal */}
      <Modal
        open={openSystemUser}
        onClose={onCloseSystemUser}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalUserSystemSearch onClose={onCloseSystemUser} exeFun={getAllUsersServices} />
      </Modal>
      {/* Address modal */}
      <Modal
        open={openAddress}
        onClose={onCloseAddress}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <AddressModal onClose={onCloseAddress} exeFun={showAddress} />
      </Modal>
      {/* Search data modal */}
      <Modal
        open={openSearch}
        onClose={onCloseSearch}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalSearch
          onClose={onCloseSearch}
          exeFun={getAllUsersServices}
          serviceId={idService}
          permissions={{
            automatic: searchAutomatic,
            manual: manualSearch,
          }}
        />
      </Modal>
    </>
  );
};

export default CreateService;
