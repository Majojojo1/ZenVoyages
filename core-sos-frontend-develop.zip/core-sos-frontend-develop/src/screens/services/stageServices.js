const stageServices = {
  1: "En coordinación",
  2: "Asignado",
  3: "En Desplazamiento",
  4: "En Sitio",
  5: "Visita Fallida",
  6: "En Curso",
  7: "Anulado",
  8: "Finalizado",
  9: "Finalizado Técnico",
};

export default stageServices;
