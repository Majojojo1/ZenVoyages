import React, { useContext, useEffect, useState } from "react";
// Import Context
import { AppContext } from "context/AppContext";
import { SearchWrapper, useSeachContext } from "context/SearchContext";
import DynamicTableServices from "../../DynamicTableServices/DynamicHeadServices";
// Import Hooks
import useGetData from "hooks/useGetData";
import { useParams } from "react-router";
// Import Services
import { ACTIVITIES } from "constants/lang/services/services/activities";
import useLangv2, { formatterText } from "hooks/useLangv2";
import { MdDownload } from "react-icons/md";
import endpoints from "services/api";
import { addItem, deleteItem, getItemById, updateItem } from "services/api/methods";
import paths from "services/paths";

const Activities = ({ getActivitiesActive, statusActivity }) => {
  return (
    <SearchWrapper>
      <ActivitiesComponent
        getActivitiesActive={getActivitiesActive}
        statusActivity={statusActivity}
      />
    </SearchWrapper>
  );
};

const tableTitles = [
  ACTIVITIES.tableTitles.nameActivity,
  ACTIVITIES.tableTitles.serviceStage,
  ACTIVITIES.tableTitles.developmentMinutes,
  ACTIVITIES.tableTitles.activityStatus,
  ACTIVITIES.tableTitles.technicalAspect,
  ACTIVITIES.tableTitles.activityCost,
  ACTIVITIES.tableTitles.formCompleted,
];

function ActivitiesComponent({ getActivitiesActive, statusActivity, getDataToUpdate }) {
  // get id url
  const { id } = useParams();
  const { setDataTable, dataTable } = useSeachContext();
  const { setInitActivity, setListActivities } = useContext(AppContext);
  const [counterActivities, setCounterActivities] = useState(0);
  const [serviceCost, setServiceCost] = useState(0);
  const [form, setForm] = useState(0);
  // activity ids
  const [activityIds, setActivityIds] = useState([]);
  const [loading, setLoading] = useState(false);
  const { showDownloadFile  } = useLangv2();

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { error, toggleLoading, toggleError, handleClick } = useGetData();

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getItemById(endpoints.services.getAllActivitiesStateByIdService, id)
      .then((data) => {        
        let newArray = [];
        let r = [];
        let forms = [];

        data.forEach((item, i) => {
          handleStructureItems(newArray, item);
          r.push(item.valor);
          forms.push(item.cantidadRespuestasFormulario)
        });

        setForm(forms);

        // sumar todos los enteros de r
        let RR = r.reduce((a, b) => a + b, 0);
        setServiceCost(RR);
        const ACTIVITY_START = activityIds.some((id) => {
          return id !== 1;
        });
        // check if activityIds has an id different to 1, if it has, set initActivity to true
        setInitActivity(ACTIVITY_START);
        const dataFinal = sortFunction(newArray, "asc");
        setListActivities(dataFinal);
        setDataTable(dataFinal);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const sortFunction = (newArray, type) => {
    let sortedArray;
    // sort iby the orden field
    if (type === "asc") {
      sortedArray = newArray.sort((a, b) => {
        return a.orden - b.orden;
      });
    } else {
      sortedArray = newArray.sort((a, b) => {
        return b.orden - a.orden;
      });
    }

    return sortedArray;
  };  

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleDownloadForm = (item, body) => {
    showDownloadFile();

    addItem(endpoints.formServices.downloadFormByActivity, body)
    .then((res) => {
      const extensionArchivo = 'pdf';
      const MimeType = 'pdf';
      const decoded = decodeBase64(res);
      DownloadPdf(decoded, `${item.nombre.replace(/ /g, '-')}.${extensionArchivo}`, MimeType);
  

    }).catch((err)=>{
      console.error(err);
    });

  };

  const decodeBase64 = (base64) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return byteArray;
  };

  const DownloadPdf = (decoded, fileName, ext) => {
    const blob = new Blob([decoded], { type: `aplication/${ext}` });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  };

  const handleStructureItems = (newArray, item) => {  

    setCounterActivities((prev) => {
      return parseInt(prev + item.tiempoActividad);
    });

    setActivityIds((prev) => {
      return [...prev, item.idEstadoActividad?.idEstadoActividad];
    });  

    newArray.push({
      
      id: item.idServicioActividad,
      nombreP: item.nombre,
      etapaS: item.idEtapaServicio.nombre,
      tiempo: item.tiempoActividad,
      EstadoActividad: item.idEstadoActividad.idEstadoActividad,
      actividadTecnica: item.actividadTecnica === 1 ? "Si" : "No",
      valor: item.valor,
      form: item.cantidadRespuestasFormulario !== 0 ? 
      <MdDownload
        size={25}
        color="gray"
        cursor="pointer"
        disabled={loading}
        onClick={() => handleDownloadForm(item, {
          idActividad: item.idActividad,
          idServicio: item.idServicio.idServicio
        })}
      /> : 'Sin Formularios',
      objeto: item,
    });
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const convertMinutesToHours = (minutes) => {
    let hours = Math.floor(minutes / 60);
    let minutesLeft = minutes % 60;
    return `${hours} ${formatterText(ACTIVITIES.hours)} ${minutesLeft} ${formatterText(ACTIVITIES.minutes)}`;
  };

  return (
    <div>
      <div className="externalElementsContainer">
        <label className="wrapForm__label">
          <h3 className="p-styles primary-green spacing-l1">
            {formatterText(ACTIVITIES.totalActivities)}: {counterActivities} ({formatterText(ACTIVITIES.minutes)}) - {formatterText(ACTIVITIES.hours)}:{" "}
            {convertMinutesToHours(counterActivities)}
          </h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles primary-green spacing-l1">
            {formatterText(ACTIVITIES.costService)}: ${serviceCost}
          </h3>
        </label>


      </div>
      <div className="tdR thR table-container">
        <DynamicTableServices
          titles={tableTitles}
          pageName={formatterText(ACTIVITIES.title)}
          getData={getDataTable}
          handleDeleteItem={handleDeleteItem}
          handleEditStateItem={handleEditStateItem}
          routeToEdit={paths.updateUser}
          canDeleted={true}
          canModify={true}
          statusActivity={statusActivity}
          getDataToUpdate={getDataToUpdate}
          setCounterActivities={setCounterActivities}
          form={form}

        />
      </div>
    </div>
  );
}

export default Activities;
