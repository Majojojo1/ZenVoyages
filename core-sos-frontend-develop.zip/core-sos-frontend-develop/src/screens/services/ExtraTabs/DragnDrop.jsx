import DropFileInput from "components/drop-file-input/DropFileInput";
import React from "react";

export default function DragnDrop() {
  const onFileChange = (files) => {};

  return (
    <div className="generalStyles">
      <div className="box">
        <DropFileInput onFileChange={(files) => onFileChange(files)} />
      </div>
    </div>
  );
}
