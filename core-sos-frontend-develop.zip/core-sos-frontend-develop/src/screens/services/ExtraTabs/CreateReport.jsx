import React from "react";

export default function CreateReport() {
  return (
    <section className="wrapForm">
      <label className="wrapForm__label">
        <h4 className="p-styles spacing-l1 mid-green">Tipo de reporte</h4>
        <select
          className="input-select"
          name="idTipoReporte"
          value=""
          onChange=""
          style={{ marginLeft: "1.5rem" }}
        >
          <option value="">Selecciona una opción</option>
        </select>
      </label>
      <label
        className=""
        style={{
          width: "100%",
          paddingLeft: "1rem",
        }}
      >
        <h4 className="p-styles mid-green" style={{ paddingBottom: "2.5rem" }}>
          Descripción
        </h4>
        <textarea
          className=""
          style={{
            width: "100%",
            marginLeft: "4rem",
            border: "0",
            boxShadow: "0px 4px 8px rgba(0, 174, 142, 0.2)",
            borderRadius: "10px",
            padding: "0.5rem 2rem",
            fontWeight: "400",
            fontFamily: "inherit",
            minWidth: "250px",
            width: "80%",
            height: "6rem",
            resize: "none",
            overflow: "visible",
          }}
          name="descripcion"
          value=""
          onChange=""
          maxLength="200"
        ></textarea>
      </label>
      <label className="">
        <h4 className="p-styles mid-green" style={{ paddingLeft: "1rem" }}>
          + Adjuntar archivos
        </h4>
      </label>
    </section>
  );
}
