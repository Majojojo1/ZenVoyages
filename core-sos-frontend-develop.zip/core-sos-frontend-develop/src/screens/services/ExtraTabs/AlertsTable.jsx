import React, { useEffect } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { FormattedMessage } from 'react-intl';
//Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
// Import Hooks
import useGetData from 'hooks/useGetData';
// Import services
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const AlertsTable = () => {
  return (
    <SearchWrapper>
      <PrecautionsComponent />
    </SearchWrapper>
  );
};

function PrecautionsComponent() {
  // hook to loading data
  const {
    // loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    // displayMessage,
    // displayLoading,
  } = useGetData();

  // useContext de búsqueda
  const { setDataTable } = useSeachContext();

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // títulos de la tabla de Recaudos
  const titlesR = ['Fecha/Hora', 'Categoría', 'Mensaje', 'Cliente', 'Ciudad', 'Marcar como leído'];

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.notifications.getAlerta)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      /* idNotificacion: item.idNotificacionServicio, */
      fechaHora: item.fechaRegistro,
      categoria: 'Cat',
      mensaje: item.mensaje,
      cliente: 'Cliente',
      ciudad: 'Ciudad',
      marcarLeido: item.leido,
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  return (
    <>
      <div className="externalElementsContainer">
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Alertas</h3>
        </label>
      </div>
      <section className="tdR thR table-container">
        <section className="userOptions">
          <Search placeholder="Buscar por ..." width="50%" />
        </section>
        <FormattedMessage id="table.name.search.users" defaultMessage="Recaudos">
          {(placeholder) => (
            <DynamicTable
              titles={titlesR}
              pageName={placeholder}
              getData={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateUser}
              canDeleted={true}
              canModify={true}
              canSearch={true}
            />
          )}
        </FormattedMessage>
      </section>
    </>
  );
}

export default AlertsTable;
