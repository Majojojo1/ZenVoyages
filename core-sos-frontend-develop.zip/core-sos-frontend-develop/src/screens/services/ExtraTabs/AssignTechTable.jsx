import React from "react";

export default function AssignTechTable() {
  return (
    <div className="assign-table-styles">
      <button
        className=""
        style={{
          background:
            "linear-gradient(113.52deg, #ffc954 34.84%, #e9b440 122.42%)",
          boxShadow: "0px 4px 8px rgba(0, 174, 142, 0.2)",
          border: "0",
          borderRadius: "50px",
          padding: "0.2rem 0.2rem",
          fontFamily: "inherit",
          color: "var(--text-dark)",
          fontWeight: "bold",
          width: "fit-content",
          cursor: "pointer",
          maxWidth: "200px",
        }}
      >
        <label style={{ paddingLeft: "1rem", paddingRight: "1rem" }}>
          Buscar técnicos
        </label>
      </button>
      <div className="assign-table-divs">
        <p className="p-styles" style={{ color: "#58585B" }}>
          Anggelo Moncada (Principal)
        </p>
        <p
          className="p-styles"
          style={{
            color: "#58585B",
            fontSize: "0.9rem",
            paddingLeft: "2.2rem",
            textDecoration: "underline",
          }}
        >
          Cambiar
        </p>
      </div>
      <div className="assign-table-divs" style={{ alignItems: "center" }}>
        <p className="p-styles" style={{ color: "#58585B" }}>
          Gregson Murcia (Auxiliar)
        </p>
        <p className="p-styles mid-green" style={{ paddingLeft: "2.5rem" }}>
          Fecha y hora de la cita
        </p>
        <input
          type="date"
          style={{
            height: "36px !important",
            background: "var(--white)",
            border: "0",
            boxShadow: "0px 4px 8px rgba(0, 174, 142, 0.2)",
            borderRadius: "50px",
            marginLeft: "1.5rem",
            fontFamily: "inherit",
            color: "var(--text-dark)",
            fontWeight: "400",
            width: "80%",
            maxWidth: "14rem",
            height: "3rem",
          }}
        />
        <select
          name="idHora"
          value=""
          onChange=""
          style={{
            marginLeft: "1.5rem",
            width: "10rem",
            height: "3rem",
            fontFamily: "inherit",
            border: "0",
            boxShadow: "0px 4px 8px rgb(0 174 142 / 20%)",
            borderRadius: "50px",
            padding: "0.5rem 1.5rem",
            background: "var(--white)",
            color: "var(--text-dark)",
            fontSize: "15px",
          }}
        >
          <option value="">09:00</option>
        </select>
        <p
          className="p-styles"
          style={{
            color: "#58585B",
            fontSize: "0.9rem",
            paddingLeft: "2.2rem",
            textDecoration: "underline",
          }}
        >
          Eliminar
        </p>
      </div>
      <div className="assign-table-divs" style={{ alignItems: "center" }}>
        <p className="p-styles" style={{ color: "#58585B" }}>
          Valeria Delgado (Auxiliar)
        </p>
        <p className="p-styles mid-green" style={{ paddingLeft: "2.5rem" }}>
          Fecha y hora de la cita
        </p>
        <input
          type="date"
          style={{
            height: "36px !important",
            background: "var(--white)",
            border: "0",
            boxShadow: "0px 4px 8px rgba(0, 174, 142, 0.2)",
            borderRadius: "50px",
            marginLeft: "1.5rem",
            fontFamily: "inherit",
            color: "var(--text-dark)",
            fontWeight: "400",
            width: "80%",
            maxWidth: "14rem",
            height: "3rem",
          }}
        />
        <select
          name="idHora"
          value=""
          onChange=""
          style={{
            marginLeft: "1.5rem",
            width: "10rem",
            height: "3rem",
            fontFamily: "inherit",
            border: "0",
            boxShadow: "0px 4px 8px rgb(0 174 142 / 20%)",
            borderRadius: "50px",
            padding: "0.5rem 1.5rem",
            background: "var(--white)",
            color: "var(--text-dark)",
            fontSize: "15px",
          }}
        >
          <option value="">09:00</option>
        </select>
        <p
          className="p-styles"
          style={{
            color: "#58585B",
            fontSize: "0.9rem",
            paddingLeft: "2.2rem",
            textDecoration: "underline",
          }}
        >
          Eliminar
        </p>
      </div>
    </div>
  );
}
