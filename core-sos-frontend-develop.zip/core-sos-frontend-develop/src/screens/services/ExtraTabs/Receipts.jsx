import React, { useEffect } from "react";
// Import Context
import DynamicTable from "common/DynamicTable/DynamicHead";
import { SearchWrapper, useSeachContext } from "context/SearchContext";
import { FormattedMessage } from "react-intl";
// Import Hooks
import useGetData from "hooks/useGetData";
// Import services
import endpoints from "services/api";
import { deleteItem, getAll, updateItem } from "services/api/methods";
import paths from "services/paths";

const Receipts = () => {
  return (
    <SearchWrapper>
      <PrecautionsComponent />
    </SearchWrapper>
  );
};

function PrecautionsComponent() {
  // hook to loading data
  const {
    // loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    // displayMessage,
    // displayLoading,
  } = useGetData();

  // useContext de búsqueda
  const { setDataTable } = useSeachContext();

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // títulos de la tabla de Recaudos
  const titlesR = ["Nombre", "Categoría asociada", "Costo", "Acciones"];
  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.users.getAllUsers)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      idRecaudo: "0",
      categoriaAsociada: "Cat2",
      costo: "$1000",
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          // console.log(res);
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  return (
    <>
      <div className="externalElementsContainer">
        <label className="wrapForm__label">
          <h3 className="p-styles primary-green spacing-l1">
            + Registrar recaudo
          </h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Ingresos: $1000</h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">Devoluciones: $100</h3>
        </label>
        <label className="wrapForm__label">
          <h3 className="p-styles spacing-l1 dark-gray">
            Valor total recaudado: $900
          </h3>
        </label>
      </div>

      <section className="tdR thR table-container">
        <FormattedMessage
          id="table.name.search.users"
          defaultMessage="Recaudos"
        >
          {(placeholder) => (
            <DynamicTable
              titles={titlesR}
              pageName={placeholder}
              getData={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateUser}
              canDeleted={true}
              canModify={true}
            />
          )}
        </FormattedMessage>
      </section>
    </>
  );
}

export default Receipts;
