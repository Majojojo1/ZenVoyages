import React, { useEffect } from "react";
// Import Context
import DynamicTable from "common/DynamicTable/DynamicHead";
import { SearchWrapper, useSeachContext } from "context/SearchContext";
import dateFormat from "dateformat";
import { FormattedMessage } from "react-intl";
// Import Hooks
import useGetData from "hooks/useGetData";
// Import services
import endpoints from "services/api";
import { deleteItem, getAll, updateItem } from "services/api/methods";
import paths from "services/paths";

const Reconciliation = () => {
  return (
    <SearchWrapper>
      <PrecautionsComponent />
    </SearchWrapper>
  );
};

function PrecautionsComponent() {
  // hook to loading data
  const {
    // loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    // displayMessage,
    // displayLoading,
  } = useGetData();

  // useContext de búsqueda
  const {  setDataTable } = useSeachContext();

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // títulos de la tabla de Facturas
  const titlesF = [
    "Número de factura",
    "Fecha de factura",
    "Subtotal",
    "Acciones",
  ];
  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.users.getAllUsers)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      idFactura: "0",
      fechaFactura: dateFormat(item.fechaRegistro, "yyyy/mm/dd - h:MM:ss TT"), //Cambiar por la de las facturas.
      subtotal: "$3000",
    });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.users.deleteUser, rowId)
        .then((res) => {
          getDataTable();
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.users.updateUser, body)
        .then((res) => {
          // console.log(res);
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  return (
    <>
      <section className="tdR thR table-container">
        <FormattedMessage
          id="table.name.search.users"
          defaultMessage="Productos"
        >
          {(placeholder) => (
            <DynamicTable
              titles={titlesF}
              pageName={placeholder}
              getData={getDataTable}
              handleDeleteItem={handleDeleteItem}
              handleEditStateItem={handleEditStateItem}
              routeToEdit={paths.updateUser}
              canDeleted={true}
              canModify={true}
            />
          )}
        </FormattedMessage>
      </section>
    </>
  );
}

export default Reconciliation;
