import React from "react";

export default function FormsDnD() {
  return (
    <div>
      <div className="formsContainer">
        <section className="formTicket">
          <div>
            <input
              type={"radio"}
              name="formRadio"
              id="radioTicket"
              value={"Subir por ticket"}
              className="ticketRadioInput"
            />
            <label htmlFor="formRadio">
              <h4>Subir por ticket</h4>
            </label>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Ticket</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Número de ticket"
                name="ticket"
                id="ticket"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Factura</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Número de Factura"
                name="factura"
                id="factura"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Fecha Factura</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Fecha de Factura"
                name="fFactura"
                id="fFactura"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Subtotal</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Subtotal de Factura"
                name="subtotalF"
                id="subtotalF"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Impuestos</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Impuestos de Factura"
                name="iFactura"
                id="iFactura"
                maxLength={35}
                // required
                // value
              />
            </section>
          </div>
        </section>
        <section className="formExped">
          <div>
            <input
              type={"radio"}
              name="formRadio"
              id="radioExp"
              value={"Subir por expediente"}
            />
            <label htmlFor="formRadio">
              <h4>Subir por expediente</h4>
            </label>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Nit Cliente</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Nit Cliente"
                name="nit"
                id="nit"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Expediente</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Número de expediente"
                name="ticket"
                id="ticket"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Factura</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Número de Factura"
                name="factura"
                id="factura"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Fecha Factura</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Fecha de Factura"
                name="fFactura"
                id="fFactura"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Subtotal</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Subtotal de Factura"
                name="subtotalF"
                id="subtotalF"
                maxLength={35}
                // required
                // value
              />
            </section>
            <section className="form-responsive-information__option ticketSection">
              <h3 className="p-styles">Impuestos</h3>
              <input
                type="text"
                className="input-primary"
                placeholder="Impuestos de Factura"
                name="iFactura"
                id="iFactura"
                maxLength={35}
                // required
                // value
              />
            </section>
          </div>
        </section>
      </div>
      <div className="form-responsive-container-buttons footer-grid-buttons">
        <input
          type={"submit"}
          className="btn-action-primary"
          value={"Guardar Factura"}
        />
      </div>
    </div>
  );
}
