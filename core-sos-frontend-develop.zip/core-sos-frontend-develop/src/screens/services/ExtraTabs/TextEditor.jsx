import React, { Component } from "react";
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { EditorState } from "draft-js";

export default class TextEditor extends Component {
  state = {
    editorState: EditorState.createEmpty(),
  };

  onEditorStateChange = (editorState) => {
    this.setState({
      editorState,
    });
  };

  render() {
    const { editorState } = this.state;
    return (
      <div className="descriptionContainer">
        <div>
          <h3 className="p-styles spacing-l1 primary-green">Descripción</h3>
        </div>
        <div>
          <Editor
            editorState={editorState}
            tool
            barClassName="toolbarClassName"
            wrapperClassName="wrapperClassName"
            editorClassName="editorText"
            onEditorStateChange={this.onEditorStateChange}
          />
        </div>
      </div>
    );
  }
}
