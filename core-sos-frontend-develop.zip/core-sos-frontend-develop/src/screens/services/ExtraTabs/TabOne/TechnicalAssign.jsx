import React, { useEffect, useState } from "react";
// Import Hooks
import useLangv2, { formatterText } from "hooks/useLangv2";
import { useNavigate, useParams } from "react-router-dom";
// Import Services
import endpoints from "services/api";
import { addItem, deleteItem, getItemById } from "services/api/methods";
import paths from "services/paths";

// Import Libs
import { Modal } from "react-responsive-modal";
import ModalSearch from '../../Modals/ModalSearch';
// import Screens
import UpdateDatimeAlert from "screens/services/Modals/UpdateDatimeAlert";

export default function TechnicalAssign({ serviceState, setPpTech, ppTech, getDataToUpdate, onOpenSearch, searchAutomatic = false, manualSearch = false }) {
  const navigate = useNavigate();
  // get id from the url
  const { id } = useParams();
  // getall technicals services
  useEffect(() => {
    getAllTechnicalsServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // use Hook of language v2
  const { successRemoveItem, errorProcess, customSB } = useLangv2();
  const [changeDateTime, setChangeDateTime] = useState(false);

  const [openSearch, setOpenSearch] = useState(false);
  const onOpenSearchModal = () => setOpenSearch(true);
  const onCloseSearchModal = () => setOpenSearch(false);

  const onCloseChangeDateTime = () => setChangeDateTime(false);

  const [infoToChange, setInfoToChange] = useState({
    principal: false,
    idTecnico: -1,
    idCitaServicioTecnico: -1,
  });

  const [auxTech, setAuxTech] = useState([]);

  const [listTechs, setListTechs] = useState([]);

  const getAllTechnicalsServices = () => {
    getItemById(endpoints.technicalServices.getTechnicalsAssignedByService, id)
      .then((data) => {       
        console.log("tecnicos: ", data);
        const auxArrayTech = [];
        const listTechs = [];
        if (data.length !== 0) {
          const promises = [];

          data.forEach((item) => {
            let idtech;
            let label;

            if (item.idTecnico.idEmpleado !== null) {
              label = `${item.idTecnico.idEmpleado.primerNombre} - ${item.idTecnico.idEmpleado.primerApellido}`;
              idtech = item.idTecnico.idTecnico;
            } else {
              idtech = item.idTecnico.idTecnico;
              label = `${item.idTecnico.idTercero.nombre} - ${item.idTecnico.idTercero.identificacion}`;
            }

            if (item.principal === 1) {
              setPpTech({
                idtech,
                label,
              });
              listTechs.push(item.idTecnico.idTecnico);
            } else {
              const idFin = item.idServicioTecnico;
              const idCita = item.idCitaServicioTecnico;

              const promise = addItem(endpoints.services.getStatusAux, {
                id_servicio: item.idServicio.idServicio,
                id_tecnico: item.idTecnico.idTecnico,
              }).then((data) => {
                const newAuxTech = {
                  idFin,
                  idCita,
                  idtech, // Usa la variable local idtech
                  statusOnServ: data?.idEstadoServicio?.idEstadoServicio,
                  label: label,
                  date: new Date(item.idServicio.fechaCita)
                    .toISOString()
                    .split("T")[0],
                  hour: item.idServicio.idHoraCita.hora,
                  idServicioTecnico: data?.idServicioTecnico?.idServicioTecnico,
                };
                auxArrayTech.push(newAuxTech);
                listTechs.push(item.idTecnico.idTecnico);
              });

              promises.push(promise);
            }
          });

          Promise.all(promises)
            .then(() => {
              setAuxTech(auxArrayTech);
              setListTechs(listTechs.join(","));
              setAuxLoading(true);
            })
            .catch((err) => {
              console.log(err);
            });
        } else {
          let idtech = -1;
          let label = '';
          setPpTech({
            idtech,
            label,
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };


  const delteAuxTech = (id) => {
    deleteItem(endpoints.services.deleteAuxTechnician, id)
      .then(() => {
        getAllTechnicalsServices();
        successRemoveItem();
      })
      .catch(() => {
        errorProcess();
      });
  };

  const [auxLoading, setAuxLoading] = useState(false);

  const canModifyDate = {
    2: true,
    3: true,
    4: true,
  };

  return (
    <section className="container-tech-assign">
      <button
        className="btn-action-style-s"
        onClick={(e) => {
          e.preventDefault();
          if (ppTech.idtech === -1) {
            localStorage.setItem("idService", id);
            navigate(paths.searchPrincialTechnical.replace(":id", id));
          } else {
            const STATE_SERVICE_ALLOWED = {
              2: true,
              3: true,
              4: true,
              6: true,
            };

            const res = STATE_SERVICE_ALLOWED[serviceState] || false;

            if (res) {
              /*localStorage.setItem("idService", id);
              window.open(`#${paths.auxTech}`, "_blank",);*/
              onOpenSearchModal();
            } else {
              // in S09 HU01 only open AuxTech if the service is in state 2,3,4,6
              customSB(
                "warning",
                "snackbar.warning.aux.state.service",
                "No se puede asignar un técnico auxiliar con el actual estado del servicio.",
              );
            }
          }
        }}
      >
        {formatterText('btn.service.edit.find.tech')}
      </button>
      {serviceState === 1 && (
        <button
          className="btn-action-style-s"
          style={{ marginLeft: "1rem" }}
          onClick={(e) => {
            e.preventDefault();
            window.open(
              `#${paths.reviewMap}?idService=${id}&assigned=false`,
              "_blank",

            );
          }}
        >
          {formatterText('btn.service.view.map')}
        </button>
      )}
      {ppTech.idtech === -1 ? (
        <p>{formatterText('title.service.no.techs.available')}</p>
      ) : (
        <div className="assign-table-divs">
          <p className="p-styles" style={{ color: "#58585B" }}>
            {ppTech.label} (Principal)
          </p>
          <button
            className="btn-action-style-s"
            style={{ marginLeft: "1rem" }}
            onClick={(e) => {
              e.preventDefault();
              window.open(
                `#${paths.reviewMap}?idService=${id}&assigned=true&list=${listTechs}`,
                "_blank",
              );
            }}
          >
            {formatterText('btn.service.view.map')}
          </button>
        </div>
      )}
      {auxLoading &&
        auxTech.map((item, index) => {
          // if the prev item, its the same idtech then dont show the label
          if (item.idtech === auxTech[index - 1]?.idtech) {
            return null;
          }
          return (
            <div
              className="assign-table-divs"
              style={{ alignItems: "center" }}
              key={item.label}
            >
              <p className="p-styles" style={{ color: "#58585B" }}>
                {item.label} ({formatterText('label.service.edit.tech.role')})
              </p>
              {canModifyDate[item.statusOnServ] && (
                <>
                  <p
                    className="p-styles"
                    style={{
                      color: "#58585B",
                      fontSize: "0.9rem",
                      padding: "0rem 2.2rem",
                      textDecoration: "underline",
                      cursor: "pointer",
                    }}
                    onClick={(e) => {
                      setInfoToChange({
                        principal: false,
                        idTecnico: item.idtech,
                        idCitaServicioTecnico: item.idCita,
                      });
                      setChangeDateTime(true);
                    }}
                  >
                  {formatterText('btn.link.change.date.service')}
                  </p>
                  <p
                    className="p-styles"
                    style={{
                      color: "#58585B",
                      fontSize: "0.9rem",
                      paddingLeft: "2.2rem",
                      textDecoration: "underline",
                      cursor: "pointer",
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      delteAuxTech(item.idServicioTecnico);
                    }}
                  >
                    {formatterText('btn.delete')}
                  </p>
                </>
              )}
            </div>
          );
        })}
      <Modal
        open={changeDateTime}
        onClose={onCloseChangeDateTime}
        center
        classNames={{
          overlay: "customOverlay",
          modal: "customModal",
        }}
      >
        <section>
          <UpdateDatimeAlert
            onClose={onCloseChangeDateTime}
            infoToChange={infoToChange}
            WayChange={true}
            getDataToUpdate={getDataToUpdate}
            getAllTechnicalsServices={getAllTechnicalsServices}
            OpenSearch={onOpenSearch}
            idTecnico={infoToChange.idTecnico}
            idCitaServicioTecnico={infoToChange.idCitaServicioTecnico}
          />
        </section>
      </Modal>
      <Modal
        open={openSearch}
        onClose={onCloseSearchModal}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <ModalSearch
          onClose={onCloseSearchModal}
          //exeFun={getAllUsersServices}
          serviceId={id}
          permissions={{
            automatic: searchAutomatic,
            manual: manualSearch,
          }}
          auxTechnical={true}
        />
      </Modal>
    </section>
  );
}
