import Search from 'common/Search';
import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';
// paths to routes
import paths from 'services/paths';
// Hooks
import useLangv2 from 'hooks/useLangv2';
// hook para cargar los datos
import useGetData from 'hooks/useGetData';
// Context de búsqueda
import ExportJsonFile from 'components/utils/ExportJsonFile';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Llamar a la tabla dinamica
import DynamicTable from 'common/DynamicTable/DynamicHead';
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { getAll } from 'services/api/methods';
import { deleteProvider, updateProvider } from 'services/api/providers';
import endpoints from '../../services/api';

const ProviderPage = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ProviderComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function ProviderComponent() {
  const { loading, error, toggleLoading, displayMessage, displayLoading } = useGetData();
  const { setDataTable } = useSeachContext();
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const [clients, setClients] = useState(null);

  // titulos de la tabla
  const titles = [
    formatterText('table.title.provider.name', 'Nombre proveedor'),
    formatterText('text.ID', 'Identificación'),
    formatterText('table.title.website', 'Sitio web'),
    formatterText('table.title.phone', 'Teléfono'),
    formatterText('table.title.email', 'Correo electrónico'),
    formatterText('table.title.municipality', 'Municipio'),
    formatterText('table.title.address', 'Dirección'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.providers);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAll(endpoints.providers.getAllProviders).then((data) => {
      let newArray = [];
      data.forEach((item) => handleStructureItems(newArray, item));
      setDataTable(newArray);
      // show loading
      toggleLoading(false);
      setClients(newArray);
    });
  };

  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteProvider(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          setClients(newArray);
          setDataTable(newArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateProvider(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idProveedor,
      nombre: item.nombreRazonSocial,
      identificacion: item.identificacion,
      sitioWeb: item.sitioWeb,
      telefono: item.telefono,
      correo: item.correo,
      municipio: item.idMunicipio.nombre,
      direccion: item.direccion,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const renderMessage = () => {
    return error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();
  };
  return (
    <>
      {!loading && clients !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createProvider}>
                <button className="btn-add">
                  <FormattedMessage
                    id="header.title.provider.create"
                    defaultMessage="Crear Proveedor"
                  />
                </button>
              </Link>
            )}
            {permittedActions.exportar && (
              <ExportJsonFile
                moduleName="Proveedores"
                userName={JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN'}
                dataTable={clients}
              />
            )}
          </section>
          <FormattedMessage id="table.name.search.provider" defaultMessage="Proveedores">
            {(placeholder) => (
              permittedActions.consultar && (<DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Proveedores}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateProvider}
                canDeleted={permittedActions.eliminar}
                canModify={permittedActions.editar}
              />)
            )}
          </FormattedMessage>
        </section>
      ) : (
        renderMessage()
      )}
    </>
  );
}

export default ProviderPage;
