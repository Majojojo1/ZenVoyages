import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import { Formiz, useForm } from '@formiz/core';
import useAxios from 'hooks/useAxios';
import useLangv2 from 'hooks/useLangv2';
import { useParams } from 'react-router-dom';
// Import Components
import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import { FormattedMessage } from 'react-intl';
// Import Libs
// Import Services
import { FilterActive } from 'common/validators/FilterActives';
import HandleOnError from 'common/validators/HandleOnError';
import endpoints from 'services/api';
import { getAllCargos } from 'services/api/cargos';
import { getAllGenres, getAllTypeDocument } from 'services/api/institutions';
import { getItemById, updateItemById } from 'services/api/methods';
import { getAllMunicipalities } from 'services/api/zones';
import HandlerChangeMailAssesor from '../fields/HandlerChangeMailAsesor';

export default function AddAdviser({ onClose, reloadData }) {
  const [selectData, setSelectData] = useState({});

  const { modalData, auxId, setAuxId, otherCurrentDataTable, setOtherCurrentDataTable } =
    useContext(TableMinimalContext);

  const MODEL = {
    emailAsesor: modalData.emailAsesor,
    correoAlternoAsesor: modalData.correoAlternoAsesor,

  };

  // manage the petitions
  const { COOKIE_USER } = useAxios();
  const { updatedItem, noFilledContent, customSB, formatterText } = useLangv2();
  // get id from url
  const { id } = useParams();
  const myForm = useForm();

  const [currentAsesor, setCurrentAsesor] = useState(MODEL);
  const [error, setError] = useState('');
  const [altErr, setAltErr] = useState('');
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    getData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getData = () => {
    setLoadingData(true);

    const promises = [getAllMunicipalities(), getAllTypeDocument(), getAllGenres(), getAllCargos()];

    Promise.all(promises).then((values) => {
      setLoadingData(false);
      setSelectData({
        ...selectData,
        municipalities: FilterActive(values[0]),
        documentTypes: FilterActive(values[1]),
        genres: FilterActive(values[2]),
        cargos: FilterActive(values[3]),
      });
    });
  };


  const handleBlurMailAsesor = (e) => {
    if (!error && e.target.value.trim() === '') {
      setError('');
    }
  };

  const handleBlurMailAltAsesor = (e) => {
    if (!altErr && e.target.value.trim() === '') {
      setAltErr('');
    }
  };

  const handleSubmit = (values) => {

    if ((altErr || error) ||
      values.identificacion.trim() === '' ||
      values.nombreAsesor.trim() === '' ||
      values.telefonoAsesor.trim() === '' ||
      values.telefonoAlternoAsesor.trim() === ''
    ) {
      noFilledContent();

    } else {

      if (currentAsesor.emailAsesor === currentAsesor.correoAlternoAsesor) {
        customSB('warning', 'warning.alert.same.mails');
        return;
      }
      if (values.telefonoAsesor === values.telefonoAlternoAsesor) {
        customSB('warning', 'warning.alert.same.tlf');
        return;
      }

      let BODY = {
        idTipoDocumentoAsesor: values.idTipoDocumentoAsesor,
        identificacion: values.identificacion,
        genero: values.genero,
        nombreAsesor: values.nombreAsesor,
        idCargo: values.idCargo,
        emailAsesor: currentAsesor.emailAsesor,
        correoAlternoAsesor: currentAsesor.correoAlternoAsesor,
        telefonoAsesor: values.telefonoAsesor,
        telefonoAlternoAsesor: values.telefonoAlternoAsesor,
        idMunicipio: values.idMunicipio,
        estado: 1,
      };

      if (auxId !== null) {
        BODY = {
          idAsesor: auxId,
          idCliente: {
            idCliente: parseInt(id),
          },
          idTipoDocumento: {
            idTipoDocumento:
              typeof BODY.idTipoDocumentoAsesor === 'string'
                ? JSON.parse(JSON.parse(BODY.idTipoDocumentoAsesor).value).value
                : BODY.idTipoDocumentoAsesor.value,
          },
          identificacion: BODY.identificacion,
          nombres: BODY.nombreAsesor,
          idGenero: {
            idGenero:
              typeof BODY.genero === 'string'
                ? JSON.parse(JSON.parse(BODY.genero).value).value
                : BODY.genero.value,
          },
          idCargo: {
            idCargo:
              typeof BODY.idCargo === 'string'
                ? JSON.parse(JSON.parse(BODY.idCargo).value).value
                : BODY.idCargo.value,
          },
          idMunicipio: {
            idMunicipio:
              typeof BODY.idMunicipio === 'string'
                ? JSON.parse(JSON.parse(BODY.idMunicipio).value).value
                : BODY.idMunicipio.value,
          },
          telefono: BODY.telefonoAsesor,
          telefonoAlterno: BODY.telefonoAlternoAsesor,
          correo: BODY.emailAsesor,
          correoAlterno: BODY.correoAlternoAsesor,
          estado: BODY.estado,
          fechaCreacion: modalData.fechaCreacion,
          fechaModificacion: null,
          usuarioCreacion: modalData.usuarioCreacion,
          usuarioModificacion: COOKIE_USER,
        };
        updateItemById(endpoints.advisers.updateAdviser, BODY?.idAsesor, BODY).then((info) => {
          onClose();
          updatedItem();
          getItemById(endpoints.advisers.getAsesorsByClient, id).then((resp) => reloadData(resp));
          setAuxId(null);
        }).catch((err) => {
          if (err.response?.data?.message) {
            HandleOnError(formatterText(err.response?.data?.message));
          } else {
            HandleOnError(formatterText(
              'snackbar.error.process.failed.general',
              'Error al realizar el proceso. Intentalo en otro momento.',
            ),
            );
          }
        });
      } else {
        otherCurrentDataTable.forEach((item, index) => {
          if (index === modalData.index) {
            let dataLeft = otherCurrentDataTable.filter((_, i) => {
              return i !== otherCurrentDataTable.indexOf(item);
            });
            setOtherCurrentDataTable([...dataLeft, BODY]);
            onClose();
          }
        });
      }
    }

  };

  return (
    <Formiz onSubmit={handleSubmit} className="form-responsive" connect={myForm}>
      <form className="container-wrapForm" noValidate onSubmit={myForm.submit}>
        <section className="grid-container-1c zero-gap">
          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.document.type" defaultMessage="Tipo de documento" />
            </span>
            <InputSelectorResponsive
              type="text"
              name="idTipoDocumentoAsesor"
              id="idTipoDocumentoAsesor"
              className="input-select-small"
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              required="Municipio es requerido"
              defaultValue={{
                label:
                  typeof modalData.idTipoDocumentoAsesor === 'string'
                    ? JSON.parse(modalData.idTipoDocumentoAsesor).label
                    : modalData.idTipoDocumentoAsesor.label,
                value:
                  typeof modalData.idTipoDocumentoAsesor === 'string'
                    ? JSON.parse(modalData.idTipoDocumentoAsesor).value
                    : modalData.idTipoDocumentoAsesor.value,
              }}
              data={
                !!selectData.documentTypes &&
                selectData.documentTypes.map((item) => {
                  let docLabel = `${item.nombre} - ${item.abreviatura}`;
                  return {
                    label: docLabel,
                    value: JSON.stringify({
                      label: `${item.nombre} - ${item.abreviatura}`,
                      value: JSON.stringify({
                        label: `${item.nombre} - ${item.abreviatura}`,
                        value: item.idTipoDocumento,
                      }),
                    }),
                  };
                })
              }
              isLoading={loadingData}
            />
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="text.ID" defaultMessage="Identificación" />
            </span>
            <InputFieldResponsive
              type="integer"
              name="identificacion"
              id="identificacion"
              placeholder="Identificación"
              validateInput="integer"
              required="La identificacion es requerida"
              className="input-primary width-50"
              defaultValue={modalData.identificacion}
            />
          </label>
          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.genero" defaultMessage="Género" />
            </span>
            <InputSelectorResponsive
              type="text"
              name="genero"
              id="genero"
              className="input-select-small"
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              required="Género es requerido"
              defaultValue={{
                label:
                  typeof modalData.genero === 'string'
                    ? JSON.parse(modalData.genero).label
                    : modalData.genero.label,
                value:
                  typeof modalData.genero === 'string'
                    ? JSON.parse(modalData.genero).value
                    : modalData.genero.value,
              }}
              data={
                !!selectData.genres &&
                selectData.genres.map((item) => {
                  let docLabel = `${item.nombre} - ${item.abreviatura}`;
                  return {
                    label: docLabel,
                    value: JSON.stringify({
                      label: docLabel,
                      value: item.idGenero,
                    }),
                  };
                })
              }
              isLoading={loadingData}
            />
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="table.title.full.name" defaultMessage="Nombre completo" />
            </span>
            <InputFieldResponsive
              type="text"
              name="nombreAsesor"
              id="nombreAsesor"
              placeholder="Nombre completo"
              validateInput="text"
              required="El Nombre completo es requerido"
              className="input-primary width-50"
              defaultValue={modalData.nombreAsesor}
            />
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="table.title.position" defaultMessage="Cargo" />
            </span>
            <InputSelectorResponsive
              type="text"
              name="idCargo"
              id="idCargo"
              className="input-select-small"
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              required="El cargo es requerido"
              defaultValue={{
                label:
                  typeof modalData.idCargo === 'string'
                    ? JSON.parse(modalData.idCargo).label
                    : modalData.idCargo.label,
                value:
                  typeof modalData.idCargo === 'string'
                    ? JSON.parse(modalData.idCargo).value
                    : modalData.idCargo.value,
              }}
              data={
                !!selectData.cargos &&
                selectData.cargos.map((item) => {
                  let docLabel = `${item.nombre}`;
                  return {
                    label: docLabel,
                    value: JSON.stringify({
                      label: item.nombre,
                      value: JSON.stringify({
                        label: item.nombre,
                        value: item.idCargo,
                      }),
                    }),
                  };
                })
              }
              isLoading={loadingData}
            />
          </label>
          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.correo" defaultMessage="Correo" />
            </span>
            <input
              type="email"
              name="emailAsesor"
              id="emailAsesor"
              placeholder="Correo"
              value={currentAsesor.emailAsesor}
              onChange={(e) => HandlerChangeMailAssesor(e, currentAsesor, setCurrentAsesor, setError)}
              onBlur={handleBlurMailAsesor}
              className="input-default-3c"
            />
            {error && <div className="error-msg">{error}</div>}
          </label>
          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.correoalterno" defaultMessage="Correo alterno" />
            </span>
            <input
              type="email"
              name="correoAlternoAsesor"
              id="correoAlternoAsesor"
              placeholder="Correo alterno"
              value={currentAsesor.correoAlternoAsesor}
              onChange={(e) => HandlerChangeMailAssesor(e, currentAsesor, setCurrentAsesor, setAltErr)}
              onBlur={handleBlurMailAltAsesor}
              className="input-default-3c"
            />
            {altErr && <div className="error-msg">{altErr}</div>}
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="table.title.phone" defaultMessage="Teléfono" />
            </span>
            <InputFieldResponsive
              name="telefonoAsesor"
              id="telefonoAsesor"
              placeholder="Teléfono"
              type="number"
              required="El Teléfono es requerido"
              className="input-primary width-50"
              validateInput="o_number"
              defaultValue={modalData.telefonoAsesor}
            />
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.alt.phone" defaultMessage="Teléfono alterno" />
            </span>
            <InputFieldResponsive
              name="telefonoAlternoAsesor"
              id="telefonoAlternoAsesor"
              placeholder="Teléfono alterno"
              type="number"
              required="El Teléfono alterno es requerido"
              className="input-primary width-50"
              validateInput="o_number"
              defaultValue={modalData.telefonoAlternoAsesor}
            />
          </label>

          <label className="d-flex">
            <span className="text-inline-md">
              <FormattedMessage id="p.city.residence" defaultMessage="Ciudad de residencia" />
            </span>
            <InputSelectorResponsive
              type="text"
              name="idMunicipio"
              id="idMunicipio"
              className="input-select-small"
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              required="La ciudad de residencia es requerida"
              defaultValue={{
                label:
                  typeof modalData.idMunicipio === 'string'
                    ? JSON.parse(modalData.idMunicipio).label
                    : modalData.idMunicipio.label,
                value:
                  typeof modalData.idMunicipio === 'string'
                    ? JSON.parse(modalData.idMunicipio).value
                    : modalData.idMunicipio.value,
              }}
              data={
                !!selectData.municipalities &&
                selectData.municipalities.map((item) => {
                  let docLabel = `${item.nombre}`;
                  return {
                    label: docLabel,
                    value: JSON.stringify({
                      label: item.nombre,
                      value: JSON.stringify({
                        label: item.nombre,
                        value: item.idMunicipio,
                      }),
                    }),
                  };
                })
              }
              isLoading={loadingData}
            />
          </label>
        </section>
        <section className="form-responsive-container-buttons">
          <input type="submit" className="width-100-fix" value={formatterText('btn.update.adviser')} />
          <input
            type="button"
            className="width-100-fix input-cancel"
            value={formatterText('btn.cancel')}
            onClick={onClose}
          />
        </section>
      </form>
    </Formiz>
  );
}


