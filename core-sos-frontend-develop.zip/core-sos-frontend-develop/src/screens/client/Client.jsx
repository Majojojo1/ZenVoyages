import React, { useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
import Search from 'common/Search';
import { downloadTable } from 'components/utils/ExportJsonFile';
// Import libs
import SortData from 'components/utils/SortData';
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom';

// Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { deleteClient, getAllClients, updateClient } from 'services/api/clients';
import paths from 'services/paths';

const Clients = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ClientsComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function ClientsComponent() {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  // titulos de la tabla
  const titles = [
    formatterText('table.title.clientname', 'Nombre cliente'),
    formatterText('p.document.type', 'Tipo de documento'),
    formatterText('p.email', 'Correo'),
    formatterText('table.title.document', 'Identificación'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { setDataTable, searchResult, sortedAscResults, setSortedAscResults } = useSeachContext();

  const [clients, setClients] = useState(null);
  // nuevo contexto
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();

  const permissionsAccessClient = () => {
    permissionsAccess(MODULES_NAME.clients);
  };

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAllClients()
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortData(newArray, 'asc');
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
        setClients(sortedArray);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    const deletePromise = new Promise((resolve, reject) => {
      deleteClient(rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          const sortedArray = SortData(newArray, 'asc');
          setClients(sortedArray);
          setDataTable(sortedArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deletePromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateClient(body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    let docType = `${item.idTipoDocumento.nombre} - ${item.idTipoDocumento.abreviatura}`;
    newArray.push({
      id: item.idCliente,
      nombre: item.nombreRazonSocial,
      tipo_documento: docType,
      correo: item.correo,
      documento: item.identificacion,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  const handleDownloadItem = () => {
    getAllClients()
      .then((data) => {
        let newArray = [];
        const moduleName = 'Cliente';
        const userName = JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN';
        const sortedArray = SortData(data, 'asc');
        sortedArray.forEach((item) => {
          const docType = `${item.idTipoDocumento.nombre} - ${item.idTipoDocumento.abreviatura}`;
          newArray.push({
            'Tipo de documento': docType,
            'Número de documento': item.identificacion,
            'Nombre o razón social': item.nombreRazonSocial,
            Celular: item.celular,
            Teléfono: item.telefono,
            'Sitio web': item.sitioWeb,
            Género: item.idGenero.nombre,
            'Tipo de cliente': item.idTipoCliente.nombre,
            Mercado: item.idMercado.nombre,
            // "Unidad de negocio": item.idUnidadNegocio.nombre,
            'Tipo de facturación': item.idTipoFacturacion.nombre,
            'Cliente especial': item.clienteEspecial ? 'Si' : ' ',
            Estado: item.estado ? 'Activo' : 'Inactivo',
            'Fecha de creación': item.fechaCreacion,
            'Fecha de modificación': item.fechaModificacion ? item.fechaModificacion : ' ',
          });
          // }
        });
        downloadTable({ moduleName, userName, dataTable: newArray });
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  useEffect(() => {
    getDataTable();
  }, []);

  useEffect(() => {
    permissionsAccessClient();
  }, [permissions]);

  useEffect(() => {
    if (!sortedAscResults) setSortedAscResults('asc');
  }, [searchResult]);

  const render = () =>
    error
      ? displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      : displayLoading();

  return (
    <>
      {!loading && clients !== null ? (
        <section className="table-container">
          <section className="userOptions">
            {permittedActions.consultar && (
              <Search
                placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
                width="50%"
              />
            )}
            {permittedActions.crear && (
              <Link to={paths.createClient}>
                <button className="btn-add">
                  {formatterText('header.title.client.create', 'Crear Cliente')}
                </button>
              </Link>
            )}

            {permittedActions.exportar && (
              <button className="btn-export" onClick={handleDownloadItem}>
                <FormattedMessage id="btn.downloadfile" defaultMessage="Descargar Excel" />
              </button>
            )}
          </section>
          {permittedActions.consultar && (
            <FormattedMessage id="table.name.search.client" defaultMessage="Cliente">
              {(placeholder) => (
                <DynamicTable
                  titles={titles}
                  pageName={PAGE_NAMES.Clientes}
                  getData={getDataTable}
                  handleDeleteItem={handleDeleteItem}
                  handleEditStateItem={handleEditStateItem}
                  routeToEdit={paths.updateClient}
                  canDeleted={permittedActions.eliminar}
                  canModify={permittedActions.editar}
                />
              )}
            </FormattedMessage>
          )}
        </section>
      ) : (
        render()
      )}
    </>
  );
}

export default Clients;
