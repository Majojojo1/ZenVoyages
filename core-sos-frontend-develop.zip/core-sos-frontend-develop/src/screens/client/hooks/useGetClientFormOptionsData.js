import { TableMinimalContext } from 'context/TableMinimalContext';
import { useContext, useEffect, useState } from 'react';
import endpoints from 'services/api';
import { getAllBillingTypes } from 'services/api/billingType';
import { getAllBusinessUnits } from 'services/api/businessUnit';
import { getAllCargos } from 'services/api/cargos';
import { getAllClientTypes } from 'services/api/clientType';
import { getAllGenres, getAllTypeAccounts, getAllTypeDocument } from 'services/api/institutions';
import { getAll } from 'services/api/methods';
import { getAllCountries, getAllMunicipalities, getAllSectors } from 'services/api/zones';

export default function useGetClientFormOptionsData() {
  const [selectData, setSelectData] = useState({});
  const [loadingData, setLoadingData] = useState(false);
  const [listPrices, setListPrices] = useState([]);
  const { setAuxId } = useContext(TableMinimalContext);

  const getData = () => {
    setLoadingData(true);
    const promises = [
      getAllCountries(),
      getAllTypeDocument(),
      getAllGenres(),
      getAllBillingTypes(),
      getAllTypeAccounts(),
      getAllMunicipalities(),
      getAllClientTypes(),
      getAllBusinessUnits(),
      getAllSectors(),
      getAllCargos(),
    ];

    Promise.all(promises).then((values) => {
      setLoadingData(true);
      setSelectData({
        ...selectData,
        countries: values[0].filter((pais) => pais.estado === 1),
        documentTypes: values[1],
        genres: values[2],
        billingTypes: values[3],
        accountTypes: values[4],
        municipalities: values[5],
        clientTypes: values[6],
        businessUnits: values[7],
        cargos: values[9],
      });
      setLoadingData(false);
    });
  };
  const getListPrices = () => {
    getAll(endpoints.listPrices.getAllListPrices).then((data) => {
      let newArray = [];
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idListaPreciosActividad,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          });
        }
      });
      setListPrices(newArray);
    });
  };

  useEffect(() => {
    getData();
    getListPrices();
    setAuxId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    selectData,
    setSelectData,
    loadingData,
    listPrices,
    getListPrices,
  };
}
