

const validateMailAssesor = (e, REGEX, setError) => {

    if (REGEX.test(e.target.value)) {
      setError('');
    } else {
      setError('snackbar.warning.input.mail.no.valid');
    }
  }

export default validateMailAssesor;