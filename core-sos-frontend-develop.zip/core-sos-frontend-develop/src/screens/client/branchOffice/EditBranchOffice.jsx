import React from "react";

const EditBranchOffice = () => {
  return <div>EditBranchOffice</div>;
};

export default EditBranchOffice;
