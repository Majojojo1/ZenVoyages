import React, { useContext, useEffect, useState } from 'react';
// Import Contexts
import { TableMinimalContext, TableMinimalWrapper } from 'context/TableMinimalContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import SelectorMulti from 'common/SelectorMulti';
import { InputFieldResponsive } from 'common/inputs/InputFieldResponsive';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import Table from 'common/minimalTables/Table';
import SelectorSearch from 'common/selects/SelectorSearch';
import { FilterActive } from 'common/validators/FilterActives';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import { ADDRESSREGEX, CCREGEX, NUMBERREGEX, TEXTREGEX, URLREGEX } from 'common/validators/Regex';
import Attachments from 'components/AttachedFiles/Attachments';
import CustomAlert from 'components/CustomAlert';
import { Modal } from 'react-responsive-modal';
import AddAdviser from './adviser/AddAdviser';
import AddBranchOffice from './branchOffice/AddBranchOffice';
// Import Libs
import { Formiz, FormizStep, useForm } from '@formiz/core';
import { isEmail, isPattern } from '@formiz/validations';
import { FormattedMessage } from 'react-intl';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
// Import Services
import { SearchWrapper } from 'context/SearchContext';
import endpoints from 'services/api';
import { getAllBillingTypes } from 'services/api/billingType';
import { addBranchOffice } from 'services/api/branchOffices';
import { getAllBusinessUnits, getUnitByMarket } from 'services/api/businessUnit';
import { getAllCargos } from 'services/api/cargos';
import { getAllClientTypes } from 'services/api/clientType';
import { getAllGenres, getAllTypeAccounts, getAllTypeDocument } from 'services/api/institutions';
import { getAllMarkets, getMarketByCountry } from 'services/api/markets';
import { addItem, getAll } from 'services/api/methods';
import { getAllCountries, getAllMunicipalities, getAllSectors } from 'services/api/zones';
import paths from 'services/paths';
import HandlerChangeMailAssesor from './fields/HandlerChangeMailAsesor';
import useGetClientFormOptionsData from './hooks/useGetClientFormOptionsData';

const MODEL = {
  idTipoDocumentoAsesor: '',
  identificacion: '',
  genero: '',
  nombreAsesor: '',
  idCargo: '',
  emailAsesor: '',
  correoAlternoAsesor: '',
  telefonoAsesor: '',
  telefonoAlternoAsesor: '',
  idMunicipio: '',
  estado: 1,
};


const CreateClient = ({setIsOpenCreateClient}) => {
  return (
    <SearchWrapper>
      <TableMinimalWrapper>
        <CreateClientComponents setIsOpenCreateClient={setIsOpenCreateClient} />
      </TableMinimalWrapper>
    </SearchWrapper>
  );
};

function CreateClientComponents({setIsOpenCreateClient}) {
  const [open, setOpen] = useState(false);
  const { COOKIE_USER } = useAxios();
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const {
    currentDataTable,
    setCurrentDataTable,
    otherCurrentDataTable,
    setOtherCurrentDataTable,
    selectedTable,
    setSelectedTable,
    setAuxId,
    dataTableUnits,
    setDataTableUnits,
  } = useContext(TableMinimalContext);

  const { loading } = useGetData();
  const myForm = useForm();
  const navigate = useNavigate();
  const { formatterText, noFilledContent, newItemCreated, customSB } = useLangv2();

  const { selectData, setSelectData } = useGetClientFormOptionsData();
  const [archivos, setCurrentFiles] = useState([]);
  const [currentBranchOffice, setCurrentBranchOffice] = useState({
    direccion: '',
    datosAdicionales: '',
    observaciones: '',
    estado: 1,
    idCiudadMunicipio: '',
    idSector: '',
  });

  const [loadingData, setLoadingData] = useState(true);

  const [error, setError] = useState('');
  const [altErr, setAltErr] = useState('');

  const titlesTableBranchOffice = [
    formatterText('tab.title.direccion'),
    formatterText('tab.title.adiconaldatos'),
    formatterText('tab.title.observaciones'),
    formatterText('table.title.state'),
    formatterText('table.actions'),
  ];

  const titlesTableAdvisers = [
    formatterText('table.title.advisor.name'),
    formatterText('table.title.advisor.document'),
    formatterText('table.title.advisor.genre'),
    formatterText('table.title.advisor.id'),
    formatterText('table.title.advisor.charge'),
    formatterText('table.title.advisor.mail'),
    formatterText('table.title.advisor.mail.alt'),
    formatterText('table.title.advisor.phone'),
    formatterText('table.title.advisor.phone.alt'),
    formatterText('table.title.state'),
    formatterText('table.actions'),

  ];

  const titlesTableBusinessUnit = [
    formatterText('tab.title.pricelist.name'),
    formatterText('table.actions'),
  ];

  useEffect(() => {
    getData();
    getListPrices();
    setAuxId(null);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAddBusinessUnit = (form) => {
    const value = form.fields?.idUnidadNegocio.value;
    const exist = [];
    for (let i = 0; i < dataTableUnits.length; i++) {
      const current = dataTableUnits[i];
      if (current.idUnidadNegocio === value) {
        exist.push(current);
      }
    }

    if (exist.length === 0) {
      const unitBusiness = [];
      for (let i = 0; i < units.length; i++) {
        const current = units[i];
        if (current.value === value) {
          unitBusiness.push(current);
        }
      }
      const addData = unitBusiness.map((item) => ({
        nombre: item.label,
        idUnidadNegocio: item.value,
      }));
      setDataTableUnits([...dataTableUnits, addData[0]]);
    }
  };

  const closeModal = _ => {
    if(setIsOpenCreateClient instanceof Function)
      setIsOpenCreateClient(false);
    else
      navigate(paths.clients);
  }

  const handleSubmit = (values) => {
    if (dataTableUnits.length == 0) {
      Swal.fire({
        icon: 'warning',
        title: 'Error',
        text: 'Al menos una unidad de negocio es requerida',
      });
    } else {
      const data = {
        clienteDto: {
          idCliente: null,
          idTipoDocumento: {
            idTipoDocumento: values.idTipoDocumento,
          },
          identificacion: values.identificacion.replaceAll(/\s{2,}/gi, ' '),
          nombreRazonSocial: values.nombreRazonSocial.replaceAll(/\s{2,}/gi, ' '),
          idGenero: {
            idGenero: values.idGenero,
          },
          idTipoCliente: {
            idTipoCliente: values.idTipoCliente,
          },
          idMercado: {
            idMercado: values.idMercado,
          },

          idTipoFacturacion: {
            idTipoFacturacion: values.idTipoFacturacion,
          },
          celular: values.celular.replaceAll(/\s{2,}/gi, ' '),
          telefono: values.telefono.replaceAll(/\s{2,}/gi, ' '),
          sitioWeb: values.sitioWeb?.replaceAll(/\s{2,}/gi, ' ') || '',
          estado: 1,
          correo: values.correo.replaceAll(/\s{2,}/gi, ' '),
          usuarioCreacion: COOKIE_USER,
          clienteEspecial: values.clienteEspecial,
        },
        unidadNegocios: dataTableUnits.map((item) => ({
          idUnidadNegocio: item.idUnidadNegocio,
        })),
      };

      postItem(data, values);
    }
  };

  const postItem = (data, values) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.clients.addClient, data)
            .then((res) => {
              associatePrices(res.cliente.idCliente, resolve, reject);
              createBranchOffice(res.cliente, values, resolve, reject);
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.clients),
              });
            })
            .catch((err) => {
              if (err.response?.data?.message) {
                HandleOnError(formatterText(err.response?.data?.message));
              } else {
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.',
                ),);
              }
            })
            .finally(_ => closeModal());
        });
      },
    });
  };

  // associate principal price list
  const associatePrices = (id, res, err) => {
    const BODY = {
      idListaPreciosActividadCliente: null,
      idListaPreciosActividad: {
        idListaPreciosActividad: auxData.idListaPrecios.value,
      },
      principal: 1,
      idCliente: id,
      usuarioCreacion: COOKIE_USER,
    };

    addItem(endpoints.listPriceClient.addListPriceClient, BODY)
      .then((data) => {
        customSB(
          'success',
          'snackbar.success.create.principal.price.list',
          'Se ha asociado la lista de precios principal al cliente',
        );
        associateSecondaryPrices(id, res, err);
      })
      .catch(() => {
        err(
          HandleOnError(
            formatterText('alert.message.failed.general', 'Error al asociar la lista de precios.'),
          ),
        );
      });
  };

  // associates secondary price lists
  const associateSecondaryPrices = (id, resolve, reject) => {
    if (selectValues.length !== 0) {
      const promesas = selectValues.map(
        (item) =>
          new Promise((resl, rej) => {
            let data = {
              idListaPreciosActividadCliente: null,
              idListaPreciosActividad: { idListaPreciosActividad: item.value },
              idCliente: id,
              principal: 0,
              usuarioCreacion: COOKIE_USER,
            };
            addItem(endpoints.listPriceClient.addListPriceClient, data)
              .then((res) => {
                resl(res);
              })
              .catch((err) => {
                rej(err);
              });
          }),
      );
      Promise.all(promesas)
        .then(() => {
          customSB(
            'success',
            'snackbar.success.create.secondary.price.list',
            'Se han asociado la(s) lista(s) de precios secundaria(s) al cliente',
          );
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText(
                'alert.message.confirm.created.general',
                'El registro se ha creado correctamente',
              ),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.clients),
            }),
          );
          uploadFiles(id);
        })
        .catch((err) => {
          if (err.response.status === 412 || err.response.status === 400) {
            HandleOnError(err.response.data);
          } else {
            HandleOnError(
              formatterText(
                'alert.message.failed.general',
                'Error al crear el registro, por favor intente nuevamente.',
              ),
            );
          }
        });
    } else {
      uploadFiles(id);
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
          text: formatterText(
            'alert.message.confirm.created.general',
            'El registro se ha creado correctamente',
          ),
          confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
          allowOutsideClick: false,
          executeFunction: () => console.log('User created', true),
        }),
      );
    }
  };

  const createBranchOffice = (res, values, resolve, reject) => {
    // TODO: verify associations
    if (currentDataTable.length > 0) {
      const promises = currentDataTable.map((item) => {
        const data = {
          idSucursal: null,
          idCliente: {
            idCliente: res.idCliente,
          },
          idDireccion: {
            idDireccion: null,
            idSector: {
              idSector:
                typeof item.idSector === 'string'
                  ? JSON.parse(item.idSector).value
                  : item.idSector.value,
            },
            direccion: item.direccion,
            datosAdicionales: item.datosAdicionales,
            observacion: item.observaciones,
          },
          telefono: values.telefono,
          sitioWeb: values.sitioWeb,
        };

        return addBranchOffice(data);
      });

      Promise.all(promises)
        .then(() => {
          createAdvisor(res, resolve, reject);
          resolve(true);
        })
        .catch((err) => {
          reject(HandleOnError('Error al crear el cliente, por favor intente nuevamente'));
        });
    } else {
      resolve(newItemCreated());
    }
  };

  const createAdvisor = (res, resolve, reject) => {
    const promises = otherCurrentDataTable.map((item) => {
      const data = {
        idAsesor: null,
        idCliente: {
          idCliente: res.idCliente,
        },
        idTipoDocumento: {
          idTipoDocumento:
            typeof item.idTipoDocumentoAsesor === 'string'
              ? JSON.parse(item.idTipoDocumentoAsesor).value
              : item.idTipoDocumentoAsesor.value,
        },
        identificacion: item.identificacion,
        nombres: item.nombreAsesor,
        idGenero: {
          idGenero:
            typeof item.genero === 'string' ? JSON.parse(item.genero).value : item.genero.value,
        },
        idCargo: {
          idCargo:
            typeof item.idCargo === 'string' ? JSON.parse(item.idCargo).value : item.idCargo.value,
        },
        idMunicipio: {
          idMunicipio:
            typeof item.idMunicipio === 'string'
              ? JSON.parse(item.idMunicipio).value
              : item.idMunicipio.value,
        },
        telefono: item.telefonoAsesor,
        telefonoAlterno: item.telefonoAlternoAsesor,
        correo: item.emailAsesor,
        correoAlterno: item.correoAlternoAsesor,
      };

      return addItem(endpoints.advisers.addAdviser, data);
    });

    Promise.all(promises)
      .then((resp) => {
        resolve(true);
        console.log('estos son clientes asesores', resp);
      })
      .catch((err) => {
        reject(HandleOnError('Error al crear el cliente, por favor intente nuevamente'));
      });
  };

  const getData = () => {
    setLoadingData(true);

    const promesas = [
      getAllMarkets(), ///
      getAllTypeDocument(), /////
      getAllGenres(), ///
      getAllBillingTypes(), ///
      getAllTypeAccounts(),
      getAllMunicipalities(), ////
      getAllClientTypes(), ///
      getAllBusinessUnits(), ////
      getAllSectors(),
      getAllCargos(),
      getAllCountries(),
    ];

    Promise.all(promesas).then((values) => {
      setLoadingData(false);
      setSelectData({
        ...selectData,
        documentTypes: values[1],
        markets: [], //FilterActives(values[0]),
        genres: values[2],
        billingTypes: FilterActive(values[3]),
        accountTypes: values[4],
        municipalities: FilterActive(values[5]),
        clientTypes: values[6],
        businessUnits: FilterActive(values[7]),
        cargos: FilterActive(values[9]),
        countries: FilterActive(values[10]),
      });
    });
  };

  const getMarketByIdCountry = (idCountry) => {
    getMarketByCountry(idCountry).then((res) =>
      setSelectData({
        ...selectData,
        markets: FilterActive(res),
      }),
    );
  };

  const AllSectorsForSelect = () => {
    getAll(endpoints.zones.getAllSectors).then((data) => {
      //convert to json the current branch office id
      const idMunicipio = JSON.parse(currentBranchOffice.idCiudadMunicipio).value;
      // create new array
      const newArray = [];
      // iterate response and get only the values that are active
      data.forEach((item) => {
        if (item.estado === 1 && item.idMunicipio.idMunicipio == idMunicipio) {
          newArray.push({
            idSector: item.idSector,
            nombre: item.nombre,
          });
        }
      });
      // set the values of the select
      setSelectData({
        ...selectData,
        sectors: newArray,
      });
    });
  };

  useEffect(() => {
    if (currentBranchOffice.idCiudadMunicipio !== '') {
      AllSectorsForSelect();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentBranchOffice.idCiudadMunicipio]);

  useEffect(() => {
    if (myForm.fields?.idPais?.value !== null && myForm.fields?.idPais?.value !== undefined) {
      getMarketByIdCountry(myForm.fields?.idPais?.value);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myForm.fields?.idPais?.value]);

  //////////////////////////SURCURSAL

  const handleChangeSucursal = (e) => {
    switch (e.target.name) {
      case 'direccion':
        HandleInput(e, ADDRESSREGEX, currentBranchOffice, setCurrentBranchOffice);
        break;

      default:
        HandleInput(e, TEXTREGEX, currentBranchOffice, setCurrentBranchOffice);
        break;
    }
  };

  const handleChangeSelect = (selectedOption) => {
    setCurrentBranchOffice({
      ...currentBranchOffice,
      [selectedOption.target.name]: selectedOption.target.value,
    });
  };

  const handleAddBranchOffice = () => {
    if (
      currentBranchOffice.idCiudadMunicipio !== '' &&
      currentBranchOffice.idSector !== '' &&
      currentBranchOffice.direccion !== ''
    ) {
      if (currentBranchOffice.datosAdicionales === '') {
        setCurrentBranchOffice((prevState) => ({
          ...prevState,
          datosAdicionales: ' ',
        }));
      }

      if (currentBranchOffice.observaciones === '') {
        setCurrentBranchOffice((prevState) => ({
          ...prevState,
          observaciones: ' ',
        }));
      }

      setCurrentDataTable([...currentDataTable, currentBranchOffice]);

      setCurrentBranchOffice({
        direccion: '',
        datosAdicionales: '',
        observaciones: '',
        estado: 1,
        idCiudadMunicipio: currentBranchOffice.idCiudadMunicipio,
        idSector: currentBranchOffice.idSector,
      });
    } else {
      HandleOnError(formatterText('p.label.title.debesCompletarTodosLosCampos'));
    }
  }; 

  const [currentAsesor, setCurrentAsesor] = useState(MODEL);

  const validateRegex = (e, regex) => {
    const { value = '', name } = e.target;

    const val = value.replaceAll(/\s{2,}/gi, ' ');

    if (val.match(regex)) {
      setCurrentAsesor({
        ...currentAsesor,
        [name]: val,
      });
    }
  };
  const handleChangeAsesor = (e) => {
    //REGEX QUE SOLO PERMITA LETRAS Y ESPACIOS
    switch (e.target.name) {
      case 'identificacion':
        validateRegex(e, CCREGEX);
        break;
      case 'nombreAsesor':
        validateRegex(e, TEXTREGEX);
        break;
      case 'telefonoAsesor':
        validateRegex(e, NUMBERREGEX);
        break;
      case 'telefonoAlternoAsesor':
        validateRegex(e, NUMBERREGEX);
        break;

      default:
        setCurrentAsesor({
          ...currentAsesor,
          [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
        });
        break;
    }
  };

  const handleBlurMailAsesor = (e) => {
    if (!error && e.target.value.trim() === '') {
      setError('');
    }
  };

  const handleBlurMailAltAsesor = (e) => {
    if (!altErr && e.target.value.trim() === '') {
      setAltErr('');
    }
  };

  const handleChangeSelectAsesor = (selectedOption) => {
    setCurrentAsesor({
      ...currentAsesor,
      [selectedOption.target.name]: selectedOption.target.value,
    });
  };

  const handleAddAsesor = () => {
    if (
      currentAsesor.idTipoDocumentoAsesor !== '' &&
      currentAsesor.identificacion !== '' &&
      currentAsesor.genero !== '' &&
      currentAsesor.nombreAsesor !== '' &&
      currentAsesor.emailAsesor !== '' &&
      currentAsesor.correoAlternoAsesor !== '' &&
      currentAsesor.telefonoAsesor !== '' &&
      currentAsesor.telefonoAlternoAsesor !== '' &&
      currentAsesor.idMunicipio !== '' &&
      currentAsesor.idCargo !== '' &&
      !error &&
      !altErr
    ) {
      if (currentAsesor.emailAsesor === currentAsesor.correoAlternoAsesor) {
        customSB('warning', 'warning.alert.same.mails');
        return;
      }
      if (currentAsesor.telefonoAsesor === currentAsesor.telefonoAlternoAsesor) {
        customSB('warning', 'warning.alert.same.tlf');
        return;
      }
      setOtherCurrentDataTable([...otherCurrentDataTable, currentAsesor]);
      setCurrentAsesor(MODEL);
    } else {
      noFilledContent();
    }
  };


  const [selectValues, setSelectValues] = useState([]);
  const [selectorValues, setSelectorValues] = useState([]);
  const [listPrices, setListPrices] = useState({});
  const [secondaryPrices, setSecondaryPrices] = useState({});
  const [auxData, setAuxData] = useState({
    idListaPrecios: 0,
  });

  //Resetea los precios secundarios si se modifica el precio principal
  useEffect(() => {
    getSecondaryPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auxData.idListaPrecios]);

  // handler for second prices to update the list and values
  const getSecondaryPrices = () => {
    // Check the number of secondary prices, to reset them
    if (selectValues.length !== 0) {
      let sameList = selectValues.filter((item) => item === auxData.idListaPrecios);
      let exceptList = selectValues.filter((item) => item !== auxData.idListaPrecios);
      // If the parent price is found to be equal to any of the children, it is reset and removes this
      if (sameList.length >= 1) {
        setSecondaryPrices(exceptList);
        setSelectValues(exceptList);
      }
    }
    // If any parent value was selected, display available child prices
    if (auxData.idListaPrecios !== 0) {
      let filter = listPrices.filter((item) => item !== auxData.idListaPrecios);
      setSecondaryPrices(filter);
    }
  };

  // get list prices
  const getListPrices = () => {
    getAll(endpoints.listPrices.getAllListPrices).then((data) => {
      let newArray = [];
      data.forEach((item) => {
        if (item.estado === 1) {
          newArray.push({
            value: item.idListaPreciosActividad,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          });
        }
      });
      setListPrices(newArray);
    });
  };

  const handleChangeMulti = (val) => {
    setSelectValues(val);
  };

  const uploadFiles = (id) => {
    return new Promise((resolve, reject) => {
      if (archivos.length > 0) {
        addItem(endpoints.UploadFiles.save, {
          idOrigen: id,
          idTipoOrigenArchivo: 7, // 7 = Clientes
          archivos,
        })
          .then((response) => {
            resolve(
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.associations.general',
                  'Las asociaciones se crearon correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.clients),
              }),
            );
          })
          .catch((err) => {
            reject(err);
          });
      } else {
        resolve(
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText(
              'alert.message.associations.general',
              'Las asociaciones se crearon correctamente',
            ),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.clients),
          }),
        );
      }
    });
  };

  const [units, setUnits] = useState([]);

  useEffect(() => {
    if (myForm.fields?.idMercado?.value !== null && myForm.fields?.idMercado?.value !== undefined) {
      setClearValue(false);
      let result = [];
      getUnitByMarket(myForm.fields.idMercado.value)
        .then((resp) => {
          resp.map((item) => result.push({ label: item.nombre, value: item.idUnidadNegocio }));
          setClearValue(true);
        })
        .catch(() => {
          HandleOnError('No hay unidades asociadas');
        });
      setUnits(result);
    }
  }, [myForm.fields?.idMercado?.value]);

  // aux val to clear the value of the select
  const [clearValue, setClearValue] = useState(true);

  return (
    <div className="centered-form">
      <Formiz onValidSubmit={handleSubmit} connect={myForm}>
        <form
          noValidate
          onSubmit={myForm.submit}
          className="container-wrapForm"
          style={{ minHeight: '16rem' }}
        >
          <div className="new-container-wrapForm__tabs">
            {myForm.steps.map((step, index) => (
              <button
                key={step.name}
                className={`new-tab-option ${step.name === myForm.currentStep.name ? 'is-active' : ''
                  }`}
                type="button"
                onClick={() => {
                  setSelectedTable(index);

                  myForm.goToStep(step.name);
                }}
              >
                {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                {formatterText(step.label)}
              </button>
            ))}
          </div>
          <div className="container-wrapForm-content">
            {/* 1: General customer information */}
            <FormizStep
              name="step1"
              label='p.information.customer.general'

            >
              <div className="title-section">
                <span className="circle-form">
                  <span>1</span>
                </span>
                <h2>
                  <FormattedMessage
                    id="p.general.data.customer"
                    defaultMessage="Datos generales del cliente"
                  />
                </h2>
              </div>
              <section className="grid-container-3c">
                <InputSelectorResponsive
                  type="text"
                  name="idTipoDocumento"
                  placeholder={formatterText('p.document.type', 'Tipo de documento')}
                  labelText={formatterText('p.document.type', 'Tipo de documento')}
                  required={formatterText('p.label.title.tipoDocumentoRequerido')}
                  data={
                    !!selectData.documentTypes &&
                    selectData.documentTypes.map((item) => {
                      let docLabel = `${item.nombre} - ${item.abreviatura}`;
                      return {
                        label: docLabel,
                        value: item.idTipoDocumento,
                      };
                    })
                  }
                  isLoading={loadingData}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="identificacion"
                  labelText={formatterText('p.id.identification', 'Identificación*')}
                  placeholder={formatterText('text.ID', 'Identificación')}
                  validateInput="integer"
                  required={formatterText('p.label.title.identificacionRequerida')}
                  styleName="input-default-3c"
                />
                <InputSelectorResponsive
                  type="text"
                  name="idGenero"
                  labelText={formatterText('input.placeholder.genre', 'Género')}
                  placeholder={formatterText('input.placeholder.genre', 'Género')}
                  required={formatterText('p.label.title.generoRequerido')}
                  data={
                    !!selectData.genres &&
                    selectData.genres.map((item) => ({
                      label: `${item.nombre} - ${item.abreviatura}`,
                      value: item.idGenero,
                    }))
                  }
                  isLoading={loadingData}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="nombreRazonSocial"
                  labelText={formatterText('p.name.social.reason', 'Nombres o razón social*')}
                  placeholder={formatterText('p.name.social.reason', 'Nombres o razón social*')}
                  validateInput="text"
                  required={formatterText('p.label.title.nombreRazonSocialRequerido')}
                  styleName="input-default-3c"
                />
                <InputSelectorResponsive
                  type="text"
                  name="idTipoCliente"
                  placeholder={formatterText('p.client.type', 'Tipo de Cliente*')}
                  labelText={formatterText('p.client.type', 'Tipo de Cliente*')}                  
                  required={formatterText('p.label.title.tipoClienteRequerido')}
                  data={
                    !!selectData.clientTypes &&
                    selectData.clientTypes.map((item) => {
                      let docLabel = `${item.nombre}`;
                      return {
                        label: docLabel,
                        value: item.idTipoCliente,
                      };
                    })
                  }
                  isLoading={loadingData}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="correo"
                  labelText={formatterText('table.title.email', 'Correo electrónico')}
                  placeholder={formatterText('table.title.email', 'Correo electrónico')}
                  validateInput="mail"
                  required={formatterText('p.label.title.correoElectronicoRequerido')}
                  validations={[
                    {
                      rule: isEmail(),
                      message: 'El correo no es válido',
                    },
                  ]}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="celular"
                  labelText={formatterText('p.movile.phone', 'Celular*')}
                  placeholder={formatterText('p.movile.phone', 'Celular*')}
                  validateInput="integer"
                  required={formatterText('p.label.title.celularRequerido')}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="telefono"
                  labelText={formatterText('table.title.phone', 'Teléfono*')}
                  placeholder={formatterText('table.title.phone', 'Teléfono*')}
                  validateInput="integer"
                  required={formatterText('p.label.title.telefonoRequerido')}
                  styleName="input-default-3c"
                />
                <InputFieldResponsive
                  type="text"
                  name="sitioWeb"
                  labelText={formatterText('table.title.website', 'Sitio web')}
                  placeholder={formatterText('table.title.website', 'Sitio web')}
                  validateInput="web"
                  styleName="input-default-3c"
                  validations={[
                    {
                      rule: isPattern(URLREGEX),
                      message: 'La url no es válida',
                    },
                  ]}
                />
                <InputSelectorResponsive
                  type="text"
                  name="clienteEspecial"
                  placeholder={formatterText('p.especial.customer', 'Cliente especial')}
                  labelText={formatterText('p.especial.customer', 'Cliente especial')}
                  required={formatterText('p.label.title.tipoClienteRequerido2')}
                  data={[
                    {
                      label: 'Sí',
                      value: 1,
                    },
                    {
                      label: 'No',
                      value: 2,
                    },
                  ]}
                  isLoading={loading}
                  styleName="input-default-3c"
                />
              </section>
            </FormizStep>
            {/* 2: Client associations */}
            <FormizStep
              name="step2"
              label='p.client.asociate'
            >
              <div className="title-section">
                <span className="circle-form">
                  <span>2</span>
                </span>
                <h2>
                  <FormattedMessage
                    id="p.client.asociate"
                    defaultMessage="Asociaciones del cliente"
                  />
                </h2>
              </div>

              <div>
                <section className="grid-container-3c">
                  <InputSelectorResponsive
                    type="text"
                    name="idPais"
                    labelText={<FormattedMessage id="p.country" defaultMessage="Pais" />}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    data={
                      selectData?.countries?.map(({ nombrePais, idPais }) => ({
                        label: nombrePais,
                        value: idPais,
                      })) ?? []
                    }
                    isLoading={loadingData}
                  />

                  <InputSelectorResponsive
                    type="text"
                    name="idMercado"
                    labelText={<FormattedMessage id="p.market" defaultMessage="Mercado" />}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    required={formatterText('p.market.required')}
                    data={
                      !!selectData.markets &&
                      selectData?.markets.map((item) => {
                        let docLabel = `${item.nombre}`;
                        return {
                          label: docLabel,
                          value: item.idMercado,
                        };
                      })
                    }
                    isLoading={loadingData}
                  />
                  <InputSelectorResponsive
                    type="text"
                    name="idTipoFacturacion"
                    labelText={formatterText('p.billing.type', 'Tipo de facturación')}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    required={formatterText('p.billing.required')}
                    data={
                      !!selectData.billingTypes &&
                      selectData.billingTypes.map((item) => {
                        let docLabel = `${item.nombre}`;
                        return {
                          label: docLabel,
                          value: item.idTipoFacturacion,
                        };
                      })
                    }
                    isLoading={loadingData}
                  />
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="p.price.list"
                        defaultMessage="Lista de precios primaria"
                      />
                    </span>
                    <section className="w100-container">
                      <SelectorSearch
                        name="idListaPrecios"
                        data={listPrices}
                        placeholder={
                          <FormattedMessage
                            id="input.placeholder.select"
                            defaultMessage="Selecione una opción"
                          />
                        }
                        dataValue={auxData.idListaPrecios}
                        setterFunction={setAuxData}
                        isLoading={loading}
                        selectValue={selectorValues}
                        isRequired={false}
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="p.price.list.second"
                        defaultMessage="Lista de precios secundaria"
                      />
                    </span>
                    <section className="w100-container">
                      <SelectorMulti
                        data={secondaryPrices}
                        isLoading={loading}
                        dataValue={selectValues}
                        setterFunction={handleChangeMulti}
                      />
                    </section>
                  </label>
                </section>
              </div>
              <div className="title-section">
                <span className="circle-form">
                  <span>2.1</span>
                </span>
                <h2>
                  <FormattedMessage
                    id="p.add.bussines.unit"
                    defaultMessage="Agregar Unidades de Negocio"
                  />
                </h2>
              </div>
              <div>
                <label>
                  <section className="form-responsive-container-buttons">
                    {clearValue && (
                      <InputSelectorResponsive
                        type="text"
                        name="idUnidadNegocio"
                        labelText={formatterText('p.unit.bussines', 'Unidad de negocio')}
                        placeholder={
                          <FormattedMessage
                            id="input.placeholder.select"
                            defaultMessage="Selecione una opción"
                          />
                        }
                        required={formatterText('p.label.title.unidadNegocioRequerida')}
                        data={units}
                        isLoading={loadingData}
                      />
                    )}
                    <label className="wrapForm w100-container">
                      <input
                        onClick={() => handleAddBusinessUnit(myForm)}
                        type="button"
                        className="btn-primary margin-auto"
                        value={formatterText(
                          'p.add.bussines.unit.single',
                          'Agregar Unidad de negocio',
                        )}
                      />
                    </label>
                  </section>
                  <section>
                    <label className="wrapForm w100-container">
                      <span className="wrap-form-title">
                        <FormattedMessage
                          id="p.associated.bussines"
                          defaultMessage="Unidades de negocio asociadas"
                        />
                      </span>
                      <Table
                        titles={titlesTableBusinessUnit}
                        data={dataTableUnits}
                        type="businessByClient"
                        max={true}
                        handleOpen={handleOpen}
                      />
                    </label>
                  </section>
                </label>
              </div>

              <div>
                <div className="title-section">
                  <span className="circle-form">
                    <span>2.2</span>
                  </span>
                  <h2>
                    <FormattedMessage id="p.add.branch" defaultMessage="Agregar sucursal" />
                  </h2>
                </div>
                <section className="wrapForm w100-container">
                  <Table
                    titles={titlesTableBranchOffice}
                    data={currentDataTable}
                    type="sucursales"
                    max={true}
                    handleOpen={handleOpen}
                  />
                  <section
                    className="grid-container-2c"
                    style={{
                      width: '100%',
                    }}
                  >
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage
                          id="p.municipiociudad"
                          defaultMessage="Municipio o ciudad"
                        />
                      </span>
                      <section className="w100-container">
                        <select
                          name="idCiudadMunicipio"
                          id="idCiudadMunicipio"
                          className="input-label-style"
                          onChange={handleChangeSelect}
                        >
                          <option value="">
                            <FormattedMessage
                              id="p.select.option"
                              defaultMessage="Seleccione una opción"
                            />
                          </option>
                          {!!selectData.municipalities &&
                            selectData.municipalities.map((item) => (
                              <option
                                key={item.idMunicipio}
                                value={JSON.stringify({
                                  label: item.nombre,
                                  value: item.idMunicipio,
                                })}
                              >
                                {item.nombre}
                              </option>
                            ))}
                        </select>
                      </section>
                    </label>
                    <label className="d-flex">
                      <span className="text-inline">
                        <FormattedMessage id="tab.title.sector" defaultMessage="Sector" />
                      </span>
                      <section className="w100-container">
                        <select
                          name="idSector"
                          id="idSector"
                          className="input-label-style"
                          onChange={handleChangeSelect}
                        >
                          <option value="">
                            <FormattedMessage
                              id="p.select.option"
                              defaultMessage="Seleccione una opción"
                            />
                          </option>
                          {!!selectData.sectors &&
                            selectData.sectors.map((item) => (
                              <option
                                key={item.idSector}
                                value={JSON.stringify({
                                  label: item.nombre,
                                  value: item.idSector,
                                })}
                              >
                                {item.nombre}
                              </option>
                            ))}
                        </select>
                      </section>
                    </label>
                  </section>
                  <label>
                    <span className="warpForm-text">
                      <formatterText id="tab.title.direccion" defaultMessage="Direción completa" />
                    </span>
                    <input
                      type="text"
                      name="direccion"
                      id="direccion"
                      placeholder={formatterText('tab.title.direccion', 'Dirección completa')}
                      value={currentBranchOffice.direccion || ''}
                      required={formatterText('p.label.title.direccionRequerida')}
                      className="input-primary-wrap-large"
                      onChange={handleChangeSucursal}
                    />
                  </label>
                  <label>
                    <span className="warpForm-text">
                      <FormattedMessage
                        id="tab.title.adiconaldatos"
                        defaultMessage="Datos adicionales"
                      />
                    </span>
                    <input
                      name="datosAdicionales"
                      id="datosAdicionales"
                      placeholder={formatterText(
                        'p.example.name.ofi',
                        'Ej: Número de local, oficina, aparatemento, peso, manzana',
                      )}
                      type="text"
                      value={currentBranchOffice.datosAdicionales || ''}
                      required={formatterText('p.label.title.datosAdicionalesRequeridos')}
                      className="input-primary-wrap-large"
                      onChange={handleChangeSucursal}
                    />
                  </label>
                  <label>
                    <span className="warpForm-text">
                      <FormattedMessage
                        id="tab.title.observaciones"
                        defaultMessage="Observaciones"
                      />
                    </span>
                    <input
                      name="observaciones"
                      id="observaciones"
                      value={currentBranchOffice.observaciones || ''}
                      placeholder={formatterText('p.ej.example.observ', 'Ej: Observaciones')}
                      type="text"
                      required={formatterText('p.label.title.observacionesRequeridas')}
                      className="input-primary-wrap-large"
                      onChange={handleChangeSucursal}
                    />
                  </label>
                  <input
                    onClick={handleAddBranchOffice}
                    type="button"
                    className="btn-primary margin-auto"
                    value={formatterText('p.add.branch', 'Agregar sucursal')}
                  />
                </section>
              </div>
            </FormizStep>
            {/* 3: Client advisors */}
            <FormizStep isEnabled={true} name="step3" label="p.client.adviser">
              <div className="title-section">
                <span className="circle-form">
                  <span>3</span>
                </span>
                <h2>
                  <FormattedMessage id="p.client.adviser" defaultMessage="Asesores del cliente" />
                </h2>
              </div>

              <section
                style={{
                  width: '95%',
                  margin: '0 auto',
                }}
              >
                <Table
                  type="asesores"
                  titles={titlesTableAdvisers}
                  data={otherCurrentDataTable}
                  max={true}
                  handleOpen={handleOpen}
                />
                <div className="title-section">
                  <span className="circle-form">
                    <span></span>
                  </span>
                  <h2>
                    <FormattedMessage id="p.add.client.adviser" defaultMessage="Agregar asesor" />
                  </h2>
                </div>

                <section
                  className="grid-container-2c sm-gap"
                  style={{
                    width: '100%',
                  }}
                >
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="p.document.type" defaultMessage="Tipo de documento" />
                    </span>
                    <section className="w100-container">
                      <select
                        name="idTipoDocumentoAsesor"
                        id="idTipoDocumentoAsesor"
                        className="input-label-style"
                        onChange={handleChangeSelectAsesor}
                      >
                        <option value="">
                          <FormattedMessage
                            id="p.select.option"
                            defaultMessage="Seleccione una opción"
                          />
                        </option>
                        {!!selectData.documentTypes &&
                          selectData.documentTypes.map((item) => (
                            <option
                              key={item.idTipoDocumento}
                              value={JSON.stringify({
                                label: `${item.nombre} - ${item.abreviatura}`,
                                value: item.idTipoDocumento,
                              })}
                            >
                              {`${item.nombre} - ${item.abreviatura}`}
                            </option>
                          ))}
                      </select>
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="text.ID" defaultMessage="Identificación" />
                    </span>
                    <section className="w100-container">
                      <input
                        type="text"
                        name="identificacion"
                        id="identificacion"
                        placeholder={formatterText('text.ID', 'Identificación')}
                        value={currentAsesor.identificacion || ''}
                        required={formatterText('p.label.title.identificacionRequerida')}
                        onChange={handleChangeAsesor}
                        className="input-default-3c"
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="input.placeholder.genre" defaultMessage="Género" />
                    </span>
                    <section className="w100-container">
                      <select
                        name="genero"
                        id="genero"
                        className="input-label-style"
                        onChange={handleChangeSelectAsesor}
                      >
                        <option value="">
                          <FormattedMessage
                            id="p.select.option"
                            defaultMessage="Seleccione una opción"
                          />
                        </option>
                        {!!selectData.genres &&
                          selectData.genres.map((item) => (
                            <option
                              key={item.idGenero}
                              value={JSON.stringify({
                                label: `${item.nombre} - ${item.abreviatura}`,
                                value: item.idGenero,
                              })}
                            >
                              {`${item.nombre} - ${item.abreviatura}`}
                            </option>
                          ))}
                      </select>
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="table.title.full.name"
                        defaultMessage="Nombre completo"
                      />
                    </span>
                    <section className="w100-container">
                      <input
                        type="text"
                        name="nombreAsesor"
                        id="nombreAsesor"
                        placeholder={formatterText('table.title.full.name', 'Nombre completo')}
                        value={currentAsesor.nombreAsesor || ''}
                        required={formatterText('p.label.title.nombreCompletoRequerido')}
                        onChange={handleChangeAsesor}
                        className="input-default-3c"
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="table.title.position" defaultMessage="Cargo" />
                    </span>
                    <section className="w100-container">
                      <select
                        name="idCargo"
                        id="idCargo"
                        className="input-label-style"
                        onChange={handleChangeSelectAsesor}
                      >
                        <option value="">
                          <FormattedMessage
                            id="p.select.option"
                            defaultMessage="Seleccione una opción"
                          />
                        </option>
                        {!!selectData.cargos &&
                          selectData.cargos.map((item) => (
                            <option
                              key={item.idCargo}
                              value={JSON.stringify({
                                label: item.nombre,
                                value: item.idCargo,
                              })}
                            >
                              {item.nombre}
                            </option>
                          ))}
                      </select>
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="p.correo" defaultMessage="Correo" />
                    </span>
                    <section className="w100-container">
                      <input
                        type="email"
                        name="emailAsesor"
                        id="emailAsesor"
                        placeholder={formatterText('p.correo')}
                        value={currentAsesor.emailAsesor || ''}
                        onChange={(e) =>
                          HandlerChangeMailAssesor(e, currentAsesor, setCurrentAsesor, setError)
                        }
                        onBlur={handleBlurMailAsesor}
                        className="input-default-3c"
                      />
                      {error && <div className="error-msg">{formatterText(error)}</div>}
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="p.correoalterno" defaultMessage="Correo alterno" />
                    </span>
                    <section className="w100-container">
                      <input
                        type="email"
                        name="correoAlternoAsesor"
                        id="correoAlternoAsesor"
                        placeholder={formatterText('p.correoalterno', 'Correo alterno')}
                        value={currentAsesor.correoAlternoAsesor || ''}
                        onChange={(e) =>
                          HandlerChangeMailAssesor(e, currentAsesor, setCurrentAsesor, setAltErr)
                        }
                        onBlur={handleBlurMailAltAsesor}
                        className="input-default-3c"
                      />
                      {altErr && <div className="error-msg">{formatterText(altErr)}</div>}
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="table.title.phone" defaultMessage="Teléfono*" />
                    </span>
                    <section className="w100-container">
                      <input
                        type="text"
                        name="telefonoAsesor"
                        id="telefonoAsesor"
                        placeholder={formatterText('table.title.phone', 'Teléfono')}
                        value={currentAsesor.telefonoAsesor || ''}
                        required={formatterText('p.label.title.telefonoRequerido')}
                        onChange={handleChangeAsesor}
                        className="input-default-3c"
                      />
                    </section>
                  </label>

                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage id="p.alt.phone" defaultMessage="Teléfono alterno" />
                    </span>
                    <section className="w100-container">
                      <input
                        type="text"
                        name="telefonoAlternoAsesor"
                        id="telefonoAlternoAsesor"
                        placeholder={formatterText('p.alt.phone', 'Teléfono alterno')}
                        value={currentAsesor.telefonoAlternoAsesor || ''}
                        required={formatterText('p.label.title.telefonoAlternoRequerido')}
                        onChange={handleChangeAsesor}
                        className="input-default-3c"
                      />
                    </section>
                  </label>
                  <label className="d-flex">
                    <span className="text-inline">
                      <FormattedMessage
                        id="p.city.residence"
                        defaultMessage="Ciudad de residencia"
                      />
                    </span>
                    <section className="w100-container">
                      <select
                        name="idMunicipio"
                        id="idMunicipio"
                        className="input-label-style"
                        onChange={handleChangeSelectAsesor}
                      >
                        <option value="">
                          <FormattedMessage
                            id="p.select.option"
                            defaultMessage="Seleccione una opción"
                          />
                        </option>
                        {!!selectData.municipalities &&
                          selectData.municipalities.map((item) => (
                            <option
                              key={item.idMunicipio}
                              value={JSON.stringify({
                                label: item.nombre,
                                value: item.idMunicipio,
                              })}
                            >
                              {item.nombre}
                            </option>
                          ))}
                      </select>
                    </section>
                  </label>
                </section>
              </section>

              <section className="form-responsive-container-buttons">
                <input
                  onClick={handleAddAsesor}
                  type="button"
                  className="btn-primary"
                  value={formatterText('p.add.client.adviser', 'Agregar asesor')}
                />
              </section>
            </FormizStep>
            {/* 4: Attachment files */}
            <FormizStep
              name="step4"
              label='tab.title.attached.data'
            >
              <Attachments
                currentFiles={archivos}
                setCurrentFiles={setCurrentFiles}
                isEdited={false}
                type={1}
                showParameters={true}
              />
            </FormizStep>
            {/* btn saves */}
            <section className="form-responsive-container-buttons">
              <button type="submit" className="btn-primary">
                <FormattedMessage
                  id="alert.button.confirm.general"
                  defaultMessage="Guardar cambios"
                />
              </button>
              <button className="input-cancel" onClick={() => closeModal()}>
                {formatterText('btn.cancel')}
              </button>
            </section>
          </div>
        </form>
      </Formiz>
      {/* Modal BranchOffice */}
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        {selectedTable === 1 ? (
          <AddBranchOffice onClose={handleClose} />
        ) : (
          <AddAdviser onClose={handleClose} />
        )}
      </Modal>
    </div>
  );
}

export default CreateClient;
