import { FormattedMessage } from "react-intl";

export const buildMarketPlaceholder = ({ selectedCountryId, markets }) => {
  if (!selectedCountryId) {
    return (
      <FormattedMessage
        id="input.placeholder.select.market.no.country"
        defaultMessage="Seleccione un país"
      />
    );
  }
  if (markets.length === 0) {
    return (
      <FormattedMessage
        id="input.placeholder.select.country.no.markets"
        defaultMessage="El país seleccionado no tiene mercados"
      />
    );
  }

  return (
    <FormattedMessage
      id="input.placeholder.select"
      defaultMessage="Selecione una opción"
    />
  );
};