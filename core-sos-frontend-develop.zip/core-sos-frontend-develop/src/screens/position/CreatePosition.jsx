import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { CODEREGEX, TEXTREGEX } from 'common/validators/Regex';
import CustomAlert from 'components/CustomAlert';
import useLangv2 from 'hooks/useLangv2';
import Cargo from 'models/Cargo';
import React, { useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { useNavigate } from 'react-router-dom';
import { addCargo } from 'services/api/cargos';
import paths from 'services/paths';
import Swal from 'sweetalert2';

export default function CreatePosition() {
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new Cargo());

  // use Hook of language v2
  const { formatterText } = useLangv2();

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCode = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, CODEREGEX, formData, setFormData);
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.create.general', 'Se va a crear un nuevo registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText:  formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addCargo(formData)
            .then((response) => {
              CustomAlert('confirm_msg', {
                icon: 'success',
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.created.general',
                  'El registro se ha creado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.positions),
              });
            })
            .catch((err) => {
              if (err.response.status === 412) {
                HandleOnError(
                  formatterText('alert.message.code.error.general', 'El código ya existe'),
                );
              } else {
                HandleOnError(
                  formatterText(
                    'alert.message.failed.general',
                    'Error al crear el cargo, intenta de nuevo.',
                  ),
                );
              }
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.position.name" defaultMessage="Nombre cargo" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText('input.placeholder.position.name', 'Nombre del cargo')}
            maxLength="25"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
          </h3>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              'input.placeholder.position.description',
              'Descripción del cargo',
            )}
            maxLength="200"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleCode}
            placeholder={formatterText('input.placeholder.position.code', 'Código del cargo')}
            maxLength="45"
            required
          />
        </section>
      </section>

      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.save.changes" defaultMessage="Guardar cambios" />
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.positions)}>
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
