import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { TEXTREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
import useLangv2 from "hooks/useLangv2";
import Cookie from "js-cookie";
import Cargo from "models/Cargo";
import React, { useEffect, useState } from "react";
import { FormattedMessage } from "react-intl";
import { useNavigate, useParams } from "react-router-dom";
import { getCargoById, updateCargo } from "services/api/cargos";
import paths from "services/paths";
import Swal from "sweetalert2";

export default function UpdatePosition() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Datos de un formulario
  const [formData, setFormData] = useState(new Cargo());
  // toggle state
  const [active, setActive] = useState(false);
  // use Hook of language v2
  const { formatterText } = useLangv2();

  useEffect(() => {
    getDataCargoById();
  }, []);

  const getDataCargoById = () => {
    getCargoById(id)
      .then((res) => {
        setFormData(res);
        setActive(res.estado === 1);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    HandleInput(e, TEXTREGEX, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCode = (e) => {
    const example = e;
    example.target.value = e.target.value.toLowerCase();
    HandleInput(example, TEXTREGEX, formData, setFormData);
  };

  // This function sets the form value by the onChange of the input
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      estado: active ? "1" : "0",
      usuarioModificacion: Cookie.get("idUsuario"),
    };

    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText:  formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateCargo(data)
            .then((response) => {
              CustomAlert("confirm_msg", {
                icon: "success",
                title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                text: formatterText(
                  'alert.message.confirm.updated.general',
                  'El registro se ha actualizado correctamente',
                ),
                confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                allowOutsideClick: false,
                executeFunction: () => navigate(paths.positions),
              });
            })
            .catch((err) => {
              if (err.response.status === 412) {
                HandleOnError(formatterText(
                  'alert.message.code.error.general',
                  'El código ya existe, por favor ingrese uno distinto',
                ),
                );
               
                console.log(err.response.data);
              } else {
                console.log("error");
                HandleOnError(formatterText(
                  'snackbar.error.process.failed.general',
                  'Error al realizar el proceso. Intentalo en otro momento.'
                ),
                );
              }

              console.log(err);
            });
        });
      },
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="form-responsive-container-information">
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage
              id="table.title.position.name"
              defaultMessage="Nombre cargo"
            />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleText}
            placeholder={formatterText(
              "input.placeholder.position.name",
              "Nombre del cargo",
            )}
            maxLength="25"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage
              id="table.title.description"
              defaultMessage="Descripción"
            />
          </h3>
          <textarea
            className="input-textarea-sm"
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handlerTextDescription}
            placeholder={formatterText(
              "input.placeholder.position.description",
              "Descripción del cargo",
            )}
            maxLength="200"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary"
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleCode}
            placeholder={formatterText(
              "input.placeholder.position.code",
              "Código del cargo",
            )}
            maxLength="45"
            required
          />
        </section>
        <section className="form-responsive-information__option">
          <h3 className="p-styles">
            <FormattedMessage id="table.title.state" defaultMessage="Estado" />
          </h3>
          <label className="form-responsive-label">
            <p className="form-responsive-toggle">
              {active
                ? formatterText("p.active", "Activo")
                : formatterText("p.unActive", "No activo")}
            </p>
            <label className="switch">
              <input
                checked={active ? true : false}
                onChange={() => {
                  setActive(!active);
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </label>
        </section>
      </section>
      <section className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage
            id="btn.save.changes"
            defaultMessage="Guardar cambios"
          />
        </button>
        <button
          className="input-cancel"
          onClick={() => navigate(paths.positions)}
        >
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </section>
    </form>
  );
}
