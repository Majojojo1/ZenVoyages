import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import BtnActions from 'common/FixedDynamicTable/BtnActions';
import FixedDynamicTable from 'common/FixedDynamicTable/FixedDynamicTable';
// Mui Cell row style
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
// Import libs
import SortData from 'components/utils/SortData';
import { FormattedMessage } from 'react-intl';
// Import services
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { usePermissionContext } from 'context/PermissionContext';
import endpoints from 'services/api';
import { deleteItem, getAll, updateItem } from 'services/api/methods';
import paths from 'services/paths';

const Position = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <PositionComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

function PositionComponent() {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();
  // useContext de búsqueda
  const { setDataTable } = useSeachContext();

  // Call context TableMinimalContext
  const { setCurrentDataTable, setResultsTableSearch } =
    useContext(TableMinimalContext);

  const { formatterText } = useLangv2();

  // titulos de la tabla
  const titles = [
    formatterText('table.title.position.name', 'Nombre cargo'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const { permissionsAccess, permittedActions, permissions } =
    usePermissionContext();

  const permissionsAccessPosition = () => {
    permissionsAccess(MODULES_NAME.positions);
  };

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);
    getAll(endpoints.cargos.getAllCargos)
      .then((data) => {
        // Resolve bug
        // setDataTable([]);
        let newArray = [];
        // En dado de poner fechaModificacion formatear la fecha
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortData(newArray, 'asc');
        setCurrentDataTable(sortedArray);
        setResultsTableSearch(sortedArray);
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    return new Promise((resolve, reject) => {
      deleteItem(endpoints.cargos.deleteCargo, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => handleStructureItems(newArray, item));
          const sortedArray = SortData(newArray, 'asc');
          setDataTable(sortedArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleEditStateItem = (body) => {
    return new Promise((resolve, reject) => {
      updateItem(endpoints.cargos.updateCargo, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
  };

  const handleStructureItems = (newArray, item) => {
    let { nombre, descripcion, codigo, estado } = item;
    newArray.push({
      id: item.idCargo,
      nombre,
      descripcion,
      codigo,
      estado,
      // objeto: { ...item },
    });
  };

  const DisplayRow = ({
    item,
    i, // index
  }) => {
    return (
      <TableRow key={i}>
        <TableCell>{item.nombre}</TableCell>
        <TableCell>{item.descripcion}</TableCell>
        <TableCell>{item.codigo}</TableCell>
        <TableCell>{item.estado}</TableCell>
        <TableCell>
          <BtnActions
            row={item}
            canModify={permittedActions.editar}
            canDelete={permittedActions.eliminar}
            handleEdit={handleEditStateItem}
            handleDelete={handleDeleteItem}
            setDialog={setDialog}
          />
        </TableCell>
      </TableRow>
    );
  };

  const [dialog, setDialog] = useState({
    text: '',
    active: false,
    function: null,
  });

  const closeDialog = () => {
    setDialog({ ...dialog, active: false });
  };

  useEffect(() => {
    permissionsAccessPosition();
  }, [permissions]);

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <>
      {!loading ? (
        <section className="table-container">
          {permittedActions.consultar && (
            <FormattedMessage id="table.name.search.positions" defaultMessage="Cargos">
              {(placeholder) => (
                <FixedDynamicTable
                  titles={titles}
                  labelTable={placeholder}
                  canSearch={true}
                  DisplayRow={DisplayRow}
                  dialog={dialog}
                  setDialog={setDialog}
                  closeDialog={closeDialog}
                  canCreate={crear}
                  pathCreate={paths.createPositions}
                  textCreate="Crear Cargos"
                />
              )}
            </FormattedMessage>
          )}
        </section>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
}

export default Position;
