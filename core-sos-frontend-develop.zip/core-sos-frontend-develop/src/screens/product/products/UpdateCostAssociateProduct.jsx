import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import { useParams } from 'react-router-dom';
// Import Components
import Selector from 'common/selects/Selector';
// Import de services
import currencyFormat from 'common/utils/currencyFormat';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import Cookie from 'js-cookie';
import endpoints from 'services/api';
import { getAll, getItemById, updateItem } from 'services/api/methods';

export default function UpdateCostAssociateProduct({
  dataUnits,
  dataProviders,
  onClose,
  data,
  costoTabla,
  getDataMiniTable,
}) {

  const { modalData, setResultsTableSearch, currentDataTable, setCurrentDataTable, } =
    useContext(TableMinimalContext);

  const formatCurrencyFromModal = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1]}`;
    }

    return formattedValue;
  };

  const formatCurrencyFromModalToTable = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '')}`;

    if (parts.length > 1) {
      formattedValue += `.${parts[1].slice(0, 2)}`;
    }

    return formattedValue;
  };
  const { loading, toggleLoading } = useGetData();
  const { formatterText } = useLangv2();


  const [selectedSearch, setSearchSelected] = useState([
    {
      proveedor: [],
      unidadMedida: [],
      subCategoriasProducto: [],
      tipoMonedas: [],
    },
  ]);
  const [costoModal, setCostoModal] = useState('');
  const [ivaModal, setIvaModal] = useState('');
  const [currectCostProduct, setCurrectCostProduct] = useState({
    idPrecioProductoProveedor: '',
    idProveedor: '',
    label_idProveedor: '',
    idUnidadMedida: '',
    label_idUnidadMedida: '',
    idProducto: '',
    costo: '',
    iva: '',
    idMoneda: '',
    label_idMoneda: '',
  });
  // get id from url
  const { id } = useParams();
  const { errorProcess, customSB } = useLangv2();

  useEffect(() => {
    getMonedas();
    getData(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getData = (id) => {
    getItemById(endpoints.costProductProvider.getCostProductProviderByProduct, id)
      .then((data) => {
        let aux = data.map((item) => {
          return {
            idPrecioProductoProveedor: item.idPrecioProductoProveedor,
            idProveedor: {
              label: `${item.idProveedor.nombreRazonSocial} - ${item.idProveedor.identificacion}`,
              value: item.idProveedor.idProveedor,
            },
            idUnidadMedida: {
              label: `${item.idUnidadMedida.descripcion} - ${item.idUnidadMedida.abreviatura}`,
              value: item.idUnidadMedida.idUnidadMedida,
            },
            costo: currencyFormat(item.costo),
            idMoneda: item.idMoneda
              ? {
                label: `${item.idMoneda.nombre} - ${item.idMoneda.codigo}`,
                value: item.idMoneda.idMoneda,
              }
              : null,
            iva: item.iva,
          };
        });
        setCurrentDataTable(aux);
        setResultsTableSearch(aux);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const [auxData, setAuxData] = useState({
    idProveedor: 0,
    idUnidadMedida: 0,
    idMoneda: 0,
  });

  // Setea los valores del select
  const [selectorValues, setSelectorValues] = useState([]);
  //  create useEffect clean function
  useEffect(() => {
    setCurrectCostProduct({
      idPrecioProductoProveedor: modalData.idPrecioProductoProveedor,
      idProveedor: modalData.idProveedor.value,
      label_idProveedor: modalData.idProveedor.label,
      idUnidadMedida: modalData.idUnidadMedida.value,
      label_idUnidadMedida: modalData.idUnidadMedida.label,
      costo: modalData.costo,
      idProducto: modalData.idProducto ? modalData.idProducto : '',
      iva: modalData.iva,
      idMoneda: modalData.idMoneda?.label,
    });
    setAuxData({
      idProveedor: {
        value: modalData.idProveedor.value,
        label: modalData.idProveedor.label,
      },
      idUnidadMedida: {
        value: modalData.idUnidadMedida.value,
        label: modalData.idUnidadMedida.label,
      },
      idMoneda: {
        value: modalData.idMoneda,
        label: modalData.idMoneda,
      },
    });
    setCostoModal(modalData.costo.replace('$', '').replace(/\./g, ''));
    setIvaModal(modalData.iva.toString());
  }, []);

  const getMonedas = () => {
    toggleLoading(true);
    getAll(endpoints.listPrices.getAllMonedas)
      .then((res) => {
        console.log(res);
        let newArray = [];
        res.map((item) => {
          let data = {
            value: item.idMoneda,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          };
          newArray.push(data);
        });
        setSearchSelected((prev) => ({
          ...prev,
          tipoMonedas: newArray,
        }));

        // Set idMoneda in currectCostProduct
        setCurrectCostProduct((prev) => ({
          ...prev,
          idMoneda: res[0]?.idMoneda || 0, // Set the first idMoneda as default (if exists)
          label_idMoneda: `${res[0]?.nombre} - ${res[0]?.codigo}` || '',
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const handleUpdateModalData = (e) => {
    e.preventDefault();
    if (modalData.costo !== '') {
      if (typeof modalData.idPrecioProductoProveedor === 'number') {
        let data = {
          idPrecioProductoProveedor: currectCostProduct.idPrecioProductoProveedor,
          idProveedor: {
            idProveedor: auxData.idProveedor.value,
          },
          idProducto: {
            idProducto: id,
          },
          idUnidadMedida: {
            idUnidadMedida: auxData.idUnidadMedida.value,
          },
          idMoneda: {
            idMoneda: currectCostProduct.idMoneda,
          },
          costo: formatCurrencyFromModalToTable(costoModal.replace(',', '.')),
          iva: formatCurrencyFromModalToTable(ivaModal.replace(',', '.')),
          estado: 1,
          fechaCreacion: new Date(),
          fechaModificacion: new Date(),
          usuarioCreacion: 1,
          usuarioModificacion: Cookie.get('idUsuario'),
        };
        updateItem(endpoints.costProductProvider.updateCostProductProvider, data)
          .then((res) => {
            onClose();
            // Actualizar el currentDataTable con los valores actualizados
            setCurrentDataTable((prevDataTable) => {
              const updatedDataTable = prevDataTable.map((item) => {
                if (
                  item.idPrecioProductoProveedor === currectCostProduct.idPrecioProductoProveedor
                ) {
                  // Actualizar los campos relevantes del objeto correspondiente
                  return {
                    ...item,
                    costo: formatCurrencyFromModal(`${currectCostProduct.costo.toString()}`),
                    iva: currectCostProduct.iva,
                    fechaModificacion: new Date(),
                    usuarioModificacion: Cookie.get('idUsuario'),
                  };
                }
                return item;
              });
              return updatedDataTable;
            });
            setResultsTableSearch((prevDataTable) => {
              const updatedDataTable = prevDataTable.map((item) => {
                if (
                  item.idPrecioProductoProveedor === currectCostProduct.idPrecioProductoProveedor
                ) {
                  // Actualizar los campos relevantes del objeto correspondiente
                  return {
                    ...item,
                    costo: formatCurrencyFromModal(`${currectCostProduct.costo.toString()}`),
                    iva: currectCostProduct.iva,
                    fechaModificacion: new Date(),
                    usuarioModificacion: Cookie.get('idUsuario'),
                  };
                }
                return item;
              });
              return updatedDataTable;
            });
            getDataMiniTable(id);
          })
          .catch((err) => {
            if (err.response.status === 412) {
              customSB('error', 'alert.message.error.costProduct', 'Ya se creo un costo con estos parametros');
            } else {
              errorProcess();
            }
            onClose();
          });
      } else {
        updateStructure();
      }
    } else {
      console.log('Debes completar todos los campos');
    }
  };

  // Update the structure of the table after search the item to update
  const updateStructure = () => {
    currentDataTable.forEach((item) => {
      if (item.idPrecioProductoProveedor === modalData.idPrecioProductoProveedor) {
        let dataLeft = currentDataTable.filter((_, i) => {
          return i !== currentDataTable.indexOf(item);
        });
        let newStructure = {
          idPrecioProductoProveedor: currectCostProduct.idPrecioProductoProveedor,
          idProveedor: {
            value: auxData.idProveedor.value,
            label: auxData.idProveedor.label,
          },

          idUnidadMedida: {
            value: auxData.idUnidadMedida.value,
            label: auxData.idUnidadMedida.label,
          },
          costo: formatCurrencyFromModal(currectCostProduct.costo.toString()),
          iva: currectCostProduct.iva,
          idMoneda: auxData.idMoneda,
        };
        setCurrentDataTable([...dataLeft, newStructure]);
        onClose();
      }
    });
  };

  // update the form number
  const handleNumber = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setCostoModal(costoFormateado);
    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrectCostProduct({
      ...currectCostProduct,
      [event.target.name]: costoConDosDecimales,
    });
  };

  const handleIvaChange = (event) => {
    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setIvaModal(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setCurrectCostProduct({
      ...currectCostProduct,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  const formatIvaField = (value) => {
    return `${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  console.log("auxData: ", auxData);
  console.log("ivaModal: ", ivaModal);

  return (
    <form className="form-responsive" onSubmit={handleUpdateModalData}>
      <section className="form-responsive-container-information">
        <label className="form-responsive-information__option">
          <h3>  
            {formatterText('p.product.unit.meassurement', 'Unidad de medida')}
          </h3>
          <Selector
            name="idUnidadMedida"
            data={dataUnits}
            placeholder={currectCostProduct.label_idUnidadMedida}
            dataValue={auxData}
            setterFunction={setAuxData}
            selectValue={auxData.idUnidadMedida}
            isRequired={false}
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('table.title.provider', 'Proveedor')}</h3>
          <Selector
            name="idProveedor"
            data={dataProviders}
            placeholder={currectCostProduct.label_idProveedor}
            dataValue={auxData}
            setterFunction={setAuxData}
            selectValue={auxData.idProveedor}
            isRequired={false}
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('table.title.cost', 'Costo')}</h3>
          <input
            className="input-primary"
            type="text"
            name="costo"
            value={formatCurrencyFromModal(costoModal)}
            onChange={handleNumber}
            placeholder="Costo"
            maxLength="20"
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>{formatterText('table.title.currency',  'Moneda')}</h3>
          <Selector
            className="input-primary"
            type="text"
            name="idMoneda"
            data={selectedSearch.tipoMonedas}
            dataValue={auxData.idMoneda.label}            
            placeholder={currectCostProduct.label_idMoneda}
            setterFunction={setAuxData}
            maxLength="20"
          />
        </label>

        <label className="form-responsive-information__option">
          <h3>{formatterText('table.title.iva',  'Iva(%)')}</h3>
          <input
            className="input-primary"
            type="text"
            name="iva"
            onChange={handleIvaChange}
            maxLength="6"
            value={formatIvaField(ivaModal)}
          />
        </label>

        <input
          type="submit"
          className="width-100-fix"
          value={formatterText('p.product.update.cost.button',  'Actualizar Costo producto')}
          onClick={handleUpdateModalData}
        />
        <input
          type="button"
          className="width-100-fix input-cancel"
          value={formatterText('btn.cancel',  'Cancelar')}
          onClick={onClose}
        />
      </section>
    </form>
  );
}
