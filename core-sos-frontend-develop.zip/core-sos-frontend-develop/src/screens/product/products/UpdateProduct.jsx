import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useGetData from 'hooks/useGetData';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Table from 'common/minimalTables/TableMinimal';
import Selector from 'common/selects/Selector';
import SelectorMultiCreate from 'common/selects/SelectorMultiCreate';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import CustomAlert from 'components/CustomAlert';
import UpdateCostAssociateProduct from './UpdateCostAssociateProduct';
// Import Models
import CostProductProvider from 'models/CostProductProvider';
import Product from 'models/Product';
// Import libs
import { Formiz, useForm } from '@formiz/core';
import InputSelectorResponsive from 'common/inputs/InputSelectorResponsive';
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import de services
import rawCurrency from 'common/utils/rawCurrency';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import { CODEREGEXBARCODE, PRICEREGEX, SKUREGEX } from 'common/validators/Regex';
import { useSeachContext } from 'context/SearchContext';
import useLangv2 from "hooks/useLangv2";
import endpoints from 'services/api';
import { deleteBarcode } from 'services/api/barcodes';
import { getUnidadMedida } from 'services/api/institutions';
import { addItem, getAll, getItemById, updateItem } from 'services/api/methods';
import { getAllProviders } from 'services/api/providers';
import paths from 'services/paths';

const style = {
  position: 'absolute',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};


export default function UpdateProduct() {
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const [costo, setCosto] = useState('');
  const [iva, setIva] = useState('');

  const { dataTable, setDataTable } = useSeachContext();

  const myForm = useForm();
  const [formCostProductProviderData, setFormCostProductProviderData] = useState(
    new CostProductProvider(),
  );
  const { currentDataTable, setCurrentDataTable, setResultsTableSearch } =
    useContext(TableMinimalContext);
  const navigate = useNavigate();
  // useLanguage
  const { formatterText, errorProcess, newItemCreated, resourceNotFound } = useLangv2();
  // Example of form data
  const [formData, setFormData] = useState(new Product());

  // Los valores que usará el multiselect
  const [selectedMultiSearch, setSearchSelectedMulti] = useState([]);
  // Los valores que usará el select
  const [selectedSearch, setSearchSelected] = useState([
    {
      proveedor: [],
      unidadMedida: [],
      subCategoriasProducto: [],
      tipoMonedas: [],
    },
  ]);

  const titlesTableCostProduct = [
    formatterText('table.title.provider', 'Proveedor'),
    formatterText('p.product.unit.meassurement', 'Unidad de medida'),
    formatterText('table.title.cost', 'Costo'),
    formatterText('table.title.iva', 'Iva(%)'),
    formatterText('table.title.currency', 'Moneda'),
    formatterText('table.actions', 'Acciones')

  ];

  // Setea los valores del multiselect
  const [selectorMultiValues, setSelectorMultiValues] = useState([]);
  // Setea los valores del select
  const [selectorValues, setSelectorValues] = useState([]);
  // espera a que cargue los valores del multiselect
  const { loading, toggleLoading } = useGetData();
  const [auxData, setAuxData] = useState({
    idSubCategoriaProducto: 0,
    idProveedor: 0,
    idUnidadMedida: 0,
    idMoneda: 0,
  });

  // toggle state
  const [active, setActive] = useState(true);
  // Setea los valores del multiselect de los paises
  const [selectValues, setSelectValues] = useState([]);
  // Auxiliar para el tamaño del multi create selector
  const [auxSelectorMulti, setAuxSelectorMulti] = useState([]);
  // get id from url
  const { id } = useParams();
  const [subcategoriesData, setSubcategoriesData] = useState([]);

  useEffect(() => {
    getDataProductCategory();
    getDataMiniTable(id);
    getMonedas();
    getAllBarcodes();
    getSubProductCategory();
    getProviders();
    getUnitMeasure();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getProductById(id);
    getDataMiniTable(id);

  }, [id]);

  const getMonedas = () => {
    toggleLoading(true);
    getAll(endpoints.listPrices.getAllMonedas)
      .then((res) => {
        let newArray = [];
        // iterate response and get only the values that are active
        res.map((item) => {
          let data = {
            value: item.idMoneda,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          };
          return newArray.push(data);
        });
        setSearchSelected((prev) => ({
          ...prev,
          tipoMonedas: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const setProductForm = (data) => {
    setFormData({      
      idProducto: data.idProducto,
      idSubCategoriaProducto: data.subCategoriaProducto?.idSubCategoriaProducto
        ? data.subCategoriaProducto.idSubCategoriaProducto
        : null,
      sku: data.sku,
      nombre: data.nombre,
      descripcion: data.descripcion,
      estado: data.estado,
      fechaRegistro: data.fechaRegistro,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion
    });
  };
  //get data from LocalStorage
  const getDataProductCategory = () => {
    const productData = JSON.parse(localStorage.getItem('dataUpdate'));

    if (productData) {
      setProductForm(productData);
      setActive(productData.estado);
      getSelectCurrentValues(productData);
      getBarcodes(productData?.codigoBarras);
    } else {
      navigate(paths.products);
    }
  };
  //get data from api
  const getProductById = (id) => {
    getItemById(endpoints.products.getProductById, id)
      .then((res) => {
        if (res !== null) {
          setProductForm(res);
          setActive(res.estado);
          getSelectCurrentValues(res);
          getBarcodes(res?.codigoBarras);

        } else {
          resourceNotFound();
        }


      }).catch((err) => {
        console.error(err);
      });
  };

  const formatIvaToTable = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `,${parts[1]}`;
    }

    return formattedValue;
  };

  const getDataMiniTable = (id) => {
    getItemById(endpoints.costProductProvider.getCostProductProviderByProduct, id)
      .then((data) => {
        let aux = data.map((item) => {
          return {
            idPrecioProductoProveedor: item.idPrecioProductoProveedor,
            idProveedor: {
              label: `${item.idProveedor.nombreRazonSocial} - ${item.idProveedor.identificacion}`,
              value: item.idProveedor.idProveedor,
            },
            idUnidadMedida: {
              label: `${item.idUnidadMedida.descripcion} - ${item.idUnidadMedida.abreviatura}`,
              value: item.idUnidadMedida.idUnidadMedida,
            },
            costo: formatCurrency(item.costo.toString()),
            idMoneda: item.idMoneda
              ? {
                label: `${item.idMoneda.nombre} - ${item.idMoneda.codigo}`,
                value: formatIvaToTable(item.idMoneda.idMoneda.toString()),
              }
              : null,
            iva: formatIvaToTable(item.iva.toString()),
          };
        });
        setCurrentDataTable(aux);
        setResultsTableSearch(aux);
        setDataTable(aux);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const getSelectCurrentValues = (item) => {
    setSelectValues({
      value: item.subCategoriaProducto?.idSubCategoriaProducto,
      label: ` ${item.subCategoriaProducto?.nombre} - ${item.subCategoriaProducto?.codigo}`,
      isFixed: true,
    });
    setAuxData({
      idSubCategoriaProducto: item.subCategoriaProducto?.idSubCategoriaProducto,
      label: ` ${item.subCategoriaProducto?.nombre} - ${item.subCategoriaProducto?.codigo}`,
      isFixed: true,
    });
  };

  const getNameValue = (item) => {
    setAuxData({
      nombre: item.nombre,
    });
  };
  const getSKUValue = (item) => {
    setAuxData({
      sku: item.sku,
    });
  };

  const getBarcodes = (data) => {
    if (data === undefined) {
      return;
    }
    let barcodes = [];
    data.forEach((item) => {
      barcodes.push({
        label: item.codigo,
        value: item.idCodigoBarras,
        codigo: item.codigo,
        estado: item.estado,
        fechaModificacion: item.fechaModificacion,
        fechaRegistro: item.fechaRegistro,
        idCodigoBarras: item.idCodigoBarras,
        usuarioCreacion: item.usuarioCreacion,
        usuarioModificacion: item.usuarioModificacion,
      });
    });
    setSelectorMultiValues(barcodes);
    setAuxSelectorMulti(barcodes.length);
  };

  const getSubProductCategory = () => {
    toggleLoading(true);
    getAll(endpoints.subProductCategory.getAllSubProductCategory)
      .then((res) => {
        setSubcategoriesData(res);
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idSubCategoriaProducto,
              label: ` ${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        //  set in setSearchSelected in the value  subCategoriasProducto and dont delete the previous value
        setSearchSelected((prev) => ({
          ...prev,
          subCategoriasProducto: newArray,
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const getProviders = () => {
    toggleLoading(true);
    getAllProviders()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idProveedor,
              label: ` ${item.nombreRazonSocial} - ${item.identificacion}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          proveedor: newArray,
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const getUnitMeasure = () => {
    toggleLoading(true);
    getUnidadMedida()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idUnidadMedida,
              label: `${item.descripcion} - ${item.abreviatura}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          unidadMedida: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  const handleText = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      }
    }
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleSku = (e) => {
    HandleInput(e, SKUREGEX, formData, setFormData);
  };
  // update the form number
  const handleNumber = (e) => {
    // create a regex to valid the number
    if (e.target.value.match(PRICEREGEX) !== null) {
      setFormCostProductProviderData({
        ...formCostProductProviderData,
        idProveedor: auxData.idProveedor,
        idUnidadMedida: auxData.idUnidadMedida,
        [e.target.name]: e.target.value,
      });
    }
  }; 
  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    const selectedSubCategory = subcategoriesData?.find(
      (item) =>
        item.idSubCategoriaProducto ===
        (auxData || selectValues.value),
    );   

    if (!myForm.isValid && (formData.nombre === '' || formData.sku === '')) {
      HandleOnError('ERROR AL LLENAR LOS CAMPOS');
    } else {
      let data = {
        ...formData,
        nombre:
          myForm.fields?.nombre?.value?.replaceAll(/\s{2,}/gi, ' ') ||
          formData.nombre.replaceAll(/\s{2,}/gi, ' '),
        descripcion: formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
        sku: formData.sku.replaceAll(/\s{2,}/gi, ' '),
        subCategoriaProducto: selectedSubCategory,
        estado: active ? 1 : 0,
        usuarioModificacion: parseInt(Cookie.get('idUsuario')),
      };
      if (selectorMultiValues.length > 0) {
        putProduct(data);
      } else {
        HandleOnError('Debes ingresar codigo de barras');
      }
    }
  };

  const putProduct = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.update.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          updateItem(endpoints.products.updateProduct, data)
            .then((res) => {
              associateBarcode(res.idProducto, resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 400) {
                HandleOnError(formatterText("alert.message.sku.repetead"));
              } else {
                HandleOnError(formatterText("Error al crear el registro"));
              }
              console.error(err);
            });
        });
      },
    });
  };

  const associateBarcode = (id, resolve, reject) => {
    if (selectorMultiValues.length > 0) {
      const promesas = selectorMultiValues.map(
        (item) =>
          new Promise((resl, rej) => {
            let data = {
              producto: {
                idProducto: id,
              },
              codigo: item.value,
            };
            if (item.__isNew__) {
              addItem(endpoints.barcodes.addBarcode, data)
                .then((response) => {
                  resl(response);
                })
                .catch((err) => {
                  rej(err);
                });
            } else {
              resl(true);
            }
          }),
      );

      Promise.all(promesas)
        .then((_) => {
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general'),
              text: formatterText('alert.message.confirm.updated.general'),
              confirmButtonText: formatterText('alert.button.continue'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.products),
            }),
          );
        })
        .catch((err) => {
          if (err.response.status === 412) {
            reject(HandleOnError(err.response.data));
          } else {
            reject(HandleOnError(formatterText('snackbar.error.process.failed.general')));
          }
          console.error(err);
        });
    } else {
      resolve(
        CustomAlert('confirm_msg', {
          icon: 'success',
          title: formatterText('alert.title.confirm.general'),
          text: formatterText('alert.message.confirm.updated.general'),
          confirmButtonText: formatterText('alert.button.continue'),
          allowOutsideClick: false,
          executeFunction: () => navigate(paths.products),
        }),
      );
    }
  };

  const handleAddCostProduct = () => {
    if (
      costo !== '' ||
      formCostProductProviderData?.idProveedor?.value !== '' ||
      formCostProductProviderData?.costo !== ''
    ) {
      const existData = currentDataTable.filter((data) => {
        return (data.idProveedor?.value === formCostProductProviderData.idProveedor?.value &&
          data.idUnidadMedida.value === formCostProductProviderData.idUnidadMedida.value) ||
          (data.idProveedor === formCostProductProviderData.idProveedor &&
            data.idUnidadMedida === formCostProductProviderData.idUnidadMedida);
      });
      if (existData.length > 0) {
        HandleOnError('Ya se creo un costo con estos parametros');
      } else {
        setCurrentDataTable([...currentDataTable, formCostProductProviderData]);
        setResultsTableSearch([...currentDataTable, formCostProductProviderData]);
        setFormCostProductProviderData({
          costo: '',
          idMoneda: '',
          iva: '',
          idPrecioProductoProveedor: uuidv4(),
        });
        setAuxData((prevState) => ({
          ...prevState,
          idUnidadMedida: null,
          idProveedor: null,
          idMoneda: null,
        }));

        const DATA = {
          idPrecioProductoProveedor: null,
          idProveedor: {
            idProveedor: formCostProductProviderData?.idProveedor?.value,
          },
          idProducto: {
            idProducto: id,
          },
          idUnidadMedida: {
            idUnidadMedida: formCostProductProviderData?.idUnidadMedida?.value,
          },
          idMoneda: {
            idMoneda: formCostProductProviderData?.idMoneda?.value,
          },
          costo: rawCurrency(formCostProductProviderData?.costo),
          iva: rawCurrency(formCostProductProviderData?.iva) || 0,
          usuarioCreacion: parseInt(Cookie.get('idUsuario')),
        };

        addItem(endpoints.costProductProvider.addCostProductProvider, DATA).then((data) => {
          getDataMiniTable(id);
          newItemCreated();
          setIva('');
          setCosto('');
        }).catch(() => {
          errorProcess();

        });
      }
    } else {
      HandleOnError('Debes completar todos los campos de costo');
    }
  };

  const getAllBarcodes = () => {
    toggleLoading(true);
    getAll(endpoints.barcodes.getAllBarcodes)
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCodigoBarras,
              label: item.codigo,
              isFixed: true,
            });
          }
        });
        setSearchSelectedMulti(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const handleChangeMulti = (val) => {
    setSelectorMultiValues(val);

    // Filtrar los elementos del array 'val' que cumplan con la expresión regular CODEREGEXBARCODE
    let valNew = val.filter((elem) => elem.value.toString().match(CODEREGEXBARCODE));

    setSelectorMultiValues(valNew);

    if (auxSelectorMulti > val.length) {
      setAuxSelectorMulti(val.length);
      const arrayToDelete = selectorMultiValues.filter((item) => !val.includes(item));

      deleteBarcode(arrayToDelete[0].value)
        .then((_) => {
          const dataUpdate = JSON.parse(localStorage.getItem('dataUpdate'));
          localStorage.setItem(
            'dataUpdate',
            JSON.stringify({
              ...dataUpdate,
              codigoBarras: val,
            }),
          );
        })
        .catch((err) => {
          console.error(err);
        });
    } else {
      // Hacer algo más en caso de que no se cumpla la condición de longitud
    }
  };

  const handleFormat = (e, formatter) => {
    setFormCostProductProviderData({
      ...formCostProductProviderData,
      [e.target.name]: formatter(formCostProductProviderData.costo),
    });
  };

  const handleCostoChange = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setCosto(costoFormateado);

    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setFormCostProductProviderData({
      ...formCostProductProviderData,
      [event.target.name]: `$${costoConDosDecimales}`,
    });
  };

  const formatCurrency = (value) => {
    const parts = value.toString().split('.');
    let formattedValue = `$${parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;

    if (parts.length > 1) {
      formattedValue += `,${parts[1]}`;
    }

    return formattedValue;
  };

  const handleIvaChange = (event) => {
    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setIva(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    setFormCostProductProviderData({
      ...formCostProductProviderData,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  const formatIvaField = (value) => {
    return `${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  useEffect(() => {
    if (auxData.idProveedor !== null || auxData.idUnidadMedida !== null) {
      setFormCostProductProviderData({
        ...formCostProductProviderData,
        idProveedor: auxData.idProveedor,
        idUnidadMedida: auxData.idUnidadMedida,
        idMoneda: auxData.idMoneda,
      });
    }
  }, [auxData]);
  return (
    <>
      <div className="centered-form">
        <Formiz onValidSubmit={handleSubmit} connect={myForm}>
          <form
            noValidate
            className="container-wrapForm"
            onSubmit={handleSubmit}
            style={{ minHeight: '16rem' }}
          >
            <div className="container-wrap-formB">
              <div className="title-section">
                <p className="wrap-form-title">
                  {formatterText('p.product', 'Producto')}
                </p>
              </div>
              <section className="grid-container-2c">
                <h3 className="p-styles">{formatterText('p.product.name', 'Nombre del producto*')}</h3>
                <input
                  className="input-primary"
                  type="text"
                  name="nombre"
                  label={formatterText('p.product.name', 'Nombre del producto*')}
                  value={formData.nombre}
                  placeholder={formData.nombre}                 
                  onChange={handleText}
                />
                <h3 className="p-styles">SKU*</h3>
                <input
                  className="input-primary"
                  type="text"
                  name="sku"
                  value={formData.sku}
                  dataValue={formData.sku}
                  placeholder={formData.sku}
                  label="SKU*"
                  onChange={handleText}
                />
              </section>
              <section className="form-responsive-information__option">
                <h3 className="p-styles">
                  {formatterText('table.title.barCode.product', 'Código de barras*')}
                </h3>
                <section className="w100-container">
                  <SelectorMultiCreate
                    isLoading={loading}
                    dataValue={selectorMultiValues}
                    setterFunction={handleChangeMulti}
                    required
                  />
                </section>
              </section>
              <section className="form-responsive-information__option">
                <h3 className="p-styles">{formatterText('p.subcategory.of.product', 'Subcategoría del producto')}</h3>
                <InputSelectorResponsive
                  newForm={true}
                  name="idSubCategoriaProducto"
                  data={selectedSearch.subCategoriasProducto}
                  placeholder={selectValues.label}
                  dataValue={selectValues.label}
                  onChange={setAuxData}
                  isLoading={loading}
                  selectValue={selectorValues}
                  required={formatterText('p.subcategory.required.product', 'La subcategoría es requerida')}
                />
              </section>
              <section className="form-responsive-information__option">
                <h3 className="p-styles">{formatterText('table.title.description', 'Descripción')}</h3>
                <textarea
                  className="input-primary-textarea"
                  name="descripcion"
                  value={formData.descripcion}
                  onChange={handlerTextDescription}
                  placeholder={formatterText('table.title.description.product', 'Descripción del producto')}
                  maxLength="200"
                  label={formatterText('table.title.description', 'Descripción')}
                />
              </section>
              <section className="form-responsive-information__option">
                <h3 className="p-styles">{formatterText('table.title.state', 'Estado')}</h3>
                <label className="form-responsive-label">
                  <p className="form-responsive-toggle">{active ? formatterText('btn.active', 'Activo') : formatterText('p.unActive', 'Inactivo')}</p>
                  <label className="switch">
                    <input
                      checked={!!active}
                      onChange={() => {
                        setActive(!active);
                      }}
                      type="checkbox"
                    />
                    <span className="slider round"></span>
                  </label>
                </label>
              </section>
              {currentDataTable.length > 0 && (
                <>
                  <p className="wrap-form-title">{formatterText('p.costs.asociated.products', 'Costos asociados al producto')} </p>
                  <section className="form-responsive-container-information">
                    <Table
                      titles={titlesTableCostProduct}
                      data={currentDataTable}
                      type="costoProductoProveedor"
                      handleOpen={handleOpen}
                      labelTable={formatterText('p.costs.asociated.products.label.footer', 'Costos asociados')}
                      canSearch={true}
                      getDataMiniTable={getDataMiniTable}
                    />
                  </section>
                </>
              )}
              <div className="title-section">
                <p className="wrap-form-title">
                  {formatterText('p.costs.assign', '+ Asignar costo')}
                </p>
              </div>
              <section className="wrapForm">
                <label className="wrapForm__label">
                  <h3 className="p-styles spacing-r1">
                    {formatterText('p.product.unit.meassurement', 'Unidad de medida')}
                  </h3>
                  <Selector
                    name="idUnidadMedida"
                    data={selectedSearch.unidadMedida}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    dataValue={auxData}
                    setterFunction={setAuxData}
                    isLoading={loading}
                    selectValue={auxData.idUnidadMedida}
                    isRequired={false}
                  />
                </label>
                <label className="wrapForm__label">
                  <h3 className="p-styles spacing-r1">
                    <FormattedMessage
                      id="table.title.provider"
                      defaultMessage="Proveedor"
                    />
                  </h3>
                  <Selector
                    name="idProveedor"
                    data={selectedSearch.proveedor}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    dataValue={auxData}
                    setterFunction={setAuxData}
                    isLoading={loading}
                    selectValue={auxData.idProveedor}
                    isRequired={false}
                  />
                </label>
                <label className="wrapForm__label">
                  <h3 className="p-styles spacing-r1">
                    <FormattedMessage
                      id="table.title.currency"
                      defaultMessage="Moneda"
                    />
                  </h3>
                  <Selector
                    name="idMoneda"
                    data={selectedSearch.tipoMonedas}
                    placeholder={
                      <FormattedMessage
                        id="input.placeholder.select"
                        defaultMessage="Selecione una opción"
                      />
                    }
                    dataValue={auxData.idMoneda}
                    setterFunction={setAuxData}
                    isLoading={loading}
                    selectValue={auxData.idMoneda}
                    isRequired={true}
                    required="Seleccione tipo de moneda"
                  />
                </label>
                <label className="wrapForm__label">
                  <h3 className="p-styles spacing-r1">IVA %</h3>
                  <input
                    className="input-primary"
                    type="text"
                    name="iva"
                    value={formatIvaField(iva)}
                    onChange={handleIvaChange}
                    placeholder="IVA"
                    maxLength="6"
                  />
                </label>
                <label className="wrapForm__label">
                  <h3 className="p-styles spacing-r1">
                    <FormattedMessage
                      id="table.title.cost"
                      defaultMessage="Costo"
                    />
                  </h3>
                  <input
                    className="input-primary"
                    type="text"
                    name="costo"
                    value={formatCurrency(costo)}
                    onChange={handleCostoChange}
                    placeholder="$0.00"
                    maxLength="20"
                  />
                </label>
              </section>
              <input
                onClick={handleAddCostProduct}
                type="button"
                className="btn-primary btn-primary-center"
                value={formatterText('p.costs.assign.button', 'Asignar costo')}
              />
            </div>
            <section className="form-responsive-container-buttons">
              <button type="submit" onClick={handleSubmit} className="btn-primary">
                {formatterText('p.product.save.button', 'Guardar producto')}
              </button>
              <button className="input-cancel" onClick={() => navigate(paths.products)}>
                {formatterText('btn.cancel', 'Cancelar')}
              </button>
            </section>
          </form>
        </Formiz>
      </div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="parent-modal-title"
        aria-describedby="parent-modal-description"
      >
        <Box sx={{ ...style, width: '90%' }}>
          <UpdateCostAssociateProduct
            dataUnits={selectedSearch.unidadMedida}
            dataProviders={selectedSearch.proveedor}
            onClose={handleClose}
            formCostProductProviderData={formCostProductProviderData}
            handleCostoChange={handleCostoChange}
            formatCurrency={formatCurrency}
            handleIvaChange={handleIvaChange}
            formatIvaField={formatIvaField}
            costoTabla={costo}
            currentDataTable={currentDataTable}
            setCurrentDataTable={setCurrentDataTable}
            getDataMiniTable={getDataMiniTable}
          />
        </Box>
      </Modal>
    </>
  );
}
