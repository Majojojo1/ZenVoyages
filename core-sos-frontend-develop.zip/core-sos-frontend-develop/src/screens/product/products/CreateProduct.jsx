import React, { useContext, useEffect, useState } from "react";
// Import Context
import { TableMinimalContext } from "context/TableMinimalContext";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLang from "hooks/useLang";
import { useNavigate } from "react-router-dom";
// Import Components
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import { InputFieldResponsive } from "common/inputs/InputFieldResponsive";
import Table from "common/minimalTables/TableMinimal";
import Selector from "common/selects/Selector";
import SelectorMultiCreate from "common/selects/SelectorMultiCreate";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { PRICEREGEX, SKUREGEX } from "common/validators/Regex";
import CustomAlert from "components/CustomAlert";
import CostProductProvider from "models/CostProductProvider";
import UpdateCostAssociateProduct from "./UpdateCostAssociateProduct";
// Import Models
import Product from "models/Product";
// Import libs
import { Formiz, useForm } from "@formiz/core";
import { FormattedMessage } from "react-intl";
import Swal from "sweetalert2";
import { v4 as uuidv4 } from "uuid";
// Import de services
import InputSelectorResponsive from "common/inputs/InputSelectorResponsive";
import rawCurrency from "common/utils/rawCurrency";
import HandleInput from "common/validators/HandleInput";
import endpoints from "services/api";
import { getUnidadMedida } from "services/api/institutions";
import { addItem, getAll } from "services/api/methods";
import { getAllProviders } from "services/api/providers";
import paths from "services/paths";
import { CODEREGEXBARCODE } from "../../../common/validators/Regex";

const style = {
  position: "absolute",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};



export default function CreateProduct() {

  const myForm = useForm();
  // Modal config
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const [costo, setCosto] = useState('');
  const [iva, setIva] = useState("");

  const [formCostProductProviderData, setFormCostProductProviderData] =
    useState(new CostProductProvider());

  // Call context TableMinimalContext
  const { currentDataTable, setCurrentDataTable, setResultsTableSearch } =
    useContext(TableMinimalContext);
  const navigate = useNavigate();
  // useLanguage
  const { formatterText } = useLang();
  // Example of form data
  const [formData, setFormData] = useState(new Product());
  const [currentItemMinimal, setCurrentItemMinimal] = useState(
    new CostProductProvider(),
  );
  // Los valores que usará el multiselect
  const [selectedMultiSearch, setSearchSelectedMulti] = useState([]);
  // Los valores que usará el select
  const [selectedSearch, setSearchSelected] = useState([
    {
      proveedor: [],
      unidadMedida: [],
      subCategoriasProducto: [],
      tipoMonedas: [],
    },
  ]);

  const titlesTableCostProduct = [
    formatterText('table.title.provider', 'Proveedor'),
    formatterText('p.product.unit.meassurement', 'Unidad de medida'),
    formatterText('table.title.cost', 'Costo'),
    formatterText('table.title.iva', 'Iva(%)'),
    formatterText('table.title.currency', 'Moneda'),
    formatterText('table.actions', 'Acciones')

  ];
  // Setea los valores del multiselect
  const [selectorMultiValues, setSelectorMultiValues] = useState([]);
  // espera a que cargue los valores del multiselect
  const { loading, toggleLoading } = useGetData();
  const [auxData, setAuxData] = useState({
    idSubCategoriaProducto: 0,
    idProveedor: 0,
    idUnidadMedida: 0,
    idMoneda: 0,
  });

  useEffect(() => {
    setCurrentDataTable([]);
    getUnitMeasure();
    getBarcodes();
    getSubProductCategory();
    getProviders();
    getMonedas();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getMonedas = () => {
    toggleLoading(true);
    getAll(endpoints.listPrices.getAllMonedas)
      .then((res) => {
        let newArray = [];
        // iterate response and get only the values that are active
        res.map((item) => {
          let data = {
            value: item.idMoneda,
            label: `${item.nombre} - ${item.codigo}`,
            isFixed: true,
          };
          return newArray.push(data);
        });
        setSearchSelected((prev) => ({
          ...prev,
          tipoMonedas: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        console.error(err);
        toggleLoading(false);
      });
  };

  const getUnitMeasure = () => {
    toggleLoading(true);
    getUnidadMedida()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idUnidadMedida,
              label: `${item.descripcion} - ${item.abreviatura}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          unidadMedida: newArray,
        }));
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getBarcodes = () => {
    toggleLoading(true);
    getAll(endpoints.barcodes.getAllBarcodes)
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idCodigoBarras,
              label: item.codigo,
              isFixed: true,
            });
          }
        });
        setSearchSelectedMulti(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getSubProductCategory = () => {
    toggleLoading(true);
    getAll(endpoints.subProductCategory.getAllSubProductCategory)
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idSubCategoriaProducto,
              label: ` ${item.nombre} - ${item.codigo}`,
              isFixed: true,
            });
          }
        });
        //  set in setSearchSelected in the value  subCategoriasProducto and dont delete the previous value
        setSearchSelected((prev) => ({
          ...prev,
          subCategoriasProducto: newArray,
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getProviders = () => {
    toggleLoading(true);
    getAllProviders()
      .then((res) => {
        const newArray = [];
        res.forEach((item) => {
          if (item.estado === 1) {
            newArray.push({
              value: item.idProveedor,
              label: `${item.nombreRazonSocial} - ${item.identificacion}`,
              isFixed: true,
            });
          }
        });
        setSearchSelected((prev) => ({
          ...prev,
          proveedor: newArray,
        }));

        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  // Update a string to set into the form
  // const handleText = (e) => {
  //   HandlerText(e, formData, setFormData);
  // };

  const handleText = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };


  // update the form number
  const handleNumber = (e) => {
    // create a regex to valid the number
    // const regex = /^[0-9]*$/;
    if (e.target.value.match(PRICEREGEX) !== null) {
      setCurrentItemMinimal({
        ...currentItemMinimal,
        idProveedor: auxData.idProveedor,
        idUnidadMedida: auxData.idUnidadMedida,
        [e.target.name]: e.target.value,
      });
    }
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    let data = {
      ...formData,
      nombre: myForm.fields?.nombre?.value?.replaceAll(/\s{2,}/gi, ' ') || formData.nombre.replaceAll(/\s{2,}/gi, ' '),
      descripcion: myForm.fields?.descripcion?.value?.replaceAll(/\s{2,}/gi, ' ') || formData.descripcion.replaceAll(/\s{2,}/gi, ' '),
      sku: myForm.fields?.sku?.value?.replaceAll(/\s{2,}/gi, ' ') || formData.sku.replaceAll(/\s{2,}/gi, ' '),
      subCategoriaProducto: {
        idSubCategoriaProducto: myForm.fields?.idSubCategoriaProducto?.value || auxData.idSubCategoriaProducto.value,
      },
      usuarioCreacion: parseInt(formData.usuarioCreacion),
      usuarioModificacion: null,
    };
    if (selectorMultiValues.length > 0
      && myForm.fields?.nombre?.value != null
      && myForm.fields?.sku?.value != null
      && myForm.fields?.idSubCategoriaProducto?.value != null) {
      const barcodeExists = selectedMultiSearch.some((item) =>
        selectorMultiValues.map((item2) => item2.label).includes(item.label),
      );
      if (barcodeExists) {
        HandleOnError(formatterText("alert.message.barcode.duplicated"));
        return;
      }
      createProduct(data);
    } else {
      HandleOnError("Faltan campos por llenar");
    }

  };

  const createProduct = (data) => {
    Swal.fire({
      title: formatterText("alert.title.general"),
      text: formatterText("alert.description.create.general"),
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      showLoaderOnConfirm: true,
      cancelButtonColor: "#d33",
      confirmButtonText: formatterText("alert.button.confirm.general"),
      allowOutsideClick: false,
      cancelButtonText: formatterText("alert.button.cancel.general"),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          // this service create the item
          addItem(endpoints.products.addProduct, data)
            .then((res) => {
              // aqui se llama el servicio para asociar el producto con el proveedor
              associateBarcode(res.idProducto, resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 400) {
                HandleOnError(formatterText("alert.message.sku.repetead"));
              } else {
                HandleOnError(formatterText("Error al crear el registro"));
              }
              console.error(err);
            });
        });
      },
    });
  };

  const associateBarcode = (id, resolve, reject) => {
    if (selectorMultiValues.length > 0) {
      const promesas = selectorMultiValues.map(
        (item) =>
          new Promise((resl, rej) => {
            let data = {
              producto: {
                idProducto: id,
              },
              codigo: item.value,
            };

            addItem(endpoints.barcodes.addBarcode, data)
              .then((response) => {
                resl(response);
              })
              .catch((err) => {
                rej(err);
              });
          }),
      );

      Promise.all(promesas)
        .then((_) => {
          resolve(
            CustomAlert("confirm_msg", {
              icon: "success",
              title: formatterText("alert.title.confirm.general"),
              text: formatterText("alert.message.confirm.created.general"),
              confirmButtonText: formatterText("alert.button.continue"),
              allowOutsideClick: false,
              executeFunction: () => associateCostProduct(id),
            }),
          );
        })
        .catch((err) => {
          if (err.response.status === 412) {
            reject(HandleOnError(err.response.data));
          } else if (err.response.status === 400) {
            HandleOnError(
              formatterText(
                "Error al crear el producto, comprobar duplicidad en los códigos existentes",
              ),
            );
          } else {
            reject(
              HandleOnError(formatterText("alert.message.failed.general")),
            );
          }
        });
    } else {
      resolve(
        CustomAlert("confirm_msg", {
          icon: "success",
          title: formatterText("alert.title.confirm.general"),
          text: formatterText("alert.message.confirm.created.general"),
          confirmButtonText: formatterText("alert.button.continue"),
          allowOutsideClick: false,
          executeFunction: () => associateCostProduct(id),
        }),
      );
    }
  };

  const associateCostProduct = (id) => {
    if (currentDataTable.length > 0) {
      const promesas = currentDataTable.map(
        (item) =>
          new Promise((resl, rej) => {
            let data = {
              idPrecioProductoProveedor: null,
              idProveedor: {
                idProveedor: item.idProveedor.value,
              },
              idProducto: {
                idProducto: id,
              },
              idUnidadMedida: {
                idUnidadMedida: item.idUnidadMedida.value,
              },
              idMoneda: {
                idMoneda: item.idMoneda.value,
              },
              costo: rawCurrency(item.costo),
              iva: rawCurrency(item.iva) || 0,
              estado: 1,
              fechaCreacion: new Date(),
              fechaModificacion: null,
              usuarioCreacion: parseInt(formData.usuarioCreacion),
              usuarioModificacion: null,
            };

            addItem(endpoints.costProductProvider.addCostProductProvider, data)
              .then((response) => {
                resl(response);
              })
              .catch((err) => {
                HandleOnError(err.response.data);
              });
          }),
      );

      Promise.all(promesas)
        .then((_) => {
          CustomAlert("confirm_msg", {
            icon: "success",
            title: formatterText("alert.title.confirm.general"),
            text: formatterText("alert.message.associations.general"),
            confirmButtonText: formatterText("alert.button.continue"),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.products),
          });
        })
        .catch((err) => {
          if (err.response.status === 412 || err.response.status === 400) {
            HandleOnError(err.response.data);
          } else {
            HandleOnError(formatterText("alert.message.failed.general"));
          }
        });
    } else {
      navigate(paths.products);
    }
  };

  const handleAddItemMinimal = () => {
    if (costo !== ""
      || formCostProductProviderData?.idProveedor?.value !== ""
      || formCostProductProviderData?.costo !== "") {
      const existData = currentDataTable.filter((data) => {
        return (data.idProveedor?.value ===
          formCostProductProviderData.idProveedor?.value &&
          data.idUnidadMedida.value ===
          formCostProductProviderData.idUnidadMedida.value) ||
          (data.idProveedor === formCostProductProviderData.idProveedor &&
            data.idUnidadMedida === formCostProductProviderData.idUnidadMedida)
          ? true
          : false;
      });
      if (existData.length > 0) {
        HandleOnError("Ya se creo un costo con estos parametros");
      } else {
        console.log('entre a guardar setcurr');
        setCurrentDataTable([...currentDataTable, formCostProductProviderData]);
        setResultsTableSearch([...currentDataTable, formCostProductProviderData]);
        setFormCostProductProviderData({
          costo: "",
          idMoneda: "",
          iva: "",
          idPrecioProductoProveedor: uuidv4(),
        });
        setAuxData((prevState) => ({
          ...prevState,
          idUnidadMedida: null,
          idProveedor: null,
          idMoneda: null,
        }));
        setIva("");
        setCosto("");
      }
    } else {
      HandleOnError("Debes completar todos los campos de costo");
    }
  };

  const handleChangeMulti = (val) => {
    console.log(val);
    let valNew = val.filter((elem) =>
      elem.value.toString().match(CODEREGEXBARCODE) ? true : false,
    );
    setSelectorMultiValues(valNew);
  };

  const handleFormat = (e, formatter) => {
    setCurrentItemMinimal({
      ...currentItemMinimal,
      [e.target.name]: formatter(currentItemMinimal.costo),
    });
  };

  const handleSku = (e) => {
    HandleInput(e, SKUREGEX, formData, setFormData);
  };

  const handleCostoChange = (event) => {
    const inputCosto = event.target.value;

    const costoFormateado = inputCosto.replace(/[^\d,]/g, '').replace(/(,.*)\,/g, '$1');

    setCosto(costoFormateado);

    const costoDecimal = parseFloat(costoFormateado.replace(',', '.'));
    const costoConDosDecimales = costoDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    setFormCostProductProviderData({
      ...formCostProductProviderData,
      [event.target.name]: `$${costoConDosDecimales}`
    });

  };

  const formatCurrency = (value) => {
    return `$${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  const handleIvaChange = (event) => {

    const inputIva = event.target.value;

    const ivaFormateado = inputIva.replace(/[^\d,]/g, '');
    setIva(ivaFormateado);

    const ivaDecimal = parseFloat(ivaFormateado.replace(',', '.'));
    const ivaConDosDecimales = ivaDecimal.toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });


    setFormCostProductProviderData({
      ...formCostProductProviderData,
      [event.target.name]: ivaConDosDecimales,
    });
  };

  const formatIvaField = (value) => {
    return `${value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };


  useEffect(() => {
    if (auxData.idProveedor !== null || auxData.idUnidadMedida !== null) {
      setFormCostProductProviderData({
        ...formCostProductProviderData,
        idProveedor: auxData.idProveedor,
        idUnidadMedida: auxData.idUnidadMedida,
        idMoneda: auxData.idMoneda,
      });
    }
  }, [auxData]);



  return (

    <div className="centered-form">
      <Formiz onValidSubmit={handleSubmit} connect={myForm}>
        <form
          noValidate
          className="container-wrapForm"
          onSubmit={handleSubmit}
          style={{ minHeight: "16rem" }}>
          <div className="container-wrap-formB" >
            <div className="title-section">
              <p className="wrap-form-title">
                {formatterText('p.product', 'Producto')}
              </p>
            </div>
            <section className="grid-container-2c">
              <InputFieldResponsive
                className="input-primary"
                type="text"
                name="nombre"
                placeholder={formatterText('p.product.name', 'Nombre del producto*')}
                required="El nombre del producto es requerido"
                labelText={formatterText('p.product.name', 'Nombre del producto*')}
              />
              <InputFieldResponsive
                className="input-primary"
                type="text"
                name="sku"
                value={formData.sku}
                placeholder="Sku"
                maxLength="45"
                required="El SKU del producto es requerido"
                labelText="SKU*"
              />
            </section>
            <section className="form-responsive-information__option">
              <label className="p-styles">
                {formatterText('table.title.barCode.product', 'Código de barras*')}
              </label>
              <section className="w100-container">
                <SelectorMultiCreate
                  data={selectedMultiSearch}
                  isLoading={loading}
                  dataValue={selectorMultiValues}
                  setterFunction={handleChangeMulti}
                  isRequired={true}
                />
              </section>
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                {formatterText('p.subcategory.of.product', 'Subcategoría del producto')}
              </h3>
              <InputSelectorResponsive
                newForm={true}
                name="idSubCategoriaProducto"
                data={selectedSearch.subCategoriasProducto}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.select"
                    defaultMessage="Selecione una opción"
                  />
                }
                dataValue={auxData.idSubCategoriaProducto}
                setterFunction={setAuxData}
                isLoading={loading}
                selectValue={auxData.idSubCategoriaProducto}
                required={formatterText('p.subcategory.required.product', 'La subcategoría es requerida')}
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.description', 'Descripción')}</h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('table.title.description.product', 'Descripción del producto')}
                maxLength="200"
                label={formatterText('table.title.description', 'Descripción')}
              />
            </section>
            {currentDataTable.length > 0 && (
              <>
                <p className="wrap-form-title">{formatterText('p.costs.asociated.products', 'Costos asociados al producto')}</p>
                <section className="form-responsive-container-information">
                  <Table
                    titles={titlesTableCostProduct}
                    data={currentDataTable}
                    type="costoProductoProveedor"
                    handleOpen={handleOpen}
                  />
                </section>
              </>
            )}
            <div className="title-section">
              <p className="wrap-form-title">
                {formatterText('p.costs.assign', '+ Asignar costo')}
              </p>
            </div>
            <section className="wrapForm">
              <label className="wrapForm__label">
                <h3 className="p-styles spacing-r1">
                  {formatterText('p.product.unit.meassurement', 'Unidad de medida')}
                </h3>
                <Selector
                  newForm={true}
                  name="idUnidadMedida"
                  data={selectedSearch.unidadMedida}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  dataValue={auxData.idUnidadMedida}
                  setterFunction={setAuxData}
                  isLoading={loading}
                  selectValue={auxData.idUnidadMedida}
                  isRequired={false}
                />
              </label>
              <label className="wrapForm__label">
                <h3 className="p-styles spacing-r1">
                  <FormattedMessage
                    id="table.title.provider"
                    defaultMessage="Proveedor"
                  />
                </h3>
                <Selector
                  newForm={true}
                  name="idProveedor"
                  data={selectedSearch.proveedor}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  dataValue={auxData.idProveedor}
                  setterFunction={setAuxData}
                  isLoading={loading}
                  selectValue={auxData.idProveedor}
                  isRequired={false}
                />
              </label>
              <label className="wrapForm__label">
                <h3 className="p-styles spacing-r1">
                  <FormattedMessage
                    id="table.title.currency"
                    defaultMessage="Moneda"
                  />
                </h3>
                <Selector
                  name="idMoneda"
                  data={selectedSearch.tipoMonedas}
                  placeholder={
                    <FormattedMessage
                      id="input.placeholder.select"
                      defaultMessage="Selecione una opción"
                    />
                  }
                  dataValue={auxData.idMoneda}
                  setterFunction={setAuxData}
                  isLoading={loading}
                  selectValue={auxData.idMoneda}
                  isRequired={false}
                />
              </label>
              <label className="wrapForm__label">
                <h3 className="p-styles spacing-r1">IVA %</h3>
                <input
                  className="input-primary"
                  type="text"
                  name="iva"
                  value={formatIvaField(iva)}
                  onChange={handleIvaChange}
                  placeholder="IVA"
                  maxLength="6"
                />
              </label>
              <label className="wrapForm__label">
                <h3 className="p-styles spacing-r1">
                  <FormattedMessage
                    id="table.title.cost"
                    defaultMessage="Costo"
                  />
                </h3>
                <input
                  className="input-primary"
                  type="text"
                  name="costo"
                  value={formatCurrency(costo)}
                  onChange={handleCostoChange}
                  placeholder="$0.00"
                  maxLength="20"
                />
              </label>
              {/* fix C-01 */}
            </section>
            <input
              onClick={handleAddItemMinimal}
              type="button"
              className="btn-primary btn-primary-center"
              value={formatterText('p.costs.assign.button', 'Asignar costo')}
            />
          </div>
          <section className="form-responsive-container-buttons">
            <button type="submit" className="btn-primary">
              {formatterText('p.product.save.button', 'Guardar producto')}
            </button>
            <button
              className="input-cancel"
              onClick={() => navigate(paths.products)}
            >
              {formatterText('btn.cancel', 'Cancelar')}
            </button>
          </section>
        </form>
      </Formiz>

      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="parent-modal-title"
        aria-describedby="parent-modal-description"
      >
        <Box sx={{ ...style, width: "90%" }}>
          <UpdateCostAssociateProduct
            dataUnits={selectedSearch.unidadMedida}
            dataProviders={selectedSearch.proveedor}
            onClose={handleClose}
          />
        </Box>
      </Modal>
    </div>


  );
}
