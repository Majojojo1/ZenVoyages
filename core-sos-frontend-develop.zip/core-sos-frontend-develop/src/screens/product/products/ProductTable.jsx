import React, { useEffect, useState } from 'react';
// Import Context
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
// Import Components
import DynamicTable from 'common/DynamicTable/DynamicHead';
// Import libs
import SortData from 'components/utils/SortData';
import { FormattedMessage } from 'react-intl';
// Import services
import { PAGE_NAMES } from 'constants/lang/services/services/pagenames';
import { useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { deleteItem, updateItem } from 'services/api/methods';
import { getAllProducts } from 'services/api/products';
import paths from 'services/paths';

const ProductTable = ({permisos}) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setSearchResults, setDataTable, dataTable } = useSeachContext();

  const [product, setProducts] = useState(null);
  const [prov, setProv] = useState('');

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const titles = [
    formatterText('table.title.productName', 'Nombre producto'),
    'Sku',
    formatterText('table.title.barCode', 'Código de barras'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.subCategory', 'Subcategoría'),
    formatterText('table.title.provider', 'Proveedor'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.products.deleteProduct, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          const sortedArray = SortData(newArray, 'asc');
          setProducts(sortedArray);
          setSearchResults(sortedArray);
          setDataTable(sortedArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.products.updateProduct, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    // iterate item to get the the items who have codigoBarras and put a comma
    // each time the item have a codigoBarras aditional
    let codigoBarras = '';
    let arrayProviderName = '';
    if (item.codigoBarras) {
      item.codigoBarras.forEach((barcode) => {
        codigoBarras += barcode.codigo + ', ';
      });
    }
    if (item.precioProductoProveedor.length > 0) {
      item.precioProductoProveedor.forEach((elem) => {
        arrayProviderName += `${elem.idProveedor.nombreRazonSocial}, `;
      });
    }

    newArray.push({
      id: item.idProducto,
      nombre: item.nombre,
      sku: item.sku,
      codigoBarras: codigoBarras.slice(0, -2),
      descripcion: item.descripcion,
      subCategoriaProducto: item.subCategoriaProducto?.nombre,
      provedor: arrayProviderName,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAllProducts()
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        const sortedArray = SortData(newArray, 'asc');
        // console.log(sortedArray);
        setProducts(sortedArray);
        setSearchResults(sortedArray);
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {!loading && product !== null ? (
        <>
          <FormattedMessage id="table.name.search.product" defaultMessage="Categoría de producto">
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.Productos}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateProduct}
                canDeleted={permisos.eliminar}
                canModify={permisos.editar}
              />
            )}
          </FormattedMessage>
        </>
      ) : error ? (
        displayMessage('error', 'Ha ocurrido un error, intentalo más tarde.', 'toast.error.general')
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ProductTable;
