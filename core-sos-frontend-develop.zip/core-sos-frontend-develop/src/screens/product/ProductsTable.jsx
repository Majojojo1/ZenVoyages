import React, { useEffect, useState } from 'react';
// Import Context
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
// Import Hooks
import useLangv2 from 'hooks/useLangv2';
// Import Components
import Search from 'common/Search';
import ExportJsonFile from 'components/utils/ExportJsonFile';
import UploadExcel from 'components/utils/UploadExcel';
// Import libs
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs';
// Import services// Import libs
import endpoints from 'services/api';
import { uploadFile } from 'services/api/methods';
import paths from 'services/paths';

// Import Screens
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import { PermissionWrapper, usePermissionContext } from 'context/PermissionContext';
import { Link } from 'react-router-dom';
import ProductCategoryTable from 'screens/product/productCategory/ProductCategoryTable';
import ProductTable from 'screens/product/products/ProductTable';

const ProductsTable = () => {
  return (
    <SearchWrapper>
      <PermissionWrapper>
        <ProductsTableComponent />
      </PermissionWrapper>
    </SearchWrapper>
  );
};

const ProductsTableComponent = () => {
  // use Hook of language v2
  const { formatterText } = useLangv2();

  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.products.principal);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  const tabs = [
    {
      id: paths.productCategory,
      nombre: formatterText('table.name.search.productCategory', 'Categoría de producto'),
      route: paths.createProductCategory,
      nombreLink: formatterText('header.title.product.category.create','Crear categoría de producto'),
      componente: <ProductCategoryTable permisos={permittedActions} />,
      exportExcel: null,
      uploadExcel: null,
      idPermiso: MODULES_NAME.products.categories,
    },
    {
      id: paths.products,
      nombre: formatterText('nav.parent.3.child.option.3', 'Productos'),
      route: paths.createProduct,
      nombreLink: formatterText('header.title.product.create.product', 'Crear producto'),
      componente: <ProductTable permisos={permittedActions} />,
      exportExcel: permittedActions.exportar,
      uploadExcel: permittedActions.importar,
      idPermiso: MODULES_NAME.products.products,
    },
  ];

  const { setSearch, searchResults = [] } = useSeachContext();

  // Select tab
  const [selectedTab, setSelectedTab] = useState(
    tabs[parseInt(JSON.parse(localStorage.getItem('indexTabProduct'))) || 0],
  );

  // Index Tab
  const [indexTabProduct] = useState(
    parseInt(JSON.parse(localStorage.getItem('indexTabProduct')) || 0),
  );

  const auxemaple = (body) => {
    const ItemPromise = new Promise((resolve, reject) => {
      uploadFile(endpoints.costProductProvider.uploadFileCostProvider, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return ItemPromise;
  };

  useEffect(() => {
    setSelectedTab(tabs[0]);
  }, []);

  return (
    <section className="table-container">
      <section className="userOptions">
        {permittedActions.consultar && (
          <Search
            placeholder={formatterText('placeholder.search.multi.items', 'Buscar por palabra')}
            width="50%"
          />
        )}
        {permittedActions.crear && (
          <Link style={{ textDecoration: 'none', alignSelf: 'center' }} to={selectedTab.route}>
            <button className="btn-add">{selectedTab.nombreLink}</button>
          </Link>
        )}
        {selectedTab.exportExcel && (
          <ExportJsonFile
            moduleName={selectedTab.id.replace('/', '')}
            userName={JSON.parse(localStorage.getItem('userData')).usuario || 'ADMIN'}
            dataTable={searchResults}
          />
        )}
        {selectedTab.uploadExcel && (
          <UploadExcel ActionFunction={auxemaple} currentText={selectedTab.id.replace('/', '')} />
        )}
      </section>
      <Tabs defaultIndex={0} selectedTabClassName="tab-option--selected">
        <TabList className="tab-list">
          {tabs.map((tab, index) => (
            <Tab
              onClick={() => {
                setSelectedTab(tab);
                permissionsAccess(tab.idPermiso);
                localStorage.setItem('indexTabProduct', index.toString());
              }}
              key={index}
              className="new-tab-option"
            >
              {tab.nombre}
            </Tab>
          ))}
        </TabList>
        {permittedActions.consultar &&
          tabs.map((tab, index) => <TabPanel key={index}>{tab.componente}</TabPanel>)}
      </Tabs>
    </section>
  );
};

export default ProductsTable;
