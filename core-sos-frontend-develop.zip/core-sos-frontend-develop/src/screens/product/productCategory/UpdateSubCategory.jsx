import React, { useContext, useEffect, useState } from "react";
// Import Context
import { TableMinimalContext } from "context/TableMinimalContext";
// Import Hooks
import { useParams } from "react-router-dom";
// Import Components
// Import Libs
import Cookie from "js-cookie";
// Import Services
import HandleInput from "common/validators/HandleInput";
import HandleOnError from "common/validators/HandleOnError";
import HandlerTextDescription from "common/validators/HandlerTextDescription";
import { CODEREGEX } from "common/validators/Regex";
import useLangv2 from "hooks/useLangv2";
import { FormattedMessage } from "react-intl";
import endpoints from "services/api";
import { updateItem } from "services/api/methods";

export default function UpdateSubCategory({ onClose, getFun }) {
  const [currentSubProductCategory, setCurrentSubProductCategory] = useState({
    idSubCategoriaProducto: "",
    nombre: "",
    codigo: "",
    estado: "",
    descripcion: "",
    idCategoriaProducto: "",
  });

  const {
    modalData,
    currentDataTable,
    setCurrentDataTable,
    setResultsTableSearch,
  } = useContext(TableMinimalContext);
  // get id in the url
  const { id } = useParams();
  const { formatterText } = useLangv2();

  //  create useEffect clean function
  useEffect(() => {
    setCurrentSubProductCategory({
      idSubCategoriaProducto: modalData.idSubCategoriaProducto,
      nombre: modalData.nombre,
      codigo: modalData.codigo,
      estado: modalData.estado,
      descripcion: modalData.descripcion,
      idCategoriaProducto: modalData.idCategoriaProducto
        ? modalData.idCategoriaProducto.idCategoriaProducto
        : "",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // handle to subCategoryProduct, permite setear la información del texto
  const handleNameTextSubCategory = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setCurrentSubProductCategory({ ...currentSubProductCategory, [e.target.name]: e.target.value });
      }
    }
  };
  const handleChangeSubCategoryCode = (e) => {
    HandleInput(
      e,
      CODEREGEX,
      currentSubProductCategory,
      setCurrentSubProductCategory,
    );
  };

  const handleUpdateProductCategory = (e) => {
    e.preventDefault();
    if (modalData.nombre !== "" && modalData.codigo !== "") {
      if (modalData.idSubCategoriaProducto !== "") {
        if (typeof modalData.idSubCategoriaProducto === "number") {
          let data = {
            idSubCategoriaProducto:
              currentSubProductCategory.idSubCategoriaProducto,
            nombre: currentSubProductCategory.nombre,
            descripcion: currentSubProductCategory.descripcion,
            idCategoriaProducto: {
              idCategoriaProducto: currentSubProductCategory.idCategoriaProducto
                ? currentSubProductCategory.idCategoriaProducto
                : "1",
            },
            codigo: currentSubProductCategory.codigo,
            estado: currentSubProductCategory.estado,
            usuarioModificacion: Cookie.get("idUsuario"),
            fechaRegistro: "2022-08-09T05:00:00.000+00:00",
            fechaModificacion: new Date(),
            usuarioCreacion: Cookie.get("idUsuario"),
          };
          updateItem(
            endpoints.subProductCategory.updateSubProductCategory,
            data,
          )
            .then(() => {
              getFun(id);
              onClose();
            })
            .catch((error) => {
              if (error.status === 500) {
                HandleOnError(
                  "Ocurrio un error en el servidor, intenta mas tarde",
                );
              } else {
                HandleOnError("La subcategoria esta asociada a otra categoria");
              }
            });
        } else {
          // find the index of the SubCategoriaProducto to update
          let index = currentDataTable.findIndex(
            (item) =>
              item.idSubCategoriaProducto === modalData.idSubCategoriaProducto,
          );

          // update the SubCategoriaProducto
          let data = {
            idSubCategoriaProducto:
              currentSubProductCategory.idSubCategoriaProducto,
            nombre: currentSubProductCategory.nombre,
            codigo: currentSubProductCategory.codigo,
            descripcion: currentSubProductCategory.descripcion,
            estado: currentSubProductCategory.estado,
          };

          // delete the SubCategoriaProducto from the currentDataTable
          let dataLeft = currentDataTable.filter((_, i) => {
            return i !== index;
          });

          setCurrentDataTable([...dataLeft, data]);
          setResultsTableSearch([...dataLeft, data]);
          onClose();
        }
      } else {
        updateStructure();
      }
    } else {
      HandleOnError("Debes completar todos los campos");
    }
  };

  // Update the structure of the table after search the item to update
  const updateStructure = () => {
    currentDataTable.forEach((item) => {
      if (item.codigo === modalData.codigo) {
        let dataLeft = currentDataTable.filter((_, i) => {
          return i !== currentDataTable.indexOf(item);
        });
        setCurrentDataTable([...dataLeft, currentSubProductCategory]);
        onClose();
      }
    });
  };

  const handleChangeSubCategoryDescription = (e) => {
    HandlerTextDescription(e, currentSubProductCategory, setCurrentSubProductCategory);

  }

  return (
    <form className="form-responsive" onSubmit={handleUpdateProductCategory}>
      <section className="form-responsive-container-information">
        <label className="form-responsive-information__option">
          <h3>{formatterText('p.subcategory.name', 'Nombre subcategoría')}</h3>
          <input
            className="input-primary width-50"
            type="text"
            name="nombre"
            value={currentSubProductCategory.nombre}
            onChange={handleNameTextSubCategory}
            placeholder="Nombre subcategoría"
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>
            <FormattedMessage id="p.code" defaultMessage="Código" />
          </h3>
          <input
            className="input-primary width-50"
            type="text"
            name="codigo"
            value={currentSubProductCategory.codigo}
            onChange={handleChangeSubCategoryCode}
            placeholder={formatterText(
              'input.placeholder.enter.up.characters',
              'Ingresa hasta 45 caracteres',
            )}
            maxLength="45"
            required
          />
        </label>
        <label className="form-responsive-information__option">
          <h3>
            <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
          </h3>
          <textarea
            className="input-primary-textarea width-50"
            type="text"
            name="descripcion"
            value={currentSubProductCategory.descripcion}
            onChange={handleChangeSubCategoryDescription}
            placeholder={formatterText('table.title.description', 'Descripción')}
            maxLength="200"
          />
        </label>
        <input
          type="submit"
          className="width-100-fix"
          value={formatterText('p.subcategory.update', 'Actualizar subcategoría')}
        />
        <input
          type="button"
          className="width-100-fix input-cancel"
          value={formatterText('btn.cancel', 'Cancelar')}
          onClick={onClose}
        />
      </section>
    </form>
  );
}
