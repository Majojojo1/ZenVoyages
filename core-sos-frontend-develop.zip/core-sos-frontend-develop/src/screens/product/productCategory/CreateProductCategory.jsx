import React, { useContext, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useLang from 'hooks/useLang';
import { useNavigate } from 'react-router-dom';
// Import Components
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import CustomAlert from 'components/CustomAlert';
import { Modal } from 'react-responsive-modal';
import UpdateSubCategory from './UpdateSubCategory';
// Import Models
import ProductCategory from 'models/ProductCategory';
// Import libs
import Cookie from 'js-cookie';
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import services
import Table from 'common/minimalTables/TableMinimal';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerSpaceNumberLetter from 'common/validators/HandlerSpaceNumberLetter';
import { CODEREGEX } from 'common/validators/Regex';
import { validateDuplicateCode } from 'common/validators/ValidateDuplicates';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { addItem, getAll } from 'services/api/methods';
import paths from 'services/paths';

const style = {
  position: 'absolute',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

export default function CreateProductCategory() {
  return (
    <SearchWrapper>
      <CreateProductCategoryComponent />
    </SearchWrapper>
  );
}
function CreateProductCategoryComponent() {
  // Configuraciones del modal
  const [open, setOpen] = useState(false);

  const toggleOpen = () => setOpen(!open);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  // Call context TableMinimalContext
  const { currentDataTable, setResultsTableSearch, setCurrentDataTable } =
    useContext(TableMinimalContext);

  const { dataTable, setDataTable, searchResults = [], setSearchResults } = useSeachContext();

  //  Call hook of language
  const { formatterText } = useLang();
  // hook para la navegacion
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new ProductCategory());
  // Información principal de la tabla intermedia
  const [currentProductCategory, setCurrentProductCategory] = useState({
    idSubCategoriaProducto: uuidv4(),
    nombre: '',
    codigo: '',
    estado: 1,
    descripcion: '',
  });

  const titlesTableSubCategories = [
    formatterText('table.title.subCategory', 'Subcategoría'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      validateDuplicateCode(formData.codigo, 'El codigo ya existe', () =>
        getAll(endpoints.productCategory.getAllProductCategory),
      )
    ) {
      createProductCategory(formData);
    }
  };

  // Call the service POST
  const createProductCategory = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general'),
      text: formatterText('alert.description.create.general'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          addItem(endpoints.productCategory.addProductCategory, data)
            .then((res) => {
              // LLamo el servicio de asociar subcategorias, pasandole el id,
              // y el resolve y el reject por si falla en algun momento la promesa
              associateSubProductCategory(res.idCategoriaProducto, resolve, reject);
            })
            .catch((err) => {
              if (err.response.status === 400) {
                console.log('err.response.status');
                reject(HandleOnError(formatterText('alert.message.code.error.general')));
              } else if (err.response.status === 412) {
                console.log('err.response.status');
                console.log(err.response.status);
                reject(HandleOnError(formatterText('alert.message.code.error.characters')));
              } else {
                reject(HandleOnError(formatterText('alert.message.failed.general')));
              }
              console.log(err);
            });
        });
      },
    });
  };

  // Call the service POST to associate subproduct categories
  const associateSubProductCategory = (idM, resolve, reject) => {
    // Revisa si el array de subcategorias tiene datos
    console.log('dataTable', dataTable);
    console.log('currentData', currentDataTable);
    if (currentDataTable.length > 0) {
      // Recorre el array de subcategorias y alimenta la constante promesas
      const promesas = currentDataTable.map(
        (item) =>
          new Promise((resl, rej) => {
            // Creo una nuea promesa para saber si se creo correctamente, la información de la estructura
            // se puede encontrar con en el el postman en
            // Tabla-intermedia>subCategoriaProducto > POST subCategoriaProducto/save/save
            let data = {
              idSubCategoriaProducto: null,
              nombre: item.nombre,
              descripcion: item.descripcion,
              codigo: item.codigo,
              idCategoriaProducto: {
                idCategoriaProducto: idM, // id de la categoria principal
              },
              fechaRegistro: null,
              fechaModificacion: null,
              usuarioCreacion: Cookie.get('idUsuario'),
              usuarioModificacion: null,
            };
            // Llamo el servicio de asociar subcategorias
            addItem(endpoints.subProductCategory.addSubProductCategory, data)
              .then((response) => {
                console.log(response);
                resl(response);
              })
              .catch((err) => {
                rej(err);
              });
          }),
      );
      // Reviso que todas las promesas hallan terminado y muestro el mensaje de exito de las asociaciones
      Promise.all(promesas)
        .then((_) => {
          resolve(
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general'),
              text: formatterText('alert.message.associations.general'),
              confirmButtonText: formatterText('alert.button.continue'),
              allowOutsideClick: false,
              executeFunction: () => navigate(paths.products),
            }),
          );
        })
        .catch((err) => {
          if (err.response.status === 400) {
            reject(HandleOnError(formatterText('alert.message.failed.associations.general')));
          } else {
            reject(HandleOnError(formatterText('alert.message.failed.general')));
          }
          console.log(err);
        });
    } else {
      // Si no tiene datos el array de subcategorias, muestro el mensaje de exito y devuelvo a la pantalla principal
      CustomAlert('confirm_msg', {
        icon: 'success',
        title: formatterText('alert.title.confirm.general'),
        text: formatterText('alert.message.confirm.created.general'),
        confirmButtonText: formatterText('alert.button.continue'),
        allowOutsideClick: false,
        executeFunction: () => navigate(paths.products),
      });
    }
  };

  // Actualiza el nombre o un texto del formulario
  const handleText = (e) => {
    HandlerSpaceNumberLetter(e, setFormData);
    //HandlerText(e, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCode = (e) => {
    HandleInput(e, CODEREGEX, formData, setFormData);
  };

  // Add a product in the dynamic minimal table
  const handleAddproductCategory = () => {
    const { nombre, codigo } = currentProductCategory;

    // Verifica si los campos están vacíos
    if (!nombre || !codigo) {
      HandleOnError('Debes completar todos los campos de subcategoria');
      return;
    }

    // Verifica si el código ya existe en la tabla de datos
    if (currentDataTable.some((item) => item.codigo === codigo)) {
      HandleOnError('El código ya existe en alguna subcategoría, por favor ingrese uno distinto');
      return;
    }

    // Agrega el nuevo elemento al contexto
    const newCategory = {
      ...currentProductCategory,
      estado: 1,
      idSubCategoriaProducto: uuidv4(),
    };

    const updatedDataTable = [...dataTable, newCategory];
    const updatedSearchResults = [...searchResults, newCategory];

    setCurrentDataTable(updatedDataTable);
    setDataTable(updatedDataTable);
    setSearchResults(updatedSearchResults);

    // Limpia el estado del formulario de subcategorías
    setCurrentProductCategory({
      nombre: '',
      codigo: '',
      descripcion: '',
      estado: 1,
      idSubCategoriaProducto: uuidv4(),
    });
  };


  // handle to subCategoryProduct, permite setear la información del texto
  const handleNameTextSubCategory = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setCurrentProductCategory({ ...currentProductCategory, [e.target.name]: e.target.value });
      }
    }
  };


  const handlerTextDescriptionSubCategory = (e) => {
    HandlerTextDescription(e, currentProductCategory, setCurrentProductCategory);
  };

  const handleChangeSubCategoryCode = (e) => {
    HandleInput(e, CODEREGEX, currentProductCategory, setCurrentProductCategory);
  };

  // Actualiza el nombre o un texto del formulario
  const handleNameText = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      }
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          {/* Formulario del servicio principal */}
          <p className="wrap-form-title">
            <FormattedMessage id="p.category.product" defaultMessage="Categoría Producto" />
          </p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.name.category" defaultMessage="Nombre categoría producto" />
              </h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleNameText}
                placeholder={formatterText('p.name.category', 'Nombre categoría de producto')}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
              </h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('table.title.description', 'Descripción')}
                maxLength="200"
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.code" defaultMessage="Código" />
              </h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handleCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
                required
              />
            </section>
          </section>
          {/* Información de la tabla intermedia */}
          <p className="wrap-form-title">
            {formatterText(
              'p.subcategory.product', 'Subcategorías del producto',
            )}
          </p>
          <section className="form-responsive-container-information">
            <Table
              titles={titlesTableSubCategories}
              data={currentDataTable}
              type="subCategorias"
              handleOpen={handleOpen}
              labelTable={formatterText(
                'p.subcategory.product', 'Subcategorías del producto',
              )}
              canSearch={true}
            />
          </section>
          {/* Formulariop de la tabla intermedia */}
          <p className="wrap-form-title">
            <FormattedMessage
              id="p.add.subcatgory.product"
              defaultMessage="Agregar subcategoría producto"
            />
          </p>
          <section
            className="grid-container-2c sm-gap"
            style={{
              width: '95%',
              margin: '0 auto',
            }}
          >
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="p.subcategory.name" defaultMessage="Nombre subcategoría" />
              </h3>
              <input
                className="input-default-3c"
                type="text"
                name="nombre"
                value={currentProductCategory.nombre}
                onChange={handleNameTextSubCategory}
                placeholder={formatterText('p.subcategory.name', 'Nombre subcategoría')}
                maxLength="45"
              />
            </label>
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="p.code" defaultMessage="Código" />
              </h3>
              <input
                className="input-default-3c"
                type="text"
                name="codigo"
                value={currentProductCategory.codigo}
                onChange={handleChangeSubCategoryCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
              />
            </label>
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
              </h3>
              <textarea
                className="input-primary-textarea width-80"
                type="text"
                name="descripcion"
                value={currentProductCategory.descripcion}
                onChange={handlerTextDescriptionSubCategory}
                placeholder={formatterText('p.subcategory.desc', 'Descripción de la subcategoría')}
                maxLength="200"
              />
            </label>
          </section>
          <section
            className="form-responsive-container-buttons"
            style={{
              height: '5.5rem',
            }}
          >
            <input
              onClick={handleAddproductCategory}
              type="button"
              className="btn-primary margin-auto"
              value={formatterText('p.add.subcategory', 'Agregar subcategoría')}
            />
          </section>
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            <FormattedMessage
              id="header.title.product.category.create"
              defaultMessage="Crear categoría de producto"
            />
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.products)}>
            <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
          </button>
        </section>
      </form>
      {/* Modal para editar la información */}
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <UpdateSubCategory onClose={handleClose} />
      </Modal>
    </>
  );
}
