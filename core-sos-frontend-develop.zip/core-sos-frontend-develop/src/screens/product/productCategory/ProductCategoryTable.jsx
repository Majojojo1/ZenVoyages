import React, { useContext, useEffect } from "react";
// Import Context
import { useSeachContext } from "context/SearchContext";
import { TableMinimalContext } from "context/TableMinimalContext";
// Import Hooks
import useGetData from "hooks/useGetData";
import useLangv2 from "hooks/useLangv2";
// Import Components
import DynamicTable from "common/DynamicTable/DynamicHead";
// Import libs
import SortData from "components/utils/SortData";
import { FormattedMessage } from "react-intl";
// Import services
import { PAGE_NAMES } from "constants/lang/services/services/pagenames";
import endpoints from "services/api";
import { deleteItem, getAll, updateItem } from "services/api/methods";
import paths from "services/paths";

const ProductCategoryTable = ({permisos}) => {
  // hook to loading data
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const { setDataTable } = useSeachContext();
  const { setCurrentDataTable, setResultsTableSearch } =
    useContext(TableMinimalContext);

  useEffect(() => {
    getDataTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // función para cargar datos
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.productCategory.getAllProductCategory)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => handleStructureItems(newArray, item));
        const sortedArray = SortData(newArray, "asc");
        setDataTable(sortedArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleDeleteItem = (rowId) => {
    const deleteItemPromise = new Promise((resolve, reject) => {
      deleteItem(endpoints.productCategory.deleteProductCategory, rowId)
        .then((res) => {
          let newArray = [];
          res.forEach((item) => {
            handleStructureItems(newArray, item);
          });
          const sortedArray = SortData(newArray, "asc");
          setDataTable(sortedArray);
          resolve(true);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return deleteItemPromise;
  };

  const handleEditStateItem = (body) => {
    const updateItemPromise = new Promise((resolve, reject) => {
      updateItem(endpoints.productCategory.updateProductCategory, body)
        .then((res) => {
          resolve(res);
        })
        .catch((err) => {
          reject(err);
        });
    });
    return updateItemPromise;
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idCategoriaProducto,
      nombre: item.nombre,
      descripcion: item.descripcion,
      codigo: item.codigo,
      estado: item.estado,
      objeto: { ...item },
    });
  };

  // use Hook of language v2
  const { formatterText } = useLangv2();

  const titles = [
    formatterText("table.title.categoryName", "Nombre categoría"),
    formatterText("table.title.description", "Descripción"),
    formatterText("table.title.code", "Código"),
    formatterText("table.title.state", "Estado"),
    formatterText("table.actions", "Acciones"),
  ];

  return (
    <>
      {!loading ? (
        <>
          <FormattedMessage
            id="table.name.search.productCategory"
            defaultMessage="Categoría de producto"
          >
            {(placeholder) => (
              <DynamicTable
                titles={titles}
                pageName={PAGE_NAMES.CategoríasProductos}
                getData={getDataTable}
                handleDeleteItem={handleDeleteItem}
                handleEditStateItem={handleEditStateItem}
                routeToEdit={paths.updateProductCategory}
                canDeleted={permisos.eliminar}
                canModify={permisos.editar}
              />
            )}
          </FormattedMessage>
        </>
      ) : error ? (
        displayMessage(
          "error",
          "Ha ocurrido un error, intentalo más tarde.",
          "toast.error.general",
        )
      ) : (
        displayLoading()
      )}
    </>
  );
};

export default ProductCategoryTable;
