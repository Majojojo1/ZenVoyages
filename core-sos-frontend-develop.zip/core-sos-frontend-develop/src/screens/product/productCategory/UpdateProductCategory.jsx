import React, { useContext, useEffect, useState } from 'react';
// Import Context
import { TableMinimalContext } from 'context/TableMinimalContext';
// Import Hooks
import useAxios from 'hooks/useAxios';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate, useParams } from 'react-router-dom';
// Import Components
import Table from 'common/minimalTables/TableMinimal';
import HandleInput from 'common/validators/HandleInput';
import HandleOnError from 'common/validators/HandleOnError';
import HandlerText from 'common/validators/HandlerText';
import HandlerTextDescription from 'common/validators/HandlerTextDescription';
import { CODEREGEX } from 'common/validators/Regex';
import CustomAlert from 'components/CustomAlert';
import { Modal } from 'react-responsive-modal';
import UpdateSubCategory from './UpdateSubCategory';
// Import models
import ProductCategory from 'models/ProductCategory';
// Import libs
import Swal from 'sweetalert2';
import { v4 as uuidv4 } from 'uuid';
// Import services
import HandlerSpaceNumberLetter from 'common/validators/HandlerSpaceNumberLetter';
import { SearchWrapper, useSeachContext } from 'context/SearchContext';
import { FormattedMessage } from 'react-intl';
import endpoints from 'services/api';
import { addItem, getItemById, updateItem } from 'services/api/methods';
import paths from 'services/paths';


export default function UpdateProductCategory() {
  return (
    <SearchWrapper>
      <UpdateProductCategoryComponent />
    </SearchWrapper>
  );
}

function UpdateProductCategoryComponent() {
  // Manage axios requests
  const { COOKIE_USER } = useAxios();
  // Get id from the url
  const { id } = useParams();
  const [open, setOpen] = useState(false);
  const { setDataTable } = useSeachContext();
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const { currentDataTable, setCurrentDataTable, setResultsTableSearch, resultsTableSearch } =
    useContext(TableMinimalContext);

  const { formatterText, resourceNotFound, noFilledContent, newItemCreated } = useLangv2();
  const navigate = useNavigate();
  // Example of form data
  const [formData, setFormData] = useState(new ProductCategory());

  // toggle state
  const [active, setActive] = useState(true);

  const [currentProductCategory, setCurrentProductCategory] = useState({
    idSubCategoriaProducto: uuidv4(),
    nombre: '',
    codigo: '',
    estado: 1,
    descripcion: '',
  });

  const titlesTableSubCategories = [
    formatterText('table.title.subCategory', 'Subcategoría'),
    formatterText('table.title.description', 'Descripción'),
    formatterText('table.title.code', 'Código'),
    formatterText('table.title.state', 'Estado'),
    formatterText('table.actions', 'Acciones'),
  ];

  useEffect(() => {
    let id = getDataProductCategory();
    getSubCategoriesProductById(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getCategoryById(id);
    getSubCategoriesProductById(id);

  }, [id]);

  const setCategoryForm = (data) => {
    setFormData({
      idCategoriaProducto: data.idCategoriaProducto,
      nombre: data.nombre,
      descripcion: data.descripcion,
      codigo: data.codigo,
      estado: data.estado,
      fechaRegistro: data.fechaRegistro,
      fechaModificacion: data.fechaModificacion,
      usuarioCreacion: data.usuarioCreacion,
      usuarioModificacion: data.usuarioModificacion,
    });
  };
  //get data from LocalStorage
  const getDataProductCategory = () => {
    const productCategory = JSON.parse(localStorage.getItem('dataUpdate'));
    if (productCategory) {
      setCategoryForm(productCategory);
      setActive(productCategory.estado);
      return productCategory.idCategoriaProducto;
    } else {
      navigate(paths.products);
    }
  };
  //get data from api
  const getCategoryById = (id) => {
    getItemById(endpoints.productCategory.getCategoryById, id)
      .then((res) => {
        if (res !== null) {
          setCategoryForm(res);
          setActive(res.estado);
        } else {
          resourceNotFound();
        }
      });
  };

  const getSubCategoriesProductById = (id) => {
    getItemById(endpoints.subProductCategory.getAllSubProductCategoryByCategory, id)
      .then((res) => {
        setCurrentDataTable(res);
        setResultsTableSearch(res);
        setDataTable(res);
      })
      .catch(() => {
        HandleOnError(
          formatterText(
            'alert.subcategory.error.general',
            'La subcategoria esta asociada a otra categoria',
          ),
        );
      });
  };

  // This function is executed when the create button is clicked
  const handleSubmit = (e) => {
    e.preventDefault();
    let data = {
      ...formData,
      estado: active ? '1' : '0',
    };
    putProductCategory(data);

  };

  const putProductCategory = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text: formatterText('alert.description.update.general', 'Se va a editar el registro'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('alert.button.confirm.general', 'Guardar cambios'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: () => {
        return new Promise((resolve, reject) => {
          updateItem(endpoints.productCategory.updateProductCategory, data)
            .then((res) => {
              resolve(
                CustomAlert('confirm_msg', {
                  icon: 'success',
                  title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
                  text: formatterText(
                    'alert.message.confirm.updated.general',
                    'El registro se ha actualizado correctamente',
                  ),
                  confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
                  allowOutsideClick: false,
                  executeFunction: () => {
                    setResultsTableSearch([]);
                    setCurrentDataTable([]);
                    navigate(paths.products);
                  },
                }),
              );
            })
            .catch((err) => {
              if (err.response.status === 400) {
                reject(
                  HandleOnError(
                    formatterText(
                      'alert.message.code.error.general',
                      'El código ya existe, por favor ingrese uno distinto',
                    ),
                  ),
                );
              } else if (err.response.status === 412) {
                reject(HandleOnError(formatterText('alert.message.code.error.characters')));
              } else {
                reject(
                  HandleOnError(
                    formatterText(
                      'alert.message.failed.general',
                      'Error al crear el registro, por favor intente nuevamente.',
                    ),
                  ),
                );
              }
              console.error(err);
            });
        });
      },
    });
  };
  // Update a string to set into the form
  const handleText = (e) => {
    HandlerSpaceNumberLetter(e, setFormData);
    //HandlerText(e, formData, setFormData);
  };

  const handlerTextDescription = (e) => {
    HandlerTextDescription(e, formData, setFormData);
  };

  const handleCode = (e) => {
    const input = e.target.value;
    if (CODEREGEX.test(input)) {
      HandlerText(e, formData, setFormData);
    } else {
      console.error('La entrada contiene caracteres no válidos o espacios en blanco.');
    }
  };
  const handleAddproductCategory = () => {
    if (currentProductCategory.nombre !== '' && currentProductCategory.codigo !== '') {
      let filter = currentDataTable.filter((item) => item.codigo === currentProductCategory.codigo);

      if (filter.length > 0) {
        HandleOnError(
          formatterText(
            'alert.subcategory.exists.general',
            'El código ya existe en alguna subcategoría, por favor ingrese uno distinto',
          ),
        );
      } else {
        const DATA = {
          idSubCategoriaProducto: null,
          nombre: currentProductCategory.nombre,
          descripcion: currentProductCategory.descripcion,
          codigo: currentProductCategory.codigo,
          idCategoriaProducto: {
            idCategoriaProducto: id,
          },
          estado: currentProductCategory.estado,
          fechaRegistro: null,
          fechaModificacion: null,
          usuarioCreacion: COOKIE_USER,
          usuarioModificacion: null,
        };

        addItem(endpoints.subProductCategory.addSubProductCategory, DATA)
          .then((data) => {
            newItemCreated();
            getSubCategoriesProductById(id);
            setCurrentProductCategory({
              nombre: '',
              codigo: '',
              descripcion: '',
              estado: '',
              idSubCategoriaProducto: uuidv4(),
            });
          })
          .catch((err) => HandleOnError(formatterText('alert.message.code.error.characters')));
      }
    } else {
      noFilledContent();
    }
  };

  const handleNameTextSubCategory = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setCurrentProductCategory({ ...currentProductCategory, [e.target.name]: e.target.value });
      }
    }
  };

  const handleChangeSubCategoryCode = (e) => {
    HandleInput(e, CODEREGEX, currentProductCategory, setCurrentProductCategory);
  };

  const handlerTextDescriptionSubCategory = (e) => {
    HandlerTextDescription(e, currentProductCategory, setCurrentProductCategory);
  };

    // Actualiza el nombre o un texto del formulario
  const handleNameText = (e) => {
    if (e.target.value.match(/^[a-zA-Z0-9 \-ñáéíóúÁÉÍÓÚÑ]*$/) !== null) {
      let result = /\s{2}/.test(e.target.value);
      if (result) {
      } else {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      }
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <section className="form-responsive container-border-wrapForm">
          <p className="wrap-form-title">
            <FormattedMessage id="p.category.product" defaultMessage="Categoría Producto" />
          </p>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.name.category" defaultMessage="Nombre categoría producto" />
              </h3>
              <input
                className="input-primary"
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleNameText}
                placeholder={formatterText('p.name.category', 'Nombre categoría de producto')}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
              </h3>
              <textarea
                className="input-primary-textarea"
                name="descripcion"
                value={formData.descripcion}
                onChange={handlerTextDescription}
                placeholder={formatterText('table.title.description', 'Descripción')}
                maxLength="200"
              />
            </section>

            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.code" defaultMessage="Código" />
              </h3>
              <input
                className="input-primary"
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handleCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
                required
              />
            </section>
            <section className="form-responsive-information__option">
              <h3 className="p-styles">{formatterText('table.title.state', 'Estado')}</h3>
              <label className="form-responsive-label">
                <p className="form-responsive-toggle">{active ? formatterText('btn.active', 'Activo') : formatterText('p.unActive', 'No activo')}</p>
                <label className="switch">
                  <input
                    checked={!!active}
                    onChange={() => {
                      setActive(!active);
                    }}
                    type="checkbox"
                  />
                  <span className="slider round"></span>
                </label>
              </label>
            </section>
          </section>
          {currentDataTable.length > 0 && (
            <>
              <p className="wrap-form-title">
                {formatterText(
                  'p.subcategory.product', 'Subcategorías del producto',
                )}</p>
              <section className="form-responsive-container-information">
                <Table
                  titles={titlesTableSubCategories}
                  data={currentDataTable}
                  type="subCategorias"
                  handleOpen={handleOpen}
                  labelTable={formatterText(
                    'p.subcategory.product', 'Subcategorías del producto',
                  )}
                  canSearch={true}
                />
              </section>
            </>
          )}
          <p className="wrap-form-title">
            <FormattedMessage
              id="p.add.subcatgory.product"
              defaultMessage="+ Agregar subcategoría producto"
            /></p>
          <section
            className="grid-container-2c sm-gap"
            style={{
              width: '95%',
              margin: '0 auto',
            }}
          >
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="p.subcategory.name" defaultMessage="Nombre subcategoría" />
              </h3>
              <input
                className="input-default-3c"
                type="text"
                name="nombre"
                value={currentProductCategory.nombre}
                onChange={handleNameTextSubCategory}
                placeholder={formatterText('p.subcategory.name', 'Nombre subcategoría')}
                maxLength="45"
              />
            </label>
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="p.code" defaultMessage="Código" />
              </h3>
              <input
                className="input-default-3c"
                type="text"
                name="codigo"
                value={currentProductCategory.codigo}
                onChange={handleChangeSubCategoryCode}
                placeholder={formatterText(
                  'input.placeholder.enter.up.characters',
                  'Ingresa hasta 45 caracteres',
                )}
                maxLength="45"
              />
            </label>
            <label className="d-flex">
              <h3 className="text-inline">
                <FormattedMessage id="table.title.description" defaultMessage="Descripción" />
              </h3>
              <textarea
                className="input-primary-textarea width-80"
                type="text"
                name="descripcion"
                value={currentProductCategory.descripcion}
                onChange={handlerTextDescriptionSubCategory}
                placeholder={formatterText('p.subcategory.desc', 'Descripción de la subcategoría')}
                maxLength="200"
              />
            </label>
          </section>
          <section
            className="form-responsive-container-buttons"
            style={{
              height: '5.5rem',
            }}
          >
            <input
              onClick={handleAddproductCategory}
              type="button"
              className="btn-primary margin-auto"
              value={formatterText('p.add.subcategory', 'Agregar subcategoría')}
            />
          </section>
        </section>
        <section className="form-responsive-container-buttons">
          <button type="submit" className="btn-primary">
            <FormattedMessage
              id="header.title.product.category.update"
              defaultMessage="Editar categoría de producto"
            />
          </button>
          <button className="input-cancel" onClick={() => navigate(paths.products)}>
            <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
          </button>
        </section>
      </form>
      <Modal
        open={open}
        onClose={handleClose}
        center
        classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      >
        <UpdateSubCategory onClose={handleClose} getFun={getSubCategoriesProductById} />
      </Modal>
    </>
  );
}
