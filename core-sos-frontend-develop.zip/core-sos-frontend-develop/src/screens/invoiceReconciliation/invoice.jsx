import { Formiz, FormizStep, useForm } from '@formiz/core';
import { FormControl, FormControlLabel, Radio, RadioGroup } from '@mui/material';
import Axios from 'axios';
import HandleOnError from 'common/validators/HandleOnError';
import { MODULES_NAME } from 'common/validators/PermissionsConstants';
import Attachments from 'components/AttachedFiles/Attachments';
import CustomAlert from 'components/CustomAlert';
import { usePermissionContext } from 'context/PermissionContext';
import useLangv2 from 'hooks/useLangv2';
import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { useNavigate } from 'react-router';
import endpoints from 'services/api';
import paths from 'services/paths';

const Invoice = () => {
  const formData = useForm();
  const [date, setDate] = useState('');
  const [value, setValue] = useState('ticket');
  const [archivos, setCurrentFiles] = useState([]);
  const [option, setOption] = useState(true);
  const navigate = useNavigate();
  const { formatterText } = useLangv2();
  const { permissionsAccess, permittedActions, permissions } = usePermissionContext();
  const permissionsAccessGaranted = () => {
    permissionsAccess(MODULES_NAME.reconciliation);
  };

  useEffect(() => {
    permissionsAccessGaranted();
  }, [permissions]);

  const handleChange = (e) => {
    setOption(!option);
    setValue(e.target.value);
  };

  const handleSaveAttachedFiles = (isTicket) => {
    if (archivos.length > 0) {
      const binary = atob(archivos[0].archivo);
      // convertir el objeto binario en un arreglo de bytes
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      // crear un objeto de archivo a partir del arreglo de bytes
      const fileData = new File([bytes.buffer], archivos[0].name + archivos[0].extensionArchivo, {
        type: '.xlsx',
      });

      const form = new FormData();

      form.append('file', fileData);
      form.append('ticket', isTicket);
      Axios.post(endpoints.services.saveInvoiceReconciliation, form, {
        headers: {
          accept: '*/*',
          'Content-Type': 'multipart/form-data',
          Authorization: sessionStorage.getItem('token'),
        },
      })
        .then((resp) => {
          const response = resp.data;
          console.log(response);
          response.map((item) => {
            console.log(item);
          });
          if (response.length > 0) {
            let message = '';
            response.map((item) => {
              message += `fila-${item.fila}: ${item.error}\n`;
            });
            HandleOnError(message);
          } else {
            CustomAlert('confirm_msg', {
              icon: 'success',
              title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
              text: formatterText('file.success.attached'),
              confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
              allowOutsideClick: false,
              executeFunction: () => setCurrentFiles([]),
            });
          }
        })
        .catch((error) => HandleOnError(formatterText('error.alert.excel.case.12')));
    }
  };

  const handleSubmit = () => {
    // console.log(formData.flatValues);
    const data = { ...formData.flatValues, fechaFactura: date };
    handleSaveAttachedFiles(option);
  };

  return (
    <>
      {permittedActions.crear && (
        <>
          <div className="centered-form">
            <Formiz onValidSubmit={handleSubmit} connect={formData}>
              <form noValidate={true} onSubmit={formData.submit} className="container-wrapForm">
                <div className="new-container-wrapForm__tabs">
                  {formData.steps.map((step, index) => (
                    <button
                      key={step.name}
                      className={`new-tab-option ${
                        step.name === formData.currentStep.name ? 'is-active' : ''
                      }`}
                      type="button"
                      onClick={() => {
                        formData.goToStep(step.name);
                      }}
                    >
                      {!step.isValid && step.isSubmitted && <small className="mr-2">⚠️</small>}
                      {step.label}
                    </button>
                  ))}
                </div>

                <div className="container-wrapForm-content">
                  <FormizStep name="step-1" label={formatterText('nav.parent.3.child.option.10', 'Conciliaciones')}>
                    <section className="container-wrapForm-content">
                      <Attachments
                        currentFiles={archivos}
                        setCurrentFiles={setCurrentFiles}
                        isEdited={false}
                        uploadNewFile={handleSaveAttachedFiles}
                        type={6} //para facturas
                        showParameters={true}
                      />
                      <section className="grid-container-3c">
                        <div className="d-flex">
                          <FormControl className="d-flex">
                            <RadioGroup
                              aria-labelledby="demo-controlled-radio-buttons-group"
                              name="controlled-radio-buttons-group"
                              defaultValue={value}
                              value={value}
                              onChange={handleChange}
                            >
                              <FormControlLabel
                                value="ticket"
                                control={<Radio color={'primary'} />}
                                label={formatterText('label.text.billing.upload.ticket', 'Subir por ticket')}
                                className="w100-container"
                              />
                              <FormControlLabel
                                value="expediente"
                                control={<Radio />}
                                label={formatterText('label.text.billing.upload.exp', 'Subir por Expediente')}
                              />
                            </RadioGroup>
                          </FormControl>
                        </div>
                      </section>
                    </section>
                  </FormizStep>
                </div>
                <div className="demo-form__footer">
                  <section className="form-responsive-container-buttons">
                    <button
                      /*  disabled={
                    isLoading || (!myForm.isValid && myForm.isSubmitted)
                  } */
                      type="submit"
                      className="btn-primary"                    >
                     {formatterText('btn.save', 'Guardar')}
                    </button>
                    <button
                      className="input-cancel"
                      onClick={() => navigate(paths.panelNotifications)}
                    >
                      <FormattedMessage
                        id="alert.button.cancel.general"
                        defaultMessage="Cancelar"
                      />
                    </button>
                  </section>
                </div>
              </form>
            </Formiz>
          </div>
        </>
      )}
    </>
  );
};

export default Invoice;
