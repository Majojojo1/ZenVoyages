/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
// Import Hooks
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import { useNavigate } from 'react-router-dom';
// Import Components
import RolSelector from 'common/RolSelector';
import Selector from 'common/Selector';
import HandleOnError from 'common/validators/HandleOnError';
import CustomAlert from 'components/CustomAlert';
// Import Assets
import './edit.css';
// Import libs
import Cookie from 'js-cookie';
import { FormattedMessage } from 'react-intl';
import Swal from 'sweetalert2';
// Import services
import { FilterActive } from 'common/validators/FilterActives';
import { TEXTREGEXWITHPOINTS } from 'common/validators/Regex';
import { useSeachContext } from 'context/SearchContext';
import endpoints from 'services/api';
import { addItem, getAll } from 'services/api/methods';
import { addUser, empleadoGetByUserAsing, tercerosGetByUserAsing } from 'services/api/users';
import paths from 'services/paths';

export default function Edit() {
  // use Hook of language v2
  const { formatterText } = useLangv2();
  const { setDataTable, setSearch } = useSeachContext();

  const { loading, toggleLoading } = useGetData();
  const [formData, setFormData] = useState({
    idUsuario: null,
    usuario: '',
    correo: '',
    estado: 2,
    avatarUrl:
      'https://png.pngtree.com/png-vector/20190710/ourlarge/pngtree-user-vector-avatar-png-image_1541962.jpg',
    idIdioma: {
      idIdioma: 1,
      idioma: 'Español',
    },
    idEmpleado: null,
    idTercero: null,
    idAsesorCliente: null,
    codigo: null,
    usuarioCreacion: Cookie.get('idUsuario'),
    dobleAutenticacion: 0,
    tipoAcceso: '',
  });

  // Estado del id de la entidad (Empleado o Tercero)
  const [entity, setEntity] = useState({
    entidad: null,
    entidadId: 0,
  });

  const [selectorData, setSelectorData] = useState([]);
  const [selectValue, setSelectValue] = useState('');

  const navigate = useNavigate();

  //Rol selector
  const [roles, setRoles] = useState([]);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [toggleSelector, setToggleSelector] = useState(false);
  const [listUsers, setListUsers] = useState([]);
  const [acces, setAcces] = useState({
    mobile: false,
    web: false,
  });

  useEffect(() => {
    getRoles();
    getListUsers();
    setSearch([]);
  }, []);

  useEffect(() => {
    setSelectorData([]);
    setSelectValue(formatterText('p.select.option'));
    switch (entity.entidad) {
      case 'tercero':
        getThirdParties();
        break;
      case 'empleado':
        getEmployees();
        break;
      case 'cliente':
        getAsesors();
        break;
      default:
        break;
    }
  }, [entity.entidad]);

  const getListUsers = () => {
    getAll(endpoints.users.getAllUsers)
      .then((ans) => {
        const res = ans.response;
        let newArray = [];
        res.map((item) => {
          return newArray.push({
            idUser: item.idUsuario,
            idEmpleado: item.idEmpleado?.idEmpleado,
            idAsesorCliente: item.idAsesorCliente?.idAsesor,
            idTercero: item.idTercero?.idTercero,
          });
        });
        setListUsers(newArray);
      })
      .catch((err) => {});
  };

  const getThirdParties = () => {
    toggleLoading(true);
    // getAllThirdParties() replaced by tercerosGetByUserAsing
    tercerosGetByUserAsing()
      .then((res) => {
        let newArray = [];
        res.map((item) => {
          if (item.estado === 1) {
            //verify if the user is already assigned to a third party or not
            const newLabel = `${item.nombre} - ${item.identificacion}`;
            return newArray.push({
              value: item.idTercero,
              label: newLabel,
            });
          }
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  const getEmployees = () => {
    toggleLoading(true);
    // getAllEmployees() replaced by empleadoGetByUserAsing
    empleadoGetByUserAsing()
      .then((res) => {
        console.log(res);
        let newArray = [];
        res.map((item) => {
          //verify if the user is already assigned to an employee or not
          let newLabel = `${item.primerNombre} ${item.primerApellido} - ${item.identificacion}`;
          return newArray.push({
            value: item.idEmpleado,
            label: newLabel,
          });
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getAsesors = () => {
    toggleLoading(true);
    getAll(endpoints.advisers.getAllAdvisers)
      .then((ans) => {
        const res = ans;
        let newArray = [];
        res.map((item) => {
          //verify if the user is already assigned to an adviser or not
          let isAssigned = listUsers.find((user) => user.idAsesorCliente === item.idAsesor);
          if (isAssigned) {
            return;
          }
          let newLabel = `${item.nombres}`;
          return newArray.push({
            value: item.idAsesor,
            label: newLabel,
          });
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getRoles = () => {
    getAll(endpoints.roles.getAllRolesActivos)
      .then((data) => {
        setRoles(FilterActive(data));
        setDataTable(FilterActive(data));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // function when the user press the button to create a new user
  const handleSubmit = (event) => {
    event.preventDefault();
    let tipoAcceso;

    if (acces.mobile && acces.web) {
      tipoAcceso = 3;
    } else if (acces.mobile && acces.web === false) {
      tipoAcceso = 2;
    } else if (acces.web && acces.mobile === false) {
      tipoAcceso = 1;
    } else {
      tipoAcceso = null;
    }

    let data = {};

    switch (entity.entidad) {
      case 'tercero':
        data = {
          ...formData,
          tipoAcceso: tipoAcceso,

          idTercero: {
            idTercero: entity.entidadId,
          },
        };
        break;
      case 'empleado':
        data = {
          ...formData,
          tipoAcceso: tipoAcceso,
          idEmpleado: {
            idEmpleado: entity.entidadId,
          },
        };
        break;
      case 'cliente':
        data = {
          ...formData,
          tipoAcceso: tipoAcceso,
          idAsesorCliente: {
            idAsesor: entity.entidadId,
          },
        };
        break;
      default:
        break;
    }

    if (selectedRoles.length === 0) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Error',
        text: 'Debes seleccionar un rol',
        confirmButtonColor: '#FFC954',
      });
    } else if (tipoAcceso === null) {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Error',
        text: 'Debes seleccionar un tipo de acceso',
        confirmButtonColor: '#FFC954',
      });
    } else {
      postUser(data);
    }
  };

  const statusMessages = (status) => {
    let msg = 'Verifique los datos ingresados, la entidad debe tener al menos una persona asociada';

    if (status === 412) {
      msg = 'El usuario / correo ya esta en uso';
    }
    if (status === 428) {
      msg = 'Correo erroneo o inactivo';
    }

    HandleOnError(msg);
  };

  const postUser = (data) => {
    Swal.fire({
      title: formatterText('alert.title.general', 'Atención, estás seguro de realizar esta acción'),
      text:
        selectedRoles.length === 0
          ? formatterText('alert.title.users.without.roles')
          : formatterText('alert.title.users.creation'),
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: formatterText('btn.create.user'),
      allowOutsideClick: false,
      cancelButtonText: formatterText('alert.button.cancel.general', 'Cancelar'),
      preConfirm: async () => {
        addUser(data)
          .then((response) => {
            asociateRole(response.idUsuario);
          })
          .catch((err) => {
            statusMessages(err.response.status);
          });
      },
    });
  };

  const asociateRole = (id) => {
    const roles = selectedRoles.map((rol) => {
      return { idRol: rol.idRol };
    });

    const data = {
      idUsuario: id,
      roles: roles,
    };

    addItem(endpoints.users.insertRolesByUser, JSON.stringify(data))
      .then((response) => {
        if (response) {
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText('alert.title.user.created'),
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.users),
          });
        } else {
          HandleOnError(formatterText('alert.title.role.not.associated'));
        }
      })
      .catch((err) => HandleOnError(formatterText('alert.title.role.not.associated')));
  };

  const sortData = (selected) => {
    // sort the selected roles by name ASC
    selected.sort((a, b) => {
      if (a.nombre < b.nombre) {
        return -1;
      }
      if (a.nombre > b.nombre) {
        return 1;
      }
      return 0;
    });
  };

  const handleAddRole = (rol) => {
    const newRoles = roles.filter((currentRol) => currentRol.nombre !== rol.nombre);
    setDataTable(newRoles);
    setRoles(newRoles);
    let selected = [...selectedRoles, rol];
    sortData(selected);
    setSelectedRoles(selected);
    setToggleSelector(!toggleSelector);
  };

  const handleRemoveRole = (e, rol) => {
    e.preventDefault();
    const selected = selectedRoles.filter((currentRol) => currentRol.nombre !== rol.nombre);
    sortData(selected);
    setSelectedRoles(selected);
    setRoles([...roles, rol]);

    setDataTable([...roles, rol]);
  };

  const handleText = (e) => {
    if (e.target.value.match(TEXTREGEXWITHPOINTS)) {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
      });
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
    });
  };

  return (
    <form className="form-responsive" onSubmit={handleSubmit}>
      <section className="grid-container-1c zero-gap">
        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="table.title.user" defaultMessage="Usuario" />
          </span>
          <input
            className="input-default-3c"
            type="text"
            placeholder={formatterText(
              'input.placeholder.userName',
              'Ingrese el nombre de usuario',
            )}
            name="usuario"
            id="usuario"
            value={formData.usuario}
            onChange={handleText}
            maxLength="45"
            required
            onPaste={(e) => {
              e.preventDefault();
              return false;
            }}
            autoComplete="off"
          />
        </section>

        <section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="p.email" defaultMessage="Correo electrónico" />
          </span>
          <input
            className="input-default-3c"
            type="email"
            placeholder={formatterText('input.placeholder.email', 'Ingrese el correo electrónico')}
            name="correo"
            value={formData.correo}
            id="correo"
            onChange={handleChange}
            maxLength="100"
            required
          />
        </section>
        <section
          className="d-flex"
          style={{
            height: 'auto',
          }}
        >
          <span className="text-inline-md">
            <FormattedMessage id="table.name.search.rols" defaultMessage="Roles" />
          </span>
          <div style={{ width: '100%' }}>
            <div
              style={{ display: 'flex', flexWrap: 'wrap', width: 'inherit' }}
              className="input-edit inputRole"
            >
              <button
                onClick={(e) => {
                  e.preventDefault();
                  setToggleSelector(!toggleSelector);
                  setSearch('')
                }}
                className="add-role"
              >
                <FormattedMessage id="p.addRole" defaultMessage="Añadir rol +" />
              </button>
              {selectedRoles.map((rol, index) => (
                <button
                  key={`${index + 1}`}
                  onClick={(e) => handleRemoveRole(e, rol)}
                  className="role-item"
                >
                  {rol.nombre} {rol.estado === 1 ? '(Activo)' : '(Inactivo)'}
                  <div></div>
                </button>
              ))}
            </div>
            {toggleSelector && (
              <RolSelector
                // searchResults={searchResults}
                handleAdd={handleAddRole}
                // handleSearch={handleSearch}
              />
            )}
          </div>
        </section>

        <section section className="d-flex">
          <span className="text-inline-md">
            <FormattedMessage id="p.accesType" defaultMessage="Tipo de acceso" />
          </span>
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'space-evenly',
            }}
          >
            <button
              style={{ marginRight: '20px' }}
              className={acces.mobile ? 'create-user-button button-selected' : 'create-user-button'}
              onClick={(e) => {
                e.preventDefault();
                setAcces({ ...acces, mobile: !acces.mobile });
              }}
            >
              <FormattedMessage id="p.mobile" defaultMessage="Móvil" />
            </button>
            <button
              className={acces.web ? 'create-user-button button-selected' : 'create-user-button'}
              onClick={(e) => {
                e.preventDefault();
                setAcces({ ...acces, web: !acces.web });
              }}
            >
              <FormattedMessage id="p.web" defaultMessage="Web" />
            </button>
          </div>
        </section>
        <section className="d-flex spacing-t1">
          <span className="text-inline-md">
            <FormattedMessage id="p.entity" defaultMessage="Entidad" />
          </span>
          <section className="w100-container">
            <Selector
              name="entidad"
              data={[
                {
                  label: formatterText('input.placeholder.third', 'Tercero'),
                  value: 'tercero',
                },
                {
                  label: formatterText('input.placeholder.employee', 'Empleado'),
                  value: 'empleado',
                },
                {
                  label: formatterText('input.placeholder.clientAssesor', 'Asesor Cliente'),
                  value: 'cliente',
                },
              ]}
              placeholder={
                <FormattedMessage
                  id="input.placeholder.select"
                  defaultMessage="Selecione una opción"
                />
              }
              dataValue={entity}
              setterFunction={setEntity}
              isRequired={true}
            />
          </section>
        </section>
        <section className="d-flex spacing-t1">
          <span className="text-inline-md">
            <FormattedMessage id="p.assigned.to" defaultMessage="Asignado a" />
          </span>
          <section className="w100-container">
            {selectorData.length > 0 && (
              <Selector
                name="entidadId"
                data={selectorData}
                placeholder={
                  <FormattedMessage
                    id="input.placeholder.select"
                    defaultMessage="Selecione una opción"
                  />
                }
                dataValue={entity}
                setterFunction={setEntity}
                isLoading={loading}
                selectValue={entity}
                isRequired={true}
              />
            )}
          </section>
        </section>
      </section>

      <div className="form-responsive-container-buttons">
        <button type="submit" className="btn-primary">
          <FormattedMessage id="btn.regUser" defaultMessage="Registrar usuario" />
        </button>
        <button className="input-cancel" onClick={() => navigate(paths.users)}>
          <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
        </button>
      </div>
    </form>
  );
}
