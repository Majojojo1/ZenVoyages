import Typography from '@mui/material/Typography';
import RolSelector from 'common/RolSelector';
import Selector from 'common/Selector';
import { FilterActive } from 'common/validators/FilterActives';
import HandleOnError from 'common/validators/HandleOnError';
import { TEXTREGEXWITHPOINTS } from 'common/validators/Regex';
import CustomAlert from 'components/CustomAlert';
import { useSeachContext } from 'context/SearchContext';
import useGetData from 'hooks/useGetData';
import useLangv2 from 'hooks/useLangv2';
import Cookie from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { useNavigate, useParams } from 'react-router-dom';
import endpoints from 'services/api';
import { addItem, getAll, getItemById, updateItem } from 'services/api/methods';
import { empleadoGetByUserAsing, tercerosGetByUserAsing } from 'services/api/users';
import paths from 'services/paths';
import Swal from 'sweetalert2';
import './edit.css';

export default function Edit() {
  const { loading, toggleLoading } = useGetData();
  const navigate = useNavigate();
  const { setDataTable, setSearch } = useSeachContext();

  const { id } = useParams();

  const [formData, setFormData] = useState({
    idUsuario: 999999999,
    usuario: '',
    correo: '',
    estado: 2,
    avatarUrl:
      'https://png.pngtree.com/png-vector/20190710/ourlarge/pngtree-user-vector-avatar-png-image_1541962.jpg',
    idIdioma: {
      idIdioma: 1,
      idioma: 'Español',
    },
    idEmpleado: null,
    idTercero: null,
    codigo: null,
    usuarioCreacion: Cookie.get('idUsuario'),
    dobleAutenticacion: 0,
    tipoAcceso: '',
  });

  // Estado del id de la entidad (Empleado o Tercero)
  const [entity, setEntity] = useState({
    entidad: null,
    entidadId: 0,
  });

  const [selectorData, setSelectorData] = useState([]);
  const [selectValue, setSelectValue] = useState('');
  const [listUsers, setListUsers] = useState([]);
  const [auxPlaceholder, setAuxPlaceholder] = useState('');
  const [entityPlaceholder, setEntityPlaceholder] = useState('');

  //Rol selector
  const [originalRoles, setOriginalRoles] = useState([]);

  // use Hook of language v2
  const { formatterText, customSB } = useLangv2();

  const handleChange = (e) => {
    if (e.target.value.match(TEXTREGEXWITHPOINTS)) {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value.replaceAll(/\s{2,}/gi, ' '),
      });
    }
  };  

  const [roles, setRoles] = useState([]); 
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [originalUsername, setOriginalUsername] = useState('');
  const [toggleSelector, setToggleSelector] = useState(false);
  const [acces, setAcces] = useState({
    mobile: false,
    web: false,
  });

  const sortData = (selected) => {
    // sort the selected roles by name ASC
    selected.sort((a, b) => {
      if (a.nombre < b.nombre) {
        return -1;
      }
      if (a.nombre > b.nombre) {
        return 1;
      }
      return 0;
    });
  };

  const handleRemoveRole = (e, rol) => {
    e.preventDefault();
    const selected = selectedRoles.filter((currentRol) => currentRol.nombre !== rol.nombre);
    console.log(roles);
    sortData(selected);
    setSelectedRoles(selected);
    setRoles([...roles, rol]);
    setDataTable([...roles, rol]);   
    getRoles();
  };

  const handleAddRole = (rol) => {
    const rolNombre = rol.nombre;
    const newRoles = [];
    for (let i = 0; i < selectedRoles.length; i++) {
      if (selectedRoles[i].nombre === rolNombre) {
        newRoles.push(selectedRoles[i]);
      }
    }   
    if (newRoles.length === 0) {
      setDataTable(newRoles);  
      setRoles(newRoles);
      let selected = [...selectedRoles, rol];
      sortData(selected);
      setSelectedRoles(selected);
      setToggleSelector(false);
    } else {
      customSB('error', 'snackbar.rol.already.selected', 'EL codigo ya fue seleccionado');
    }
    getRoles();
  };

  const checkUsername = async (username) => {
    const lowerCaseUsername = username.toLowerCase();
    if (lowerCaseUsername === originalUsername.toLowerCase()) {
      return false;
    } else {
      for (let user of listUsers) {
        if (user.usuario.toLowerCase() === lowerCaseUsername) {
          return true;
        }
      }
      return false;
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    checkUsername(formData.usuario)
      .then((usernameExists) => {
        if (usernameExists) {
          HandleOnError(formatterText('alert.title.username.in.use'));
        } else {
          let tipoAcceso;

          if (acces.mobile && acces.web) {
            tipoAcceso = 3;
          } else if (acces.mobile && acces.web === false) {
            tipoAcceso = 2;
          } else if (acces.web && acces.mobile === false) {
            tipoAcceso = 1;
          } else {
            tipoAcceso = null;
          }

          let data = {};

          let conditionalSwitch = entity.entidad;

          switch (conditionalSwitch) {
            case 'tercero':
              data = {
                ...formData,
                tipoAcceso: tipoAcceso,

                idTercero: {
                  idTercero: entity.entidadId,
                },
              };
              break;
            case 'empleado':
              data = {
                ...formData,
                tipoAcceso: tipoAcceso,
                idEmpleado: {
                  idEmpleado: entity.entidadId,
                },
              };
              break;
            case 'cliente':
              data = {
                ...formData,
                tipoAcceso: tipoAcceso,
                idAsesorCliente: {
                  idAsesor: entity.entidadId,
                },
              };
              break;
            default:
              console.log(formatterText('alert.title.no.entity.selected'));
              break;
          }

          if (tipoAcceso === null) {
            CustomAlert('short_msg', {
              icon: 'warning',
              title: 'Error',
              text: formatterText('alert.title.select.access.type'),
              confirmButtonColor: '#FFC954',
            });
          } else if (selectedRoles.length === 0) {
            CustomAlert('short_msg', {
              icon: 'warning',
              title: 'Error',
              text: formatterText('alert.title.select.role'),
            });
          } else {
            postUser(data);
          }
        }
      })
      .catch((error) => {
        HandleOnError(formatterText('alert.title.username.verification.error'));
      });
  };
  const asociateRole = (id) => {
    const roles = selectedRoles.map((rol) => {
      return { idRol: rol.idRol };
    });

    const data = {
      idUsuario: id,
      roles: roles,
    };

    addItem(endpoints.users.insertRolesByUser, JSON.stringify(data))
      .then((response) => {
        if (response) {
          CustomAlert('confirm_msg', {
            icon: 'success',
            title: formatterText('alert.title.confirm.general', 'Operación exitosa'),
            text: formatterText('alert.title.user.updated.successfully'), 
            confirmButtonText: formatterText('alert.button.continue', 'Continuar'),
            allowOutsideClick: false,
            executeFunction: () => navigate(paths.users),
          });
        } else {
          HandleOnError(formatterText('alert.title.role.not.associated'));
        }
      })
      .catch((err) => HandleOnError(formatterText('alert.title.role.not.associated')));
  };
 
  useEffect(() => {
    getRoles();
    getListUsers();
    setSearch([]);
  }, []);

  useEffect(() => {
    getListUsers();
    getUser(id);
  }, [id]);

  useEffect(() => {
    setSelectorData([]);
    setAuxPlaceholder(formatterText('p.select.option'));
    switch (entity.entidad) {
      case 'tercero':
        getThirdParties();
        break;
      case 'empleado':
        getEmployees();
        break;
      case 'cliente':
        getAdvisors();
        break;
      default:
    }
  }, [entity.entidad]);

  const getRoles = () => {
    getAll(endpoints.roles.getAllRolesActivos)
      .then((data) => {        
        setRoles(FilterActive(data));
        setDataTable(FilterActive(data));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getThirdParties = () => {
    toggleLoading(true);
    tercerosGetByUserAsing()
      .then((res) => {
        let newArray = [];
        res.map((item) => {
          let newLabel = `${item.nombre} - ${item.identificacion}`;
          newArray.push({
            value: item.idTercero,
            label: newLabel,
          });
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toggleLoading(false);
      });
  };

  const getEmployees = () => {
    toggleLoading(true);
    empleadoGetByUserAsing()
      .then((res) => {
        let newArray = [];

        res.forEach((item) => {
          let newLabel = `${item.primerNombre} ${item.primerApellido} - ${item.identificacion}`;
          newArray.push({
            value: item.idEmpleado,
            label: newLabel,
          });
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };

  const getListUsers = () => {
    getAll(endpoints.users.getAllUsers)
      .then((ans) => {
        const res = ans;
        let newArray = [];
        res.map((item) => {
          return newArray.push({
            idUser: item.idUsuario,
            username: item.usuario,
            idEmpleado: item.idEmpleado?.idEmpleado,
            idAsesorCliente: item.idAsesorCliente?.idAsesor,
            idTercero: item.idTercero?.idTercero,
            usuario: item.usuario,
          });
        });
        setListUsers(newArray);
        getUser(id);
      })
      .catch((err) => {});
  };

  const getAdvisors = () => {
    toggleLoading(true);
    getAll(endpoints.advisers.getAllAdvisers)
      .then((ans) => {
        const res = ans;
        let newArray = [];
        res.map((item) => {
          //verify if the user is already assigned to an adviser or not
          let isAssigned = listUsers.find((user) => user.idAsesorCliente === item.idAsesor);
          if (isAssigned) {
            return;
          }
          let newLabel = `${item.nombres}`;
          return newArray.push({
            value: item.idAsesor,
            label: newLabel,
          });
        });
        setSelectorData(newArray);
        toggleLoading(false);
      })
      .catch((err) => {
        toggleLoading(false);
      });
  };
  const handleChangeMail = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const getUser = (id) => {
    getItemById(endpoints.users.getUserById, id)
      .then((data) => {
        setFormData({
          idUsuario: data.idUsuario,
          usuario: data.usuario,
          correo: data.correo,
          clave: data.clave,
          estado: data.estado,
          dobleAutenticacion: data.dobleAutenticacion,
          fechaRegistro: data.fechaRegistro,
          fechaModificacion: data.fechaModificacion,
          tipoAcceso: data.tipoAcceso,
          avatarUrl: data.avatarUrl,
          idIdioma: data.idIdioma,
          usuarioCreacion: data.usuarioCreacion,
          usuarioModificacion: data.usuarioModificacion,
          roles: data.roles,
        });
        setOriginalUsername(data.usuario);

        if (data.tipoAcceso === 1) {
          setAcces({ ...acces, web: true });
        } else if (data.tipoAcceso === 2) {
          setAcces({ ...acces, mobile: true });
        } else if (data.tipoAcceso === 3) {
          setAcces({ web: true, mobile: true });
        }

        // llena la información si es tercero o empleado
        if (data.idEmpleado !== null) {
          setEntity({
            entidad: 'empleado',
            entidadId: data.idEmpleado.idEmpleado,
          });
          getEmployees();
          let userInfoEntity = `${data.idEmpleado.primerNombre} ${data.idEmpleado.segundoNombre} - ${data.idEmpleado.identificacion}`;
          setAuxPlaceholder(userInfoEntity);
          setEntityPlaceholder('Empleado');
        } else if (data.idTercero !== null) {
          setEntity({
            entidad: 'tercero',
            entidadId: data.idTercero.idTercero,
          });
          getThirdParties();
          let userInfoEntity = `${data.idTercero.nombre} - ${data.idTercero.identificacion}`;
          setAuxPlaceholder(userInfoEntity);
          setEntityPlaceholder('Tercero');
        } else if (data.idAsesorCliente !== null) {
          setEntity({
            entidad: 'cliente',
            entidadId: data.idAsesorCliente.idAsesor,
          });
          let userInfoEntity = `${data.idAsesorCliente.nombres} - ${data.idAsesorCliente.identificacion}`;
          setAuxPlaceholder(userInfoEntity);
          setEntityPlaceholder('Asesor de cliente');
        }

        getAll(endpoints.roles.getAllRolesActivos)
          .then((roles) => {
            let newRoles = roles.filter((rol) =>
              data.roles.find((element) => element.idRol === rol.idRol),
            );
            const filter = FilterActive(newRoles);
            setRoles(filter);           
            setSelectedRoles(data.roles);
            setOriginalRoles(data.roles);
          })
          .catch((error) => {
            console.log(error);
          });
      })
      .catch((err) => console.log(err));
  };

  const postUser = (data) => {
    Swal.fire({
      title: `${formatterText('question.swal.title.edit')}`,
      text:
        selectedRoles.length === 0
          ? `${formatterText('question.swal.title.edit.user.without.roles')}`
          : `${formatterText('question.swal.title.edit.user')}`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      showLoaderOnConfirm: true,
      cancelButtonColor: '#d33',
      confirmButtonText: `${formatterText('question.swal.title.edit.confirm')}`,
      allowOutsideClick: false,
      cancelButtonText: `${formatterText('question.swal.title.edit.cancel')}`,
      preConfirm: async () => {
        await updateItem(endpoints.users.updateUser, JSON.stringify(data))
          // .then((response) => response.json())
          .then((response) => {
            if (response) {
              const removedRoles = originalRoles.filter(
                (rol) => !selectedRoles.some((current) => rol.idRol === current.idRol),
              );
              if (removedRoles.length > 0) {
                removeRole(data.idUsuario, removedRoles);
              } else {
                asociateRole(data.idUsuario);
              }
            } else {
              HandleOnError(formatterText('alert.title.username.or.email.in.use') );
            }
          })
          .catch((error) => {
            HandleOnError(formatterText('alert.title.username.or.email.in.use') );
          });
      },
    });
  };

  const removeRole = (id, removedRoles) => {
    const roles = removedRoles.map((rol) => {
      return { idRol: rol.idRol };
    });

    const data = {
      idUsuario: id,
      roles: roles,
    };

    addItem(endpoints.users.deleteRolesByUser, JSON.stringify(data))
      .then((response) => {
        if (response) {
          asociateRole(id);
        } else {
          HandleOnError(formatterText('alert.title.roles.not.removed'));
        }
      })
      .catch((err) => HandleOnError(formatterText('alert.title.roles.not.removed')));
  };

  return (
    <div>
     
        <section className="container-profile">
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <div>
              <img
                src={formData.avatarUrl}
                alt="profile image"
                width="200"
                height="200"
                style={{ borderRadius: '50%' }}
              />
              <p
                style={{
                  marginTop: '8px',
                  fontWeight: 'bold',
                  color: '#747474',
                  textDecoration: 'underline',
                }}
              >
                <FormattedMessage
                  id="p.change.profile.pic"
                  defaultMessage="Editar foto de perfil"
                />
              </p>
            </div>

            <div style={{ textAlign: 'left', marginLeft: '30px' }}>
              <Typography
                variant="h1"
                sx={{
                  fontSize: '1.6rem',
                  fontWeight: 'bold',
                  color: '#8B909C',
                }}
              >
                <FormattedMessage id="p.user.name" defaultMessage="Nombre del usuario" />
              </Typography>
              <Typography
                variant="h1"
                sx={{
                  fontSize: '1rem',
                  fontWeight: 'bold',
                  color: '#0ED6B5',
                }}
              >
                {formatterText('table.title.user', 'Usuario') + ': ' + formData.usuario}
              </Typography>
            </div>
          </div>

          <Typography
            variant="h1"
            sx={{
              fontSize: '1.2rem',
              fontWeight: 'bold',
              color: '#0ED6B5',
            }}
          >
            {formData.estado === 1
              ? formatterText('p.active', 'Activo')
              : formData.estado === 0
              ? formatterText('p.unActive', 'No activo')
              : ''}{' '}
            {formData.estado === 2 && 'Inhabilitado'}
            <label className="switch">
              <input
                checked={formData.estado === 1}
                onChange={() => {
                  if (formData.estado === 1) {
                    setFormData({ ...formData, estado: 0 });
                  } else {
                    setFormData({ ...formData, estado: 1 });
                  }
                }}
                type="checkbox"
              />
              <span className="slider round"></span>
            </label>
          </Typography>
        </section>

        <form className="form-responsive" onSubmit={handleSubmit}>
          <section className="form-responsive-container-information">
            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="table.title.user" defaultMessage="Usuario" />
              </h3>

              <input
                className="input-edit"
                type="text"
                placeholder={formatterText(
                  'input.placeholder.userName',
                  'Ingrese el nombre de usuario',
                )}
                name="usuario"
                id="usuario"
                value={formData.usuario}
                onChange={handleChange}
                required
              />
            </section>

            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="table.title.email" defaultMessage="Correo electrónico" />
              </h3>

              <input
                className="input-edit"
                type="email"
                placeholder={formatterText(
                  'input.placeholder.email',
                  'Ingrese el correo electrónico',
                )}
                name="correo"
                value={formData.correo}
                id="correo"
                onChange={handleChangeMail}
                maxLength="40"
                required
              />
            </section>

            {formData.estado === 1 ? (
              <section className="form-responsive-information__option">
                <h3 className="p-styles">
                  <FormattedMessage id="table.name.search.rols" defaultMessage="Roles" />
                </h3>
                <div>
                  <div
                    style={{ display: 'flex', flexWrap: 'wrap' }}
                    className="input-edit inputRole"
                  >
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        setToggleSelector(!toggleSelector);
                        setSearch('')                       
                      }}
                      className="add-role"
                    >
                      <FormattedMessage id="p.addRole" defaultMessage="Añadir rol +" />
                    </button>
                    {selectedRoles.map((rol, index) => (
                      <button
                        key={index}
                        onClick={(e) => handleRemoveRole(e, rol)}
                        className="role-item"
                      >
                        {rol.nombre} {rol.estado === 1 ? '(Activo)' : '(Inactivo)'}
                        <div></div>
                      </button>
                    ))}
                  </div>
                  {toggleSelector && <RolSelector handleAdd={handleAddRole} />}
                </div>
              </section>
            ) : null}

            <section className="form-responsive-information__option">
              <h3 className="p-styles">
                <FormattedMessage id="p.accesType" defaultMessage="Tipo de acceso" />
              </h3>

              <div>
                <button
                  style={{ marginRight: '20px' }}
                  className={
                    acces.mobile ? 'create-user-button button-selected' : 'create-user-button'
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setAcces({ ...acces, mobile: !acces.mobile });
                  }}
                >
                  <FormattedMessage id="p.mobile" defaultMessage="Móvil" />
                </button>
                <button
                  className={
                    acces.web ? 'create-user-button button-selected' : 'create-user-button'
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setAcces({ ...acces, web: !acces.web });
                  }}
                >
                  <FormattedMessage id="p.web" defaultMessage="Web" />
                </button>
              </div>
            </section>
            {/* selector entity */}
            <section className="form-responsive-information__option spacing-t1">
              <h3 className="p-styles">
                <FormattedMessage id="p.entity" defaultMessage="Entidad" />
              </h3>
              <Selector
                name="entidad"
                data={[
                  {
                    label: formatterText('input.placeholder.third', 'Tercero'),
                    value: 'tercero',
                  },
                  {
                    label: formatterText('input.placeholder.employee', 'Empleado'),
                    value: 'empleado',
                  },
                  {
                    label: formatterText('input.placeholder.asesor', 'Asesor Cliente'),
                    value: 'cliente',
                  },
                ]}
                placeholder={entityPlaceholder}
                dataValue={entity}
                setterFunction={setEntity}
                isRequired={true}
              />
              {selectorData.length > 0 && (
                <Selector
                  name="entidadId"
                  data={selectorData}
                  placeholder={auxPlaceholder}
                  dataValue={entity}
                  setterFunction={setEntity}
                  isLoading={loading}
                  selectValue={selectValue}
                  isRequired={true}
                />
              )}
            </section>
          </section>
          <div className="form-responsive-container-buttons">
            <button type="submit" className="btn-primary">
              <FormattedMessage id="btn.edit.user" defaultMessage="Editar usuario" />
            </button>
            <button className="input-cancel" onClick={() => navigate(paths.users)}>
              <FormattedMessage id="btn.cancel" defaultMessage="Cancelar" />
            </button>
          </div>
        </form>
      
    </div>
  );
}
