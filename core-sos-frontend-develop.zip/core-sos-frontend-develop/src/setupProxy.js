const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function(app) {
  app.use(
    "/api-sos",
    createProxyMiddleware({
      target: "http://44.204.46.216:8080",
      changeOrigin: true,
    })
  );
};
