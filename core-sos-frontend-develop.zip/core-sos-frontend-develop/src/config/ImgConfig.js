import fileDefault from '../assets/FlatFile.png';

// Here can also be added some new types of files.

export const ImgConfig = {
    default: fileDefault
}
