class Example {
  constructor(
    nombre,
    apellido,
    estado,
    numero,
    usuarioCreacion,
    usuarioModificacion
  ) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.estado = estado;
    this.numero = numero;
    this.usuarioCreacion = usuarioCreacion;
    this.usuarioModificacion = usuarioModificacion;
  }
}

export default Example;
