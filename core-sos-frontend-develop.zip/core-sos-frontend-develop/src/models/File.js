import Cookie from "js-cookie";

class File {
  constructor(
    idTipoArchivoAdjunto = null,
    nombre = "",
    extension = "",
    pesoMaximoArchivo = "",
    estado = "1",
    descripcion = "",
    fecha_registro = new Date(),
    cantidadMaxima = 1,
    fecha_modificacion = "",
    usuario_creacion = parseInt(Cookie.get("idUsuario")),
  ) {
    this.idTipoArchivoAdjunto = idTipoArchivoAdjunto;
    this.nombre = nombre;
    this.extension = extension;
    this.pesoMaximoArchivo = pesoMaximoArchivo;
    this.estado = estado;
    this.descripcion = descripcion;
    this.cantidadMaxima = cantidadMaxima;
    this.fechaCreacion = fecha_registro;
    this.fechaModificacion = fecha_modificacion;
    this.usuarioCreacion = usuario_creacion;
  }
}

export default File;
