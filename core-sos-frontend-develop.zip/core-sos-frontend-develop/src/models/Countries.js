class Countries {
  constructor(
    idPais,
    codigoPais,
    nombrePais,
    prefijo,
    estado,
    fechaCreacion,
    usuarioCreacion,
    usuarioModificacion
  ) {
    this.idPais = idPais;
    this.codigoPais = codigoPais;
    this.nombrePais = nombrePais;
    this.prefijo = prefijo;
    this.estado = estado;
    this.fechaCreacion = fechaCreacion;
    this.usuarioCreacion = usuarioCreacion;
    this.usuarioModificacion = usuarioModificacion;
  }
}

export default Countries;
