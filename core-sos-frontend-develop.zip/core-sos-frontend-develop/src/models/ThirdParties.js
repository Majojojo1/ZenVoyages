class ThirdParties {
  constructor(
    idTercero = null,
    nombre = "",
    idTipoDocumento = 0,
    documento = "",
    abrebiatura = "",
    regimen = "",
    identificacion = "",
    idMunicipio = 0,
    direccion = "",
    telefono = "",
    telefonoAlterno = "",
    sitioWeb = "",
    correo = "",
    idTipoTercero = 0,
    estado = 1,
    fechaRegistro = null,
    fechaModificacion = null,
    usuario_creacion = null,
    usuarioModificacion = null
  ) {
    this.idTercero = idTercero;
    this.nombre = nombre;
    this.idTipoDocumento = idTipoDocumento;
    this.documento = documento;
    this.abrebiatura = abrebiatura;
    this.regimen = regimen;
    this.identificacion = identificacion;
    this.idMunicipio = idMunicipio;
    this.direccion = direccion;
    this.telefono = telefono;
    this.telefonoAlterno = telefonoAlterno;
    this.sitioWeb = sitioWeb;
    this.correo = correo;
    this.idTipoTercero = idTipoTercero;
    this.estado = estado;
    this.fechaRegistro = fechaRegistro;
    this.fechaModificacion = fechaModificacion;
    this.usuario_creacion = usuario_creacion;
    this.usuarioModificacion = usuarioModificacion;
  }
}

export default ThirdParties;
