import Cookie from "js-cookie";

class BillingType {
  constructor(
    idTipoFacturacion = null,
    nombre = "",
    codigo = "",
    descripcion = "",
    estado = 1,
    fechaRegistro = "",
    fechaModificacion = "",
    usuarioCreacion = Cookie.get("idUsuario"),
    usuarioModificacion = Cookie.get("idUsuario")
  ) {
    this.idTipoFacturacion = idTipoFacturacion;
    this.nombre = nombre;
    this.codigo = codigo;
    this.descripcion = descripcion;
    this.estado = estado;
    this.fechaRegistro = fechaRegistro;
    this.fechaModificacion = fechaModificacion;
    this.usuarioCreacion = usuarioCreacion;
    this.usuarioModificacion = usuarioModificacion;
  }
}

export default BillingType;
