import useAxios from 'hooks/useAxios';
import { useEffect, useState } from 'react';
import { getPerssimionModuleByUser } from 'services/api/roles';

export default function usePermission() {
  const [permissions, setPermissions] = useState([]);
  const { COOKIE_USER } = useAxios();

  // Obtiene todos los permisos al cargar la pagina
  const _allPermission = () => {
    getPerssimionModuleByUser(COOKIE_USER).then((resp) => {      
      const modules = resp.map((elem) => ({
        idModulo: elem.idModulo,
        nombreModulo: elem.nombreModulo,
      }));
      setPermissions(resp);
    });
  };

  // Filtra los permisos correspondientes a cada modulo
  const permissionPerModule = (module) => {
    const filterModule = permissions.filter((item) => item.idModulo === module);
    return filterModule;
  };

  // permissions access
  useEffect(() => {
    const currentURL = window.location.href;
    if (!currentURL.endsWith('/#/login')) {
      _allPermission();
    }
  }, []);

  return { permissions, permissionPerModule };
}
