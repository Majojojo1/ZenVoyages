import { es, enUS } from "date-fns/locale";
const LANGS = {
  "en-ES": es,
  "en-US": enUS,
};

export default LANGS;
