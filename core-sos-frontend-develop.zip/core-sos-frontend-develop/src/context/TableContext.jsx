import React, { createContext, useState } from "react";
import { searchDataTable } from "common/utils/searchDataTable";

export const TableContext = createContext();

export function TableWrapper({ children }) {
  const [searchResults, setSearchResults] = useState("");
  const [dataTable, setDataTable] = useState(null);

  const handleSearch = (e) => {
    const search = searchDataTable({
      data: dataTable,
      query: e?.target?.value || "",
    });

    setSearchResults(search);
  };

  return (
    <TableContext.Provider
      value={{
        searchResults,
        setSearchResults,
        dataTable,
        setDataTable,
        handleSearch,
      }}
    >
      {children}
    </TableContext.Provider>
  );
}
