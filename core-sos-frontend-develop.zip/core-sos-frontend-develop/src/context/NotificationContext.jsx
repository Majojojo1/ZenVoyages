import React, { createContext, useState } from "react";
// Import Hooks
import useGetData from "hooks/useGetData";

// Import services
import { getAll } from "services/api/methods";
import endpoints from "services/api";
// Import libs
import SortData from "components/utils/SortData";
import { searchDataTable } from "common/utils/searchDataTable";

export const SearchContext = createContext();

export function SearchWrapper({ children }) {
  const [searchResults, setSearchResults] = useState([]);
  const [dataTable, setDataTable] = useState([]);
  const [search, setSearch] = useState("");
  const {
    loading,
    error,
    toggleLoading,
    toggleError,
    handleClick,
    displayMessage,
    displayLoading,
  } = useGetData();

  const handleSearch = (e) => {
    const search = searchDataTable({
      data: dataTable,
      query: e?.target?.value || "",
    });

    setSearchResults(search);
  };

  // función para cargar datos de la tabla de actividades
  const getDataTable = () => {
    // show loading
    toggleLoading(true);

    getAll(endpoints.activitiesServices.getAllActivitiesServicesBasic)
      .then((data) => {
        let newArray = [];
        data.forEach((item) => {
          handleStructureItems(newArray, item);
        });
        const sortedArray = SortData(newArray, "asc");
        setSearchResults(sortedArray);
        setDataTable(newArray);
        // show loading
        toggleLoading(false);
      })
      .catch((err) => {
        console.log(err);
        // mostrar error
        toggleError(!error);
        handleClick();
      });
  };

  const handleStructureItems = (newArray, item) => {
    newArray.push({
      id: item.idActividad,

      nombre: item.nombre,
      descripcion: item.descripcion,
      sku1: item.sku,

      estado: item.estado,
      objeto: { ...item },
    });
  };

  return (
    <SearchContext.Provider
      value={{
        searchResults,
        setSearchResults,
        dataTable,
        setDataTable,
        handleSearch,
        search,
        setSearch,
        loading,
        error,
        toggleLoading,
        toggleError,
        handleClick,
        displayMessage,
        displayLoading,
        handleStructureItems,
        getDataTable,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
}
