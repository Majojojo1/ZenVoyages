import uploadImg from "assets/uploadImg.png";
import HandleOnError from 'common/validators/HandleOnError';
import PropTypes from "prop-types";
import React, { useRef, useState } from "react";
import { ImgConfig } from "../../config/ImgConfig";

import CustomAlert from "components/CustomAlert";
import "./drop-file-input.css";

// Import required AWS SDK clients and commands for Node.js.
import { S3 } from "aws-sdk";

// import { PutObjectCommand } from "@aws-sdk/client-s3";
// import { s3Client } from "./libs/s3Client.js"; // Helper function that creates an Amazon S3 service client module.
// import { path } from "path";
// import { fs } from "fs";

const DropFileInput = (props) => {
  const wrapperRef = useRef(null);
  const [fileList, setFileList] = useState([]);
  const onDragEnter = () => wrapperRef.current.classList.add("dragover");
  const onDragLeave = () => wrapperRef.current.classList.remove("dragover");
  const onDrop = () => wrapperRef.current.classList.remove("dragover");
  const [uploadStatus, setUploadStatus] = useState(null);
  const fileInput = useRef(null);

  const onError = (error) => {
    CustomAlert("short_msg", {
      icon: "error",
      title: "Oops... ha ocurrido un error",
      text: error,
    });
  };

  const onSuccess = (sucess) => {
    CustomAlert("short_msg", {
      icon: "success",
      title: "Acción realizada correctamente",
      text: sucess,
    });
  };

  //AWS upload

  const handleUpload = () => {
    // Obtiene el archivo seleccionado por el usuario
    const file = fileInput.current.files[0];

    // Inicializa la AWS SDK
    const s3 = new S3({
      accessKeyId: "YOUR_ACCESS_KEY_ID",
      secretAccessKey: "YOUR_SECRET_ACCESS_KEY",
    });

    // Crea un params object para subir el archivo a S3
    const params = {
      Bucket: "YOUR_BUCKET_NAME",
      Key: file.name,
      Body: file,
    };

    // Llama al método putObject de la AWS SDK para subir el archivo a S3
    s3.putObject(params, (err, data) => {
      if (err) {
        setUploadStatus("Error");
      } else {
        setUploadStatus("Success");
      }
    });
  };

  function uploadFile(e) {
    //try catch para que no se cargue el archivo, si no se selecciona ninguno
    try {
      //Obtención de el archivo seleccionado y su tamaño
      let file = e.target.files[0];

      let fileSize = e.target.files[0].size;
      //If que valida si el archivo tiene un tamaño menor a 5MB
      if (fileSize < 5000000) {
        //If que valida si el archivo el .xlsx, si no lo es, no se encola y se muestra el modal de error
        if (!file.name.match(/\.(xlsx|XLSX)$/)) {
          HandleOnError("El archivo seleccionado debe ser de extensión .xlsx");
          e.target.value = null;
          //Si es .xlsx, se encola el archivo y se muestra el modal de éxito en la subida
        } else if (file) {
          const updatedList = [...fileList, file];
          setFileList(updatedList);
          props.onFileChange(updatedList);
          onSuccess("Archivo subido con éxito");
        }
      } else {
        HandleOnError("El archivo supera los 5MB");
      }
    } catch (error) {
      console.log("error", error);
    }
  }

  const fileRemove = (file) => {
    const updatedList = [...fileList];
    updatedList.splice(fileList.indexOf(file), 1);
    setFileList(updatedList);
    props.onFileChange(updatedList);
  };

  return (
    <>
      <div
        ref={wrapperRef}
        className="drop-file-input"
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
      >
        <div className="drop-file-input__label">
          <img src={uploadImg} alt="uploadImg" />
          <p>Arrastre y suelte sus archivos aquí</p>
          <p>ó</p>
          <button className="btnBrowse">Busque sus archivos</button>
        </div>
        <input
          id="file-input"
          type="file"
          value=""
          accept=".xlsx"
          onChange={uploadFile}
        />
      </div>
      <div>
        <input type="file" ref={fileInput} />
        <button onClick={handleUpload}>Subir a AWS</button>
        {uploadStatus === "Success" && (
          <p>El archivo se ha subido correctamente a S3</p>
        )}
        {uploadStatus === "Error" && (
          <p>Se ha producido un error al subir el archivo a S3</p>
        )}
      </div>
      {fileList.length > 0 ? (
        <div className="drop-file-preview">
          <p className="drop-file-preview__title">Listo para subir</p>
          {fileList.map((item, index) => (
            <div key={index} className="drop-file-preview__item">
              <img src={ImgConfig["default"]} alt="" />
              <div className="drop-file-preview__item__info">
                <p>{item.name}</p>
                <p>{item.size} B</p>
              </div>
              <span
                className="drop-file-preview__item__del"
                onClick={() => fileRemove(item)}
              >
                x
              </span>
            </div>
          ))}
        </div>
      ) : null}
    </>
  );
};

DropFileInput.propTypes = {
  onFileChange: PropTypes.func,
};

export default DropFileInput;
