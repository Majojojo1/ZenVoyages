const CONFIG = {

}

const granttDiagram = ({props})=>{


}


export default granttDiagram;

