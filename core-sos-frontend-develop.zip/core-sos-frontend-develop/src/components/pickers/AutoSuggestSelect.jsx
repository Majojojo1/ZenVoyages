import { useState, useEffect } from "react";
// Import Material UI Components
import CircularProgress from "@mui/material/CircularProgress";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
// Import Libs
import PropTypes from "prop-types";
// Import Styles
import styles from "./AutoSuggestSelect.module.css";
function sleep(delay = 0) {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
}

export default function AutoSuggestSelect({
  name,
  selectValues,
  selectValue,
  setterFunction,
  val,
  setVal,
  getData,
  handleStructureData,
  placeholder,
}) {
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const loading = open && options.length === 0;

  useEffect(() => {
    let active = true;

    if (!loading) {
      return undefined;
    }

    (async () => {
      if (active && val.length >= 3) {
        const response = await getData(val);
        await sleep(1e3);
        const data = await response.json();
        let newArray = [];
        Object.keys(data).forEach((key) => {
          handleStructureData(newArray, data, key);
        });
        setOptions(newArray);
      }
    })();

    return () => {
      active = false;
    };
  }, [loading, val]);

  useEffect(() => {
    if (!open) {
      setOptions([]);
    }
  }, [open]);

  return (
    <Autocomplete
      id={name}
      style={{ width: 300 }}
      className={styles.container}
      value={selectValue}
      open={open}
      onOpen={() => {
        setOpen(true);
      }}
      onClose={() => {
        setOpen(false);
      }}
      getOptionSelected={(option, value) => option.id === value.id}
      getOptionLabel={(option) => {
        if (option.hasOwnProperty("label")) {
          return option.label;
        }
        return option;
      }}
      options={options}
      loading={loading}
      sx={{ padding: 0, margin: 0 }}
      onChange={(event, newValue) => {
        if (newValue === null) {
          setterFunction((prev) => ({
            ...prev,
            [name]: {
              id: 0,
              label: "",
            },
          }));
        } else {
          setterFunction({
            ...selectValues,
            [name]: newValue,
          });
        }
      }}
      classes={{
        option: styles.menuItem,
        listbox: styles.menuList,
        noOptions: styles.noOptions,
        groupLabel: styles.headerItem,
        notchedOutline: styles.notchedOutline,
        input: styles.inputData,
      }}
      renderInput={(params, index) => (
        <TextField
          {...params}
          key={index}
          label={placeholder}
          variant="outlined"
          value={val}
          onChange={(e) => {
            setVal(e.target.value);
          }}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
    />
  );
}

AutoSuggestSelect.propTypes = {
  name: PropTypes.string,
  selectValue: PropTypes.object,
  setterFunction: PropTypes.func,
  data: PropTypes.object,
  placeholder: PropTypes.string,
};
