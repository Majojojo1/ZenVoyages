import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import CustomAlert from 'CustomAlert';
import React, { useRef } from 'react';
import { IoIosArrowForward } from 'react-icons/io';
// importar hooks
import useToggle from 'hooks/useToggle';
// importar endpoints
import Cookie from 'js-cookie';
import endpoints from 'services/api';
import { addRole } from 'services/api/roles';
// importar estilos
import './admin.css';
import { getAll } from 'services/api/methods';

export default function CreateRole({ getData }) {
  const roleName = useRef(null);
  const roleDescription = useRef(null);

  const [value, toggle] = useToggle();

  const handleSubmit = (e) => {
    e.preventDefault();
    // regular expression to validate the role name, only letters, numbers and spaces
    const regex = /^[a-zA-Z0-9 ]+$/;
    // validate the role name
    if (regex.test(roleName.current.value)) {
      getAllRoles();
    } else {
      CustomAlert('short_msg', {
        icon: 'warning',
        title: 'Ops...',
        text: 'El nombre del rol no es válido',
        confirmButtonColor: '#FFC954',
      });
    }
  };

  const postRole = () => {
    const data = JSON.stringify({
      nombre: roleName.current.value.toUpperCase(),
      descripcion: roleDescription.current.value || 'No se añadió descripción',
      usuarioCreacion: Cookie.get('idUsuario'),
      estado: 1,
    });

    addRole(data)
      .then((res) => {
        console.log(res);
        roleName.current.value = '';
        roleDescription.current.value = '';
        getData();
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getAllRoles = () => {
    getAll(endpoints.roles.getAllRoles)
      .then((res) => {
        let rolesNames = [];
        res.map((role) => {
          rolesNames.push(role.nombre);
        });

        if (rolesNames.includes(roleName.current.value.toUpperCase())) {
          CustomAlert('short_msg', {
            icon: 'warning',
            title: 'Ops...',
            text: 'El nombre del rol ya existe',
            confirmButtonColor: '#FFC954',
          });
        } else {
          CustomAlert('short_msg', {
            icon: 'success',
            title: 'Se ha creado el rol correctamente',
            text: 'Se agregó un nuevo rol',
          });

          postRole();
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <Stack>
      <Typography
        variant="span"
        component="span"
        onClick={() => {
          toggle(!value);
        }}
        sx={{
          color: '#7E8491',
          fontSize: 14,
          textDecoration: 'underline',
          cursor: 'pointer',
          mt: 2,
          mb: 2,
          ml: 2,
          width: 'fit-content',
        }}
      >
        <IoIosArrowForward />
        Agregar nuevo rol
      </Typography>
      {value && (
        <form className="role-container-rol" onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Nombre del rol"
            className="input-create-role"
            ref={roleName}
            required
          />
          <input
            type="text"
            placeholder="Descripción"
            className="input-create-role"
            ref={roleDescription}
          />
          <button type="submit" className="btn-create-role">
            Crear rol
          </button>
        </form>
      )}
    </Stack>
  );
}
