import soundUrlO1 from 'assets/sounds/opcion_1.wav';
import { AppContext } from 'context/AppContext';
import useAxios from 'hooks/useAxios';
import useInteraction from 'hooks/useInteraction';
import React, { useContext, useEffect, useState } from 'react';
import { BiBell, BiMessageRoundedError } from 'react-icons/bi';
import { IoMdInformationCircle } from 'react-icons/io';
import { Link } from 'react-router-dom';
import {
  alertsByUser,
  getAllAlerts,
  getCountAlertIcon,
  markAllAlertsAsRead,
} from 'services/api/alerts';
import {
  getAllNotifications,
  getCountNotificationsIcon,
  markAllAsRead,
} from 'services/api/notifications';

import useLangv2 from 'hooks/useLangv2';
import { refresh } from 'hooks/useRedirect';
import { DateTime } from 'luxon';
import 'styles/alertIcon.css';

export default function AlertIcon() {
  const ALERT_TIME_MS = process.env.REACT_APP_ALERT_TIME_MS;
  //SOUND ALERTS
  const hasInteracted = useInteraction();
  let audio = new Audio(soundUrlO1);
  const { COOKIE_USER } = useAxios();

  const { formatterText } = useLangv2();

  const { setSelectNotificacion, selectNotificacion } = useContext(AppContext);
  const [showNotification, setShowNotification] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);
  const [notificacionesValue, setNotificacionesValue] = useState('');
  const [alertasValue, setAlertasValue] = useState('');
  const [notificacionesList, setNotificacionesList] = useState([]);
  const [alert, setAlert] = useState([{}]);

  const getDataByType = (typeUser, id) => {
    getCountNotificationsIcon().then((data) => {
      setNotificacionesValue(data);
    });
    getCountAlertIcon().then((data) => {
      setAlertasValue(data);
    });
  };

  const DeterminateTypeUser = () => {
    let idEmpleado = JSON.parse(localStorage.getItem('userData'))?.idEmpleado?.idEmpleado || '';
    let idAsesorCliente =
      JSON.parse(localStorage.getItem('userData'))?.idAsesorCliente?.idAsesor || '';
    if (idEmpleado !== '') {
      idEmpleado = parseInt(idEmpleado);
    }
    if (idAsesorCliente !== '') {
      idAsesorCliente = parseInt(idAsesorCliente);
    }
    //Determinate with a hash if the user is an employee or a client advisor
    if (idEmpleado !== '' && idAsesorCliente === '') {
      getDataByType(true, idEmpleado);
    }
    if (idEmpleado === '' && idAsesorCliente !== '') {
      getDataByType(false, idAsesorCliente);
    }
  };

  const searchNotificationsCallback = (cb) => {
    const timeout = setTimeout(() => {
      getAllNotifications().then((res) => {
        let sound = notificacionesList.length !== res.length;
        if (res.length > 0 && sound) {
          audio.play();
        }
      });
      cb();
      DeterminateTypeUser();
      getAlert();
    }, ALERT_TIME_MS);
    let locationLogin = new URL(window.location.href).hash.includes('login');
    if (locationLogin) {
      clearTimeout(timeout);
    }
  };

  const searchNotifications = () => {
    const timeout = setTimeout(() => {
      getAllAlerts({ idUser: COOKIE_USER, currentPage: 0, registersPerPage: 25 }).then((res) => {
        let sound = notificacionesList.length !== res.length;

        // Ordena el arreglo de forma ascendente
        const arregloOrdenado = _.orderBy(res, 'fechaNotificacionPais');
        // Toma los 10 primeros elementos del arreglo ordenado
        setAlert(arregloOrdenado);
        // setNotificacionesList(res);
        //comprove if notificacionesList is !== to res.response

        // setAlertasValue(res.length);
        if (res.length > 0 && sound) {
          audio.play();
        }
      });
      searchNotificationsCallback(searchNotifications);
      DeterminateTypeUser();
      getAlert();
    }, ALERT_TIME_MS);

    let locationLogin = new URL(window.location.href).hash.includes('login');
    if (locationLogin) {
      clearTimeout(timeout);
    }
  };

  const setNotification = () => {
    getAllNotifications().then((res) => {
      const sound = res.length;
      const data = res.map((item) => ({
        ticket: item.idServicio.ticket,
        tiempoTranscurrido: tiempoTranscurridoMin(item.fechaHoraNotificacion),
        fecha: item.fechaHoraNotificacion,
        hora: item.fechaHoraNotificacion,
        idServicio: item.idServicio.idServicio,
        status: item.idTipoNotificacion.tipo,
        ciudad: item.nombreCiudadServicio,
        nombreTecnico: item.nombreTecnico,
      }));
      const sortData = _.sortBy(data, 'tiempoTranscurrido');
      setNotificacionesList(sortData);

      if (notificacionesValue > 0 && sound) {
        audio.play();
      }
      searchNotificationsCallback(searchNotifications);
      getAlert();
      DeterminateTypeUser();
    });
  };

  useEffect(() => {
    if (!hasInteracted) {
      return;
    }

    setNotification();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasInteracted]);

  const tiempoTranscurridoMin = (fechaItem) => {
    const now = DateTime.now().setZone(process.env.REACT_APP_GTM);
    const inicial = DateTime.fromISO(fechaItem.split('+')[0]);
    const diferencia = now.diff(inicial);

    // Formatear la diferencia de tiempo en HH:MM:SS
    const tiempoFormateado = diferencia.toFormat('hh:mm:ss');

    return tiempoFormateado;
  };

  const getAlert = () => {
    alertsByUser({
      idUser: COOKIE_USER,
      currentPage: 0,
      registersPerPage: 10,
    })
      .then((res) => {
        const result = res.map((elem) => ({
          cliente: elem.nombreCliente,
          ciudad: elem.nombreCiudadServicio,
          status: elem.idTipoNotificacion.tipo,
          ticket: elem.idServicio.ticket,
          idServicio: elem.idServicio.idServicio,
          fecha: elem.fechaHoraNotificacion,
          tiempoTranscurrido: `${tiempoTranscurridoMin(elem.fechaHoraNotificacion)}`,
        }));

        setAlert(_.sortBy(result, 'tiempoTranscurrido'));
      })
      .catch((err) => console.log(err));
  };

  const clearAlerts = () => {
    markAllAlertsAsRead();
    setShowAlerts(false);
    setAlertasValue(0);
    setAlert([]);
  };

  const clearAlertsNotification = () => {
    markAllAsRead();
    setShowNotification(false);
    setNotificacionesValue(0);
    setNotificacionesList([]);
  };

  const handleClickNotification = (notificacion) => {
    localStorage.setItem('idService', notificacion.idServicio);
    setSelectNotificacion(notificacion);
    // refresh(paths.searchPrincialTechnical.replace(':id', notificacion.idServicio));
    refresh(`/servicios/editar/${notificacion.idServicio}`);
  };

  const textNotficaciones = (notificacion) => {
    let card = '';
    switch (notificacion.status.toLowerCase()) {
      case 'marcado en sitio':
        card = (
          <>
            <p className="alert-icon-description">
              {formatterText('notification.technician', 'El técnico')} {notificacion.nombreTecnico}{' '}
              {formatterText(
                'notification.on.site.for.service',
                'se marcó en sitio para el servicio #',
              )}{' '}
              {notificacion.ticket} ({notificacion.fecha} {notificacion.hora})
            </p>
            <p className="alert-icon-time">
              {formatterText('notification.elapsed.time', 'Tiempo transcurrido')}:{' '}
              {notificacion.tiempoTranscurrido} {formatterText('notification.hours', 'hrs')}
            </p>
          </>
        );
        break;

      case 'ingreso de nuevo servicio':
        card = (
          <>
            <p className="alert-icon-description">
              {formatterText(
                'notification.new.service.created',
                'Se ha creado un nuevo servicio #',
              )}{' '}
              {notificacion.ticket}{' '}
              {formatterText('notification.in.the.city.of', 'en la ciudad de')}{' '}
              {notificacion.ciudad}
            </p>
            <p className="alert-icon-time">
              {formatterText('notification.elapsed.time', 'Tiempo transcurrido')}:{' '}
              {notificacion.tiempoTranscurrido} {formatterText('notification.hours', 'hrs')}
            </p>
          </>
        );
        break;

      default:
        card = (
          <>
            <p className="alert-icon-description">
              {formatterText('notification.service.with.ticket.number')} {notificacion.ticket}
            </p>
            <p className="alert-icon-time">
              {formatterText('notification.elapsed.time', 'Tiempo transcurrido')}:{' '}
              {notificacion.tiempoTranscurrido} {formatterText('notification.hours', 'hrs')}
            </p>
          </>
        );
        break;
    }
    return card;
  };

  return (
    <>
      <section
        className="alert-icon-container"
        onClick={() => {
          setShowAlerts(!showAlerts);
          setShowNotification(false);
        }}
      >
        <BiMessageRoundedError size={30} color={'#58585B'} cursor="pointer" />
        <p className={alertasValue > 0 ? 'icon-bubble' : 'icon-bubble-disable'}>
          {alertasValue || 0}
        </p>
      </section>
      <section
        className="alert-icon-container"
        onClick={() => {
          setShowNotification(!showNotification);
          setShowAlerts(false);
        }}
      >
        <BiBell size={30} color={'#58585B'} cursor="pointer" />
        <p className={notificacionesValue > 0 ? 'icon-bubble' : 'icon-bubble-disable'}>
          {notificacionesValue}
        </p>
      </section>
      {showAlerts && alertasValue > 0 && (
        <section className="alert-icon">
          <section className="alert-icon-container-header">
            <Link
              to="/panel-notificaciones"
              onClick={() => {
                localStorage.setItem('indexNotification', 1);
                setShowAlerts(false);
              }}
            >
              <p className="message-to-read">
                {formatterText('p.view.all.alerts', 'Ver todas las alertas')} {alertasValue}
              </p>
            </Link>
            <Link
              to="/panel-notificaciones"
              onClick={() => {
                clearAlerts();
              }}
            >
              <p className="message-to-read">
                {formatterText('p.mark.as.read.alerts', 'Marcar todas como leídas')}
              </p>
            </Link>
          </section>
          <section className="alert-icon-container-body">
            {alert.map((alerta, index) => (
              <section className="alert-icon-container-message" key={`${index + 1}`}>
                <IoMdInformationCircle size={25} color={'#58585B'} />
                <section className="alert-icon-container-info">
                  <p
                    className="alert-icon-description"
                    style={{
                      textAlign: 'left',
                    }}
                    onClick={() => {
                      refresh(`/servicios/editar/${alerta.idServicio}`);
                      setShowAlerts(false);
                    }}
                  >
                    {formatterText('notification.service', 'El servicio')} {alerta.ticket}{' '}
                    {formatterText('notification.of.the.client', 'del cliente')} {alerta.cliente}{' '}
                    {formatterText('notification.of')} {alerta.ciudad}{' '}
                    {formatterText('notification.marked.as', 'se marcó como')} {alerta.status}
                  </p>
                </section>
              </section>
            ))}
          </section>
        </section>
      )}
      {showNotification && notificacionesValue > 0 && (
        <section className="alert-icon">
          <section className="alert-icon-container-header">
            <Link
              to="/panel-notificaciones"
              onClick={() => {
                localStorage.setItem('indexNotification', 1);
                setShowNotification(false);
              }}
            >
              <p className="message-to-read">
                {formatterText(
                  'notification.view.all.notifications',
                  'Ver todas las notificaciones',
                )}
                {notificacionesValue}
              </p>
            </Link>
            <p className="message-to-read" onClick={clearAlertsNotification}>
              {formatterText('notification.mark.all.as.read', 'Marcar todas como leídas')}
            </p>
          </section>
          <section className="alert-icon-container-body">
            {notificacionesList.map((notificacion, index) => (
              <a
                key={index}
                onClick={() => {
                  handleClickNotification(notificacion);
                  setShowNotification(false);
                }}
              >
                <section className="alert-icon-container-message">
                  <IoMdInformationCircle size={25} color={'#58585B'} />
                  <section className="alert-icon-container-info">
                    {textNotficaciones(notificacion)}
                  </section>
                </section>
              </a>
            ))}
          </section>
        </section>
      )}
    </>
  );
}
