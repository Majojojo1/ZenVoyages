let regexPattern = /\s+/g;

const removeExtraSpaces = (word) => word.replace(regexPattern, " ");

export default removeExtraSpaces;
