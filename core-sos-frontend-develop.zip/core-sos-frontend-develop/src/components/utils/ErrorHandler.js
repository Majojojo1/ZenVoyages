import ERROR from './ErrorsList';
/**
 * Manage of the requests
 *
 * @param {object} error the structure of the error object
 * @param {function} customSB the function to show a custom snackbar
 * @returns {string} code of the error
 */
const ErrorHandler = (error, customSB) => {
  try {
    if (error.response.status) {
      const ERROR_MESSAGE =
        ERROR[error.response.status] ||
        '???: Error desconocido, notificar al administrador;;snackbar.error.unknown.exception';

      const SPLIT = ERROR_MESSAGE.split(';');

      customSB('error', SPLIT[1], SPLIT[0]);

      return error.response.status;
    } else if (error.message) {
      const ERROR_MESSAGE =
        error.response.status === 0
          ? error.message
          : ERROR[error.response.status] ||
            '???: Error desconocido, notificar al administrador;;snackbar.error.unknown.exception';

      if (error.response.status !== 0) {
        const SPLIT = ERROR_MESSAGE.split(';');
        customSB('error', SPLIT[1], SPLIT[0]);
      }

      return error.message;
    }
  } catch (error) {
    console.error('Error in ErrorHandler', error);
    throw new Error(error?.message ?? 'Error in ErrorHandler');
  }
};

export default ErrorHandler;
