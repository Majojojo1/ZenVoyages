export const ALERT = {
    update: "alert.update",
    requiredFields: "alert.error.requiredFields",
    fileNotValidMediaPngJpgTiffMp4: "alert.error.fileNotValidMediaPngJpgTiffMp4",
    fileNotValidMediaPdfPngJpgTiff: "alert.error.fileNotValidMediaDdfPngJpgTiff",
    fileLarge: "alert.error.fileLarge",
    selectShippingOption: "alert.message.selectShippingOption",
    whileDeletingResponse: "alert.error.whileDeletingResponse",
    
}