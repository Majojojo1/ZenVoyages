export const BROWSER_MEDIA = {
    browserNotSupportVideoPlayback: "browserMedia.error.browserNotSupportVideoPlayback",
}