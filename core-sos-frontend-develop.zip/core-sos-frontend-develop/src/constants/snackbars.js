export const SNACKBAR = {
    download:"snackbar.download",
    reportDeleteError: "snackbar.report.reportDeleteError",
}