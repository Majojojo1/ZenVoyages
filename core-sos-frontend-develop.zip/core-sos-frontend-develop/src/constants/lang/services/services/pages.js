export const PAGES = {
    Paises: "titles.page.name.dinamic.table.paises",
    Departamentos: "titles.page.name.dinamic.table.departamentos",
    Municipalidades: "titles.page.name.dinamic.table.municipalidades",
    Sectores: "titles.page.name.dinamic.table.sectores",
    Auditorías: "titles.page.name.dinamic.table.auditorias",
  };
  

