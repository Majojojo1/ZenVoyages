export const REPORTS={
    title: "service.services.editService.reports",
    generateReport: "service.services.editService.reports.generateReport",
    reportType: "service.services.editService.reports.reportType",
    publicReport: "service.services.editService.reports.publicReport",
}