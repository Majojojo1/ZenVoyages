export const NQR_CONST={
    NQRCategory: "service.services.editService.nqr.NQRCategory",
    advisorManagement: "service.services.editService.nqr.advisorManagement",
    NQRStatus: "service.services.editService.nqr.NQRStatus",
    NQRType: "service.services.editService.nqr.NQRType",
}